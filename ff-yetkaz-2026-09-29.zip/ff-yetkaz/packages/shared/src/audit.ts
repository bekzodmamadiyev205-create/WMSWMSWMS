/**
 * Типы аудита. Таблица `audit_events` — append-only: каждый переход статуса и
 * каждая финансовая операция пишутся сюда с «было / стало».
 */
export const AUDIT_ACTIONS = [
  'LOGIN_SUCCESS',
  'LOGIN_FAILED',
  'CREATE',
  'UPDATE',
  'DELETE',
  'STATE_TRANSITION',
  'INVALID_STATE_TRANSITION',
  'FINANCIAL_POSTING',
  /** Правка конфигурации: кто и когда сдвинул порог или адрес интеграции. */
  'CONFIG_UPDATED',
] as const;

export type AuditAction = (typeof AUDIT_ACTIONS)[number];

export interface AuditEventRecord {
  id: string;
  occurredAt: string;
  actorUserId: string | null;
  actorRole: string | null;
  entityType: string;
  entityId: string | null;
  action: AuditAction;
  before: Record<string, unknown> | null;
  after: Record<string, unknown> | null;
  correlationId: string | null;
  ip: string | null;
}
