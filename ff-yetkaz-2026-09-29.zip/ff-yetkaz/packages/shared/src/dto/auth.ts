import type { Role } from '../roles';

export interface LoginRequest {
  email: string;
  password: string;
}

/**
 * Кто выполняет запрос. Ровно то, что лежит в токене — без похода в БД
 * на каждый запрос и без лишнего PII.
 */
export interface AuthPrincipal {
  id: string;
  email: string;
  roles: Role[];
  /** Заполнен только у роли SELLER — область видимости данных. */
  sellerId: string | null;
}

/** Профиль для UI: principal + отображаемое имя. */
export interface AuthUser extends AuthPrincipal {
  fullName: string;
}

export interface LoginResponse {
  accessToken: string;
  /** ISO-время истечения токена. */
  expiresAt: string;
  user: AuthUser;
}

/** Полезная нагрузка access-JWT. Без PII сверх email. */
export interface JwtClaims {
  sub: string;
  email: string;
  roles: Role[];
  sellerId: string | null;
  iat: number;
  exp: number;
}
