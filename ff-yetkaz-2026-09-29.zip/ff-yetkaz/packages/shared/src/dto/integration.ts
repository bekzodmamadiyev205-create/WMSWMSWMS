import type { ShipmentStatus } from '../states/shipment';

export const OUTBOX_STATUSES = ['PENDING', 'IN_PROGRESS', 'DELIVERED', 'FAILED'] as const;
export type OutboxStatus = (typeof OUTBOX_STATUSES)[number];

export const WEBHOOK_RESULTS = ['ACCEPTED', 'DUPLICATE', 'REJECTED'] as const;
export type WebhookResult = (typeof WEBHOOK_RESULTS)[number];

/** Темы исходящих сообщений перевозчику. */
export const OUTBOX_TOPICS = { SHIPMENT_READY: 'shipment.ready' } as const;
export type OutboxTopic = (typeof OUTBOX_TOPICS)[keyof typeof OUTBOX_TOPICS];

/** Тело, которое FF отправляет перевозчику при передаче отправления. */
export interface CarrierHandoffPayload {
  shipmentNo: string;
  orderExternalId: string;
  sellerCode: string;
  warehouseCode: string;
  recipientName: string;
  recipientPhone: string;
  address: string;
  region: string | null;
  weightG: number;
  lengthMm: number | null;
  widthMm: number | null;
  heightMm: number | null;
  /** Строкой: деньги через float недопустимы. */
  codAmount: string | null;
  currency: string | null;
  items: Array<{ skuCode: string; name: string; quantity: number }>;
}

/**
 * Тело входящего вебхука от перевозчика.
 *
 * Статусы перечислены в терминах FF: перевозчик приводит свои коды к нашим на
 * своей стороне. Так таблица переходов остаётся единственным арбитром.
 */
export interface CarrierWebhookPayload {
  shipmentNo: string;
  status: ShipmentStatus;
  /** ISO-время события у перевозчика. */
  occurredAt: string;
  trackingNo?: string | null;
  reason?: string | null;
  pod?: {
    recipientName?: string | null;
    signatureUrl?: string | null;
    photoUrl?: string | null;
  } | null;
  cod?: {
    collectedAmount: string;
    collectedAt: string;
  } | null;
}

export interface OutboxMessageDto {
  id: string;
  carrierCode: string;
  topic: string;
  entityType: string;
  entityId: string;
  status: OutboxStatus;
  attempts: number;
  nextAttemptAt: string;
  lastError: string | null;
  deliveredAt: string | null;
  createdAt: string;
}

export interface OutboxDispatchResultDto {
  claimed: number;
  delivered: number;
  retried: number;
  failed: number;
}

export interface ShipmentStatusEventDto {
  id: string;
  shipmentId: string;
  fromStatus: ShipmentStatus | null;
  toStatus: ShipmentStatus;
  occurredAt: string;
  recordedAt: string;
  source: 'FF' | 'CARRIER';
  comment: string | null;
}

export interface WebhookAckDto {
  result: WebhookResult;
  shipmentNo: string | null;
  /** Статус отправления после применения — или текущий, если ничего не менялось. */
  status: ShipmentStatus | null;
}
