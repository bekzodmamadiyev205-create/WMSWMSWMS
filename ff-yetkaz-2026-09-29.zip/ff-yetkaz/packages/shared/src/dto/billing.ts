export const CHARGE_KINDS = [
  'INBOUND',
  'STORAGE',
  'PICKING',
  'PACKING',
  'DELIVERY',
  'COD_FEE',
  'SURCHARGE',
] as const;
export type ChargeKind = (typeof CHARGE_KINDS)[number];

/**
 * За что считается цена. `PER_M3_DAY` — кубометр-сутки хранения: остаток
 * величина мгновенная, поэтому он считается по ежедневным срезам.
 */
export const TARIFF_UNITS = [
  'PER_ORDER',
  'PER_UNIT',
  'PER_KG',
  'PER_M3_DAY',
  'PERCENT_OF_COD',
  'FLAT',
  /**
   * Коробочная и паллетная тарификация. Количество коробок/паллет не хранится
   * как факт — оно СЧИТАЕТСЯ из `skus.units_per_box` / `units_per_pallet`:
   * склад считает штуки, а не тару, и требовать от кладовщика вводить ещё и
   * число коробок значит гарантированно получить расхождение.
   */
  'PER_BOX',
  'PER_PALLET',
  /** Хранение: тара × сутки. Отдельно от разовых `PER_BOX`/`PER_PALLET` —
   *  «1000 за паллету» и «1000 за паллету в сутки» это разные деньги. */
  'PER_BOX_DAY',
  'PER_PALLET_DAY',
] as const;
export type TariffUnit = (typeof TARIFF_UNITS)[number];

/**
 * Составляющая цены. До сих пор у услуги в плане была РОВНО одна единица —
 * ограничение существовало, чтобы цена не зависела от порядка строк в выдаче.
 * Комбинированные тарифы («паллета + перевес по кг») это ограничение снимают,
 * но не возвращают неоднозначность: каждая составляющая названа, считается
 * ровно один раз и попадает в счёт отдельной строкой.
 */
export const TARIFF_COMPONENTS = ['BASE', 'WEIGHT', 'VOLUME', 'HANDLING', 'SURCHARGE'] as const;
export type TariffComponent = (typeof TARIFF_COMPONENTS)[number] | string;

/** Составляющая по умолчанию — та, что была единственной до комбинаций. */
export const DEFAULT_TARIFF_COMPONENT = 'BASE';

export const INVOICE_STATUSES = ['DRAFT', 'ISSUED', 'PAID', 'CANCELLED'] as const;
export type InvoiceStatus = (typeof INVOICE_STATUSES)[number];

export const LEDGER_SIDES = ['DEBIT', 'CREDIT'] as const;
export type LedgerSide = (typeof LEDGER_SIDES)[number];

/**
 * Какая единица тарификации осмысленна для какого вида услуги. Ограничение
 * смысловое: «хранение за заказ» — это ошибка ввода, а не тариф, и поймать её
 * дешевле в форме, чем в счёте.
 */
export const ALLOWED_UNITS: Record<ChargeKind, readonly TariffUnit[]> = {
  INBOUND: ['PER_UNIT', 'FLAT', 'PER_BOX', 'PER_PALLET', 'PER_KG'],
  STORAGE: ['PER_M3_DAY', 'PER_BOX_DAY', 'PER_PALLET_DAY'],
  PICKING: ['PER_UNIT', 'PER_ORDER', 'PER_BOX'],
  PACKING: ['PER_ORDER', 'PER_KG', 'PER_UNIT', 'PER_BOX'],
  DELIVERY: ['PER_ORDER', 'PER_KG', 'PER_BOX', 'PER_PALLET'],
  COD_FEE: ['PERCENT_OF_COD'],
  SURCHARGE: ['FLAT', 'PER_ORDER', 'PER_KG', 'PER_UNIT', 'PER_BOX', 'PER_PALLET'],
};

export interface TariffRuleDto {
  id: string;
  planId: string;
  kind: ChargeKind;
  unit: TariffUnit;
  /**
   * Составляющая цены. Внутри одной услуги единица уникальна для СВОЕЙ
   * составляющей — так «паллета + кг» считаются оба, а «за заказ» и «за кг»
   * в одной составляющей по-прежнему конфликт.
   */
  component: string;
  /** Строкой: деньги через float недопустимы. */
  price: string;
  minQty: string;
  effectiveFrom: string;
  effectiveTo: string | null;
}

export interface TariffPlanDto {
  id: string;
  code: string;
  name: string;
  currency: string;
  isDefault: boolean;
  isActive: boolean;
  rules: TariffRuleDto[];
}

export interface ChargeDto {
  id: string;
  sellerId: string;
  kind: ChargeKind;
  unit: TariffUnit;
  quantity: string;
  unitPrice: string;
  amount: string;
  currency: string;
  occurredAt: string;
  orderId: string | null;
  shipmentId: string | null;
  sourceKey: string;
  invoiceId: string | null;
}

export interface BillingProblemDto {
  id: string;
  sellerId: string | null;
  kind: ChargeKind;
  sourceKey: string;
  reason: string;
  occurredAt: string;
  resolvedAt: string | null;
}

export interface AccrualResultDto {
  periodStart: string;
  periodEnd: string;
  created: number;
  skippedExisting: number;
  problems: number;
  byKind: Record<string, number>;
}

export interface InvoiceLineDto {
  id: string;
  kind: ChargeKind;
  description: string;
  quantity: string;
  unit: TariffUnit;
  unitPrice: string;
  amount: string;
}

export interface InvoiceDto {
  id: string;
  number: string;
  sellerId: string;
  sellerName: string;
  periodStart: string;
  periodEnd: string;
  currency: string;
  /** Сумма услуг фулфилмента за период. */
  servicesTotal: string;
  /** Наложенный платёж, собранный с покупателей в пользу селлера. */
  codCollectedTotal: string;
  /** К перечислению селлеру: собранный COD минус услуги. */
  payoutTotal: string;
  status: InvoiceStatus;
  issuedAt: string | null;
  lines: InvoiceLineDto[];
}

/** Сверка наложенного платежа: что обещали собрать против того, что собрали. */
export interface CodReconciliationRowDto {
  shipmentId: string;
  shipmentNo: string;
  orderExternalId: string;
  sellerId: string;
  expected: string;
  collected: string | null;
  difference: string;
  currency: string;
  deliveredAt: string | null;
  status: 'MATCHED' | 'SHORT' | 'OVER' | 'MISSING';
}

export interface CodReconciliationDto {
  periodStart: string;
  periodEnd: string;
  totalExpected: string;
  totalCollected: string;
  rows: CodReconciliationRowDto[];
}

export interface LedgerBalanceRowDto {
  accountCode: string;
  accountName: string;
  currency: string;
  debit: string;
  credit: string;
  balance: string;
}
