import type { OrderStatus } from '../states/order';
import type { DateRangeQuery, SortDirection } from './common';

export interface OrderLineDto {
  id: string;
  skuId: string;
  /** Артикул и название приезжают вместе со строкой: список заказов без них
   *  показывал бы оператору идентификаторы вместо товара. */
  skuCode: string;
  skuName: string;
  quantity: number;
}

export interface OrderDto {
  id: string;
  sellerId: string;
  /** Внешний канал: маркетплейс, сайт селлера, ручной ввод. */
  channel: string;
  /** Номер заказа У КЛИЕНТА (из канала). FF его не генерирует. */
  externalId: string;
  /** Наш код-штрихкод заказа: FF-YES0000001… Присваивает система при создании. */
  orderCode: string;
  status: OrderStatus;
  /** Склад исполнения. Пусто у разделённого заказа-контейнера и пока идёт резерв. */
  warehouseId: string | null;
  parentOrderId: string | null;
  /** Заказ разделён между складами; исполняют дочерние заказы. */
  isSplit: boolean;
  /** Часть позиций не обеспечена остатком нигде — заказ ждёт поставки. */
  hasShortage: boolean;
  recipientName: string;
  recipientPhone: string;
  address: string;
  region: string | null;
  /** Строка, а не number: деньги через float — недопустимо. */
  codAmount: string | null;
  currency: string | null;
  /** Заявленный вес отправления в кг, строкой (как деньги — без float). */
  weightKg: string | null;
  /** Категория заказа (справочник `order_categories`). Может быть не задана. */
  categoryId: string | null;
  /** Денормализованы В ОТВЕТ, а не в таблицу: список заказов иначе тянул бы
   *  справочник на клиент ради двух слов в строке. */
  categoryCode: string | null;
  categoryName: string | null;
  categoryColor: string | null;
  /** Когда коробка выдана со склада («Расходный»). ISO-8601 либо null. */
  dispatchedAt: string | null;
  lines: OrderLineDto[];
  /** Дочерние заказы при разделении между складами. */
  children: OrderDto[];
  /** ISO-8601. Список заказов без времени создания читать невозможно. */
  createdAt: string;
}

/**
 * Одна запись трека статусов. Отдельная таблица, а не выборка из `audit_events`:
 * аудит хранит ВСЁ и по нему нельзя ни отсортировать заказы по времени сборки,
 * ни построить воронку — там jsonb и разнородные действия. Здесь узкая
 * проекция ровно под трек и аналитику.
 */
export interface OrderStatusEventDto {
  id: string;
  orderId: string;
  /** null у самой первой записи: у создания заказа нет «откуда». */
  fromStatus: OrderStatus | null;
  toStatus: OrderStatus;
  /** Кто перевёл: пользователь, вебхук перевозчика или планировщик. */
  source: string;
  actorUserId: string | null;
  actorName: string | null;
  comment: string | null;
  occurredAt: string;
}

/** Полный трек заказа: события + сколько времени заняла каждая стадия. */
export interface OrderTrackDto {
  orderId: string;
  events: OrderStatusEventDto[];
}

/** Что не удалось обеспечить остатком при резерве. */
export interface OrderShortageDto {
  skuId: string;
  requested: number;
  available: number;
}

export interface OrderIntakeResultDto {
  order: OrderDto;
  /** Заказ уже существовал: повторная выгрузка канала не создала дубль. */
  duplicate: boolean;
  shortages: OrderShortageDto[];
}

// ------------------------------------------------------------ загрузка файлом

/**
 * Позиция заказа из файла. Здесь АРТИКУЛ, а не `skuId`: в выгрузке селлера
 * внутренних идентификаторов FF нет и быть не может. Сопоставление делает
 * сервер — клиент не должен для этого выкачивать весь каталог.
 */
export interface OrderImportLineDto {
  skuCode: string;
  quantity: number;
}

export interface OrderImportOrderDto {
  /** Номер строки ФАЙЛА, с которой начался заказ: отчёт указывает на то, что
   *  оператор видит в Excel, а не на позицию в отправленном массиве. */
  fileLine: number;
  externalId: string;
  recipientName: string;
  recipientPhone: string;
  address: string;
  region?: string | null;
  /** Строкой: деньги через float недопустимы. */
  codAmount?: string | null;
  currency?: string | null;
  /** Вес заказа в кг, строкой. */
  weightKg?: string | null;
  lines: OrderImportLineDto[];
}

export const ORDER_IMPORT_OUTCOMES = ['CREATED', 'DUPLICATE', 'FAILED'] as const;
export type OrderImportOutcome = (typeof ORDER_IMPORT_OUTCOMES)[number];

export interface OrderImportResultRowDto {
  row: number;
  externalId: string;
  outcome: OrderImportOutcome;
  orderId: string | null;
  status: OrderStatus | null;
  /** Заказ принят, но остатка не хватило — он ждёт поставки, а не потерян. */
  hasShortage: boolean;
  message: string | null;
}

export interface OrderImportResultDto {
  created: number;
  /** Заказ уже был в системе: повторная выгрузка не создала дубль. */
  duplicates: number;
  failed: number;
  rows: OrderImportResultRowDto[];
}

// ------------------------------------------------------- список с фильтрами

/** По каким колонкам список заказов разрешено сортировать на сервере. */
export const ORDER_SORT_FIELDS = [
  'createdAt',
  'orderCode',
  'externalId',
  'status',
  'recipientName',
  'codAmount',
  'weightKg',
  'dispatchedAt',
] as const;
export type OrderSortField = (typeof ORDER_SORT_FIELDS)[number];

/**
 * Запрос списка заказов. Фильтры серверные: раньше поиск и период считались
 * на клиенте поверх первых 100 строк — то есть просто врали, как только заказов
 * стало больше.
 */
export interface OrderListQuery extends DateRangeQuery {
  sellerId?: string;
  status?: OrderStatus;
  /** Несколько статусов через запятую — канбан просит сразу пачку. */
  statuses?: string;
  categoryId?: string;
  warehouseId?: string;
  channel?: string;
  /** Номер FF, номер клиента, получатель или телефон — одним полем. */
  search?: string;
  /** Показывать ли контейнеры разделённых заказов. По умолчанию нет. */
  includeSplitChildren?: boolean;
  page?: number;
  pageSize?: number;
  sort?: OrderSortField;
  direction?: SortDirection;
}

/** Итоги по текущему фильтру — считает SQL, а не клиент по странице. */
export interface OrderListTotalsDto {
  total: number;
  byStatus: Array<{ status: OrderStatus; count: number }>;
}

export interface UpdateOrderPayload {
  categoryId?: string | null;
  region?: string | null;
  recipientName?: string;
  recipientPhone?: string;
  address?: string;
  weightKg?: string | null;
}
