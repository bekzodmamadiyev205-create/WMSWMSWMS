import type { ReturnItemCondition, ReturnReason, ReturnStatus } from '../states/returns';
import type { DateRangeQuery, SortDirection } from './common';

export interface ReturnItemDto {
  id: string;
  skuId: string;
  skuCode: string;
  skuName: string;
  /** Сколько единиц принято физически. */
  quantity: number;
  condition: ReturnItemCondition;
  /**
   * Сколько из принятого уже вернулось в доступный остаток. Отдельно от
   * `quantity`, потому что брак на полку не возвращается, а раскладка может
   * быть частичной — «принято 10, годных 7» обязано быть видно.
   */
  restockedQuantity: number;
  binCode: string | null;
}

export interface ReturnStatusEventDto {
  id: string;
  fromStatus: ReturnStatus | null;
  toStatus: ReturnStatus;
  actorUserId: string | null;
  actorName: string | null;
  comment: string | null;
  occurredAt: string;
}

export interface ReturnDto {
  id: string;
  /** Номер возврата, выдаёт последовательность БД: `RMA000000001`. */
  returnNo: string;
  status: ReturnStatus;
  sellerId: string;
  sellerName: string | null;
  warehouseId: string;
  warehouseCode: string | null;
  /** Заказ, по которому вернулся товар. Возврат без заказа допустим. */
  orderId: string | null;
  orderCode: string | null;
  orderExternalId: string | null;
  reason: ReturnReason;
  comment: string | null;
  items: ReturnItemDto[];
  /** Суммарно принято и суммарно возвращено в остаток — считает SQL. */
  totalQuantity: number;
  totalRestocked: number;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
  events?: ReturnStatusEventDto[];
}

export interface CreateReturnItemPayload {
  skuId: string;
  quantity: number;
  condition?: ReturnItemCondition;
}

export interface CreateReturnPayload {
  sellerId: string;
  warehouseId: string;
  orderId?: string | null;
  reason: ReturnReason;
  comment?: string | null;
  items: CreateReturnItemPayload[];
  /**
   * Переводить ли связанный заказ в `RETURNED`. По умолчанию да — иначе
   * заказ навсегда останется «доставлен», хотя товар лежит на складе.
   */
  markOrderReturned?: boolean;
}

export const RETURN_SORT_FIELDS = ['createdAt', 'returnNo', 'status', 'totalQuantity'] as const;
export type ReturnSortField = (typeof RETURN_SORT_FIELDS)[number];

export interface ReturnListQuery extends DateRangeQuery {
  sellerId?: string;
  warehouseId?: string;
  status?: ReturnStatus;
  reason?: ReturnReason;
  /** Номер возврата, номер заказа или артикул. */
  search?: string;
  page?: number;
  pageSize?: number;
  sort?: ReturnSortField;
  direction?: SortDirection;
}

/** Раскладка принятого возврата: что куда положили. */
export interface StoreReturnPayload {
  lines: Array<{
    itemId: string;
    /** Сколько единиц уходит в доступный остаток (остальное — брак). */
    goodQuantity: number;
    damagedQuantity: number;
    /** Ячейка хранения для годного. Пусто — берётся ячейка STORAGE склада. */
    binId?: string | null;
  }>;
  comment?: string | null;
}

export interface MoveReturnPayload {
  /** Куда переезжает коробка целиком. */
  binId: string;
  comment?: string | null;
}
