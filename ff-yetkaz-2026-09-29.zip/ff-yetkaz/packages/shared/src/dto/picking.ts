import type { PickLineStatus, PickTaskKind, PickTaskStatus } from '../states/picking';

export interface PickTaskLineDto {
  id: string;
  taskId: string;
  orderId: string;
  skuId: string;
  skuCode: string;
  skuName: string;
  binId: string;
  /** Код ячейки: строки задания отсортированы по нему — это и есть маршрут. */
  binCode: string;
  lotId: string | null;
  qtyRequested: number;
  qtyPicked: number;
  status: PickLineStatus;
}

export interface PickTaskDto {
  id: string;
  warehouseId: string;
  kind: PickTaskKind;
  status: PickTaskStatus;
  assigneeUserId: string | null;
  orderIds: string[];
  startedAt: string | null;
  completedAt: string | null;
  lines: PickTaskLineDto[];
}

/** Итог скана: что зачлось и сколько осталось по строке. */
export interface PickScanResultDto {
  task: PickTaskDto;
  lineId: string;
  picked: number;
  remaining: number;
}

/** Итог объявления недобора. */
export interface ShortPickResultDto {
  task: PickTaskDto;
  missing: number;
  /** Недостающее нашлось в других ячейках склада — добавлены новые строки. */
  reallocated: boolean;
  /** Не нашлось нигде: заказ помечен нехваткой. */
  orderFlagged: boolean;
}
