/**
 * Общие кирпичи списков: страница, сортировка, период.
 *
 * До этого каждый список отдавал голый массив с `take(limit)` — без общего
 * числа строк и без смещения. Такой ответ невозможно листать: клиент не знает,
 * есть ли что-то дальше, и «Показано 100 из ?» превращается в «Показано 100».
 * Поэтому вводится один конверт на весь проект.
 */
export interface PageDto<T> {
  rows: T[];
  /** Сколько строк удовлетворяет фильтру ЦЕЛИКОМ, а не сколько пришло. */
  total: number;
  /** Нумерация с единицы: так же, как её видит человек в интерфейсе. */
  page: number;
  pageSize: number;
}

export const SORT_DIRECTIONS = ['asc', 'desc'] as const;
export type SortDirection = (typeof SORT_DIRECTIONS)[number];

/** Потолок страницы. Без него `?pageSize=1000000` кладёт и базу, и браузер. */
export const MAX_PAGE_SIZE = 500;
export const DEFAULT_PAGE_SIZE = 50;

/**
 * Границы периода — ISO-даты `YYYY-MM-DD`, ОБЕ включительно.
 *
 * Включительность правого края — решение, а не мелочь: «по 20 августа» в
 * отчёте обязано содержать двадцатое. Сервер сам превращает это в
 * `< dateTo + 1 день`, чтобы не потерять записи, сделанные днём.
 */
export interface DateRangeQuery {
  dateFrom?: string;
  dateTo?: string;
}

/** Формат выгрузки. Пока один, но ручки уже принимают параметр. */
export const EXPORT_FORMATS = ['xlsx'] as const;
export type ExportFormat = (typeof EXPORT_FORMATS)[number];
