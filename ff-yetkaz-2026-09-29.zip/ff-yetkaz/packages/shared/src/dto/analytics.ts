import type { OrderStatus } from '../states/order';
import type { DateRangeQuery } from './common';

/**
 * BI-слой. Все цифры считает SQL и отдаёт готовыми — клиент ничего не
 * агрегирует. Правило не стилистическое: витрина, собранная из первых ста
 * заказов на клиенте, начинает врать ровно на сто первом, и заметить это
 * невозможно — график продолжает рисоваться.
 */

export const ANALYTICS_GRANULARITIES = ['day', 'week', 'month'] as const;
export type AnalyticsGranularity = (typeof ANALYTICS_GRANULARITIES)[number];

export interface AnalyticsQuery extends DateRangeQuery {
  sellerId?: string;
  warehouseId?: string;
  categoryId?: string;
  granularity?: AnalyticsGranularity;
}

/** Одно число с сравнением к предыдущему периоду такой же длины. */
export interface AnalyticsMetricDto {
  key: string;
  /** Строкой: среди метрик есть деньги, а деньги через float недопустимы. */
  value: string;
  previous: string | null;
  /** Процент изменения, строкой с одним знаком. null — не с чем сравнивать. */
  changePct: string | null;
  /** Рост — это хорошо? У возвратов и отмен наоборот. */
  positiveIsGood: boolean;
  /** 'count' | 'money' | 'percent' | 'weight' — как форматировать на клиенте. */
  format: 'count' | 'money' | 'percent' | 'weight';
  currency?: string | null;
}

export interface AnalyticsSeriesPointDto {
  /** Начало интервала, ISO-дата. */
  bucket: string;
  values: Record<string, string>;
}

export interface AnalyticsOverviewDto {
  generatedAt: string;
  dateFrom: string;
  dateTo: string;
  currency: string | null;
  metrics: AnalyticsMetricDto[];
  ordersByStatus: Array<{ status: OrderStatus; count: number }>;
  ordersByCategory: Array<{
    categoryId: string | null;
    name: string;
    color: string | null;
    count: number;
  }>;
  series: AnalyticsSeriesPointDto[];
  /** Ключи внутри `values` серий — чтобы клиент не угадывал. */
  seriesKeys: string[];
}

/** Строка витрины по селлеру — то, за чем и приходят в BI. */
export interface SellerAnalyticsRowDto {
  sellerId: string;
  sellerCode: string;
  sellerName: string;
  orders: number;
  delivered: number;
  cancelled: number;
  returned: number;
  /** Доля возвратов от отгруженных, строкой с одним знаком. */
  returnRatePct: string;
  units: number;
  /** Оборот = начисления FF за период. Строкой. */
  revenue: string;
  /** Наложенный платёж, собранный перевозчиком. Это деньги селлера, не наши. */
  codCollected: string;
  currency: string | null;
  /** Средний чек по заказам с COD. */
  averageOrderValue: string;
  stockUnits: number;
}

export interface SellerAnalyticsDto {
  generatedAt: string;
  dateFrom: string;
  dateTo: string;
  rows: SellerAnalyticsRowDto[];
  totals: Omit<SellerAnalyticsRowDto, 'sellerId' | 'sellerCode' | 'sellerName'>;
}

/**
 * Описание витрин для внешнего BI (Metabase / Superset). Отдаётся ручкой,
 * чтобы аналитик подключился к базе и сразу видел, какие представления
 * поддерживаются, а не читал схему целиком.
 */
export interface BiViewDto {
  name: string;
  title: string;
  description: string;
  columns: Array<{ name: string; type: string; description: string }>;
}
