import type { Role } from '../roles';
import type { StockTableRowDto } from './inventory';
import type { OrderDto } from './orders';
import type { ReturnDto } from './returns';
import type { SellerDto, SkuDto } from './mdm';
import type { UserSummaryDto } from './users';

/**
 * Права на уровне КОЛОНКИ.
 *
 * Роль отвечает на вопрос «куда пускать», а это — на вопрос «что показывать».
 * Разница практическая: сборщику нужен заказ, но не нужен телефон получателя и
 * сумма наложенного платежа; финансисту нужны деньги, но не нужен адрес.
 * Раньше выбор был бинарный — либо весь DTO, либо 403 на всю ручку.
 *
 * Модель намеренно ПЛОСКАЯ (роль × сущность × поле), без наследования и без
 * условий по строкам: строчную изоляцию уже держит `seller_id`, а иерархия
 * прав — это то, что через полгода никто не может объяснить.
 */

/** Сущности, чьи поля можно закрывать. Список закрытый — иначе матрица прав
 *  превращается в свалку из случайных имён. */
export const ACL_ENTITIES = ['order', 'stock', 'return', 'seller', 'sku', 'user'] as const;
export type AclEntity = (typeof ACL_ENTITIES)[number];

/**
 * `satisfies` вместо простого массива строк — так опечатка в имени поля или
 * переименование в DTO ломают сборку, а не тихо создают право на
 * несуществующую колонку.
 */
const ORDER_FIELDS = [
  'sellerId',
  'channel',
  'externalId',
  'orderCode',
  'status',
  'warehouseId',
  'recipientName',
  'recipientPhone',
  'address',
  'region',
  'codAmount',
  'currency',
  'weightKg',
  'categoryId',
  'categoryName',
  'dispatchedAt',
  'hasShortage',
  'lines',
  'createdAt',
] as const satisfies readonly (keyof OrderDto)[];

const RETURN_FIELDS = [
  'returnNo',
  'status',
  'sellerId',
  'sellerName',
  'warehouseId',
  'orderId',
  'orderCode',
  'reason',
  'comment',
  'items',
  'totalQuantity',
  'totalRestocked',
  'createdAt',
  'completedAt',
] as const satisfies readonly (keyof ReturnDto)[];

const SELLER_FIELDS = [
  'code',
  'legalName',
  'taxId',
  'contactEmail',
  'contactPhone',
  'address',
  'isActive',
] as const satisfies readonly (keyof SellerDto)[];

const SKU_FIELDS = [
  'skuCode',
  'name',
  'sellerId',
  'weightG',
  'lengthMm',
  'widthMm',
  'heightMm',
  'isActive',
] as const satisfies readonly (keyof SkuDto)[];

const USER_FIELDS = [
  'email',
  'fullName',
  'isActive',
  'sellerId',
  'departmentId',
  'departmentName',
  'roles',
] as const satisfies readonly (keyof UserSummaryDto)[];

/**
 * Поля витрины остатков — ключи строки ответа, а не колонки SQL.
 *
 * Список тоже привязан к DTO через `satisfies`: раньше он был просто массивом
 * строк, и в нём годами лежало поле `receivedAt`, которого в ответе нет вовсе
 * (реальные ключи — `firstReceivedAt`/`lastReceivedAt`). Администратор снимал
 * галку, а не скрывалось НИЧЕГО — худший вид средства защиты. Теперь такое
 * расхождение ловит сборка.
 *
 * `sellerId` и `sellerCode` перечислены рядом с `sellerName` намеренно: скрыть
 * одно название, оставив код и идентификатор, значит не скрыть селлера.
 */
const STOCK_FIELDS = [
  'skuCode',
  'skuName',
  'sellerId',
  'sellerCode',
  'sellerName',
  'warehouseCode',
  'quantity',
  'available',
  'reserved',
  'damaged',
  'firstReceivedAt',
  'lastReceivedAt',
  'status',
  'bins',
] as const satisfies readonly (keyof StockTableRowDto)[];

export const ACL_FIELDS: Record<AclEntity, readonly string[]> = {
  order: ORDER_FIELDS,
  stock: STOCK_FIELDS,
  return: RETURN_FIELDS,
  seller: SELLER_FIELDS,
  sku: SKU_FIELDS,
  user: USER_FIELDS,
};

/** Человеческие названия сущностей для матрицы прав. */
export const ACL_ENTITY_TITLES: Record<AclEntity, string> = {
  order: 'Заказы',
  stock: 'Остатки',
  return: 'Возвраты',
  seller: 'Селлеры',
  sku: 'Товары',
  user: 'Пользователи',
};

export interface FieldPermissionDto {
  role: Role;
  entity: AclEntity;
  field: string;
  /** Видно ли поле в ответе API. `false` — ключ удаляется целиком, а не
   *  обнуляется: `null` фронт и выгрузка прочитали бы как реальное значение. */
  canView: boolean;
  /** Можно ли прислать это поле на запись. `false` → 403 на попытку. */
  canEdit: boolean;
  /** Можно ли очистить значение / удалить запись по этому полю. */
  canDelete: boolean;
}

/** Матрица целиком — то, что правит администратор одним сохранением. */
export interface FieldPermissionMatrixDto {
  entities: Array<{
    entity: AclEntity;
    title: string;
    fields: string[];
  }>;
  permissions: FieldPermissionDto[];
}

export interface FieldPermissionUpdatePayload {
  permissions: FieldPermissionDto[];
}

/** Что реально можно текущему пользователю: `entity → field → права`. */
export type EffectiveFieldAcl = Record<
  string,
  Record<string, { view: boolean; edit: boolean; delete: boolean }>
>;

export interface EffectiveFieldAclDto {
  /** Роли, из которых сложились права: пригодится в подсказке «почему скрыто». */
  roles: Role[];
  /** У администратора матрица не применяется вовсе — иначе первый же
   *  неаккуратный чек-бокс отрезал бы админа от собственной системы. */
  unrestricted: boolean;
  acl: EffectiveFieldAcl;
}

/**
 * Разрешение конфликта между ролями — СЛОЖЕНИЕ (любая роль, дающая право,
 * побеждает). Обратный вариант (запрет сильнее) выглядит «безопаснее», но
 * означает, что выдача сотруднику дополнительной роли ОТНИМАЕТ у него доступ —
 * поведение, которое невозможно объяснить администратору.
 */
export function mergeFieldAcl(parts: EffectiveFieldAcl[]): EffectiveFieldAcl {
  const merged: EffectiveFieldAcl = {};
  for (const part of parts) {
    for (const [entity, fields] of Object.entries(part)) {
      const target = (merged[entity] ??= {});
      for (const [field, rights] of Object.entries(fields)) {
        const current = target[field];
        target[field] = current
          ? {
              view: current.view || rights.view,
              edit: current.edit || rights.edit,
              delete: current.delete || rights.delete,
            }
          : { ...rights };
      }
    }
  }
  return merged;
}

/** Поле видно, если про него ничего не сказано: умолчание — «открыто». */
export function canViewField(acl: EffectiveFieldAcl, entity: string, field: string): boolean {
  return acl[entity]?.[field]?.view ?? true;
}

export function canEditField(acl: EffectiveFieldAcl, entity: string, field: string): boolean {
  return acl[entity]?.[field]?.edit ?? true;
}
