/**
 * Категория заказа — справочник, а не перечисление в коде.
 *
 * Категории у оператора меняются чаще, чем выходят релизы («маркетплейс»,
 * «розница», «B2B-паллета», «возвратная отправка»), и по ним считается
 * аналитика. Хардкод превратил бы каждое новое направление бизнеса в задачу
 * разработчику, а старые заказы — в записи со статусом «прочее».
 */
export interface OrderCategoryDto {
  id: string;
  /** Машинный код: `MARKETPLACE`, `B2B`. По нему связывают выгрузки. */
  code: string;
  name: string;
  description: string | null;
  /**
   * Цвет метки в интерфейсе — hex `#RRGGBB`. Хранится в справочнике, иначе
   * палитра расползётся по экранам и одна и та же категория будет разной.
   */
  color: string | null;
  /** Порядок в выпадающем списке: алфавит редко совпадает с частотой. */
  sortOrder: number;
  isActive: boolean;
  /** Сколько заказов уже отнесено к категории — считает SQL, не клиент. */
  ordersCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateOrderCategoryPayload {
  code: string;
  name: string;
  description?: string | null;
  color?: string | null;
  sortOrder?: number;
}

export interface UpdateOrderCategoryPayload {
  name?: string;
  description?: string | null;
  color?: string | null;
  sortOrder?: number;
  isActive?: boolean;
}

/** Палитра по умолчанию для новых категорий — чтобы не выбирать цвет вручную. */
export const ORDER_CATEGORY_COLORS = [
  '#6366f1',
  '#0ea5e9',
  '#10b981',
  '#f59e0b',
  '#ef4444',
  '#8b5cf6',
  '#14b8a6',
  '#e11d48',
] as const;
