import type { Role } from '../roles';

/** Пользователь глазами администратора. Хэш пароля наружу не выходит никогда. */
export interface UserSummaryDto {
  id: string;
  email: string;
  fullName: string;
  isActive: boolean;
  /** Заполнен ровно у роли SELLER — инвариант держит триггер в БД. */
  sellerId: string | null;
  /** Отдел сотрудника (организационная привязка). Пусто у селлера и неназначенных. */
  departmentId: string | null;
  departmentName: string | null;
  roles: Role[];
  createdAt: string;
}

/** Минимальная длина пароля. Одно число для API, CLI и подсказки в интерфейсе. */
export const PASSWORD_MIN_LENGTH = 12;

/**
 * Пароли, которые нельзя ставить независимо от длины. Не «чёрный список
 * интернета», а защита от очевидно-слабых: одна и та же учётка открывает
 * данные клиентов, и пароль «1234…»-класса тут недопустим.
 *
 * Возвращает причину отказа или null. Одна функция для сервера, CLI и подсказки
 * во фронте — правила не должны разъезжаться между тремя местами.
 */
export function passwordProblem(raw: string): string | null {
  const pw = raw ?? '';
  if (pw.length < PASSWORD_MIN_LENGTH) {
    return `Пароль не короче ${PASSWORD_MIN_LENGTH} символов.`;
  }
  if (/^(.)\1+$/.test(pw)) {
    return 'Пароль из одного повторяющегося символа недопустим.';
  }
  if (isSequential(pw)) {
    return 'Пароль — простая последовательность (1234…, qwerty…). Так нельзя.';
  }
  const lower = pw.toLowerCase();
  if (COMMON_PASSWORDS.some((bad) => lower === bad || lower.startsWith(bad))) {
    return 'Слишком простой пароль — его подберут за секунды.';
  }
  return null;
}

/** Возрастающая или убывающая цепочка соседних символов по всей длине. */
function isSequential(pw: string): boolean {
  let up = true;
  let down = true;
  for (let i = 1; i < pw.length; i += 1) {
    const delta = pw.charCodeAt(i) - pw.charCodeAt(i - 1);
    if (delta !== 1) up = false;
    if (delta !== -1) down = false;
  }
  return up || down;
}

const COMMON_PASSWORDS = [
  'password',
  'parol',
  'qwerty',
  'admin',
  'yetkaz',
  'fulfillpro',
  '123456789012',
  '111111111111',
  '000000000000',
];
