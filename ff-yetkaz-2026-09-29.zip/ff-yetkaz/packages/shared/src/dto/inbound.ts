import type { AsnStatus, ReceiptLineStatus, ReceiptStatus } from '../states/inbound';

export interface AsnLineDto {
  id: string;
  skuId: string;
  /** Артикул и название — чтобы UI не резолвил справочник по каждой строке. */
  skuCode: string;
  skuName: string;
  expectedQty: number;
  /** Сколько уже принято по этой позиции всеми приёмками ASN. */
  receivedQty: number;
  /**
   * У SKU есть хотя бы один штрихкод. Товар без кода отсканировать нельзя —
   * приёмщик должен узнать об этом до того, как поднесёт коробку к сканеру,
   * а не по отказу.
   */
  hasBarcode: boolean;
}

export interface AsnDto {
  id: string;
  sellerId: string;
  warehouseId: string;
  externalRef: string | null;
  status: AsnStatus;
  expectedAt: string | null;
  /** Факт разошёлся с планом хотя бы по одной позиции. */
  hasDiscrepancy: boolean;
  lines: AsnLineDto[];
}

export interface ReceiptLineDto {
  id: string;
  receiptId: string;
  skuId: string;
  skuCode: string;
  skuName: string;
  lotId: string | null;
  qtyReceived: number;
  qtyOk: number;
  qtyDamaged: number;
  /** Ячейка хранения; пусто, пока позиция не разложена. */
  binId: string | null;
  status: ReceiptLineStatus;
}

export interface ReceiptDto {
  id: string;
  asnId: string;
  warehouseId: string;
  status: ReceiptStatus;
  receivedBy: string | null;
  completedAt: string | null;
  lines: ReceiptLineDto[];
}

/** Итог сверки приёмки с заявкой. */
export interface ReceiptCompletionDto {
  receipt: ReceiptDto;
  asnStatus: AsnStatus;
  hasDiscrepancy: boolean;
  discrepancies: Array<{
    skuId: string;
    expectedQty: number;
    receivedQty: number;
  }>;
}
