/** Назначение ячейки — определяет, что в ней может лежать. */
export const BIN_KINDS = [
  'RECEIVING',
  'STORAGE',
  'PICKING',
  'PACKING',
  'QUARANTINE',
  'DAMAGED',
  'SHIPPING',
] as const;
export type BinKind = (typeof BIN_KINDS)[number];

export const BARCODE_KINDS = ['EAN13', 'EAN8', 'UPC', 'CODE128', 'INTERNAL'] as const;
export type BarcodeKind = (typeof BARCODE_KINDS)[number];

export interface SellerDto {
  id: string;
  code: string;
  legalName: string;
  taxId: string | null;
  contactEmail: string | null;
  contactPhone: string | null;
  address: string | null;
  isActive: boolean;
}

export interface WarehouseDto {
  id: string;
  code: string;
  name: string;
  address: string | null;
  /** IANA-зона: отсечки приёмки и дедлайны SLA считаются по местному времени склада. */
  timezone: string;
  isActive: boolean;
}

export interface BinLocationDto {
  id: string;
  warehouseId: string;
  code: string;
  kind: BinKind;
  isActive: boolean;
}

export interface SkuBarcodeDto {
  id: string;
  skuId: string;
  barcode: string;
  kind: BarcodeKind;
  isPrimary: boolean;
}

/** Строка загрузки каталога: одна позиция из файла клиента. */
export interface SkuImportRowDto {
  skuCode: string;
  name: string;
  barcode?: string | null;
  weightG?: number | null;
  lengthMm?: number | null;
  widthMm?: number | null;
  heightMm?: number | null;
}

export const SKU_IMPORT_OUTCOMES = ['CREATED', 'UPDATED', 'FAILED'] as const;
export type SkuImportOutcome = (typeof SKU_IMPORT_OUTCOMES)[number];

export interface SkuImportResultRowDto {
  /** Номер строки в исходном файле — оператору надо знать, что чинить. */
  row: number;
  skuCode: string;
  outcome: SkuImportOutcome;
  message: string | null;
}

export interface SkuImportResultDto {
  created: number;
  updated: number;
  failed: number;
  rows: SkuImportResultRowDto[];
}

export interface SkuDto {
  id: string;
  sellerId: string;
  skuCode: string;
  name: string;
  /** Габариты в миллиметрах, вес в граммах — целыми, без плавающей точки. */
  lengthMm: number | null;
  widthMm: number | null;
  heightMm: number | null;
  weightG: number | null;
  /** Вычисляется БД из габаритов; null, пока габариты не заполнены. */
  volumeMm3: string | null;
  isLotTracked: boolean;
  isExpiryTracked: boolean;
  shelfLifeDays: number | null;
  isActive: boolean;
  barcodes: SkuBarcodeDto[];
}
