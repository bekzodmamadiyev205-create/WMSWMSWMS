/** Одна плитка сводки: что считаем и сколько получилось. */
export interface MetricDto {
  key: string;
  title: string;
  value: number;
  /** Плитка требует вмешательства оператора, а не просто информирует. */
  attention: boolean;
}

export interface OpsDashboardDto {
  generatedAt: string;
  /** Сколько работы стоит в очереди на каждом переделе. */
  queues: MetricDto[];
  /** Что пошло не так и ждёт человека. */
  problems: MetricDto[];
  /** Что склад сделал за сегодня. */
  today: MetricDto[];
  /** Заказы по статусам — вся воронка одним взглядом. */
  ordersByStatus: Array<{ status: string; count: number }>;
}

export interface SellerStockRowDto {
  skuId: string;
  skuCode: string;
  name: string;
  available: number;
  reserved: number;
  /** Собрано и упаковано, но ещё не отгружено. */
  inProgress: number;
  quarantine: number;
  damaged: number;
}

export interface SellerShipmentRowDto {
  shipmentNo: string;
  orderExternalId: string;
  status: string;
  trackingNo: string | null;
  handedOverAt: string | null;
  deliveredAt: string | null;
  codAmount: string | null;
  codCollectedAmount: string | null;
}

export interface SellerDashboardDto {
  sellerId: string;
  sellerName: string;
  generatedAt: string;
  ordersByStatus: Array<{ status: string; count: number }>;
  stock: SellerStockRowDto[];
  recentShipments: SellerShipmentRowDto[];
  /** Незакрытые счета: сколько селлер должен или сколько должны ему. */
  openInvoices: Array<{
    id: string;
    number: string;
    periodStart: string;
    periodEnd: string;
    currency: string;
    servicesTotal: string;
    payoutTotal: string;
    status: string;
  }>;
}
