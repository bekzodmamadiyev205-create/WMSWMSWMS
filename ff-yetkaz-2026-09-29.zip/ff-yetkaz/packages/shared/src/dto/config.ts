export const SETTING_VALUE_TYPES = ['number', 'string', 'boolean', 'json'] as const;
export type SettingValueType = (typeof SETTING_VALUE_TYPES)[number];

export interface AppSettingDto {
  key: string;
  value: unknown;
  valueType: SettingValueType;
  description: string;
  updatedAt: string;
}

export interface CarrierDto {
  id: string;
  code: string;
  name: string;
  baseUrl: string;
  handoffPath: string;
  timeoutMs: number;
  /** Имя переменной окружения с секретом — не сам секрет. */
  secretEnvKey: string;
  isActive: boolean;
  /** Проверено на старте: переменная окружения существует и не пуста. */
  secretConfigured: boolean;
  updatedAt: string;
}

/**
 * Ключи настроек, на которые ссылается код. Строкой ключ нигде не пишется:
 * опечатка в `'packing.weight_tolerace_pct'` тихо вернула бы значение по
 * умолчанию, и допуск разъехался бы с тем, что видит оператор.
 */
export const SETTING_KEYS = {
  WEIGHT_TOLERANCE_PCT: 'packing.weight_tolerance_pct',
  OUTBOX_MAX_ATTEMPTS: 'integration.outbox_max_attempts',
  OUTBOX_BACKOFF_BASE_SECONDS: 'integration.outbox_backoff_base_seconds',
  OUTBOX_BATCH_SIZE: 'integration.outbox_batch_size',
  WEBHOOK_TOLERANCE_SECONDS: 'integration.webhook_tolerance_seconds',
} as const;

export type SettingKey = (typeof SETTING_KEYS)[keyof typeof SETTING_KEYS];

/**
 * Значения на случай пустой таблицы — только чтобы сервис поднялся на голой
 * базе. Источник правды — `app_settings`.
 */
export const SETTING_FALLBACKS: Record<SettingKey, number> = {
  [SETTING_KEYS.WEIGHT_TOLERANCE_PCT]: 5,
  [SETTING_KEYS.OUTBOX_MAX_ATTEMPTS]: 8,
  [SETTING_KEYS.OUTBOX_BACKOFF_BASE_SECONDS]: 15,
  [SETTING_KEYS.OUTBOX_BATCH_SIZE]: 25,
  [SETTING_KEYS.WEBHOOK_TOLERANCE_SECONDS]: 300,
};
