import type { ShipmentStatus } from '../states/shipment';

/**
 * Состояние упаковки. Не самостоятельная статусная машина: упаковка живёт
 * ровно столько, сколько заказ идёт по PACKING → PACKED, и её состояние —
 * проекция статуса заказа, а не независимый жизненный цикл.
 */
export const PACKAGE_STATUSES = ['OPEN', 'PACKED', 'CANCELLED'] as const;
export type PackageStatus = (typeof PACKAGE_STATUSES)[number];

export interface PackageItemDto {
  id: string;
  skuId: string;
  skuCode: string;
  skuName: string;
  lotId: string | null;
  quantity: number;
  /** Вес единицы из справочника; null — не заполнен, расчётный вес не построить. */
  unitWeightG: number | null;
}

export interface PackageDto {
  id: string;
  orderId: string;
  warehouseId: string;
  status: PackageStatus;
  /** Сумма весов позиций. null — хотя бы у одного SKU не заполнен вес. */
  expectedWeightG: number | null;
  actualWeightG: number | null;
  /** Отклонение факта от расчёта больше допуска. */
  weightMismatch: boolean;
  /**
   * Действующий допуск, %. Приезжает с сервера, а не зашит в UI: значение живёт
   * в `app_settings`, и подсказка упаковщику не должна разъехаться с проверкой.
   */
  weightTolerancePct: number;
  lengthMm: number | null;
  widthMm: number | null;
  heightMm: number | null;
  packerUserId: string | null;
  comment: string | null;
  startedAt: string;
  packedAt: string | null;
  items: PackageItemDto[];
}

export interface ShipmentDto {
  id: string;
  orderId: string;
  packageId: string;
  /** Внутренний номер FF: он же штрихкод этикетки, пока нет трека перевозчика. */
  shipmentNo: string;
  status: ShipmentStatus;
  carrier: string;
  /** Трек перевозчика — появляется при передаче в iPost GO. */
  trackingNo: string | null;
  weightG: number;
  codAmount: string | null;
  currency: string | null;
  handedOverAt: string | null;
  createdAt: string;
}

/**
 * Отправление может быть ещё не оформлено. Конверт, а не голый `null`:
 * пустое тело ответа клиенту не разобрать как JSON.
 */
export interface PackageShipmentDto {
  shipment: ShipmentDto | null;
}

/** Строка очереди упаковки: заказ собран и ждёт коробки. */
export interface PackingQueueItemDto {
  orderId: string;
  externalId: string;
  channel: string;
  sellerId: string;
  warehouseId: string;
  /** PICKED — ждёт упаковщика, PACKING — уже в работе. */
  status: string;
  recipientName: string;
  address: string;
  hasShortage: boolean;
  /** Что реально доехало до зоны упаковки, а не что просил канал. */
  itemsCount: number;
  unitsCount: number;
  pickedAt: string | null;
  packageId: string | null;
  packerUserId: string | null;
}

/** Итог взвешивания. */
export interface PackCompletionDto {
  package: PackageDto;
  expectedWeightG: number | null;
  actualWeightG: number;
  /** Отклонение в процентах; null — расчётный вес неизвестен. */
  deviationPct: number | null;
  tolerancePct: number;
  weightMismatch: boolean;
}
