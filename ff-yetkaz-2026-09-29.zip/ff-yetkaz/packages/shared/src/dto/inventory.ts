import type { InventoryUnitStatus } from '../states/inventory-unit';

/**
 * Причина движения остатка. Журнал `stock_movements` — append-only: остаток
 * никогда не правится напрямую, только движением, у которого есть причина.
 */
export const MOVEMENT_REASONS = [
  'RECEIPT',
  'PUTAWAY',
  'MOVE',
  'RESERVE',
  'RELEASE',
  'ADJUSTMENT',
  'INSPECTION',
  'DAMAGE',
  'PICK',
  'PACK',
  'SHIP',
  'WRITE_OFF',
  /** Возврат на склад отменённого до отгрузки заказа: коробку вскрыли и разложили. */
  'PUT_BACK',
] as const;
export type MovementReason = (typeof MOVEMENT_REASONS)[number];

export const RESERVATION_STATUSES = ['ACTIVE', 'RELEASED', 'CONSUMED'] as const;
export type ReservationStatus = (typeof RESERVATION_STATUSES)[number];

export interface LotDto {
  id: string;
  skuId: string;
  lotCode: string;
  /** ISO-дата (без времени): срок годности партии. */
  expiryDate: string | null;
  receivedAt: string;
}

export interface StockDto {
  id: string;
  skuId: string;
  warehouseId: string;
  binId: string;
  lotId: string | null;
  status: InventoryUnitStatus;
  quantity: number;
}

/** Где именно лежит товар: строка остатка по ячейке и статусу. */
export interface StockBinRowDto {
  binId: string;
  binCode: string;
  status: InventoryUnitStatus;
  quantity: number;
}

/** Свод остатка по SKU и складу в разрезе статусов. */
export interface StockSummaryDto {
  skuId: string;
  /** Артикул и название рядом с количеством: свод без них нечитаем. */
  skuCode: string;
  skuName: string;
  warehouseId: string;
  byStatus: Record<string, number>;
  /** Сколько реально можно зарезервировать прямо сейчас. */
  available: number;
  total: number;
  /**
   * Раскладка по ячейкам. Вопрос кладовщика звучит не «сколько всего»,
   * а «где взять» — сумма по складу на него не отвечает.
   */
  bins: StockBinRowDto[];
}

export interface StockMovementDto {
  id: string;
  occurredAt: string;
  skuId: string;
  warehouseId: string;
  lotId: string | null;
  fromBinId: string | null;
  fromStatus: InventoryUnitStatus | null;
  toBinId: string | null;
  toStatus: InventoryUnitStatus | null;
  quantity: number;
  reason: MovementReason;
  referenceType: string | null;
  referenceId: string | null;
  comment: string | null;
  actorUserId: string | null;
}

export interface ReservationDto {
  id: string;
  ownerType: string;
  ownerId: string;
  skuId: string;
  warehouseId: string;
  binId: string;
  lotId: string | null;
  quantity: number;
  status: ReservationStatus;
}

export interface ReserveResultDto {
  ownerType: string;
  ownerId: string;
  skuId: string;
  warehouseId: string;
  requested: number;
  /** Раскладка резерва по ячейкам и партиям — в порядке выдачи FEFO/FIFO. */
  lines: ReservationDto[];
}

// ------------------------------------------------- витрина остатков (таблица)

/** По каким колонкам разрешено сортировать витрину остатков на сервере. */
export const STOCK_SORT_FIELDS = [
  'skuCode',
  'skuName',
  'sellerName',
  'warehouseCode',
  'quantity',
  'receivedAt',
  'status',
] as const;
export type StockSortField = (typeof STOCK_SORT_FIELDS)[number];

/**
 * Строка витрины остатков: SKU × склад × статус.
 *
 * Разрез именно по статусу, а не «одна строка на товар»: кладовщику и
 * финансисту нужны РАЗНЫЕ числа — доступное к продаже и лежащее в браке это не
 * одно и то же количество, и складывать их в одну ячейку значит врать.
 */
export interface StockTableRowDto {
  /** Стабильный ключ строки для таблицы: `skuId:warehouseId:status`. */
  key: string;
  skuId: string;
  skuCode: string;
  skuName: string;
  sellerId: string;
  sellerCode: string;
  sellerName: string;
  warehouseId: string;
  warehouseCode: string;
  status: InventoryUnitStatus;
  quantity: number;
  /** Контекст по тому же SKU и складу — чтобы строка читалась без раскрытия. */
  available: number;
  reserved: number;
  damaged: number;
  /**
   * Дата поступления. Берётся из журнала движений (`RECEIPT`/`PUTAWAY`), а не
   * из `stock.created_at`: строка остатка живёт вечно и переиспользуется, её
   * дата создания может быть старше лежащего в ячейке товара на месяцы.
   * `first` — самая старая партия в срезе (возраст запаса), `last` — последний
   * приход (когда пополняли).
   */
  firstReceivedAt: string | null;
  lastReceivedAt: string | null;
  bins: StockBinRowDto[];
}

export interface StockTableQuery {
  sellerId?: string;
  warehouseId?: string;
  status?: InventoryUnitStatus;
  /** Артикул, название, штрихкод — или номер заказа, в котором есть этот товар. */
  search?: string;
  /** Период поступления, обе границы включительно (ISO `YYYY-MM-DD`). */
  dateFrom?: string;
  dateTo?: string;
  /** Показывать ли нулевые срезы. По умолчанию нет — это шум. */
  includeZero?: boolean;
  page?: number;
  pageSize?: number;
  sort?: StockSortField;
  direction?: 'asc' | 'desc';
}

/** Итоги по всему фильтру, а не по видимой странице. */
export interface StockTableTotalsDto {
  rows: number;
  units: number;
  available: number;
  reserved: number;
  damaged: number;
  skus: number;
}
