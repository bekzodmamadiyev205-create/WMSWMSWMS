import { StateMachine, type TransitionTable } from '../fsm';

export const PICK_TASK_STATUSES = [
  'NEW',
  'ASSIGNED',
  'IN_PROGRESS',
  'COMPLETED',
  'CANCELLED',
] as const;
export type PickTaskStatus = (typeof PICK_TASK_STATUSES)[number];

/**
 * Задание на сборку. Отмены задания в MVP нет намеренно: у заказа нет перехода
 * PICKING → RESERVED, поэтому вернуть начатую сборку было бы некуда. Если сборщик
 * выбыл — задание переназначается, а не отменяется.
 */
const PICK_TASK_TRANSITIONS: TransitionTable<PickTaskStatus> = {
  NEW: ['ASSIGNED', 'CANCELLED'],
  ASSIGNED: ['IN_PROGRESS', 'CANCELLED'],
  IN_PROGRESS: ['COMPLETED'],
  COMPLETED: [],
  CANCELLED: [],
};

export const pickTaskFsm = new StateMachine<PickTaskStatus>(
  'PickTask',
  PICK_TASK_TRANSITIONS,
  'NEW',
);

export const PICK_TASK_KINDS = ['SINGLE', 'BATCH'] as const;
export type PickTaskKind = (typeof PICK_TASK_KINDS)[number];

/**
 * Строка задания: ждёт сборки → собрана → недобор. CANCELLED — заказ отменили
 * посреди сборки: за этим товаром идти уже незачем.
 */
export const PICK_LINE_STATUSES = ['PENDING', 'PICKED', 'SHORT', 'CANCELLED'] as const;
export type PickLineStatus = (typeof PICK_LINE_STATUSES)[number];
