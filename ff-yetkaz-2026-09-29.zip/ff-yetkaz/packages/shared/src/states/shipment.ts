import { StateMachine, type TransitionTable } from '../fsm';

export const SHIPMENT_STATUSES = [
  'READY',
  'HANDED_OVER',
  'IN_TRANSIT',
  'DELIVERED',
  'FAILED',
  'RETURNING',
  'CANCELLED',
] as const;

export type ShipmentStatus = (typeof SHIPMENT_STATUSES)[number];

/**
 * По ТЗ: READY → HANDED_OVER → IN_TRANSIT → DELIVERED | FAILED | RETURNING.
 *
 * READY и HANDED_OVER ставит FF (передача в iPost GO). Всё, что дальше, приходит
 * входящим вебхуком от iPost GO — FF только применяет присланный статус, проверяя
 * его этой таблицей.
 *
 * CANCELLED достижим только из READY (решение PM): отменить можно то, что ещё не
 * уехало. После передачи перевозчику отменяет уже он — присылает FAILED/RETURNING.
 *
 * ОТКРЫТЫЙ ВОПРОС (решение PM): FAILED сейчас терминальный. На практике за
 * неудачной доставкой обычно следует либо повторная попытка (FAILED → IN_TRANSIT),
 * либо возврат (FAILED → RETURNING) — в ТЗ этого нет, поэтому не додумывал.
 */
const SHIPMENT_TRANSITIONS: TransitionTable<ShipmentStatus> = {
  READY: ['HANDED_OVER', 'CANCELLED'],
  HANDED_OVER: ['IN_TRANSIT'],
  IN_TRANSIT: ['DELIVERED', 'FAILED', 'RETURNING'],
  DELIVERED: [],
  FAILED: [],
  RETURNING: [],
  CANCELLED: [],
};

export const shipmentFsm = new StateMachine<ShipmentStatus>(
  'Shipment',
  SHIPMENT_TRANSITIONS,
  'READY',
);
