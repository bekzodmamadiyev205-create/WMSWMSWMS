import { StateMachine, type TransitionTable } from '../fsm';

export const ORDER_STATUSES = [
  'NEW',
  'VALIDATED',
  'RESERVED',
  'PICKING',
  'PICKED',
  'PACKING',
  'PACKED',
  'READY_TO_SHIP',
  /**
   * «Расходный»: коробка физически выдана со склада — выписана расходная
   * накладная. Отдельный статус, а не синоним SHIPPED: SHIPPED подтверждает
   * ПЕРЕВОЗЧИК вебхуком, а расход фиксирует склад в момент выдачи. Между ними
   * бывают часы, а иногда вебхука нет вовсе — тогда без этого статуса заказ
   * навсегда оставался бы «готов к отгрузке», хотя его уже увезли.
   */
  'DISPATCHED',
  'SHIPPED',
  'DELIVERED',
  'RETURNED',
  'CANCELLED',
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];

/**
 * Основная цепочка по ТЗ:
 *   NEW → VALIDATED → RESERVED → PICKING → PICKED → PACKING → PACKED
 *       → READY_TO_SHIP → SHIPPED → DELIVERED | RETURNED
 *
 * Отмена (решение PM): CANCELLED достижим из ЛЮБОГО статуса до доставки, а не
 * только после SHIPPED, как было записано в ТЗ. Причина практическая: отмена
 * снимает резерв, и без раннего перехода отменённый селлером заказ держал бы
 * остаток вечно.
 *
 * Границы системы: FF владеет заказом до READY_TO_SHIP. Переходы SHIPPED →
 * DELIVERED | RETURNED приходят из iPost GO входящим вебхуком, FF их не инициирует.
 */
const ORDER_TRANSITIONS: TransitionTable<OrderStatus> = {
  NEW: ['VALIDATED', 'CANCELLED'],
  VALIDATED: ['RESERVED', 'CANCELLED'],
  RESERVED: ['PICKING', 'CANCELLED'],
  PICKING: ['PICKED', 'CANCELLED'],
  PICKED: ['PACKING', 'CANCELLED'],
  PACKING: ['PACKED', 'CANCELLED'],
  PACKED: ['READY_TO_SHIP', 'CANCELLED'],
  // READY_TO_SHIP → SHIPPED оставлен намеренно: вебхук перевозчика приходит и
  // на заказы, которые склад не отмечал расходом руками, и ломать приём статусов
  // ради нового шага нельзя.
  READY_TO_SHIP: ['DISPATCHED', 'SHIPPED', 'CANCELLED'],
  DISPATCHED: ['SHIPPED', 'DELIVERED', 'RETURNED', 'CANCELLED'],
  SHIPPED: ['DELIVERED', 'RETURNED', 'CANCELLED'],
  DELIVERED: [],
  RETURNED: [],
  CANCELLED: [],
};

export const orderFsm = new StateMachine<OrderStatus>('Order', ORDER_TRANSITIONS, 'NEW');
