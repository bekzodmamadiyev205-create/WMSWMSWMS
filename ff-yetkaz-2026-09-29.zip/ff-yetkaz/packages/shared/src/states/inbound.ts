import { StateMachine, type TransitionTable } from '../fsm';

export const ASN_STATUSES = [
  'DRAFT',
  'SUBMITTED',
  'RECEIVING',
  'COMPLETED',
  'CANCELLED',
] as const;
export type AsnStatus = (typeof ASN_STATUSES)[number];

/**
 * Заявка селлера на поставку: черновик → отправлена → идёт приёмка → закрыта.
 * На один ASN может быть несколько приёмок (частичные поставки), поэтому
 * RECEIVING держится, пока оператор не закроет заявку.
 */
const ASN_TRANSITIONS: TransitionTable<AsnStatus> = {
  DRAFT: ['SUBMITTED', 'CANCELLED'],
  SUBMITTED: ['RECEIVING', 'CANCELLED'],
  RECEIVING: ['COMPLETED', 'CANCELLED'],
  COMPLETED: [],
  CANCELLED: [],
};

export const asnFsm = new StateMachine<AsnStatus>('Asn', ASN_TRANSITIONS, 'DRAFT');

export const RECEIPT_STATUSES = ['OPEN', 'COMPLETED', 'CANCELLED'] as const;
export type ReceiptStatus = (typeof RECEIPT_STATUSES)[number];

const RECEIPT_TRANSITIONS: TransitionTable<ReceiptStatus> = {
  OPEN: ['COMPLETED', 'CANCELLED'],
  COMPLETED: [],
  CANCELLED: [],
};

export const receiptFsm = new StateMachine<ReceiptStatus>('Receipt', RECEIPT_TRANSITIONS, 'OPEN');

/** Позиция приёмки: принята в приёмочную зону → разложена по ячейкам хранения. */
export const RECEIPT_LINE_STATUSES = ['RECEIVED', 'PUT_AWAY'] as const;
export type ReceiptLineStatus = (typeof RECEIPT_LINE_STATUSES)[number];
