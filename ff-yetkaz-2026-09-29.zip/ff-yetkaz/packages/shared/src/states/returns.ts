import { StateMachine, type TransitionTable } from '../fsm';

/**
 * Обратная логистика (RMA). Статусы взяты из требований оператора дословно:
 * принят возврат → на хранении → перемещение → завершён.
 *
 * Почему это НЕ статус заказа: заказ уже уехал и его жизненный цикл закрылся
 * (`RETURNED`). Возврат — самостоятельный документ со своим складским
 * движением, своим составом и своими сроками; вешать его на заказ значило бы
 * потерять возвраты без заказа (клиент вернул не через нас, перепутанная
 * посылка, брак партии).
 */
export const RETURN_STATUSES = [
  /** Принят возврат: коробка на складе, товар оприходован в зоне приёмки. */
  'ACCEPTED',
  /** На хранении: осмотрен и разложен — годное в остаток, брак в брак. */
  'IN_STORAGE',
  /** Перемещение: едет между ячейками/зонами (или обратно селлеру). */
  'MOVING',
  /** Завершён: решение принято и исполнено, документ закрыт. */
  'COMPLETED',
  'CANCELLED',
] as const;

export type ReturnStatus = (typeof RETURN_STATUSES)[number];

/**
 * `IN_STORAGE ⇄ MOVING` в обе стороны намеренно: перемещение — это состояние
 * логистики, а не точка невозврата. Коробку могут отвезти в другую зону и
 * вернуть обратно, и оба факта должны быть в журнале.
 *
 * `MOVING → MOVING` в таблице НЕТ намеренно, хотя короб возят по складу
 * сколько нужно: повторный переезд — та же операция, а не новое состояние, и
 * запись «перешёл сам в себя» замусорила бы трек событиями без смены статуса.
 * Повтор обрабатывает сервис — он пропускает переход, если статус уже MOVING
 * (`ReturnsService.move`), ровно как это сделано с повторной раскладкой.
 */
const RETURN_TRANSITIONS: TransitionTable<ReturnStatus> = {
  ACCEPTED: ['IN_STORAGE', 'MOVING', 'CANCELLED'],
  IN_STORAGE: ['MOVING', 'COMPLETED', 'CANCELLED'],
  MOVING: ['IN_STORAGE', 'COMPLETED', 'CANCELLED'],
  COMPLETED: [],
  CANCELLED: [],
};

export const returnFsm = new StateMachine<ReturnStatus>('Return', RETURN_TRANSITIONS, 'ACCEPTED');

/** Состояние вернувшегося товара — от него зависит, куда он ляжет на складе. */
export const RETURN_ITEM_CONDITIONS = ['GOOD', 'DAMAGED'] as const;
export type ReturnItemCondition = (typeof RETURN_ITEM_CONDITIONS)[number];

/** Почему товар вернулся. Справочник закрытый: это поле идёт в аналитику. */
export const RETURN_REASONS = [
  'CUSTOMER_REFUSED',
  'NOT_DELIVERED',
  'DAMAGED_IN_TRANSIT',
  'WRONG_ITEM',
  'DEFECT',
  'OTHER',
] as const;
export type ReturnReason = (typeof RETURN_REASONS)[number];
