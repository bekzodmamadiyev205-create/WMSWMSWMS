import { StateMachine, type TransitionTable } from '../fsm';

export const INVENTORY_UNIT_STATUSES = [
  'EXPECTED',
  'RECEIVED',
  'INSPECTED',
  'AVAILABLE',
  'RESERVED',
  'PICKED',
  'PACKED',
  'SHIPPED',
  'DAMAGED',
  'QUARANTINE',
] as const;

export type InventoryUnitStatus = (typeof INVENTORY_UNIT_STATUSES)[number];

/**
 * Основная цепочка по ТЗ:
 *   EXPECTED → RECEIVED → INSPECTED → AVAILABLE → RESERVED → PICKED → PACKED → SHIPPED
 * плюс ветки DAMAGED и QUARANTINE.
 *
 * Обратные переходы RESERVED → AVAILABLE и PICKED → AVAILABLE заданы не «на всякий
 * случай», а потому что их требуют события реестра: `inventory.released` (снятие
 * резерва при отмене) и short-pick из ТЗ (нехватка при сборке → возврат в остаток).
 *
 * PACKED → AVAILABLE (решение PM) — возврат на склад при отмене заказа до передачи
 * в доставку. Это НЕ возврат от клиента (RMA): товар физически не покидал склад,
 * коробку вскрывают и раскладывают обратно. Без этого перехода отменённый после
 * упаковки заказ навсегда удерживал бы остаток вне доступного.
 *
 * ОТКРЫТЫЙ ВОПРОС (решение PM): куда именно ведёт QUARANTINE. Сейчас — обратно в
 * AVAILABLE (карантин снят) или в DAMAGED (брак подтверждён). Списание/утилизация
 * как отдельное состояние не заведена.
 */
const INVENTORY_UNIT_TRANSITIONS: TransitionTable<InventoryUnitStatus> = {
  EXPECTED: ['RECEIVED'],
  RECEIVED: ['INSPECTED', 'DAMAGED', 'QUARANTINE'],
  INSPECTED: ['AVAILABLE', 'DAMAGED', 'QUARANTINE'],
  AVAILABLE: ['RESERVED', 'QUARANTINE'],
  RESERVED: ['PICKED', 'AVAILABLE'],
  PICKED: ['PACKED', 'AVAILABLE'],
  PACKED: ['SHIPPED', 'AVAILABLE'],
  SHIPPED: [],
  DAMAGED: [],
  QUARANTINE: ['AVAILABLE', 'DAMAGED'],
};

export const inventoryUnitFsm = new StateMachine<InventoryUnitStatus>(
  'InventoryUnit',
  INVENTORY_UNIT_TRANSITIONS,
  'EXPECTED',
);
