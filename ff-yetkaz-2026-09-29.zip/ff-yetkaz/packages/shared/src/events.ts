import type { ShipmentStatus } from './states/shipment';

/**
 * Реестр доменных событий FF. Единственный источник правды об именах событий —
 * модули публикуют и слушают только то, что перечислено здесь.
 *
 * Денежные суммы во всех payload'ах — строки (decimal из БД), не number:
 * float для денег недопустим, а bigint не сериализуется в JSON.
 */
export interface FfEventPayloads {
  'order.created': {
    orderId: string;
    sellerId: string;
    /** Идентификатор во внешнем канале (маркетплейс, интеграция), если пришёл. */
    externalId: string | null;
  };
  'order.validated': {
    orderId: string;
    sellerId: string;
  };
  /**
   * Владелец резерва обобщённый (`ownerType`/`ownerId`), а не жёстко заказ:
   * Inventory не должен знать про модуль Orders, чтобы резервировать умели и
   * другие потребители. Для заказов ownerType = 'ORDER', ownerId = id заказа.
   */
  'inventory.reserved': {
    ownerType: string;
    ownerId: string;
    skuId: string;
    warehouseId: string;
    quantity: number;
  };
  'inventory.released': {
    ownerType: string;
    ownerId: string;
    skuId: string;
    warehouseId: string;
    quantity: number;
    reason: string;
  };
  'pick.completed': {
    orderId: string;
    pickTaskId: string;
    pickerUserId: string;
    /** Собрано меньше запрошенного — триггер перерезерва или уведомления. */
    shortPicked: boolean;
  };
  'pack.completed': {
    orderId: string;
    packageId: string;
    packerUserId: string;
    weightKg: string;
    /** Отклонение фактического веса от расчётного больше допуска ±5%. */
    weightMismatch: boolean;
  };
  'shipment.ready': {
    shipmentId: string;
    orderId: string;
    trackingNo: string | null;
    codAmount: string | null;
  };
  'shipment.status_changed': {
    shipmentId: string;
    orderId: string;
    from: ShipmentStatus;
    to: ShipmentStatus;
    /** Кто инициировал: FF (передача) или входящий вебхук iPost GO. */
    source: 'FF' | 'IPOST_GO';
  };
  'rma.created': {
    rmaId: string;
    orderId: string;
    reason: string;
  };
  'billing.charge_created': {
    chargeId: string;
    sellerId: string;
    /** Вид услуги из тарифного справочника: inbound / storage / picking / packing / delivery / cod_fee. */
    kind: string;
    amount: string;
    currency: string;
  };
}

/** `satisfies` гарантирует: у каждого имени в реестре есть описанный payload. */
export const FF_EVENTS = {
  ORDER_CREATED: 'order.created',
  ORDER_VALIDATED: 'order.validated',
  INVENTORY_RESERVED: 'inventory.reserved',
  INVENTORY_RELEASED: 'inventory.released',
  PICK_COMPLETED: 'pick.completed',
  PACK_COMPLETED: 'pack.completed',
  SHIPMENT_READY: 'shipment.ready',
  SHIPMENT_STATUS_CHANGED: 'shipment.status_changed',
  RMA_CREATED: 'rma.created',
  BILLING_CHARGE_CREATED: 'billing.charge_created',
} as const satisfies Record<string, keyof FfEventPayloads>;

export type FfEventName = (typeof FF_EVENTS)[keyof typeof FF_EVENTS];

export const FF_EVENT_NAMES: readonly FfEventName[] = Object.values(FF_EVENTS);

/** Конверт события: полезная нагрузка + кто и когда инициировал. */
export interface FfDomainEvent<K extends FfEventName = FfEventName> {
  readonly name: K;
  readonly occurredAt: string;
  readonly payload: FfEventPayloads[K];
  readonly actorUserId: string | null;
  /** Сквозной идентификатор запроса — связывает событие с audit_events. */
  readonly correlationId: string | null;
}
