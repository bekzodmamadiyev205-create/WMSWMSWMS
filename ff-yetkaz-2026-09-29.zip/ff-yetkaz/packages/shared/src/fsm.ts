/**
 * Явная машина состояний: таблица разрешённых переходов задаётся данными,
 * недопустимый переход бросает InvalidTransitionError.
 *
 * Живёт в shared намеренно: те же таблицы нужны фронту, чтобы показывать
 * только действительно доступные действия, а не угадывать их.
 */

export class InvalidTransitionError extends Error {
  constructor(
    readonly machine: string,
    readonly from: string,
    readonly to: string,
    readonly allowed: readonly string[],
  ) {
    super(
      `Недопустимый переход ${machine}: ${from} → ${to}. ` +
        (allowed.length ? `Разрешено: ${allowed.join(', ')}.` : 'Состояние терминальное.'),
    );
    this.name = 'InvalidTransitionError';
  }
}

export type TransitionTable<S extends string> = Readonly<Record<S, readonly S[]>>;

export class StateMachine<S extends string> {
  constructor(
    readonly name: string,
    private readonly table: TransitionTable<S>,
    readonly initial: S,
  ) {}

  /** Все состояния машины. */
  states(): readonly S[] {
    return Object.keys(this.table) as S[];
  }

  /** Состояния, достижимые из `from` за один переход. */
  next(from: S): readonly S[] {
    return this.table[from] ?? [];
  }

  /** Терминальное — то, из которого нет исходящих переходов. */
  isTerminal(state: S): boolean {
    return this.next(state).length === 0;
  }

  isState(value: unknown): value is S {
    return typeof value === 'string' && Object.prototype.hasOwnProperty.call(this.table, value);
  }

  can(from: S, to: S): boolean {
    return this.next(from).includes(to);
  }

  /** Бросает InvalidTransitionError, если переход не разрешён таблицей. */
  assert(from: S, to: S): void {
    if (!this.can(from, to)) {
      throw new InvalidTransitionError(this.name, from, to, this.next(from));
    }
  }
}
