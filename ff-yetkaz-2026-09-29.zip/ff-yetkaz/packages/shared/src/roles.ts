/** Роли FF. Фиксированный набор — новые роли добавляются миграцией enum'а в БД. */
export const ROLES = [
  'ADMIN',
  'WAREHOUSE_OPERATOR',
  'PICKER',
  'PACKER',
  // Приёмщик: только приём (склад через ТСД). Скоуп держит RolesGuard;
  // своих статусов не вводит — ходит по тем же эндпоинтам приёмки.
  'RECEIVER',
  'FINANCE',
  'SELLER',
] as const;

export type Role = (typeof ROLES)[number];

export function isRole(value: unknown): value is Role {
  return typeof value === 'string' && (ROLES as readonly string[]).includes(value);
}

/** Роль внешнего клиента-селлера: видит только свои данные (изоляция по seller_id). */
export const SELLER_ROLE: Role = 'SELLER';

/** Роли сотрудников оператора — им seller_id не назначается. */
export const STAFF_ROLES: readonly Role[] = ROLES.filter((r) => r !== SELLER_ROLE);
