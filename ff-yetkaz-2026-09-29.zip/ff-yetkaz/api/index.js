// Точка входа serverless-функции Vercel для ОДНОГО проекта, где рядом живут
// статика фронта и API. Так фронт и бэкенд оказываются на одном происхождении:
// CORS не нужен вовсе, а токен не путешествует между доменами.
//
// Обычный JS, а НЕ TypeScript: сборщик функций Vercel компилирует TS через
// esbuild, а тот не эмитит метаданные декораторов — вся инъекция зависимостей
// NestJS на них и держится. Поэтому здесь только require уже скомпилированного
// `dist`, который собрал `nest build` с нужными настройками компилятора.
'use strict';
require('reflect-metadata');

const express = require('express');
const { ConfigService } = require('@nestjs/config');
const { NestFactory } = require('@nestjs/core');
const { ExpressAdapter } = require('@nestjs/platform-express');
const { AppModule } = require('../apps/api/dist/app.module');
const { configureApp } = require('../apps/api/dist/bootstrap');

/**
 * Приложение поднимается ОДИН раз на «тёплый» инстанс и переиспользуется:
 * подъём Nest с TypeORM занимает секунды и открывает пул соединений — делать
 * это на каждый запрос значит и тормозить, и исчерпать лимит соединений базы.
 *
 * Кэшируется промис, а не результат: два параллельных холодных запроса иначе
 * начали бы инициализацию дважды.
 */
let appPromise = null;

async function bootstrap() {
  const server = express();
  const app = await NestFactory.create(AppModule, new ExpressAdapter(server), {
    logger: ['error', 'warn', 'log'],
  });
  configureApp(app, app.get(ConfigService));
  await app.init();
  return server;
}

function getApp() {
  if (!appPromise) {
    appPromise = bootstrap().catch((error) => {
      // Сбрасываем кэш: иначе одна неудачная инициализация (база была
      // недоступна секунду) навсегда ломает тёплый инстанс.
      appPromise = null;
      throw error;
    });
  }
  return appPromise;
}

module.exports = async (request, response) => {
  const server = await getApp();
  server(request, response);
};
