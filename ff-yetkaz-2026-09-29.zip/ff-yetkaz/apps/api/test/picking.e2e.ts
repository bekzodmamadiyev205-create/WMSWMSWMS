// Сквозной тест этапа 1.3 (Picking) против настоящего PostgreSQL.
//   npx ts-node -T test/picking.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_picking_pg');
const PG_PORT = Number(process.env.FF_PICK_PGPORT || 5447);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_picking');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_picking`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    async function login(email: string): Promise<string> {
      const response = await request(http)
        .post('/api/v1/auth/login')
        .send({ email, password: PASSWORD });
      return response.body.accessToken as string;
    }

    await createUser('admin@ff.local', ['ADMIN'], null);
    const picker1 = await createUser('picker1@ff.local', ['PICKER'], null);
    await createUser('picker2@ff.local', ['PICKER'], null);
    const adminToken = await login('admin@ff.local');
    const picker1Token = await login('picker1@ff.local');
    const picker2Token = await login('picker2@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);
    const asPicker1 = (r: request.Test) => r.set('Authorization', `Bearer ${picker1Token}`);
    const asPicker2 = (r: request.Test) => r.set('Authorization', `Bearer ${picker2Token}`);

    // ---------- 1. Подготовка -----------------------------------------------
    console.log('\n1. Миграция и данные');
    check(
      applied.some((m) => m.name === 'Picking1786233600000'),
      'Миграция Picking применилась',
      `всего: ${applied.length}`,
    );
    const tables: Array<{ table_name: string }> = await dataSource.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`,
    );
    for (const expected of ['pick_tasks', 'pick_task_orders', 'pick_task_lines']) {
      check(tables.some((t) => t.table_name === expected), `Таблица ${expected} создана`);
    }

    const seller = (
      await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'Акме' })
    ).body;
    const warehouse = (
      await asAdmin(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })
    ).body;
    const bare = (
      await asAdmin(request(http).post('/api/v1/warehouses')).send({ code: 'SAM-1', name: 'Самарканд' })
    ).body;

    async function makeBin(warehouseId: string, code: string, kind: string) {
      return (
        await asAdmin(request(http).post('/api/v1/bin-locations')).send({ warehouseId, code, kind })
      ).body;
    }
    const bin1 = await makeBin(warehouse.id, 'S-01-01-01', 'STORAGE');
    const bin2 = await makeBin(warehouse.id, 'S-02-01-01', 'STORAGE');
    await makeBin(warehouse.id, 'P-01-01-01', 'PACKING');
    const bareBin = await makeBin(bare.id, 'S-01-01-01', 'STORAGE');

    async function makeSku(code: string, barcode: string) {
      const sku = (
        await asAdmin(request(http).post('/api/v1/skus')).send({
          sellerId: seller.id,
          skuCode: code,
          name: code,
        })
      ).body;
      await asAdmin(request(http).post(`/api/v1/skus/${sku.id}/barcodes`)).send({
        barcode,
        kind: 'EAN13',
        isPrimary: true,
      });
      return sku;
    }
    const skuA = await makeSku('A', '1000000000011');
    const skuB = await makeSku('B', '1000000000028');
    const skuC = await makeSku('C', '1000000000035');
    // Лежит ТОЛЬКО на складе без ячейки PACKING — иначе аллокатор увёл бы заказ
    // на основной склад и проверка стала бы бессмысленной.
    const skuD = await makeSku('D', '1000000000042');

    async function stockIn(skuId: string, warehouseId: string, binId: string, quantity: number) {
      return asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
        skuId,
        warehouseId,
        binId,
        quantity,
      });
    }
    await stockIn(skuA.id, warehouse.id, bin1.id, 5);
    await stockIn(skuB.id, warehouse.id, bin1.id, 3);
    await stockIn(skuB.id, warehouse.id, bin2.id, 4);
    await stockIn(skuC.id, warehouse.id, bin1.id, 2);
    await stockIn(skuD.id, bare.id, bareBin.id, 5);

    let orderSeq = 0;
    async function makeOrder(lines: Array<{ skuId: string; quantity: number }>) {
      orderSeq += 1;
      const response = await asAdmin(request(http).post('/api/v1/orders')).send({
        sellerId: seller.id,
        channel: 'uzum',
        externalId: `ORD-${orderSeq}`,
        recipientName: 'Иванов',
        recipientPhone: '+998901234567',
        address: 'Ташкент',
        lines,
      });
      return response.body.order;
    }
    const order1 = await makeOrder([{ skuId: skuA.id, quantity: 2 }]);
    const order2 = await makeOrder([{ skuId: skuB.id, quantity: 3 }]);
    const order3 = await makeOrder([{ skuId: skuC.id, quantity: 2 }]);
    const order4 = await makeOrder([{ skuId: skuA.id, quantity: 1 }]);
    const order5 = await makeOrder([{ skuId: skuA.id, quantity: 1 }]);
    check(
      [order1, order2, order3, order4, order5].every((o) => o.status === 'RESERVED'),
      'Пять заказов зарезервированы и готовы к сборке',
    );

    // ---------- 2. Создание задания -----------------------------------------
    console.log('\n2. Создание задания');
    const bareOrder = await asAdmin(request(http).post('/api/v1/orders')).send({
      sellerId: seller.id,
      channel: 'uzum',
      externalId: 'ORD-BARE',
      recipientName: 'Иванов',
      recipientPhone: '+998901234567',
      address: 'Самарканд',
      lines: [{ skuId: skuD.id, quantity: 1 }],
    });
    check(
      bareOrder.body.order.warehouseId === bare.id,
      'Заказ ушёл на склад без ячейки упаковки',
      `warehouseId=${bareOrder.body.order.warehouseId}`,
    );
    const noPackingBin = await asAdmin(request(http).post('/api/v1/picking/tasks')).send({
      orderIds: [bareOrder.body.order.id],
    });
    check(
      noPackingBin.status === 409,
      'Сборка на складе без ячейки PACKING → 409',
      `status=${noPackingBin.status}`,
    );

    const task1 = await asAdmin(request(http).post('/api/v1/picking/tasks')).send({
      orderIds: [order1.id],
    });
    check(task1.status === 201 && task1.body.kind === 'SINGLE', 'Задание создано как SINGLE');
    check(task1.body.lines.length === 1, 'Строка задания выросла из резерва');
    check(task1.body.lines[0].binCode === 'S-01-01-01', 'В строке ячейка резерва', task1.body.lines[0].binCode);

    const orderAfterTask = await asAdmin(request(http).get(`/api/v1/orders/${order1.id}`));
    check(orderAfterTask.body.status === 'PICKING', 'Заказ перешёл в PICKING', orderAfterTask.body.status);

    const twice = await asAdmin(request(http).post('/api/v1/picking/tasks')).send({
      orderIds: [order1.id],
    });
    check(twice.status === 409, 'Тот же заказ во втором задании → 409', `status=${twice.status}`);

    const notReserved = await asAdmin(request(http).post('/api/v1/picking/tasks')).send({
      orderIds: [order1.id, order2.id],
    });
    check(notReserved.status === 409, 'Заказ не в RESERVED → 409', `status=${notReserved.status}`);

    const batch = await asAdmin(request(http).post('/api/v1/picking/tasks')).send({
      orderIds: [order4.id, order5.id],
    });
    check(batch.status === 201 && batch.body.kind === 'BATCH', 'Batch-задание из двух заказов');
    check(batch.body.orderIds.length === 2, 'В задании оба заказа');

    // ---------- 3. Скан ------------------------------------------------------
    console.log('\n3. Сканирование');
    const assigned = await asPicker1(request(http).post(`/api/v1/picking/tasks/${task1.body.id}/assign`)).send({});
    check(assigned.status === 201 && assigned.body.status === 'ASSIGNED', 'Сборщик взял задание');
    check(assigned.body.assigneeUserId === picker1.id, 'Исполнитель проставлен');

    const alienPicker = await asPicker2(
      request(http).post(`/api/v1/picking/tasks/${task1.body.id}/scan`),
    ).send({ barcode: '1000000000011', quantity: 1 });
    check(alienPicker.status === 403, 'Чужой сборщик не может сканировать → 403', `status=${alienPicker.status}`);

    const unknown = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task1.body.id}/scan`),
    ).send({ barcode: '9999999999999', quantity: 1 });
    check(unknown.status === 404, 'Неизвестный штрихкод → 404', `status=${unknown.status}`);

    const notInTask = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task1.body.id}/scan`),
    ).send({ barcode: '1000000000028', quantity: 1 });
    check(notInTask.status === 409, 'Товар не из задания → 409', `status=${notInTask.status}`);

    const tooMany = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task1.body.id}/scan`),
    ).send({ barcode: '1000000000011', quantity: 5 });
    check(tooMany.status === 409, 'Больше зарезервированного → 409', `status=${tooMany.status}`);

    const partial = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task1.body.id}/scan`),
    ).send({ barcode: '1000000000011', quantity: 1 });
    check(
      partial.status === 201 && partial.body.remaining === 1,
      'Частичный скан зачтён',
      `осталось: ${partial.body.remaining}`,
    );
    check(partial.body.task.status === 'IN_PROGRESS', 'Первый скан перевёл задание в работу');

    const notFinished = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task1.body.id}/complete`),
    ).send({});
    check(notFinished.status === 409, 'Завершение с несобранными строками → 409', `status=${notFinished.status}`);

    const finalScan = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task1.body.id}/scan`),
    ).send({ barcode: '1000000000011', quantity: 1 });
    check(finalScan.body.task.lines[0].status === 'PICKED', 'Строка закрыта как собранная');

    const stockA = (await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${skuA.id}`))).body.find(
      (s: { warehouseId: string }) => s.warehouseId === warehouse.id,
    );
    // Остальной RESERVED по этому SKU законно держат другие заказы (batch),
    // поэтому проверяем перешедшее количество, а резерв — по самому заказу ниже.
    check(
      stockA.byStatus.PICKED === 2,
      'Собранное перешло в PICKED',
      JSON.stringify(stockA.byStatus),
    );

    const completed = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task1.body.id}/complete`),
    ).send({});
    check(completed.status === 201 && completed.body.status === 'COMPLETED', 'Задание завершено');

    const orderPicked = await asAdmin(request(http).get(`/api/v1/orders/${order1.id}`));
    check(orderPicked.body.status === 'PICKED', 'Заказ перешёл в PICKED', orderPicked.body.status);

    const leftoverReservations: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM reservations WHERE owner_id = $1 AND status = 'ACTIVE'`,
      [order1.id],
    );
    check(leftoverReservations[0].count === '0', 'Резервы собранного заказа погашены', `осталось: ${leftoverReservations[0].count}`);

    // ---------- 4. Недобор с перерезервом ------------------------------------
    console.log('\n4. Недобор с перерезервом');
    const task2 = await asAdmin(request(http).post('/api/v1/picking/tasks')).send({
      orderIds: [order2.id],
    });
    await asPicker1(request(http).post(`/api/v1/picking/tasks/${task2.body.id}/assign`)).send({});

    const shortLine = task2.body.lines[0];
    const shorted = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task2.body.id}/lines/${shortLine.id}/short`),
    ).send({ reason: 'В ячейке пусто' });
    check(shorted.status === 201 && shorted.body.reallocated === true, 'Недостающее найдено в другой ячейке');
    check(shorted.body.orderFlagged === false, 'Заказ не помечен нехваткой — замена нашлась');

    const newLines = shorted.body.task.lines.filter(
      (l: { status: string; binCode: string }) => l.status === 'PENDING',
    );
    check(
      newLines.length === 1 && newLines[0].binCode === 'S-02-01-01',
      'В задание добавлена строка из другой ячейки',
      JSON.stringify(newLines.map((l: { binCode: string }) => l.binCode)),
    );

    const quarantined: Array<{ quantity: number }> = await dataSource.query(
      `SELECT quantity FROM stock WHERE sku_id = $1 AND bin_id = $2 AND status = 'QUARANTINE'`,
      [skuB.id, bin1.id],
    );
    check(
      quarantined.length === 1 && quarantined[0].quantity === 3,
      'Недостача ушла в карантин исходной ячейки, а не обратно в доступные',
      JSON.stringify(quarantined),
    );

    await asPicker1(request(http).post(`/api/v1/picking/tasks/${task2.body.id}/scan`)).send({
      barcode: '1000000000028',
      quantity: 3,
    });
    const task2Done = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task2.body.id}/complete`),
    ).send({});
    check(task2Done.status === 201, 'Задание с перерезервом завершено');

    // ---------- 5. Недобор без замены ---------------------------------------
    console.log('\n5. Недобор без замены');
    const task3 = await asAdmin(request(http).post('/api/v1/picking/tasks')).send({
      orderIds: [order3.id],
    });
    await asPicker1(request(http).post(`/api/v1/picking/tasks/${task3.body.id}/assign`)).send({});

    const noReplacement = await asPicker1(
      request(http).post(
        `/api/v1/picking/tasks/${task3.body.id}/lines/${task3.body.lines[0].id}/short`,
      ),
    ).send({ reason: 'Ячейка пуста, замены нет' });
    check(
      noReplacement.status === 201 && noReplacement.body.reallocated === false,
      'Замена не найдена',
      `reallocated=${noReplacement.body.reallocated}`,
    );
    check(noReplacement.body.orderFlagged === true, 'Заказ помечен нехваткой');

    const flagged = await asAdmin(request(http).get(`/api/v1/orders/${order3.id}`));
    check(flagged.body.hasShortage === true, 'Отметка нехватки видна в заказе');

    const task3Done = await asPicker1(
      request(http).post(`/api/v1/picking/tasks/${task3.body.id}/complete`),
    ).send({});
    check(
      task3Done.status === 201 && task3Done.body.status === 'COMPLETED',
      'Задание с недобором завершается',
    );
    const order3After = await asAdmin(request(http).get(`/api/v1/orders/${order3.id}`));
    check(
      order3After.body.status === 'PICKED',
      'Заказ с недобором всё равно уходит в PICKED — собранное надо упаковать',
      order3After.body.status,
    );

    // ---------- 6. Инварианты и доступ --------------------------------------
    console.log('\n6. Инварианты и доступ');
    const mismatch: Array<{ mismatches: string }> = await dataSource.query(`
      WITH ledger AS (
        SELECT sku_id, warehouse_id, to_bin_id AS bin_id, lot_id, to_status AS status, quantity AS qty
          FROM stock_movements WHERE to_bin_id IS NOT NULL
        UNION ALL
        SELECT sku_id, warehouse_id, from_bin_id, lot_id, from_status, -quantity
          FROM stock_movements WHERE from_bin_id IS NOT NULL
      ), agg AS (
        SELECT sku_id, warehouse_id, bin_id, lot_id, status, SUM(qty)::int AS qty
          FROM ledger GROUP BY 1,2,3,4,5
      )
      SELECT count(*)::text AS mismatches
        FROM agg FULL JOIN stock s
          ON s.sku_id = agg.sku_id AND s.warehouse_id = agg.warehouse_id
         AND s.bin_id = agg.bin_id AND s.lot_id IS NOT DISTINCT FROM agg.lot_id
         AND s.status = agg.status
       WHERE COALESCE(s.quantity, 0) <> COALESCE(agg.qty, 0)
    `);
    check(mismatch[0].mismatches === '0', 'Журнал сходится с остатком после всей сборки', `расхождений: ${mismatch[0].mismatches}`);

    const taskTransitions: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events
        WHERE action = 'STATE_TRANSITION' AND entity_type = 'PickTask'`,
    );
    check(Number(taskTransitions[0].count) >= 6, 'Переходы заданий в аудите', `записей: ${taskTransitions[0].count}`);

    await createUser('seller@ff.local', ['SELLER'], seller.id);
    const sellerToken = await login('seller@ff.local');
    const sellerTasks = await request(http)
      .get('/api/v1/picking/tasks')
      .set('Authorization', `Bearer ${sellerToken}`);
    check(sellerTasks.status === 403, 'Селлер не видит задания склада → 403', `status=${sellerTasks.status}`);

    const mine = await asPicker1(request(http).get('/api/v1/picking/tasks?mine=true'));
    check(
      mine.status === 200 && mine.body.length === 3,
      'Сборщик видит свои задания',
      `заданий: ${mine.body.length}`,
    );

    // ---------- 6. Отбор без скана ------------------------------------------
    // До починки единственным не-сканерным выходом со строки был «Недобор»:
    // сборщик с товаром В РУКАХ объявлял его отсутствующим, товар уезжал в
    // карантин, а на заказ садилась ложная нехватка.
    console.log('\n6. Ручное подтверждение отбора');

    await asPicker1(request(http).post(`/api/v1/picking/tasks/${batch.body.id}/assign`)).send({});
    const manualLine = batch.body.lines[0];
    const manualUrl = `/api/v1/picking/tasks/${batch.body.id}/lines/${manualLine.id}/pick`;

    const alienManual = await asPicker2(request(http).post(manualUrl)).send({ quantity: 1 });
    check(
      alienManual.status === 403,
      'Чужой сборщик не подтверждает отбор → 403',
      `status=${alienManual.status}`,
    );

    const overManual = await asPicker1(request(http).post(manualUrl)).send({
      quantity: manualLine.qtyRequested + 5,
    });
    check(
      overManual.status === 409,
      'Больше, чем осталось по строке → 409',
      `status=${overManual.status}`,
    );

    const stockBefore = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${manualLine.skuId}`))
    ).body[0];

    const manual = await asPicker1(request(http).post(manualUrl)).send({
      quantity: manualLine.qtyRequested,
    });
    check(
      manual.status === 201 && manual.body.remaining === 0,
      'Строка закрыта отбором без скана',
      `status=${manual.status}, осталось=${manual.body.remaining}`,
    );
    const manualAfter = manual.body.task.lines.find(
      (l: { id: string }) => l.id === manualLine.id,
    );
    check(manualAfter.status === 'PICKED', 'Строка помечена собранной, а не недобором');

    // Списание идёт тем же кодом, что и скан: отдельного пути в остаток
    // появиться не должно — иначе резервы и гонки обрабатывались бы дважды.
    const stockAfter = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${manualLine.skuId}`))
    ).body[0];
    // Общий остаток при сборке НЕ уменьшается: товар покидает склад при
    // передаче перевозчику, а сборка лишь двигает его между статусами.
    const pickedBefore = stockBefore.byStatus.PICKED ?? 0;
    const pickedAfter = stockAfter.byStatus.PICKED ?? 0;
    check(
      pickedAfter - pickedBefore === manualLine.qtyRequested,
      'Подтверждённое количество переведено в статус PICKED',
      `PICKED: ${pickedBefore} → ${pickedAfter}`,
    );
    check(
      stockAfter.total === stockBefore.total,
      'Общий остаток сборкой не уменьшается — товар ещё на складе',
      `было ${stockBefore.total}, стало ${stockAfter.total}`,
    );

    const manualQuarantine: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM stock
        WHERE sku_id = $1 AND status = 'QUARANTINE' AND quantity > 0`,
      [manualLine.skuId],
    );
    check(
      manualQuarantine[0].count === '0',
      'Ручной отбор не отправляет товар в карантин — в отличие от недобора',
      `строк карантина: ${manualQuarantine[0].count}`,
    );

    const manualComment: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM stock_movements
        WHERE sku_id = $1 AND reason = 'PICK' AND comment IS NOT NULL`,
      [manualLine.skuId],
    );
    check(
      Number(manualComment[0].count) >= 1,
      'Ручной отбор помечен комментарием в журнале движений',
      `помеченных движений: ${manualComment[0].count}`,
    );

  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\npicking e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
