// Сквозной тест этапа Orders против настоящего PostgreSQL.
//   npx ts-node -T test/orders.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import { Readable } from 'node:stream';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import ExcelJS from 'exceljs';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_orders_pg');
const PG_PORT = Number(process.env.FF_ORD_PGPORT || 5446);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_orders');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_orders`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    async function login(email: string): Promise<string> {
      const response = await request(http)
        .post('/api/v1/auth/login')
        .send({ email, password: PASSWORD });
      return response.body.accessToken as string;
    }

    await createUser('admin@ff.local', ['ADMIN'], null);
    await createUser('picker@ff.local', ['PICKER'], null);
    const adminToken = await login('admin@ff.local');
    const pickerToken = await login('picker@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);
    const asPicker = (r: request.Test) => r.set('Authorization', `Bearer ${pickerToken}`);

    // ---------- 1. Подготовка -----------------------------------------------
    console.log('\n1. Миграция и данные');
    check(
      applied.some((m) => m.name === 'Orders1786147200000'),
      'Миграция Orders применилась',
      `всего: ${applied.length}`,
    );
    const tables: Array<{ table_name: string }> = await dataSource.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`,
    );
    for (const expected of ['orders', 'order_lines']) {
      check(tables.some((t) => t.table_name === expected), `Таблица ${expected} создана`);
    }

    const sellerA = (
      await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'Акме' })
    ).body;
    const sellerB = (
      await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'BETA', legalName: 'Бета' })
    ).body;

    async function makeWarehouse(code: string) {
      const wh = (
        await asAdmin(request(http).post('/api/v1/warehouses')).send({ code, name: code })
      ).body;
      const bin = (
        await asAdmin(request(http).post('/api/v1/bin-locations')).send({
          warehouseId: wh.id,
          code: `${code}-S-01`,
          kind: 'STORAGE',
        })
      ).body;
      return { wh, bin };
    }
    const w1 = await makeWarehouse('TAS-1');
    const w2 = await makeWarehouse('SAM-1');

    async function makeSku(sellerId: string, code: string) {
      return (
        await asAdmin(request(http).post('/api/v1/skus')).send({ sellerId, skuCode: code, name: code })
      ).body;
    }
    const skuA = await makeSku(sellerA.id, 'A');
    const skuB = await makeSku(sellerA.id, 'B');
    const skuC = await makeSku(sellerA.id, 'C');
    const skuD = await makeSku(sellerA.id, 'D');
    const foreignSku = await makeSku(sellerB.id, 'FOREIGN');

    async function stockIn(skuId: string, place: { wh: { id: string }; bin: { id: string } }, quantity: number) {
      return asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
        skuId,
        warehouseId: place.wh.id,
        binId: place.bin.id,
        quantity,
      });
    }
    await stockIn(skuA.id, w1, 10);
    await stockIn(skuB.id, w2, 10);
    await stockIn(skuC.id, w1, 5);
    await stockIn(skuC.id, w2, 5);

    const baseOrder = {
      sellerId: sellerA.id,
      channel: 'uzum',
      recipientName: 'Иванов Иван',
      recipientPhone: '+998901234567',
      address: 'Ташкент, Амира Темура 1',
      region: 'Ташкент',
    };

    // ---------- 2. Приём и валидация ----------------------------------------
    console.log('\n2. Приём заказа');
    const pickerIntake = await asPicker(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'X-1',
      lines: [{ skuId: skuA.id, quantity: 1 }],
    });
    check(pickerIntake.status === 403, 'PICKER не принимает заказы → 403', `status=${pickerIntake.status}`);

    const foreignLine = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'X-BAD',
      lines: [{ skuId: foreignSku.id, quantity: 1 }],
    });
    check(foreignLine.status === 400, 'SKU чужого селлера → 400', `status=${foreignLine.status}`);

    const codWithoutCurrency = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'X-COD',
      codAmount: '150000.00',
      lines: [{ skuId: skuA.id, quantity: 1 }],
    });
    check(
      codWithoutCurrency.status === 400,
      'Наложенный платёж без валюты → 400',
      `status=${codWithoutCurrency.status}`,
    );

    const order1 = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'ORD-1',
      codAmount: '150000.00',
      currency: 'UZS',
      lines: [{ skuId: skuA.id, quantity: 2 }],
    });
    check(order1.status === 201, 'Заказ принят', `status=${order1.status}`);
    check(order1.body.order.status === 'RESERVED', 'Заказ дошёл до RESERVED', order1.body.order.status);
    check(order1.body.order.warehouseId === w1.wh.id, 'Назначен склад с остатком');
    check(order1.body.order.codAmount === '150000.00', 'Сумма COD хранится строкой', String(order1.body.order.codAmount));

    const stockA = (await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${skuA.id}`))).body[0];
    check(
      stockA.available === 8 && stockA.byStatus.RESERVED === 2,
      'Резерв заказа виден в остатках',
      JSON.stringify(stockA.byStatus),
    );

    // ---------- 3. Идемпотентность ------------------------------------------
    console.log('\n3. Повторная выгрузка канала');
    const repeat = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'ORD-1',
      codAmount: '150000.00',
      currency: 'UZS',
      lines: [{ skuId: skuA.id, quantity: 2 }],
    });
    check(repeat.body.duplicate === true, 'Повтор помечен как дубль');
    check(repeat.body.order.id === order1.body.order.id, 'Вернулся тот же заказ, а не новый');

    const orderCount: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM orders WHERE external_id = 'ORD-1'`,
    );
    check(orderCount[0].count === '1', 'В БД ровно один ORD-1', `записей: ${orderCount[0].count}`);

    const stockAfterRepeat = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${skuA.id}`))
    ).body[0];
    check(
      stockAfterRepeat.byStatus.RESERVED === 2,
      'Повтор не зарезервировал товар второй раз',
      JSON.stringify(stockAfterRepeat.byStatus),
    );

    // ---------- 4. Разделение между складами --------------------------------
    console.log('\n4. Разделение между складами');
    const split = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'ORD-2',
      lines: [
        { skuId: skuA.id, quantity: 1 },
        { skuId: skuB.id, quantity: 1 },
      ],
    });
    check(split.status === 201 && split.body.order.isSplit === true, 'Заказ помечен как разделённый');
    check(split.body.order.children.length === 2, 'Создано два дочерних заказа', `детей: ${split.body.order.children.length}`);
    check(
      split.body.order.lines.length === 2,
      'Заказ-контейнер сохранил все позиции канала',
      `позиций: ${split.body.order.lines.length}`,
    );
    const childWarehouses = split.body.order.children.map((c: { warehouseId: string }) => c.warehouseId);
    check(
      new Set(childWarehouses).size === 2 && childWarehouses.includes(w1.wh.id) && childWarehouses.includes(w2.wh.id),
      'Части уехали на разные склады',
      JSON.stringify(childWarehouses),
    );
    check(
      split.body.order.children.every((c: { status: string }) => c.status === 'RESERVED'),
      'Все части зарезервированы',
    );
    check(split.body.order.status === 'RESERVED', 'Контейнер тоже RESERVED', split.body.order.status);

    // ---------- 5. Нехватка остатка -----------------------------------------
    console.log('\n5. Нехватка остатка');
    const shortage = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'ORD-3',
      lines: [{ skuId: skuD.id, quantity: 3 }],
    });
    check(shortage.status === 201, 'Заказ без остатка всё равно принят (решение PM)');
    check(shortage.body.order.status === 'VALIDATED', 'Ждёт поставки в статусе VALIDATED', shortage.body.order.status);
    check(shortage.body.order.hasShortage === true, 'Помечена нехватка');
    check(
      shortage.body.shortages.length === 1 && shortage.body.shortages[0].available === 0,
      'В ответе перечислен дефицит',
      JSON.stringify(shortage.body.shortages),
    );

    // Позиция целиком уезжает на один склад: 8 штук есть суммарно (5+5),
    // но ни на одном складе по отдельности — это документированное упрощение.
    const acrossWarehouses = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'ORD-4',
      lines: [{ skuId: skuC.id, quantity: 8 }],
    });
    check(
      acrossWarehouses.body.order.hasShortage === true,
      'Позиция не дробится между складами — уходит в нехватку',
      `статус=${acrossWarehouses.body.order.status}`,
    );

    // ---------- 6. Повторный резерв после поставки --------------------------
    console.log('\n6. Резерв после поставки');
    await stockIn(skuD.id, w1, 5);
    const retried = await asAdmin(
      request(http).post(`/api/v1/orders/${shortage.body.order.id}/reserve`),
    ).send({});
    check(retried.status === 201 && retried.body.order.status === 'RESERVED', 'После прихода заказ зарезервирован', retried.body.order.status);
    check(retried.body.order.hasShortage === false, 'Отметка нехватки снята');

    const alreadyReserved = await asAdmin(
      request(http).post(`/api/v1/orders/${shortage.body.order.id}/reserve`),
    ).send({});
    check(alreadyReserved.status === 409, 'Повторный резерв уже зарезервированного → 409', `status=${alreadyReserved.status}`);

    // ---------- 7. Отмена ---------------------------------------------------
    console.log('\n7. Отмена и возврат остатка');
    const beforeCancel = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${skuA.id}`))
    ).body[0];

    const cancelled = await asAdmin(request(http).post(`/api/v1/orders/${order1.body.order.id}/cancel`)).send({
      reason: 'Клиент передумал',
    });
    check(cancelled.status === 201 && cancelled.body.status === 'CANCELLED', 'Заказ отменён из RESERVED');

    const afterCancel = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${skuA.id}`))
    ).body[0];
    check(
      afterCancel.available === beforeCancel.available + 2,
      'Отмена вернула товар в доступные',
      `${beforeCancel.available} → ${afterCancel.available}`,
    );

    const cancelAgain = await asAdmin(
      request(http).post(`/api/v1/orders/${order1.body.order.id}/cancel`),
    ).send({});
    check(
      cancelAgain.status === 409 && cancelAgain.body.error === 'INVALID_TRANSITION',
      'Повторная отмена отбита статусной моделью',
      `status=${cancelAgain.status}, error=${cancelAgain.body.error}`,
    );

    const cancelSplit = await asAdmin(
      request(http).post(`/api/v1/orders/${split.body.order.id}/cancel`),
    ).send({ reason: 'Отмена сборного заказа' });
    check(cancelSplit.status === 201 && cancelSplit.body.status === 'CANCELLED', 'Разделённый заказ отменён');
    check(
      cancelSplit.body.children.every((c: { status: string }) => c.status === 'CANCELLED'),
      'Дочерние заказы отменены вместе с ним',
      JSON.stringify(cancelSplit.body.children.map((c: { status: string }) => c.status)),
    );

    const stockB = (await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${skuB.id}`))).body[0];
    check(
      stockB.available === 10 && !stockB.byStatus.RESERVED,
      'Резерв дочернего заказа снят',
      JSON.stringify(stockB.byStatus),
    );

    // ---------- 8. Инварианты и доступ --------------------------------------
    console.log('\n8. Инварианты и доступ');
    // Инвариант, а не магическое число: у отменённых заказов не должно остаться
    // ни одного активного резерва, и при этом живые резервы обязаны существовать —
    // иначе проверка была бы пустой.
    const leaked: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count
         FROM reservations r
         JOIN orders o ON o.id::text = r.owner_id
        WHERE r.status = 'ACTIVE' AND o.status = 'CANCELLED'`,
    );
    check(leaked[0].count === '0', 'У отменённых заказов не осталось активных резервов', `утечек: ${leaked[0].count}`);

    const stillActive: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM reservations WHERE status = 'ACTIVE'`,
    );
    check(
      Number(stillActive[0].count) > 0,
      'Резервы действующих заказов остались на месте',
      `активных строк: ${stillActive[0].count}`,
    );

    const mismatch: Array<{ mismatches: string }> = await dataSource.query(`
      WITH ledger AS (
        SELECT sku_id, warehouse_id, to_bin_id AS bin_id, lot_id, to_status AS status, quantity AS qty
          FROM stock_movements WHERE to_bin_id IS NOT NULL
        UNION ALL
        SELECT sku_id, warehouse_id, from_bin_id, lot_id, from_status, -quantity
          FROM stock_movements WHERE from_bin_id IS NOT NULL
      ), agg AS (
        SELECT sku_id, warehouse_id, bin_id, lot_id, status, SUM(qty)::int AS qty
          FROM ledger GROUP BY 1,2,3,4,5
      )
      SELECT count(*)::text AS mismatches
        FROM agg FULL JOIN stock s
          ON s.sku_id = agg.sku_id AND s.warehouse_id = agg.warehouse_id
         AND s.bin_id = agg.bin_id AND s.lot_id IS NOT DISTINCT FROM agg.lot_id
         AND s.status = agg.status
       WHERE COALESCE(s.quantity, 0) <> COALESCE(agg.qty, 0)
    `);
    check(mismatch[0].mismatches === '0', 'Журнал движений сходится с остатком', `расхождений: ${mismatch[0].mismatches}`);

    const orderTransitions: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events
        WHERE action = 'STATE_TRANSITION' AND entity_type = 'Order'`,
    );
    check(Number(orderTransitions[0].count) >= 10, 'Переходы заказов записаны в аудит', `записей: ${orderTransitions[0].count}`);

    await createUser('seller-b@ff.local', ['SELLER'], sellerB.id);
    const foreignToken = await login('seller-b@ff.local');
    const alien = await request(http)
      .get(`/api/v1/orders/${split.body.order.id}`)
      .set('Authorization', `Bearer ${foreignToken}`);
    check(alien.status === 404, 'Чужой заказ для селлера → 404', `status=${alien.status}`);

    const alienList = await request(http)
      .get('/api/v1/orders')
      .set('Authorization', `Bearer ${foreignToken}`);
    // Список заказов отдаёт СТРАНИЦУ ({rows,total,page,pageSize}), а не голый
    // массив: без общего числа строк список невозможно листать честно.
    check(
      alienList.status === 200 && alienList.body.rows.length === 0 && alienList.body.total === 0,
      'В списке заказов чужие не видны',
      `записей: ${alienList.body.total}`,
    );

    const ownList = await asAdmin(request(http).get('/api/v1/orders'));
    check(
      ownList.status === 200 &&
        Array.isArray(ownList.body.rows) &&
        ownList.body.rows.every((o: { parentOrderId: string | null }) => o.parentOrderId === null),
      'В списке только заказы канала, дочерние не дублируются',
      `записей: ${ownList.body.total}`,
    );
    check(
      typeof ownList.body.total === 'number' &&
        ownList.body.page === 1 &&
        typeof ownList.body.pageSize === 'number' &&
        ownList.body.total >= ownList.body.rows.length,
      'Список заказов — конверт страницы с общим числом строк',
      JSON.stringify({ total: ownList.body.total, page: ownList.body.page, pageSize: ownList.body.pageSize }),
    );

    interface ListedOrder {
      externalId: string;
      createdAt: string;
      lines: Array<{ skuCode: string; skuName: string; quantity: number }>;
    }
    const listed: ListedOrder[] = ownList.body.rows;
    check(
      listed.every((o) => typeof o.createdAt === 'string' && !Number.isNaN(Date.parse(o.createdAt))),
      'В списке есть время создания заказа',
      listed[0]?.createdAt ?? '—',
    );
    check(
      listed.every((o) => o.lines.every((line) => Boolean(line.skuCode) && Boolean(line.skuName))),
      'В позициях списка есть артикул и название товара',
      JSON.stringify(listed[0]?.lines?.[0] ?? null),
    );

    // ---------- 9. Загрузка заказов файлом ----------------------------------
    console.log('\n9. Загрузка заказов файлом');
    const pickerImport = await asPicker(request(http).post('/api/v1/orders/import')).send({
      sellerId: sellerA.id,
      channel: 'uzum',
      orders: [
        {
          fileLine: 2,
          externalId: 'IMP-X',
          recipientName: 'Тест',
          recipientPhone: '+998900000000',
          address: 'Ташкент',
          lines: [{ skuCode: 'A', quantity: 1 }],
        },
      ],
    });
    check(pickerImport.status === 403, 'PICKER не загружает заказы → 403', `status=${pickerImport.status}`);

    const recipient = {
      recipientName: 'Петров Пётр',
      recipientPhone: '+998901112233',
      address: 'Ташкент, Мирабад 5',
    };
    const imported = await asAdmin(request(http).post('/api/v1/orders/import')).send({
      sellerId: sellerA.id,
      // Тот же канал, что и у ORD-1: естественный ключ включает канал, и без
      // совпадения повтор не был бы повтором.
      channel: 'uzum',
      orders: [
        {
          fileLine: 2,
          externalId: 'IMP-1',
          ...recipient,
          // Артикул в другом регистре — сопоставление не должно быть чувствительным.
          lines: [
            { skuCode: 'a', quantity: 2 },
            { skuCode: 'A', quantity: 1 },
          ],
        },
        {
          fileLine: 5,
          externalId: 'IMP-2',
          ...recipient,
          lines: [{ skuCode: 'НЕТ-ТАКОГО', quantity: 1 }],
        },
        { fileLine: 7, externalId: 'ORD-1', ...recipient, lines: [{ skuCode: 'A', quantity: 1 }] },
        {
          fileLine: 9,
          externalId: 'IMP-COD',
          ...recipient,
          codAmount: '50000.00',
          lines: [{ skuCode: 'A', quantity: 1 }],
        },
        { fileLine: 11, externalId: 'IMP-3', ...recipient, lines: [{ skuCode: 'A', quantity: 99 }] },
      ],
    });

    interface ImportRow {
      row: number;
      externalId: string;
      outcome: string;
      orderId: string | null;
      status: string | null;
      hasShortage: boolean;
      message: string | null;
    }
    const importBody: { created: number; duplicates: number; failed: number; rows: ImportRow[] } =
      imported.body;
    const byExternal = new Map(importBody.rows.map((row) => [row.externalId, row]));

    check(imported.status === 201, 'Файл принят', `status=${imported.status}`);
    check(
      importBody.created === 2 && importBody.duplicates === 1 && importBody.failed === 2,
      'Итог загрузки: 2 новых, 1 дубль, 2 с ошибкой',
      JSON.stringify({
        created: importBody.created,
        duplicates: importBody.duplicates,
        failed: importBody.failed,
      }),
    );
    check(
      importBody.rows.map((row) => row.row).join(',') === '2,5,7,9,11',
      'Отчёт указывает на строки файла, а не на позиции в массиве',
      importBody.rows.map((row) => row.row).join(','),
    );
    check(
      byExternal.get('IMP-2')?.outcome === 'FAILED' &&
        (byExternal.get('IMP-2')?.message ?? '').includes('НЕТ-ТАКОГО'),
      'Неизвестный артикул назван в сообщении об ошибке',
      byExternal.get('IMP-2')?.message ?? '—',
    );
    check(
      byExternal.get('IMP-COD')?.outcome === 'FAILED' &&
        (byExternal.get('IMP-COD')?.message ?? '').includes('валют'),
      'Сумма наложенного платежа без валюты отбита с понятной причиной',
      byExternal.get('IMP-COD')?.message ?? '—',
    );
    check(byExternal.get('ORD-1')?.outcome === 'DUPLICATE', 'Существующий номер помечен дублем');
    check(
      byExternal.get('IMP-3')?.hasShortage === true &&
        (byExternal.get('IMP-3')?.message ?? '').includes('Не хватает остатка'),
      'Заказ без остатка принят и помечен ожиданием поставки',
      byExternal.get('IMP-3')?.message ?? '—',
    );

    const impOne = byExternal.get('IMP-1');
    check(impOne?.outcome === 'CREATED' && impOne?.status === 'RESERVED', 'Заказ из файла зарезервирован', impOne?.status ?? '—');
    check(
      (impOne?.message ?? '').includes('сложены'),
      'Повтор одного артикула в заказе сложен, и это сказано в отчёте',
      impOne?.message ?? '—',
    );

    const impOneOrder = await asAdmin(request(http).get(`/api/v1/orders/${impOne?.orderId}`));
    check(
      impOneOrder.body.lines.length === 1 && impOneOrder.body.lines[0].quantity === 3,
      'В заказе одна позиция с суммарным количеством 3',
      JSON.stringify(impOneOrder.body.lines.map((l: { skuCode: string; quantity: number }) => l)),
    );

    const ordOneCount: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM orders WHERE external_id = 'ORD-1'`,
    );
    check(ordOneCount[0].count === '1', 'Дубль из файла не создал второй ORD-1', `записей: ${ordOneCount[0].count}`);

    const failedPersisted: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM orders WHERE external_id IN ('IMP-2', 'IMP-COD')`,
    );
    check(
      failedPersisted[0].count === '0',
      'Ошибочные строки файла не оставили заказов в базе',
      `записей: ${failedPersisted[0].count}`,
    );

    const importAudit: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events WHERE entity_type = 'OrderImport'`,
    );
    check(importAudit[0].count === '1', 'Загрузка записана в аудит', `записей: ${importAudit[0].count}`);

    const repeatImport = await asAdmin(request(http).post('/api/v1/orders/import')).send({
      sellerId: sellerA.id,
      channel: 'uzum',
      orders: [{ fileLine: 2, externalId: 'IMP-1', ...recipient, lines: [{ skuCode: 'A', quantity: 3 }] }],
    });
    check(
      repeatImport.body.duplicates === 1 && repeatImport.body.created === 0,
      'Повторная загрузка того же файла не плодит заказы',
      JSON.stringify({ created: repeatImport.body.created, duplicates: repeatImport.body.duplicates }),
    );

    // ---------- 10. Сплит с нехваткой → поставка → повторный резерв ----------
    // Самый дорогой сценарий: контейнер хранит ВСЕ позиции канала, а часть из
    // них уже исполняет живой ребёнок. Повторный резерв обязан считать разницу,
    // иначе он резервирует поверх ребёнка (товар уедет дважды) и пытается
    // создать часть с уже занятым суффиксом.
    console.log('\n10. Повторный резерв разделённого заказа');
    const skuE = await makeSku(sellerA.id, 'E');
    const skuF = await makeSku(sellerA.id, 'F');
    await stockIn(skuE.id, w1, 10);

    const splitShort = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'SPLIT-1',
      lines: [
        { skuId: skuE.id, quantity: 2 },
        { skuId: skuF.id, quantity: 2 },
      ],
    });
    const containerId = splitShort.body.order.id as string;
    check(
      splitShort.body.order.isSplit === true &&
        splitShort.body.order.status === 'VALIDATED' &&
        splitShort.body.order.hasShortage === true,
      'Часть покрыта, часть нет: контейнер ждёт поставки',
      `status=${splitShort.body.order.status}, shortage=${splitShort.body.order.hasShortage}`,
    );
    check(
      splitShort.body.order.children.length === 1 &&
        splitShort.body.order.children[0].externalId === 'SPLIT-1#2',
      'Создана одна часть с суффиксом #2',
      JSON.stringify(splitShort.body.order.children.map((c: { externalId: string }) => c.externalId)),
    );

    async function reservedFor(skuId: string): Promise<number> {
      const rows: Array<{ reserved: string }> = await dataSource.query(
        `SELECT COALESCE(SUM(quantity), 0)::text AS reserved
           FROM stock WHERE sku_id = $1 AND status = 'RESERVED'`,
        [skuId],
      );
      return Number(rows[0].reserved);
    }
    check(await reservedFor(skuE.id) === 2, 'Покрытая позиция зарезервирована один раз');

    // Пришла поставка недостающей позиции — на ДРУГОЙ склад.
    await stockIn(skuF.id, w2, 5);
    const reReserve = await asAdmin(
      request(http).post(`/api/v1/orders/${containerId}/reserve`),
    ).send({});
    check(
      reReserve.status === 201 && reReserve.body.order.status === 'RESERVED',
      'После поставки контейнер обеспечен целиком',
      `status=${reReserve.status}/${reReserve.body.order.status}`,
    );
    check(reReserve.body.order.hasShortage === false, 'Отметка нехватки снята с контейнера');
    check(
      await reservedFor(skuE.id) === 2,
      'Повторный резерв НЕ зарезервировал позицию живого ребёнка второй раз',
      `в резерве: ${await reservedFor(skuE.id)}`,
    );
    check(await reservedFor(skuF.id) === 2, 'Недостающая позиция зарезервирована после поставки');

    const containerReservations: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM reservations
        WHERE owner_type = 'ORDER' AND owner_id = $1 AND status = 'ACTIVE'`,
      [containerId],
    );
    check(
      containerReservations[0].count === '0',
      'На контейнер резерв не вешается — держат части',
      `резервов: ${containerReservations[0].count}`,
    );

    const children2: Array<{ external_id: string }> = await dataSource.query(
      `SELECT external_id FROM orders WHERE parent_order_id = $1 ORDER BY external_id`,
      [containerId],
    );
    check(
      children2.map((c) => c.external_id).join(',') === 'SPLIT-1#2,SPLIT-1#3',
      'Новая часть получила СЛЕДУЮЩИЙ суффикс, а не занятый #2',
      children2.map((c) => c.external_id).join(','),
    );

    // ---------- 11. Статус контейнера — представление статусов частей --------
    // Двигаем части мимо сервиса: сборка и упаковка проверяются своими тестами,
    // здесь нужен только эффект на ЧТЕНИЕ статуса контейнера.
    console.log('\n11. Статус разделённого заказа');
    await dataSource.query(`UPDATE orders SET status = 'PICKING' WHERE parent_order_id = $1`, [
      containerId,
    ]);
    const containerPicking = await asAdmin(request(http).get(`/api/v1/orders/${containerId}`));
    check(
      containerPicking.body.status === 'PICKING',
      'Контейнер показывает статус самой отстающей части',
      containerPicking.body.status,
    );

    const totalsPicking = await asAdmin(request(http).get('/api/v1/orders/totals'));
    const pickingCount = (totalsPicking.body.byStatus as Array<{ status: string; count: number }>)
      .find((item) => item.status === 'PICKING')?.count;
    check(pickingCount === 1, 'Итоги считают контейнер в той же колонке', `PICKING=${pickingCount}`);

    const pickingList = await asAdmin(request(http).get('/api/v1/orders?status=PICKING'));
    check(
      pickingList.body.total === 1 && pickingList.body.rows[0]?.id === containerId,
      'Фильтр по статусу отдаёт ровно то, что посчитали итоги',
      `total=${pickingList.body.total}`,
    );

    // Одна часть уехала дальше другой — контейнер равняется по отстающей.
    await dataSource.query(
      `UPDATE orders SET status = 'DELIVERED' WHERE external_id = 'SPLIT-1#2'`,
    );
    await dataSource.query(`UPDATE orders SET status = 'PICKED' WHERE external_id = 'SPLIT-1#3'`);
    const containerMixed = await asAdmin(request(http).get(`/api/v1/orders/${containerId}`));
    check(
      containerMixed.body.status === 'PICKED',
      'Пока хоть одна часть в работе, контейнер показывает её',
      containerMixed.body.status,
    );

    await dataSource.query(
      `UPDATE orders SET status = 'DELIVERED' WHERE parent_order_id = $1`,
      [containerId],
    );
    const containerDone = await asAdmin(request(http).get(`/api/v1/orders/${containerId}`));
    check(
      containerDone.body.status === 'DELIVERED',
      'Все части доставлены — контейнер больше не висит в RESERVED',
      containerDone.body.status,
    );
    const containerRow: Array<{ status: string }> = await dataSource.query(
      `SELECT status FROM orders WHERE id = $1`,
      [containerId],
    );
    check(
      containerRow[0].status === 'RESERVED',
      'Канонический статус в БД не тронут — это представление, а не запись',
      containerRow[0].status,
    );

    // ---------- 12. Пустые значения в обязательных полях ---------------------
    console.log('\n12. Отказ вместо пятисотки');
    const nullName = await asAdmin(
      request(http).patch(`/api/v1/orders/${shortage.body.order.id}`),
    ).send({ recipientName: null });
    check(nullName.status === 400, 'PATCH с null в обязательном поле → 400', `status=${nullName.status}`);

    const codNullCurrency = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'X-COD-NULL',
      codAmount: '1000.00',
      currency: null,
      lines: [{ skuId: skuA.id, quantity: 1 }],
    });
    check(
      codNullCurrency.status === 400,
      'Сумма COD с валютой null → 400, а не CHECK-нарушение',
      `status=${codNullCurrency.status}`,
    );

    const currencyNullCod = await asAdmin(request(http).post('/api/v1/orders')).send({
      ...baseOrder,
      externalId: 'X-COD-NULL-2',
      codAmount: null,
      currency: 'UZS',
      lines: [{ skuId: skuA.id, quantity: 1 }],
    });
    check(
      currencyNullCod.status === 400,
      'Валюта без суммы → 400',
      `status=${currencyNullCod.status}`,
    );

    // ---------- 13. Матрица прав в выгрузке и в правке -----------------------
    console.log('\n13. Права на колонки');
    async function exportHeaders(token: string): Promise<string[]> {
      const response = await request(http)
        .get('/api/v1/orders/export')
        .set('Authorization', `Bearer ${token}`)
        .responseType('blob');
      // Через поток, а не `load(buffer)`: exceljs объявляет свой `Buffer extends
      // ArrayBuffer`, и Node'овский буфер в него не приводится.
      const source = new Readable();
      source.push(response.body as Buffer);
      source.push(null);
      const workbook = await new ExcelJS.Workbook().xlsx.read(source);
      const sheet = workbook.worksheets[0];
      let headers: string[] = [];
      sheet.eachRow((row) => {
        const values = (row.values as Array<string | undefined>).filter(
          (value): value is string => typeof value === 'string',
        );
        if (values.includes('Код FF')) headers = values;
      });
      return headers;
    }

    const adminHeaders = await exportHeaders(adminToken);
    check(
      adminHeaders.includes('COD') && adminHeaders.includes('Валюта'),
      'Админ выгружает файл с суммами COD',
      adminHeaders.join('|'),
    );
    const pickerHeaders = await exportHeaders(pickerToken);
    check(
      pickerHeaders.length > 0 &&
        !pickerHeaders.includes('COD') &&
        !pickerHeaders.includes('Валюта'),
      'Закрытые матрицей колонки не попадают в выгрузку сборщика',
      pickerHeaders.join('|'),
    );
    check(
      pickerHeaders.includes('Получатель'),
      'Открытые колонки в выгрузке сборщика остались',
      pickerHeaders.join('|'),
    );

    await createUser('operator@ff.local', ['WAREHOUSE_OPERATOR'], null);
    const operatorToken = await login('operator@ff.local');
    const asOperator = (r: request.Test) => r.set('Authorization', `Bearer ${operatorToken}`);

    // Матрица правится ручкой, а не INSERT'ом: она кэшируется на 60 секунд, и
    // строка, вставленная мимо сервиса, вступила бы в силу уже после теста.
    await asAdmin(request(http).put('/api/v1/field-permissions')).send({
      permissions: [
        {
          role: 'WAREHOUSE_OPERATOR',
          entity: 'order',
          field: 'address',
          canView: true,
          canEdit: false,
          canDelete: false,
        },
      ],
    });

    const forbiddenPatch = await asOperator(
      request(http).patch(`/api/v1/orders/${shortage.body.order.id}`),
    ).send({ address: 'Ташкент, Юнусабад 7' });
    check(
      forbiddenPatch.status === 403,
      'Закрытое на изменение поле не пишется прямым PATCH',
      `status=${forbiddenPatch.status}`,
    );

    const allowedPatch = await asOperator(
      request(http).patch(`/api/v1/orders/${shortage.body.order.id}`),
    ).send({ region: 'Самарканд' });
    check(
      allowedPatch.status === 200 && allowedPatch.body.region === 'Самарканд',
      'Открытое поле правится как прежде',
      `status=${allowedPatch.status}`,
    );

    // ---------- 14. Уехавший заказ: доставочные поля заморожены -------------
    // Статус двигаем прямым UPDATE, как в разделе 11: дорогу до DISPATCHED через
    // сборку и упаковку проверяют свои наборы, здесь нужен только эффект на PATCH.
    console.log('\n14. Правка карточки уехавшего заказа');
    const frozenId = shortage.body.order.id as string;
    const reportCategory = (
      await asAdmin(request(http).post('/api/v1/order-categories')).send({
        code: 'REPORT_ONLY',
        name: 'Переклассификация для отчёта',
      })
    ).body as { id: string };

    async function setOrderStatus(status: string): Promise<void> {
      await dataSource.query(`UPDATE orders SET status = $2 WHERE id = $1`, [frozenId, status]);
    }
    const patchFrozen = (body: Record<string, unknown>) =>
      asAdmin(request(http).patch(`/api/v1/orders/${frozenId}`)).send(body);

    await setOrderStatus('DISPATCHED');
    const dispatchedAddress = await patchFrozen({ address: 'Ташкент, Чиланзар 12' });
    check(
      dispatchedAddress.status === 409,
      'Адрес выданного со склада заказа (DISPATCHED) не правится → 409',
      `status=${dispatchedAddress.status}`,
    );
    check(
      String(dispatchedAddress.body.message).includes('этикетка'),
      'Отказ объясняет причину, а не просто называет статус',
      String(dispatchedAddress.body.message),
    );
    const addressRow: Array<{ address: string }> = await dataSource.query(
      `SELECT address FROM orders WHERE id = $1`,
      [frozenId],
    );
    check(
      addressRow[0].address !== 'Ташкент, Чиланзар 12',
      'Адрес в базе остался прежним',
      addressRow[0].address,
    );

    const dispatchedPhone = await patchFrozen({ recipientPhone: '+998900000001' });
    check(
      dispatchedPhone.status === 409,
      'Телефон получателя после выдачи тоже заморожен',
      `status=${dispatchedPhone.status}`,
    );
    const dispatchedWeight = await patchFrozen({ weightKg: '3.500' });
    check(
      dispatchedWeight.status === 409,
      'Вес после выдачи заморожен: по нему уже посчитан тариф',
      `status=${dispatchedWeight.status}`,
    );

    const dispatchedCategory = await patchFrozen({ categoryId: reportCategory.id });
    check(
      dispatchedCategory.status === 200 && dispatchedCategory.body.categoryId === reportCategory.id,
      'Категорию уехавшего заказа менять по-прежнему можно',
      `status=${dispatchedCategory.status}`,
    );

    await setOrderStatus('SHIPPED');
    const shippedName = await patchFrozen({ recipientName: 'Сидоров Сидор' });
    check(
      shippedName.status === 409,
      'Получатель принятого перевозчиком заказа (SHIPPED) не правится → 409',
      `status=${shippedName.status}`,
    );

    await setOrderStatus('RESERVED');
    const liveAddress = await patchFrozen({ address: 'Ташкент, Чиланзар 12' });
    check(
      liveAddress.status === 200 && liveAddress.body.address === 'Ташкент, Чиланзар 12',
      'Пока заказ на складе, адрес правится как прежде',
      `status=${liveAddress.status}`,
    );

    // ---------- 15. Ручка сканера: кривой параметр — 400, а не 500 ----------
    console.log('\n15. Поиск заказа по коду');
    const frozenOrder = (await asAdmin(request(http).get(`/api/v1/orders/${frozenId}`))).body as {
      orderCode: string;
    };
    const byCode = (query: string) => asAdmin(request(http).get(`/api/v1/orders/by-code${query}`));

    const scanOk = await byCode(`?code=${encodeURIComponent(frozenOrder.orderCode)}`);
    check(
      scanOk.status === 200 && scanOk.body.id === frozenId,
      'Штатный скан по FF-коду открывает заказ',
      `status=${scanOk.status}, code=${frozenOrder.orderCode}`,
    );
    const scanLower = await byCode(`?code=${encodeURIComponent(frozenOrder.orderCode.toLowerCase())}`);
    check(
      scanLower.status === 200 && scanLower.body.id === frozenId,
      'Регистр кода по-прежнему не важен',
      `status=${scanLower.status}`,
    );

    // Express складывает повторённый параметр в массив, а `code[$ne]` — в объект:
    // до правки оба доезжали до `.trim()` и отвечали 500 INTERNAL_ERROR.
    const scanRepeated = await byCode('?code=A&code=B');
    check(
      scanRepeated.status === 400,
      'Повторённый параметр code → 400, а не 500',
      `status=${scanRepeated.status}, error=${scanRepeated.body.error}`,
    );
    const scanObject = await byCode('?code[$ne]=x');
    check(
      scanObject.status === 400,
      'Объект вместо строки в code → 400',
      `status=${scanObject.status}, error=${scanObject.body.error}`,
    );
    const scanMissing = await byCode('');
    check(
      scanMissing.status === 400,
      'Запрос без code → 400 с объяснением',
      `status=${scanMissing.status}`,
    );
    const scanBlank = await byCode('?code=%20%20');
    check(
      scanBlank.status === 400,
      'Код из одних пробелов → 400',
      `status=${scanBlank.status}`,
    );
    const scanUnknown = await byCode('?code=FF-YES9999999');
    check(
      scanUnknown.status === 404,
      'Неизвестный код → 404, как и раньше',
      `status=${scanUnknown.status}`,
    );
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\norders e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
