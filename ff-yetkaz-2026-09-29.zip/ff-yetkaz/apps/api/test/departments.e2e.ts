// Сквозной тест модуля Departments (отделы + привязка сотрудника) против
// настоящего PostgreSQL.
//   npx ts-node -T test/departments.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_departments_pg');
const PG_PORT = Number(process.env.FF_DEP_PGPORT || 5449);
const PASSWORD = 'Sklad-2026-Admin!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_departments');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_departments`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    await dataSource.runMigrations();

    const passwordHash = await passwords.hash(PASSWORD);
    await dataSource.transaction(async (em) => {
      const users = em.getRepository(UserEntity);
      const admin = await users.save(
        users.create({
          email: 'admin@ff.local',
          passwordHash,
          fullName: 'Админ',
          isActive: true,
          sellerId: null,
        }),
      );
      await em.getRepository(UserRoleEntity).insert({ userId: admin.id, role: 'ADMIN' });
    });

    async function login(email: string, password = PASSWORD): Promise<string | null> {
      const response = await request(http).post('/api/v1/auth/login').send({ email, password });
      return (response.body.accessToken as string) ?? null;
    }
    const adminToken = await login('admin@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);

    console.log('\n1. Стартовый набор отделов из миграции');
    const seeded = await asAdmin(request(http).get('/api/v1/departments'));
    check(seeded.status === 200, 'Список отделов доступен ADMIN', `status=${seeded.status}`);
    const codes = (seeded.body as Array<{ code: string }>).map((d) => d.code).sort();
    check(
      JSON.stringify(codes) === JSON.stringify(['FINANCE', 'OFFICE', 'WAREHOUSE']),
      'Засеяны WAREHOUSE / OFFICE / FINANCE',
      JSON.stringify(codes),
    );
    const warehouse = (seeded.body as Array<{ id: string; code: string; memberCount: number }>).find(
      (d) => d.code === 'WAREHOUSE',
    )!;
    const office = (seeded.body as Array<{ id: string; code: string }>).find((d) => d.code === 'OFFICE')!;
    check(warehouse.memberCount === 0, 'У пустого отдела memberCount = 0', String(warehouse.memberCount));

    console.log('\n2. Создание отдела');
    const created = await asAdmin(request(http).post('/api/v1/departments')).send({
      code: 'SUPPORT',
      name: 'Поддержка',
      description: 'Работа с обращениями',
    });
    check(created.status === 201, 'Отдел создан', `status=${created.status}`);
    check(created.body.code === 'SUPPORT' && created.body.isActive === true, 'Код и признак активности верны');

    const dupCode = await asAdmin(request(http).post('/api/v1/departments')).send({
      code: 'SUPPORT',
      name: 'Дубликат',
    });
    check(dupCode.status === 409, 'Повторный код → 409', `status=${dupCode.status}`);

    const badCode = await asAdmin(request(http).post('/api/v1/departments')).send({
      code: 'support',
      name: 'Строчными нельзя',
    });
    check(badCode.status === 400, 'Код в нижнем регистре → 400', `status=${badCode.status}`);

    console.log('\n3. Переименование и отключение');
    const renamed = await asAdmin(request(http).patch(`/api/v1/departments/${created.body.id}`)).send({
      name: 'Клиентская поддержка',
    });
    check(renamed.status === 200 && renamed.body.name === 'Клиентская поддержка', 'Отдел переименован');

    const disabled = await asAdmin(request(http).patch(`/api/v1/departments/${created.body.id}`)).send({
      isActive: false,
    });
    check(disabled.status === 200 && disabled.body.isActive === false, 'Отдел отключён');

    console.log('\n4. Привязка сотрудника к отделу');
    const employee = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'operator@ff.local',
      fullName: 'Оператор Олим',
      password: 'Sklad-Operator-2026!',
      roles: ['WAREHOUSE_OPERATOR'],
      departmentId: warehouse.id,
    });
    check(employee.status === 201, 'Сотрудник с отделом создан', `status=${employee.status}`);
    check(
      employee.body.departmentId === warehouse.id && employee.body.departmentName === 'Склад',
      'В ответе есть отдел сотрудника',
      `${employee.body.departmentId} / ${employee.body.departmentName}`,
    );

    const afterAssign = await asAdmin(request(http).get('/api/v1/departments'));
    const whAfter = (afterAssign.body as Array<{ code: string; memberCount: number }>).find(
      (d) => d.code === 'WAREHOUSE',
    )!;
    check(whAfter.memberCount === 1, 'memberCount отдела вырос до 1', String(whAfter.memberCount));

    console.log('\n5. Отключённый отдел назначать нельзя');
    const toDisabled = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'nope@ff.local',
      fullName: 'Никак',
      password: 'Sklad-Nikak-2026!',
      roles: ['PICKER'],
      departmentId: created.body.id, // SUPPORT отключён выше
    });
    check(toDisabled.status === 400, 'Назначение в отключённый отдел → 400', `status=${toDisabled.status}`);

    console.log('\n6. Переназначение и снятие отдела');
    // Переназначение с уже заполненного отдела ловит TypeORM-ловушку «связь бьёт FK»:
    // save() загруженной сущности берёт department_id из объекта отношения, а не из
    // колонки. Поэтому и назначение на другой отдел, и снятие идут update() по FK.
    const reassigned = await asAdmin(request(http).patch(`/api/v1/users/${employee.body.id}`)).send({
      departmentId: office.id,
    });
    check(
      reassigned.status === 200 && reassigned.body.departmentName === 'Офис',
      'Отдел переназначен (Склад → Офис)',
      `status=${reassigned.status} dep=${reassigned.body.departmentName}`,
    );

    const cleared = await asAdmin(request(http).patch(`/api/v1/users/${employee.body.id}`)).send({
      departmentId: null,
    });
    check(
      cleared.status === 200 && cleared.body.departmentId === null && cleared.body.departmentName === null,
      'Отдел снят (departmentId = null)',
      `status=${cleared.status} dep=${cleared.body.departmentId}`,
    );

    console.log('\n7. Селлеру отдел не положен');
    const seller = await asAdmin(request(http).post('/api/v1/sellers')).send({
      code: 'S-DEP-1',
      legalName: 'ООО Тест-Селлер',
    });
    if (seller.status === 201) {
      const sellerUser = await asAdmin(request(http).post('/api/v1/users')).send({
        email: 'seller@ff.local',
        fullName: 'Селлер Клиент',
        password: 'Seller-Client-2026!',
        roles: ['SELLER'],
        sellerId: seller.body.id,
        departmentId: warehouse.id,
      });
      check(sellerUser.status === 400, 'SELLER + отдел → 400', `status=${sellerUser.status}`);
    } else {
      console.log(`  SKIP  создание селлера вернуло ${seller.status} — проверку SELLER+отдел пропускаем`);
    }

    console.log('\n8. Права доступа');
    const picker = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'picker2@ff.local',
      fullName: 'Сборщик',
      password: 'Sklad-Picker-2026!',
      roles: ['PICKER'],
    });
    const pickerToken = await login('picker2@ff.local', 'Sklad-Picker-2026!');
    const pickerForbidden = await request(http)
      .get('/api/v1/departments')
      .set('Authorization', `Bearer ${pickerToken}`);
    check(
      picker.status === 201 && pickerForbidden.status === 403,
      'Не-ADMIN отделы не видит → 403',
      `status=${pickerForbidden.status}`,
    );
  } catch (error) {
    fail++;
    console.error('E2E упал:', error);
  } finally {
    if (app) await app.close();
    await pg.stop();
    rmSync(DATA_DIR, { recursive: true, force: true });
  }

  console.log(`\nDepartments e2e: ${pass}/${pass + fail} проверок прошли`);
  process.exit(fail ? 1 : 0);
})();
