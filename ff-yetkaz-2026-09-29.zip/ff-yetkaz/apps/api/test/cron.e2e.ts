// Тест точек входа планировщика: вход по секрету и идемпотентность.
//   npx ts-node -T test/cron.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_cron_pg');
const PG_PORT = Number(process.env.FF_CRON_PGPORT || 5454);
const CRON_SECRET = 'cron-secret-for-e2e';
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_cron');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_cron`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';
    delete process.env.FF_CRON_SECRET;
    delete process.env.CRON_SECRET;

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[]) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId: null }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    await createUser('admin@ff.local', ['ADMIN']);
    const token = (
      await request(http).post('/api/v1/auth/login').send({ email: 'admin@ff.local', password: PASSWORD })
    ).body.accessToken as string;

    const CRON = '/api/v1/cron/storage-snapshot';

    // ---------- 1. Без секрета ручка закрыта --------------------------------
    console.log('\n1. Планировщик не настроен');
    const notConfigured = await request(http).get(CRON);
    check(
      notConfigured.status === 401,
      'Без заданного секрета ручка закрыта совсем → 401',
      `status=${notConfigured.status}`,
    );

    // ---------- 2. Проверка секрета -----------------------------------------
    console.log('\n2. Проверка секрета');
    process.env.FF_CRON_SECRET = CRON_SECRET;

    const noHeader = await request(http).get(CRON);
    check(noHeader.status === 401, 'Без заголовка → 401', `status=${noHeader.status}`);

    const wrong = await request(http).get(CRON).set('Authorization', `Bearer ${CRON_SECRET}-x`);
    check(wrong.status === 401, 'Неверный секрет → 401', `status=${wrong.status}`);

    const jwtInstead = await request(http).get(CRON).set('Authorization', `Bearer ${token}`);
    check(
      jwtInstead.status === 401,
      'JWT администратора здесь не подходит: вход отдельный',
      `status=${jwtInstead.status}`,
    );

    const ok = await request(http).get(CRON).set('Authorization', `Bearer ${CRON_SECRET}`);
    check(ok.status === 200, 'С верным секретом срез снимается', `status=${ok.status}`);

    // ---------- 3. Идемпотентность -------------------------------------------
    console.log('\n3. Идемпотентность');
    const seller = (
      await request(http)
        .post('/api/v1/sellers')
        .set('Authorization', `Bearer ${token}`)
        .send({ code: 'ACME', legalName: 'Акме' })
    ).body;
    const wh = (
      await request(http)
        .post('/api/v1/warehouses')
        .set('Authorization', `Bearer ${token}`)
        .send({ code: 'TAS-1', name: 'Ташкент' })
    ).body;
    const bin = (
      await request(http)
        .post('/api/v1/bin-locations')
        .set('Authorization', `Bearer ${token}`)
        .send({ warehouseId: wh.id, code: 'S-01-01-01', kind: 'STORAGE' })
    ).body;
    const sku = (
      await request(http)
        .post('/api/v1/skus')
        .set('Authorization', `Bearer ${token}`)
        .send({
          sellerId: seller.id,
          skuCode: 'W',
          name: 'W',
          weightG: 500,
          lengthMm: 100,
          widthMm: 100,
          heightMm: 100,
        })
    ).body;
    await request(http)
      .post('/api/v1/inventory/stock-in')
      .set('Authorization', `Bearer ${token}`)
      .send({ skuId: sku.id, warehouseId: wh.id, binId: bin.id, quantity: 7 });

    await request(http).get(CRON).set('Authorization', `Bearer ${CRON_SECRET}`);
    await request(http).get(CRON).set('Authorization', `Bearer ${CRON_SECRET}`);
    const snapshots: Array<{ count: string; units: number }> = await dataSource.query(
      `SELECT count(*)::text AS count, MAX(units)::int AS units FROM storage_snapshots`,
    );
    check(
      snapshots[0].count === '1' && snapshots[0].units === 7,
      'Повторный съём за тот же день уточняет строку, а не плодит вторую',
      JSON.stringify(snapshots[0]),
    );

    const dispatch = await request(http)
      .get('/api/v1/cron/outbox-dispatch')
      .set('Authorization', `Bearer ${CRON_SECRET}`);
    check(
      dispatch.status === 200 && dispatch.body.claimed === 0,
      'Разбор пустой очереди отрабатывает вхолостую',
      JSON.stringify(dispatch.body),
    );

    const accrue = await request(http)
      .get('/api/v1/cron/accrue-yesterday')
      .set('Authorization', `Bearer ${CRON_SECRET}`);
    check(
      accrue.status === 200 && accrue.body.created === 0,
      'Ночной прогон начислений без тарифов ничего не создаёт',
      JSON.stringify({ created: accrue.body.created, problems: accrue.body.problems }),
    );

    // ---------- 4. Фон на serverless ----------------------------------------
    console.log('\n4. Фон на serverless');
    const { backgroundTimersSupported } = await import('../src/infrastructure/runtime/runtime');
    process.env.VERCEL = '1';
    check(
      backgroundTimersSupported() === false,
      'На Vercel фоновые таймеры выключаются сами — их место занимает Cron',
    );
    delete process.env.VERCEL;
    check(backgroundTimersSupported() === true, 'На обычном процессе таймеры работают');
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\ncron e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
