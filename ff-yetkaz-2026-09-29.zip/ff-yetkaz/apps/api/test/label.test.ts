// Штрихкод и этикетка: без БД и без Nest.
//   npx ts-node -T test/label.test.ts
import {
  CODE128_PATTERNS,
  CODE128_START_B,
  CODE128_STOP,
  Code128Error,
  code128Bars,
  code128BChecksum,
  encodeCode128B,
} from '../src/domain/labels/code128';
import { renderLabel, type LabelData } from '../src/infrastructure/labels/label.renderer';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  console.log('Code 128 — таблица символов');

  // Целостность таблицы. Опечатка в одной цифре почти наверняка ломает сумму
  // модулей, поэтому эти три проверки закрывают ручной перенос стандарта.
  check(CODE128_PATTERNS.length === 107, 'В таблице 107 символов', `${CODE128_PATTERNS.length}`);

  const data = CODE128_PATTERNS.slice(0, CODE128_STOP);
  check(
    data.every((pattern) => pattern.length === 6),
    'Каждый значимый символ — 6 модулей',
  );
  const badSum = data.filter(
    (pattern) => [...pattern].reduce((sum, digit) => sum + Number(digit), 0) !== 11,
  );
  check(badSum.length === 0, 'Ширина каждого символа — 11 модулей', badSum.join(', '));
  check(
    new Set(CODE128_PATTERNS).size === CODE128_PATTERNS.length,
    'Все шаблоны различны',
  );
  const stop = CODE128_PATTERNS[CODE128_STOP];
  check(
    stop === '2331112' && [...stop].reduce((sum, digit) => sum + Number(digit), 0) === 13,
    'Стоп-символ — 7 модулей шириной 13',
  );

  console.log('\nControl digit');
  // Ручной расчёт для «FF000000001»:
  //   старт 104 + 1·38 + 2·38 + (3…10)·16 + 11·17 = 1237; 1237 mod 103 = 1.
  check(code128BChecksum('FF000000001') === 1, 'Контрольный символ FF000000001 = 1');
  check(code128BChecksum('A') === (104 + 33) % 103, 'Контрольный символ односимвольной строки');

  const symbols = encodeCode128B('FF000000001');
  check(symbols[0] === CODE128_START_B, 'Последовательность начинается со Start B');
  check(symbols[symbols.length - 1] === CODE128_STOP, 'Последовательность кончается стопом');
  check(symbols.length === 11 + 3, 'Символов = данные + старт + контроль + стоп');

  console.log('\nРаскладка полос');
  const { bars, modules } = code128Bars('FF000000001');
  // 11 знаков + старт + контроль + стоп: 13 символов по 11 модулей + 13.
  check(modules === 13 * 11 + 13, 'Полная ширина в модулях', `${modules}`);
  check(
    bars.every((bar) => bar.width >= 1 && bar.width <= 4),
    'Ширина полосы — от 1 до 4 модулей',
  );
  check(
    bars.every((bar, index) => index === 0 || bar.offset > bars[index - 1].offset),
    'Полосы идут слева направо без наложений',
  );

  let rejected = false;
  try {
    code128Bars('ЖЖ1');
  } catch (error) {
    rejected = error instanceof Code128Error;
  }
  check(rejected, 'Символ вне набора B отбит понятной ошибкой');

  console.log('\nЭтикетка PDF');
  const label: LabelData = {
    shipmentNo: 'FF000000001',
    orderCode: 'FF-YES0000001',
    trackingNo: null,
    carrier: 'IPOST_GO',
    orderExternalId: 'DEMO-1',
    channel: 'uzum',
    sellerName: 'ООО «Акме»',
    warehouseCode: 'TAS-1',
    recipientName: 'Иванов Иван Иванович',
    recipientPhone: '+998901234567',
    address: 'Ташкент, Амира Темура 1, кв. 5',
    region: 'Ташкент',
    weightG: 1250,
    lengthMm: 300,
    widthMm: 200,
    heightMm: 150,
    codAmount: '250000.00',
    currency: 'UZS',
    items: [
      { skuCode: 'ACME-KETTLE', name: 'Чайник электрический 1.7 л', quantity: 2 },
      { skuCode: 'ACME-LAMP', name: 'Лампа настольная', quantity: 1 },
    ],
    printedAt: new Date('2026-08-06T09:30:00Z'),
  };

  const pdf = await renderLabel(label);
  check(pdf.subarray(0, 5).toString('latin1') === '%PDF-', 'Ответ — валидный PDF-заголовок');
  check(pdf.includes(Buffer.from('%%EOF')), 'PDF закрыт маркером %%EOF');
  check(pdf.length > 20_000, 'Шрифт с кириллицей вшит в документ', `${pdf.length} байт`);

  const raw = pdf.toString('latin1');
  check(
    /\/MediaBox \[0 0 283\.4\d+ 425\.1\d+\]/.test(raw),
    'Формат страницы — 100×150 мм',
    (raw.match(/\/MediaBox[^\]]*\]/) ?? [''])[0],
  );

  // Одна страница — это инвариант, а не косметика: вторая страница означает,
  // что содержимое переполнило наклейку и принтер выплюнет лишнюю этикетку.
  const pages = (data_: Buffer) => (data_.toString('latin1').match(/\/Count\s+(\d+)/) ?? [])[1];
  check(pages(pdf) === '1', 'Этикетка занимает ровно одну страницу', `страниц: ${pages(pdf)}`);

  const crowded = await renderLabel({
    ...label,
    items: Array.from({ length: 40 }, (_, index) => ({
      skuCode: `ACME-${String(index).padStart(4, '0')}`,
      name: 'Позиция с очень длинным наименованием, которое не должно ломать вёрстку',
      quantity: index + 1,
    })),
  });
  check(pages(crowded) === '1', 'Длинный состав не выдавливает вторую страницу');

  // Кириллица в PDF живёт в потоках, поэтому проверяем не текст, а то, что
  // документ построился на встроенном шрифте: без него pdfkit падает.
  const withoutCod = await renderLabel({ ...label, codAmount: null, currency: null });
  check(withoutCod.length > 20_000 && withoutCod.length < pdf.length, 'Без COD этикетка короче');

  const withTracking = await renderLabel({ ...label, trackingNo: 'IPST0001234567' });
  check(withTracking.length > 20_000, 'С треком перевозчика этикетка строится');

  let tooLong = false;
  try {
    await renderLabel({ ...label, shipmentNo: 'F'.repeat(40) });
  } catch {
    tooLong = true;
  }
  check(tooLong, 'Штрихкод, не влезающий в 100 мм, отбит');

  console.log(`\nlabel test: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
