// Сквозной тест этапа 1.4 (Packing) против настоящего PostgreSQL.
//   npx ts-node -T test/packing.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import { FF_EVENTS, type FfDomainEvent, type Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { EVENT_BUS, type EventBus } from '../src/infrastructure/queues/events/event-bus';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_packing_pg');
const PG_PORT = Number(process.env.FF_PACK_PGPORT || 5448);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_packing');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_packing`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    // Шина событий — часть контракта реестра: смотрим, что упаковка и
    // отправление действительно публикуют то, что обещано в events.ts.
    const bus = app.get<EventBus>(EVENT_BUS);
    const packed: Array<FfDomainEvent<'pack.completed'>> = [];
    const ready: Array<FfDomainEvent<'shipment.ready'>> = [];
    const picked: Array<FfDomainEvent<'pick.completed'>> = [];
    bus.subscribe(FF_EVENTS.PACK_COMPLETED, (event) => void packed.push(event));
    bus.subscribe(FF_EVENTS.SHIPMENT_READY, (event) => void ready.push(event));
    bus.subscribe(FF_EVENTS.PICK_COMPLETED, (event) => void picked.push(event));

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    async function login(email: string): Promise<string> {
      const response = await request(http)
        .post('/api/v1/auth/login')
        .send({ email, password: PASSWORD });
      return response.body.accessToken as string;
    }

    await createUser('admin@ff.local', ['ADMIN'], null);
    const packer1 = await createUser('packer1@ff.local', ['PACKER'], null);
    await createUser('packer2@ff.local', ['PACKER'], null);
    const adminToken = await login('admin@ff.local');
    const packer1Token = await login('packer1@ff.local');
    const packer2Token = await login('packer2@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);
    const asPacker1 = (r: request.Test) => r.set('Authorization', `Bearer ${packer1Token}`);
    const asPacker2 = (r: request.Test) => r.set('Authorization', `Bearer ${packer2Token}`);

    // ---------- 1. Схема и данные -------------------------------------------
    console.log('\n1. Схема и данные');
    check(
      applied.some((m) => m.name === 'Packing1786320000000'),
      'Миграция Packing применилась',
      `всего: ${applied.length}`,
    );
    const tables: Array<{ table_name: string }> = await dataSource.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`,
    );
    for (const expected of ['packages', 'package_items', 'shipments']) {
      check(tables.some((t) => t.table_name === expected), `Таблица ${expected} создана`);
    }

    const seller = (
      await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'ООО Акме' })
    ).body;
    const whMain = (
      await asAdmin(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })
    ).body;
    const whNoShipping = (
      await asAdmin(request(http).post('/api/v1/warehouses')).send({ code: 'SAM-1', name: 'Самарканд' })
    ).body;

    async function makeBin(warehouseId: string, code: string, kind: string) {
      return (
        await asAdmin(request(http).post('/api/v1/bin-locations')).send({ warehouseId, code, kind })
      ).body;
    }
    const storeMain = await makeBin(whMain.id, 'S-01-01-01', 'STORAGE');
    const packMain = await makeBin(whMain.id, 'P-01-01-01', 'PACKING');
    const shipMain = await makeBin(whMain.id, 'X-01-01-01', 'SHIPPING');
    const storeAlt = await makeBin(whNoShipping.id, 'S-01-01-01', 'STORAGE');
    const packAlt = await makeBin(whNoShipping.id, 'P-01-01-01', 'PACKING');

    async function makeSku(code: string, barcode: string, weightG: number | null) {
      const body: Record<string, unknown> = { sellerId: seller.id, skuCode: code, name: code };
      if (weightG !== null) body.weightG = weightG;
      const sku = (await asAdmin(request(http).post('/api/v1/skus')).send(body)).body;
      await asAdmin(request(http).post(`/api/v1/skus/${sku.id}/barcodes`)).send({
        barcode,
        kind: 'EAN13',
        isPrimary: true,
      });
      return sku;
    }
    const skuW = await makeSku('W', '2000000000018', 500);
    const skuN = await makeSku('N', '2000000000025', null);
    const skuB = await makeSku('B', '2000000000032', 300);
    const skuS = await makeSku('S', '2000000000049', 100);
    check(skuW.weightG === 500 && skuN.weightG === null, 'SKU с весом и без веса заведены');

    async function stockIn(skuId: string, warehouseId: string, binId: string, quantity: number) {
      return asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
        skuId,
        warehouseId,
        binId,
        quantity,
      });
    }
    await stockIn(skuW.id, whMain.id, storeMain.id, 20);
    await stockIn(skuN.id, whMain.id, storeMain.id, 10);
    await stockIn(skuB.id, whNoShipping.id, storeAlt.id, 10);
    await stockIn(skuS.id, whMain.id, storeMain.id, 1);

    let orderSeq = 0;
    async function makeOrder(lines: Array<{ skuId: string; quantity: number }>, cod = false) {
      orderSeq += 1;
      const body: Record<string, unknown> = {
        sellerId: seller.id,
        channel: 'uzum',
        externalId: `ORD-${orderSeq}`,
        recipientName: 'Иванов Иван',
        recipientPhone: '+998901234567',
        address: 'Ташкент, Амира Темура 1',
        lines,
      };
      if (cod) {
        body.codAmount = '250000.00';
        body.currency = 'UZS';
      }
      return (await asAdmin(request(http).post('/api/v1/orders')).send(body)).body.order;
    }

    /** Проводит заказ через сборку: задание → скан всех строк → завершение. */
    async function pickFully(orderId: string, scans: Array<{ barcode: string; quantity: number }>) {
      const task = (
        await asAdmin(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [orderId] })
      ).body;
      await asAdmin(request(http).post(`/api/v1/picking/tasks/${task.id}/assign`)).send({});
      for (const scan of scans) {
        await asAdmin(request(http).post(`/api/v1/picking/tasks/${task.id}/scan`)).send(scan);
      }
      await asAdmin(request(http).post(`/api/v1/picking/tasks/${task.id}/complete`)).send({});
      return task;
    }

    const order1 = await makeOrder([{ skuId: skuW.id, quantity: 2 }], true);
    const order2 = await makeOrder([
      { skuId: skuW.id, quantity: 1 },
      { skuId: skuN.id, quantity: 1 },
    ]);
    const order3 = await makeOrder([{ skuId: skuW.id, quantity: 2 }]);
    const order4 = await makeOrder([{ skuId: skuB.id, quantity: 1 }]);
    const order5 = await makeOrder([{ skuId: skuS.id, quantity: 1 }]);
    check(order4.warehouseId === whNoShipping.id, 'Заказ 4 ушёл на склад без зоны отгрузки');

    await pickFully(order1.id, [{ barcode: '2000000000018', quantity: 2 }]);
    await pickFully(order2.id, [
      { barcode: '2000000000018', quantity: 1 },
      { barcode: '2000000000025', quantity: 1 },
    ]);
    await pickFully(order3.id, [{ barcode: '2000000000018', quantity: 2 }]);
    await pickFully(order4.id, [{ barcode: '2000000000032', quantity: 1 }]);
    check(
      picked.length === 4 && picked.every((event) => event.payload.shortPicked === false),
      'Событие pick.completed опубликовано по каждому заказу',
      `событий: ${picked.length}`,
    );

    // ---------- 2. Очередь упаковки ------------------------------------------
    console.log('\n2. Очередь упаковки');
    const queue = await asPacker1(request(http).get('/api/v1/packing/queue'));
    check(queue.status === 200 && queue.body.length === 4, 'В очереди четыре собранных заказа', `${queue.body.length}`);

    const q1 = queue.body.find((item: { orderId: string }) => item.orderId === order1.id);
    check(q1.status === 'PICKED' && q1.packageId === null, 'Заказ ждёт упаковщика');
    check(
      q1.itemsCount === 1 && q1.unitsCount === 2,
      'Состав очереди считается по факту сборки',
      JSON.stringify({ items: q1.itemsCount, units: q1.unitsCount }),
    );

    const filtered = await asPacker1(
      request(http).get(`/api/v1/packing/queue?warehouseId=${whNoShipping.id}`),
    );
    check(filtered.body.length === 1, 'Фильтр по складу работает', `${filtered.body.length}`);

    await createUser('seller@ff.local', ['SELLER'], seller.id);
    const sellerToken = await login('seller@ff.local');
    const sellerQueue = await request(http)
      .get('/api/v1/packing/queue')
      .set('Authorization', `Bearer ${sellerToken}`);
    check(sellerQueue.status === 403, 'Селлер не видит очередь упаковки → 403', `status=${sellerQueue.status}`);

    // ---------- 3. Взятие в работу -------------------------------------------
    console.log('\n3. Взятие в работу');
    const pkg1 = await asPacker1(request(http).post(`/api/v1/packing/orders/${order1.id}/start`)).send({});
    check(pkg1.status === 201 && pkg1.body.status === 'OPEN', 'Коробка открыта');
    check(
      pkg1.body.expectedWeightG === 1000,
      'Расчётный вес — сумма весов справочника',
      `${pkg1.body.expectedWeightG}`,
    );
    check(pkg1.body.items.length === 1 && pkg1.body.items[0].quantity === 2, 'Состав взят из журнала сборки');

    const orderInPacking = await asAdmin(request(http).get(`/api/v1/orders/${order1.id}`));
    check(orderInPacking.body.status === 'PACKING', 'Заказ перешёл в PACKING', orderInPacking.body.status);

    const resumed = await asPacker1(request(http).post(`/api/v1/packing/orders/${order1.id}/start`)).send({});
    check(
      resumed.status === 201 && resumed.body.id === pkg1.body.id,
      'Повторное взятие возвращает ту же коробку, а не создаёт вторую',
    );

    const notPicked = await asPacker1(
      request(http).post(`/api/v1/packing/orders/${order5.id}/start`),
    ).send({});
    check(notPicked.status === 409, 'Несобранный заказ упаковать нельзя → 409', `status=${notPicked.status}`);

    // ---------- 4. Контроль веса ---------------------------------------------
    console.log('\n4. Контроль веса');
    const alien = await asPacker2(
      request(http).post(`/api/v1/packing/orders/${order1.id}/complete`),
    ).send({ weightG: 1000 });
    check(alien.status === 403, 'Чужой упаковщик не закрывает коробку → 403', `status=${alien.status}`);

    // 1040 г при расчётных 1000 — отклонение 4%, в допуске.
    const inTolerance = await asPacker1(
      request(http).post(`/api/v1/packing/orders/${order1.id}/complete`),
    ).send({ weightG: 1040, lengthMm: 300, widthMm: 200, heightMm: 150 });
    check(inTolerance.status === 201, 'Упаковка завершена', `status=${inTolerance.status}`);
    check(
      inTolerance.body.deviationPct === 4 && inTolerance.body.weightMismatch === false,
      'Отклонение 4% укладывается в допуск ±5%',
      JSON.stringify({
        deviation: inTolerance.body.deviationPct,
        mismatch: inTolerance.body.weightMismatch,
      }),
    );
    check(inTolerance.body.tolerancePct === 5, 'Допуск отдаётся клиенту, а не зашит в UI');

    const orderPacked = await asAdmin(request(http).get(`/api/v1/orders/${order1.id}`));
    check(orderPacked.body.status === 'PACKED', 'Заказ перешёл в PACKED', orderPacked.body.status);

    const closedTwice = await asPacker1(
      request(http).post(`/api/v1/packing/orders/${order1.id}/complete`),
    ).send({ weightG: 1040 });
    check(closedTwice.status === 409, 'Повторное закрытие коробки → 409', `status=${closedTwice.status}`);

    const movedToShipping: Array<{ quantity: number }> = await dataSource.query(
      `SELECT quantity FROM stock WHERE sku_id = $1 AND bin_id = $2 AND status = 'PACKED'`,
      [skuW.id, shipMain.id],
    );
    check(
      movedToShipping.length === 1 && movedToShipping[0].quantity === 2,
      'Упакованное уехало в зону отгрузки со статусом PACKED',
      JSON.stringify(movedToShipping),
    );

    check(
      packed.length === 1 &&
        packed[0].payload.orderId === order1.id &&
        packed[0].payload.weightKg === '1.040' &&
        packed[0].payload.weightMismatch === false,
      'Событие pack.completed с весом в килограммах строкой',
      JSON.stringify(packed[0]?.payload),
    );

    // Расхождение больше допуска: помечаем, но не блокируем.
    await asPacker1(request(http).post(`/api/v1/packing/orders/${order3.id}/start`)).send({});
    const mismatch = await asPacker1(
      request(http).post(`/api/v1/packing/orders/${order3.id}/complete`),
    ).send({ weightG: 1200, comment: 'Коробка тяжелее: доложен наполнитель' });
    check(
      mismatch.status === 201 && mismatch.body.weightMismatch === true,
      'Отклонение 20% помечено расхождением',
      `deviation=${mismatch.body.deviationPct}`,
    );
    check(
      mismatch.body.package.status === 'PACKED',
      'Расхождение веса не блокирует упаковку — коробка закрыта',
    );
    check(
      packed[1]?.payload.weightMismatch === true,
      'Флаг расхождения уехал в событие',
    );

    // Вес не у всех SKU — сравнивать не с чем.
    const pkg2 = await asPacker1(request(http).post(`/api/v1/packing/orders/${order2.id}/start`)).send({});
    check(pkg2.body.expectedWeightG === null, 'Без веса хотя бы у одного SKU расчёт не строится');
    const unweighed = await asPacker1(
      request(http).post(`/api/v1/packing/orders/${order2.id}/complete`),
    ).send({ weightG: 700 });
    check(
      unweighed.body.deviationPct === null && unweighed.body.weightMismatch === false,
      'Без расчётного веса расхождение не выдумывается',
      JSON.stringify({ deviation: unweighed.body.deviationPct, mismatch: unweighed.body.weightMismatch }),
    );

    // Склад без зоны отгрузки: упакованное остаётся в зоне упаковки.
    await asPacker1(request(http).post(`/api/v1/packing/orders/${order4.id}/start`)).send({});
    await asPacker1(request(http).post(`/api/v1/packing/orders/${order4.id}/complete`)).send({
      weightG: 300,
    });
    const stayed: Array<{ quantity: number }> = await dataSource.query(
      `SELECT quantity FROM stock WHERE sku_id = $1 AND bin_id = $2 AND status = 'PACKED'`,
      [skuB.id, packAlt.id],
    );
    check(
      stayed.length === 1 && stayed[0].quantity === 1,
      'Без зоны отгрузки упакованное остаётся в зоне упаковки, но уже PACKED',
      JSON.stringify(stayed),
    );

    // ---------- 5. Отправление и этикетка ------------------------------------
    console.log('\n5. Отправление и этикетка');
    const notIssued = await asPacker1(
      request(http).get(`/api/v1/packing/packages/${pkg1.body.id}/label.pdf`),
    );
    check(notIssued.status === 409, 'Печать без оформления отправления → 409', `status=${notIssued.status}`);

    // Пустой ответ должен быть разбираемым JSON, а не пустым телом: голый null
    // Nest отдаёт нулевой длиной, и клиент падает на разборе.
    const noShipment = await asPacker1(
      request(http).get(`/api/v1/packing/packages/${pkg1.body.id}/shipment`),
    );
    check(
      noShipment.status === 200 && noShipment.body.shipment === null,
      'Пока отправления нет, ручка отдаёт JSON-конверт с null',
      JSON.stringify(noShipment.body),
    );

    const shipment = await asPacker1(
      request(http).post(`/api/v1/packing/packages/${pkg1.body.id}/label`),
    ).send({});
    check(shipment.status === 201 && shipment.body.status === 'READY', 'Отправление оформлено');
    check(
      /^FF\d{9}$/.test(shipment.body.shipmentNo),
      'Номер отправления выдан последовательностью БД',
      shipment.body.shipmentNo,
    );
    check(shipment.body.trackingNo === null, 'Трек перевозчика появится только при передаче');
    check(
      shipment.body.codAmount === '250000.00' && shipment.body.weightG === 1040,
      'COD и вес заморожены на момент отгрузки',
      JSON.stringify({ cod: shipment.body.codAmount, weight: shipment.body.weightG }),
    );

    const readyOrder = await asAdmin(request(http).get(`/api/v1/orders/${order1.id}`));
    check(
      readyOrder.body.status === 'READY_TO_SHIP',
      'Заказ дошёл до границы зоны FF — READY_TO_SHIP',
      readyOrder.body.status,
    );
    check(
      ready.length === 1 && ready[0].payload.shipmentId === shipment.body.id,
      'Событие shipment.ready опубликовано',
      JSON.stringify(ready[0]?.payload),
    );

    const withShipment = await asPacker1(
      request(http).get(`/api/v1/packing/packages/${pkg1.body.id}/shipment`),
    );
    check(
      withShipment.body.shipment?.shipmentNo === shipment.body.shipmentNo,
      'После оформления ручка отдаёт то же отправление',
      JSON.stringify(withShipment.body.shipment?.shipmentNo),
    );

    const reissued = await asPacker1(
      request(http).post(`/api/v1/packing/packages/${pkg1.body.id}/label`),
    ).send({});
    check(
      reissued.body.id === shipment.body.id && ready.length === 1,
      'Повторное оформление возвращает то же отправление и не шлёт событие второй раз',
    );

    const pdf = await asPacker1(
      request(http).get(`/api/v1/packing/packages/${pkg1.body.id}/label.pdf`),
    ).responseType('blob');
    check(pdf.status === 200, 'Этикетка отдаётся', `status=${pdf.status}`);
    check(
      String(pdf.headers['content-type']).includes('application/pdf'),
      'Content-Type — application/pdf',
      String(pdf.headers['content-type']),
    );
    check(
      Buffer.isBuffer(pdf.body) && pdf.body.subarray(0, 5).toString('latin1') === '%PDF-',
      'Тело ответа — PDF',
      Buffer.isBuffer(pdf.body) ? `${pdf.body.length} байт` : typeof pdf.body,
    );
    check(
      String(pdf.headers['content-disposition']).includes(shipment.body.shipmentNo),
      'Имя файла содержит номер отправления',
      String(pdf.headers['content-disposition']),
    );

    const secondPdf = await asPacker1(
      request(http).get(`/api/v1/packing/packages/${pkg1.body.id}/label.pdf`),
    ).responseType('blob');
    const afterReprint = await asAdmin(request(http).get(`/api/v1/orders/${order1.id}`));
    check(
      secondPdf.status === 200 && afterReprint.body.status === 'READY_TO_SHIP',
      'Перепечатка этикетки ничего не меняет в статусе',
    );

    // ---------- 6. Пустая сборка ---------------------------------------------
    console.log('\n6. Заказ, из которого ничего не собрали');
    const emptyTask = (
      await asAdmin(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [order5.id] })
    ).body;
    await asAdmin(request(http).post(`/api/v1/picking/tasks/${emptyTask.id}/assign`)).send({});
    const shorted = await asAdmin(
      request(http).post(`/api/v1/picking/tasks/${emptyTask.id}/lines/${emptyTask.lines[0].id}/short`),
    ).send({ reason: 'Ячейка пуста, замены нет' });
    check(shorted.body.reallocated === false, 'Недобор без замены');
    await asAdmin(request(http).post(`/api/v1/picking/tasks/${emptyTask.id}/complete`)).send({});

    const nothingToPack = await asPacker1(
      request(http).post(`/api/v1/packing/orders/${order5.id}/start`),
    ).send({});
    check(
      nothingToPack.status === 409,
      'Пустой заказ в упаковку не берётся → 409',
      `status=${nothingToPack.status}`,
    );

    // ---------- 7. Инварианты -------------------------------------------------
    console.log('\n7. Инварианты');
    const mismatchRows: Array<{ mismatches: string }> = await dataSource.query(`
      WITH ledger AS (
        SELECT sku_id, warehouse_id, to_bin_id AS bin_id, lot_id, to_status AS status, quantity AS qty
          FROM stock_movements WHERE to_bin_id IS NOT NULL
        UNION ALL
        SELECT sku_id, warehouse_id, from_bin_id, lot_id, from_status, -quantity
          FROM stock_movements WHERE from_bin_id IS NOT NULL
      ), agg AS (
        SELECT sku_id, warehouse_id, bin_id, lot_id, status, SUM(qty)::int AS qty
          FROM ledger GROUP BY 1,2,3,4,5
      )
      SELECT count(*)::text AS mismatches
        FROM agg FULL JOIN stock s
          ON s.sku_id = agg.sku_id AND s.warehouse_id = agg.warehouse_id
         AND s.bin_id = agg.bin_id AND s.lot_id IS NOT DISTINCT FROM agg.lot_id
         AND s.status = agg.status
       WHERE COALESCE(s.quantity, 0) <> COALESCE(agg.qty, 0)
    `);
    check(
      mismatchRows[0].mismatches === '0',
      'Журнал движений сходится с остатком после упаковки',
      `расхождений: ${mismatchRows[0].mismatches}`,
    );

    const transitions: Array<{ to_state: string }> = await dataSource.query(
      `SELECT after->>'status' AS to_state FROM audit_events
        WHERE action = 'STATE_TRANSITION' AND entity_type = 'Order' AND entity_id = $1
        ORDER BY id ASC`,
      [order1.id],
    );
    const chain = transitions.map((row) => row.to_state).join(' → ');
    check(
      chain.endsWith('PICKING → PICKED → PACKING → PACKED → READY_TO_SHIP'),
      'Полная цепочка переходов заказа в аудите',
      chain,
    );

    const orphanPackages: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM packages p
        WHERE p.status = 'PACKED' AND p.actual_weight_g IS NULL`,
    );
    check(orphanPackages[0].count === '0', 'Закрытая коробка не бывает невзвешенной');

    const stuckPicked: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM stock
        WHERE status = 'PICKED' AND quantity > 0 AND bin_id = $1`,
      [packMain.id],
    );
    check(
      stuckPicked[0].count === '0',
      'В зоне упаковки не осталось собранного, но не упакованного',
      `строк: ${stuckPicked[0].count}`,
    );
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\npacking e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
