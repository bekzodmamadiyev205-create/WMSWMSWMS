// Сквозной тест модуля Users (выдача доступа из интерфейса) против настоящего
// PostgreSQL.
//   npx ts-node -T test/users.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_users_pg');
const PG_PORT = Number(process.env.FF_USR_PGPORT || 5447);
const PASSWORD = 'Sklad-2026-Admin!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_users');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_users`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    await dataSource.runMigrations();

    // Стартовый администратор — как его создал бы сид.
    const passwordHash = await passwords.hash(PASSWORD);
    await dataSource.transaction(async (em) => {
      const users = em.getRepository(UserEntity);
      const admin = await users.save(
        users.create({
          email: 'admin@ff.local',
          passwordHash,
          fullName: 'Админ',
          isActive: true,
          sellerId: null,
        }),
      );
      await em.getRepository(UserRoleEntity).insert({ userId: admin.id, role: 'ADMIN' });
    });

    async function login(email: string, password = PASSWORD): Promise<string | null> {
      const response = await request(http).post('/api/v1/auth/login').send({ email, password });
      return (response.body.accessToken as string) ?? null;
    }
    const adminToken = await login('admin@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);

    console.log('\n1. Выдача доступа');
    const created = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'Picker@FF.local',
      fullName: 'Сборщик Санжар',
      password: 'Sborka-2026-!!',
      roles: ['PICKER'] satisfies Role[],
    });
    check(created.status === 201, 'Сотрудник создан', `status=${created.status}`);
    check(created.body.email === 'picker@ff.local', 'Email нормализован к нижнему регистру', created.body.email);
    check(
      JSON.stringify(created.body.roles) === JSON.stringify(['PICKER']),
      'Роль присвоена',
      JSON.stringify(created.body.roles),
    );

    const pickerToken = await login('picker@ff.local', 'Sborka-2026-!!');
    check(pickerToken !== null && pickerToken !== undefined, 'Новый сотрудник может войти своим паролем');

    const pickerForbidden = await request(http)
      .get('/api/v1/users')
      .set('Authorization', `Bearer ${pickerToken}`);
    check(pickerForbidden.status === 403, 'Не-ADMIN список пользователей не видит → 403', `status=${pickerForbidden.status}`);

    console.log('\n2. Валидация');
    const shortPassword = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'x@ff.local',
      fullName: 'Икс',
      password: '123',
      roles: ['PICKER'],
    });
    check(shortPassword.status === 400, 'Короткий пароль отбит → 400', `status=${shortPassword.status}`);

    const noRoles = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'y@ff.local',
      fullName: 'Игрек',
      password: 'Dlinny-parol-123',
      roles: [],
    });
    check(noRoles.status === 400, 'Пользователь без ролей отбит → 400', `status=${noRoles.status}`);

    const duplicate = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'PICKER@ff.local',
      fullName: 'Дубль',
      password: 'Dlinny-parol-123',
      roles: ['PICKER'],
    });
    check(duplicate.status === 409, 'Повторный email (в другом регистре) → 409', `status=${duplicate.status}`);

    const sellerNoRef = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'seller@ff.local',
      fullName: 'Селлер',
      password: 'Dlinny-parol-123',
      roles: ['SELLER'],
    });
    check(sellerNoRef.status === 400, 'SELLER без селлера отбит → 400', `status=${sellerNoRef.status}`);

    const mixed = await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'mixed@ff.local',
      fullName: 'Смешанный',
      password: 'Dlinny-parol-123',
      roles: ['SELLER', 'PICKER'],
    });
    check(mixed.status === 400, 'SELLER не совмещается с ролями сотрудников → 400', `status=${mixed.status}`);

    console.log('\n3. Смена пароля и отключение');
    const pickerId = created.body.id as string;
    const reset = await asAdmin(request(http).post(`/api/v1/users/${pickerId}/password`)).send({
      password: 'Noviy-parol-2026!',
    });
    check(reset.status === 204, 'Пароль сменён администратором', `status=${reset.status}`);
    check((await login('picker@ff.local', 'Sborka-2026-!!')) === undefined || (await login('picker@ff.local', 'Sborka-2026-!!')) === null, 'Старый пароль больше не работает');
    check(Boolean(await login('picker@ff.local', 'Noviy-parol-2026!')), 'Новый пароль работает');

    const disabled = await asAdmin(request(http).patch(`/api/v1/users/${pickerId}`)).send({
      isActive: false,
    });
    check(disabled.status === 200 && disabled.body.isActive === false, 'Сотрудник отключён');
    check(!(await login('picker@ff.local', 'Noviy-parol-2026!')), 'Отключённый войти не может');

    const reenabled = await asAdmin(request(http).patch(`/api/v1/users/${pickerId}`)).send({
      isActive: true,
      roles: ['PICKER', 'PACKER'],
    });
    check(
      reenabled.status === 200 &&
        reenabled.body.isActive === true &&
        reenabled.body.roles.length === 2,
      'Включён обратно с расширением ролей',
      JSON.stringify(reenabled.body.roles),
    );

    console.log('\n4. Защита последнего администратора');
    const admins = await asAdmin(request(http).get('/api/v1/users'));
    const adminRow = admins.body.find((row: { email: string }) => row.email === 'admin@ff.local');
    const selfDisable = await asAdmin(request(http).patch(`/api/v1/users/${adminRow.id}`)).send({
      isActive: false,
    });
    check(selfDisable.status === 403, 'Последнего ADMIN нельзя отключить → 403', `status=${selfDisable.status}`);

    const selfDemote = await asAdmin(request(http).patch(`/api/v1/users/${adminRow.id}`)).send({
      roles: ['FINANCE'],
    });
    check(selfDemote.status === 403, 'Последнего ADMIN нельзя разжаловать → 403', `status=${selfDemote.status}`);

    console.log('\n5. Аудит и хранение');
    const auditRows: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events WHERE entity_type = 'User' AND action IN ('CREATE','UPDATE')`,
    );
    check(Number(auditRows[0].count) >= 4, 'Действия с доступом записаны в аудит', `записей: ${auditRows[0].count}`);

    const leaked: Array<{ leaked: string }> = await dataSource.query(
      `SELECT count(*)::text AS leaked FROM audit_events
        WHERE entity_type = 'User'
          AND (after::text ILIKE '%parol%' OR after::text ILIKE '%password_hash%' OR after::text ILIKE '%argon2%')`,
    );
    check(leaked[0].leaked === '0', 'Ни пароль, ни хэш в аудит не попали', `совпадений: ${leaked[0].leaked}`);

    const listed = await asAdmin(request(http).get('/api/v1/users'));
    check(
      listed.body.every((row: Record<string, unknown>) => !('passwordHash' in row) && !('password_hash' in row)),
      'Хэш пароля не отдаётся списком',
    );
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\nusers e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
