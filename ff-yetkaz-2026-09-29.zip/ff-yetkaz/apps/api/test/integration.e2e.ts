// Сквозной тест этапа 1.7: передача перевозчику и входящие статусы.
//   npx ts-node -T test/integration.e2e.ts
import 'reflect-metadata';
import { createServer, type Server } from 'node:http';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { CarrierWebhookPayload, Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { signPayload, verifySignature } from '../src/infrastructure/integrations/carrier/signature';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_integration_pg');
const PG_PORT = Number(process.env.FF_INTEGRATION_PGPORT || 5451);
const CARRIER_PORT = Number(process.env.FF_CARRIER_PORT || 9401);
const SECRET = 'shared-secret-for-e2e';
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

/** Мок перевозчика: принимает передачу и проверяет нашу подпись. */
interface MockCarrier {
  server: Server;
  received: Array<{ body: unknown; signatureValid: boolean; deliveryId: string | undefined }>;
  failNext: number;
}

function startMockCarrier(): Promise<MockCarrier> {
  const state: MockCarrier = { server: null as unknown as Server, received: [], failNext: 0 };

  state.server = createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer) => chunks.push(chunk));
    req.on('end', () => {
      const raw = Buffer.concat(chunks);
      let signatureValid = false;
      try {
        verifySignature({
          secret: SECRET,
          body: raw,
          header: req.headers['x-ff-signature'] as string,
          toleranceSeconds: 300,
        });
        signatureValid = true;
      } catch {
        signatureValid = false;
      }

      if (state.failNext > 0) {
        state.failNext -= 1;
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'склад перевозчика недоступен' }));
        return;
      }

      state.received.push({
        body: JSON.parse(raw.toString('utf8')),
        signatureValid,
        deliveryId: req.headers['x-ff-delivery-id'] as string | undefined,
      });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ accepted: true }));
    });
  });

  return new Promise((resolve) => {
    state.server.listen(CARRIER_PORT, '127.0.0.1', () => resolve(state));
  });
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;
  let carrier: MockCarrier | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_integration');
    carrier = await startMockCarrier();

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_integration`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';
    process.env.FF_IPOST_GO_SECRET = SECRET;

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[]) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId: null }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    await createUser('admin@ff.local', ['ADMIN']);
    const token = (
      await request(http).post('/api/v1/auth/login').send({ email: 'admin@ff.local', password: PASSWORD })
    ).body.accessToken as string;
    const as = (r: request.Test) => r.set('Authorization', `Bearer ${token}`);

    // ---------- 1. Схема и настройка перевозчика ----------------------------
    console.log('\n1. Схема и настройка перевозчика');
    check(
      applied.some((m) => m.name === 'CarrierIntegration1786579200000'),
      'Миграция CarrierIntegration применилась',
      `всего: ${applied.length}`,
    );
    const tables: Array<{ table_name: string }> = await dataSource.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`,
    );
    for (const expected of ['integration_outbox', 'webhook_deliveries', 'shipment_status_events']) {
      check(tables.some((t) => t.table_name === expected), `Таблица ${expected} создана`);
    }

    const activated = await as(request(http).put('/api/v1/carriers/IPOST_GO')).send({
      baseUrl: `http://127.0.0.1:${CARRIER_PORT}`,
      handoffPath: '/api/ff/shipments',
      isActive: true,
    });
    check(activated.status === 200 && activated.body.isActive, 'Перевозчик включён и указывает на мок');

    // ---------- 2. Заказ до отправления --------------------------------------
    console.log('\n2. Заказ доведён до отправления');
    const seller = (await as(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'Акме' })).body;
    const wh = (await as(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })).body;
    const mkBin = async (code: string, kind: string) =>
      (await as(request(http).post('/api/v1/bin-locations')).send({ warehouseId: wh.id, code, kind })).body;
    const store = await mkBin('S-01-01-01', 'STORAGE');
    await mkBin('P-01-01-01', 'PACKING');
    const shipBin = await mkBin('X-01-01-01', 'SHIPPING');

    const sku = (
      await as(request(http).post('/api/v1/skus')).send({
        sellerId: seller.id,
        skuCode: 'W',
        name: 'Чайник',
        weightG: 1000,
      })
    ).body;
    await as(request(http).post(`/api/v1/skus/${sku.id}/barcodes`)).send({
      barcode: '5000000000011',
      kind: 'EAN13',
      isPrimary: true,
    });
    await as(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: sku.id,
      warehouseId: wh.id,
      binId: store.id,
      quantity: 10,
    });

    const order = (
      await as(request(http).post('/api/v1/orders')).send({
        sellerId: seller.id,
        channel: 'uzum',
        externalId: 'INT-1',
        recipientName: 'Иванов Иван',
        recipientPhone: '+998901234567',
        address: 'Ташкент, Амира Темура 1',
        codAmount: '250000.00',
        currency: 'UZS',
        lines: [{ skuId: sku.id, quantity: 2 }],
      })
    ).body.order;
    const task = (await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [order.id] })).body;
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/assign`)).send({});
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/scan`)).send({
      barcode: '5000000000011',
      quantity: 2,
    });
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/complete`)).send({});
    const pkg = (await as(request(http).post(`/api/v1/packing/orders/${order.id}/start`)).send({})).body;
    await as(request(http).post(`/api/v1/packing/orders/${order.id}/complete`)).send({
      weightG: 2000,
      lengthMm: 300,
      widthMm: 200,
      heightMm: 150,
    });
    const shipment = (await as(request(http).post(`/api/v1/packing/packages/${pkg.id}/label`)).send({})).body;
    check(shipment.status === 'READY', 'Отправление оформлено', shipment.shipmentNo);

    // ---------- 3. Очередь исходящих ----------------------------------------
    console.log('\n3. Очередь исходящих');
    const queued = await as(request(http).get('/api/v1/integration/outbox'));
    check(
      queued.body.length === 1 && queued.body[0].topic === 'shipment.ready',
      'Сообщение легло в очередь вместе с отправлением',
      JSON.stringify(queued.body.map((m: { topic: string; status: string }) => m)),
    );
    check(queued.body[0].status === 'PENDING' && queued.body[0].attempts === 0, 'Сообщение ждёт первой попытки');

    await as(request(http).post(`/api/v1/packing/packages/${pkg.id}/label`)).send({});
    const stillOne = await as(request(http).get('/api/v1/integration/outbox'));
    check(stillOne.body.length === 1, 'Повторное оформление не плодит сообщений', `${stillOne.body.length}`);

    // Перевозчик лежит: первая попытка обязана уйти в повтор, а не потеряться.
    carrier.failNext = 1;
    const failedRun = await as(request(http).post('/api/v1/integration/outbox/dispatch')).send({});
    check(
      failedRun.body.claimed === 1 && failedRun.body.retried === 1 && failedRun.body.delivered === 0,
      'Отказ перевозчика переводит сообщение в повтор',
      JSON.stringify(failedRun.body),
    );
    const afterFail: Array<{ status: string; attempts: number; last_error: string; future: boolean }> =
      await dataSource.query(
        `SELECT status, attempts, last_error, next_attempt_at > now() AS future FROM integration_outbox`,
      );
    check(
      afterFail[0].status === 'PENDING' && afterFail[0].attempts === 1 && afterFail[0].future === true,
      'Следующая попытка отложена бэкоффом',
      JSON.stringify(afterFail[0]),
    );
    check(
      afterFail[0].last_error.includes('500'),
      'Причина отказа сохранена',
      afterFail[0].last_error?.slice(0, 60),
    );

    const idleRun = await as(request(http).post('/api/v1/integration/outbox/dispatch')).send({});
    check(idleRun.body.claimed === 0, 'До истечения бэкоффа сообщение не берётся', JSON.stringify(idleRun.body));

    // Ждать 15 секунд в тесте незачем — двигаем время следующей попытки.
    await dataSource.query(`UPDATE integration_outbox SET next_attempt_at = now()`);
    const okRun = await as(request(http).post('/api/v1/integration/outbox/dispatch')).send({});
    check(
      okRun.body.delivered === 1,
      'Со второй попытки сообщение доставлено',
      JSON.stringify(okRun.body),
    );
    check(carrier.received.length === 1, 'Перевозчик получил ровно одну передачу', `${carrier.received.length}`);
    check(carrier.received[0].signatureValid, 'Исходящая подпись проверяется перевозчиком');
    check(
      carrier.received[0].deliveryId === `shipment.ready:${shipment.id}`,
      'Передача помечена идентификатором доставки — перевозчик сможет отсеять повтор',
      carrier.received[0].deliveryId,
    );

    const handoff = carrier.received[0].body as Record<string, unknown>;
    check(
      handoff.shipmentNo === shipment.shipmentNo && handoff.codAmount === '250000.00',
      'В передаче номер отправления и сумма наложенного платежа',
      JSON.stringify({ no: handoff.shipmentNo, cod: handoff.codAmount }),
    );
    check(
      Array.isArray(handoff.items) && (handoff.items as unknown[]).length === 1,
      'Состав отправления уехал перевозчику',
    );

    // Упавший диспетчер оставляет строку в IN_PROGRESS: её должен подобрать
    // следующий проход по истечении аренды, иначе сообщение зависнет навсегда.
    await dataSource.query(
      `INSERT INTO integration_outbox
         (carrier_code, topic, entity_type, entity_id, payload, status, locked_until)
       VALUES ('IPOST_GO', 'shipment.ready', 'Shipment', 'stuck-entity',
               '{"shipmentNo":"FF000000999"}'::jsonb, 'IN_PROGRESS', now() - interval '5 minutes')`,
    );
    const recovered = await as(request(http).post('/api/v1/integration/outbox/dispatch')).send({});
    check(
      recovered.body.claimed === 1 && recovered.body.delivered === 1,
      'Сообщение с истёкшей арендой подобрано следующим проходом',
      JSON.stringify(recovered.body),
    );

    // ---------- 4. Входящие вебхуки: отказы -----------------------------------
    console.log('\n4. Входящие вебхуки: отказы');
    const webhookUrl = '/api/v1/integration/carriers/IPOST_GO/webhook';
    // Тело передаётся СТРОКОЙ, а не Buffer'ом: supertest прогнал бы буфер через
    // JSON.stringify и отправил {"type":"Buffer",...} — подпись считалась бы по
    // одним байтам, а до сервера доехали бы другие.
    const body = (payload: CarrierWebhookPayload) => JSON.stringify(payload);
    const sign = (raw: string, seconds = Math.floor(Date.now() / 1000)) =>
      signPayload(SECRET, Buffer.from(raw, 'utf8'), seconds);

    const handedOver: CarrierWebhookPayload = {
      shipmentNo: shipment.shipmentNo,
      status: 'HANDED_OVER',
      occurredAt: new Date().toISOString(),
      trackingNo: 'IPST-778899',
    };
    const handedRaw = body(handedOver);

    const noSignature = await request(http)
      .post(webhookUrl)
      .set('Content-Type', 'application/json')
      .set('X-FF-Delivery-Id', 'd-nosig')
      .send(handedRaw);
    check(noSignature.status === 401, 'Вебхук без подписи → 401', `status=${noSignature.status}`);

    const badSignature = await request(http)
      .post(webhookUrl)
      .set('Content-Type', 'application/json')
      .set('X-FF-Delivery-Id', 'd-bad')
      .set('X-FF-Signature', sign(body({ ...handedOver, shipmentNo: 'FF999999999' })))
      .send(handedRaw);
    check(badSignature.status === 401, 'Подпись от другого тела → 401', `status=${badSignature.status}`);

    const stale = await request(http)
      .post(webhookUrl)
      .set('Content-Type', 'application/json')
      .set('X-FF-Delivery-Id', 'd-stale')
      .set('X-FF-Signature', sign(handedRaw, Math.floor(Date.now() / 1000) - 3600))
      .send(handedRaw);
    check(stale.status === 401, 'Просроченная подпись → 401 (защита от повтора)', `status=${stale.status}`);

    const rejected: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM webhook_deliveries WHERE result='REJECTED'`,
    );
    check(Number(rejected[0].count) >= 3, 'Отвергнутые доставки записаны для разбора', rejected[0].count);

    const noSecretResponse = await request(http)
      .post('/api/v1/integration/carriers/UNKNOWN/webhook')
      .set('X-FF-Delivery-Id', 'd-unknown')
      .set('X-FF-Signature', sign(handedRaw))
      .send(handedRaw);
    check(noSecretResponse.status === 401, 'Вебхук неизвестного перевозчика → 401');

    // ---------- 5. Входящие вебхуки: применение -------------------------------
    console.log('\n5. Входящие вебхуки: применение');
    const accepted = await request(http)
      .post(webhookUrl)
      .set('Content-Type', 'application/json')
      .set('X-FF-Delivery-Id', 'd-handover-1')
      .set('X-FF-Signature', sign(handedRaw))
      .send(handedRaw);
    check(
      accepted.status === 201 && accepted.body.result === 'ACCEPTED',
      'Корректный вебхук принят',
      JSON.stringify(accepted.body),
    );

    const afterHandover: Array<{ status: string; tracking_no: string; handed_over_at: string }> =
      await dataSource.query(
        `SELECT status, tracking_no, handed_over_at FROM shipments WHERE id=$1`,
        [shipment.id],
      );
    check(
      afterHandover[0].status === 'HANDED_OVER' && afterHandover[0].tracking_no === 'IPST-778899',
      'Отправление передано, трек перевозчика записан',
      JSON.stringify(afterHandover[0]),
    );

    const orderShipped = await as(request(http).get(`/api/v1/orders/${order.id}`));
    check(orderShipped.body.status === 'SHIPPED', 'Заказ перешёл в SHIPPED', orderShipped.body.status);

    const shippedStock: Array<{ status: string; quantity: number }> = await dataSource.query(
      `SELECT status, quantity FROM stock WHERE sku_id=$1 AND bin_id=$2 AND quantity>0`,
      [sku.id, shipBin.id],
    );
    check(
      shippedStock.length === 1 && shippedStock[0].status === 'SHIPPED' && shippedStock[0].quantity === 2,
      'Товар списан со склада в статус SHIPPED при передаче',
      JSON.stringify(shippedStock),
    );

    const replay = await request(http)
      .post(webhookUrl)
      .set('Content-Type', 'application/json')
      .set('X-FF-Delivery-Id', 'd-handover-1')
      .set('X-FF-Signature', sign(handedRaw))
      .send(handedRaw);
    check(
      replay.status === 201 && replay.body.result === 'DUPLICATE',
      'Повтор той же доставки не применяется второй раз',
      JSON.stringify(replay.body),
    );
    const shipMovements: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM stock_movements WHERE reason='SHIP' AND reference_id=$1`,
      [order.id],
    );
    check(shipMovements[0].count === '1', 'Повтор не списал товар дважды', shipMovements[0].count);

    const outOfOrder: CarrierWebhookPayload = {
      shipmentNo: shipment.shipmentNo,
      status: 'DELIVERED',
      occurredAt: new Date().toISOString(),
    };
    // DELIVERED достижим только из IN_TRANSIT — пропуск этапа обязан быть отбит.
    const skipped = await request(http)
      .post(webhookUrl)
      .set('Content-Type', 'application/json')
      .set('X-FF-Delivery-Id', 'd-skip')
      .set('X-FF-Signature', sign(body(outOfOrder)))
      .send(body(outOfOrder));
    check(
      skipped.status === 409,
      'Статус не по порядку отбит статусной машиной → 409',
      `status=${skipped.status}`,
    );

    const inTransit: CarrierWebhookPayload = {
      shipmentNo: shipment.shipmentNo,
      status: 'IN_TRANSIT',
      occurredAt: new Date().toISOString(),
    };
    const transit = await request(http)
      .post(webhookUrl)
      .set('Content-Type', 'application/json')
      .set('X-FF-Delivery-Id', 'd-transit')
      .set('X-FF-Signature', sign(body(inTransit)))
      .send(body(inTransit));
    check(transit.body.result === 'ACCEPTED', 'Промежуточный статус принят');
    const orderStillShipped = await as(request(http).get(`/api/v1/orders/${order.id}`));
    check(
      orderStillShipped.body.status === 'SHIPPED',
      'IN_TRANSIT не двигает заказ — это состояние доставки, а не заказа',
      orderStillShipped.body.status,
    );

    const delivered: CarrierWebhookPayload = {
      shipmentNo: shipment.shipmentNo,
      status: 'DELIVERED',
      occurredAt: new Date().toISOString(),
      pod: { recipientName: 'Иванов И.И.', signatureUrl: 'https://cdn.ipost/sign/1.png', photoUrl: null },
      cod: { collectedAmount: '250000.00', collectedAt: new Date().toISOString() },
    };
    const deliveredResponse = await request(http)
      .post(webhookUrl)
      .set('Content-Type', 'application/json')
      .set('X-FF-Delivery-Id', 'd-delivered')
      .set('X-FF-Signature', sign(body(delivered)))
      .send(body(delivered));
    check(deliveredResponse.body.result === 'ACCEPTED', 'Доставка принята');

    const finalShipment: Array<Record<string, unknown>> = await dataSource.query(
      `SELECT status, delivered_at, pod_recipient_name, pod_signature_url,
              cod_collected_amount, cod_collected_at
         FROM shipments WHERE id=$1`,
      [shipment.id],
    );
    check(
      finalShipment[0].status === 'DELIVERED' && finalShipment[0].pod_recipient_name === 'Иванов И.И.',
      'POD сохранён вместе со статусом',
      JSON.stringify(finalShipment[0]),
    );
    check(
      finalShipment[0].cod_collected_amount === '250000.00' && finalShipment[0].cod_collected_at !== null,
      'Собранный наложенный платёж зафиксирован суммой и временем',
      JSON.stringify({
        amount: finalShipment[0].cod_collected_amount,
        at: finalShipment[0].cod_collected_at,
      }),
    );
    const orderDelivered = await as(request(http).get(`/api/v1/orders/${order.id}`));
    check(orderDelivered.body.status === 'DELIVERED', 'Заказ доставлен', orderDelivered.body.status);

    // ---------- 6. История и инварианты ---------------------------------------
    console.log('\n6. История и инварианты');
    const history = await as(request(http).get(`/api/v1/integration/shipments/${shipment.id}/history`));
    const chain = history.body.map((e: { toStatus: string }) => e.toStatus).join(' → ');
    check(
      chain === 'READY → HANDED_OVER → IN_TRANSIT → DELIVERED',
      'История отправления полная и по порядку',
      chain,
    );
    check(
      history.body[0].source === 'FF' && history.body[1].source === 'CARRIER',
      'Видно, кто поставил статус: склад или перевозчик',
    );

    const mismatch: Array<{ mismatches: string }> = await dataSource.query(`
      WITH ledger AS (
        SELECT sku_id, warehouse_id, to_bin_id AS bin_id, lot_id, to_status AS status, quantity AS qty
          FROM stock_movements WHERE to_bin_id IS NOT NULL
        UNION ALL
        SELECT sku_id, warehouse_id, from_bin_id, lot_id, from_status, -quantity
          FROM stock_movements WHERE from_bin_id IS NOT NULL
      ), agg AS (
        SELECT sku_id, warehouse_id, bin_id, lot_id, status, SUM(qty)::int AS qty
          FROM ledger GROUP BY 1,2,3,4,5
      )
      SELECT count(*)::text AS mismatches
        FROM agg FULL JOIN stock s
          ON s.sku_id = agg.sku_id AND s.warehouse_id = agg.warehouse_id
         AND s.bin_id = agg.bin_id AND s.lot_id IS NOT DISTINCT FROM agg.lot_id
         AND s.status = agg.status
       WHERE COALESCE(s.quantity, 0) <> COALESCE(agg.qty, 0)
    `);
    check(mismatch[0].mismatches === '0', 'Журнал сходится с остатком после отгрузки');

    const audited: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events
        WHERE action='STATE_TRANSITION' AND entity_type='Shipment' AND entity_id=$1`,
      [shipment.id],
    );
    check(audited[0].count === '3', 'Все переходы отправления в аудите', audited[0].count);
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    if (carrier) await new Promise<void>((resolve) => carrier!.server.close(() => resolve()));
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\nintegration e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
