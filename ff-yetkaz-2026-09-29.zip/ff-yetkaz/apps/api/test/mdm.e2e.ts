// Сквозной тест этапа 0.2 (MDM) против настоящего PostgreSQL.
//   npx ts-node -T test/mdm.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { SellerEntity, UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_mdm_pg');
const PG_PORT = Number(process.env.FF_MDM_PGPORT || 5443);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_mdm');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_mdm`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();

    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }

    async function login(email: string): Promise<string> {
      const response = await request(http)
        .post('/api/v1/auth/login')
        .send({ email, password: PASSWORD });
      return response.body.accessToken as string;
    }

    // ---------- 1. Миграции -------------------------------------------------
    console.log('\n1. Миграции MDM');
    // По имени, а не по счётчику: следующие этапы добавляют свои миграции.
    check(
      applied.some((m) => m.name === 'Mdm1785888000000'),
      'Миграция MDM применилась',
      `применено всего: ${applied.length}`,
    );
    const tables: Array<{ table_name: string }> = await dataSource.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`,
    );
    const names = tables.map((t) => t.table_name);
    for (const expected of ['warehouses', 'bin_locations', 'skus', 'sku_barcodes']) {
      check(names.includes(expected), `Таблица ${expected} создана`);
    }

    await createUser('admin@ff.local', ['ADMIN'], null);
    await createUser('operator@ff.local', ['WAREHOUSE_OPERATOR'], null);
    await createUser('picker@ff.local', ['PICKER'], null);
    const adminToken = await login('admin@ff.local');
    const operatorToken = await login('operator@ff.local');
    const pickerToken = await login('picker@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);
    const asOperator = (r: request.Test) => r.set('Authorization', `Bearer ${operatorToken}`);
    const asPicker = (r: request.Test) => r.set('Authorization', `Bearer ${pickerToken}`);

    // ---------- 2. Селлеры --------------------------------------------------
    console.log('\n2. Селлеры');
    const sellerA = await asAdmin(request(http).post('/api/v1/sellers')).send({
      code: 'ACME',
      legalName: 'ООО Акме',
      contactEmail: 'ops@acme.uz',
    });
    check(sellerA.status === 201, 'ADMIN создал селлера', `status=${sellerA.status}`);

    const sellerB = await asAdmin(request(http).post('/api/v1/sellers')).send({
      code: 'BETA',
      legalName: 'ООО Бета',
    });
    check(sellerB.status === 201, 'Создан второй селлер');

    const dupSeller = await asAdmin(request(http).post('/api/v1/sellers')).send({
      code: 'acme',
      legalName: 'Дубль',
    });
    check(dupSeller.status === 409, 'Дубль кода селлера (иной регистр) → 409', `status=${dupSeller.status}`);

    const operatorCreatesSeller = await asOperator(request(http).post('/api/v1/sellers')).send({
      code: 'GAMMA',
      legalName: 'ООО Гамма',
    });
    check(
      operatorCreatesSeller.status === 403,
      'WAREHOUSE_OPERATOR не заводит селлеров → 403',
      `status=${operatorCreatesSeller.status}`,
    );

    // ---------- 3. Склады ---------------------------------------------------
    console.log('\n3. Склады');
    const warehouse = await asOperator(request(http).post('/api/v1/warehouses')).send({
      code: 'TAS-1',
      name: 'Ташкент, основной',
      timezone: 'Asia/Tashkent',
    });
    check(warehouse.status === 201, 'Склад создан', `status=${warehouse.status}`);

    const badTz = await asOperator(request(http).post('/api/v1/warehouses')).send({
      code: 'TAS-2',
      name: 'Плохая зона',
      timezone: 'Mars/Olympus',
    });
    check(badTz.status === 400, 'Несуществующая таймзона → 400', `status=${badTz.status}`);

    const warehouse2 = await asOperator(request(http).post('/api/v1/warehouses')).send({
      code: 'SAM-1',
      name: 'Самарканд',
    });
    check(warehouse2.status === 201, 'Второй склад создан (таймзона по умолчанию)');
    check(warehouse2.body.timezone === 'Asia/Tashkent', 'Таймзона по умолчанию проставлена');

    // ---------- 4. Ячейки ---------------------------------------------------
    console.log('\n4. Ячейки хранения');
    const binB = await asOperator(request(http).post('/api/v1/bin-locations')).send({
      warehouseId: warehouse.body.id,
      code: 'A-02-01-01',
    });
    const binA = await asOperator(request(http).post('/api/v1/bin-locations')).send({
      warehouseId: warehouse.body.id,
      code: 'A-01-01-01',
      kind: 'PICKING',
    });
    check(binA.status === 201 && binB.status === 201, 'Ячейки созданы');
    check(binA.body.kind === 'PICKING', 'Назначение ячейки сохранено');

    const dupBin = await asOperator(request(http).post('/api/v1/bin-locations')).send({
      warehouseId: warehouse.body.id,
      code: 'a-01-01-01',
    });
    check(dupBin.status === 409, 'Дубль кода ячейки на складе → 409', `status=${dupBin.status}`);

    const sameCodeOtherWarehouse = await asOperator(request(http).post('/api/v1/bin-locations')).send({
      warehouseId: warehouse2.body.id,
      code: 'A-01-01-01',
    });
    check(
      sameCodeOtherWarehouse.status === 201,
      'Тот же код ячейки на другом складе допустим',
      `status=${sameCodeOtherWarehouse.status}`,
    );

    const binList = await asPicker(request(http).get(`/api/v1/warehouses/${warehouse.body.id}/bins`));
    check(
      binList.status === 200 && binList.body[0].code === 'A-01-01-01',
      'Список ячеек отсортирован по коду (порядок обхода при сборке)',
      JSON.stringify(binList.body.map((b: { code: string }) => b.code)),
    );

    // ---------- 5. SKU ------------------------------------------------------
    console.log('\n5. SKU');
    const sku = await asOperator(request(http).post('/api/v1/skus')).send({
      sellerId: sellerA.body.id,
      skuCode: 'ACME-001',
      name: 'Чайник электрический',
      lengthMm: 300,
      widthMm: 200,
      heightMm: 250,
      weightG: 1500,
    });
    check(sku.status === 201, 'SKU создан', `status=${sku.status}`);
    check(sku.body.volumeMm3 === '15000000', 'Объём вычислен БД', `volumeMm3=${sku.body.volumeMm3}`);

    const dupSku = await asOperator(request(http).post('/api/v1/skus')).send({
      sellerId: sellerA.body.id,
      skuCode: 'acme-001',
      name: 'Дубль',
    });
    check(dupSku.status === 409, 'Дубль артикула у селлера (иной регистр) → 409', `status=${dupSku.status}`);

    const sameCodeOtherSeller = await asOperator(request(http).post('/api/v1/skus')).send({
      sellerId: sellerB.body.id,
      skuCode: 'ACME-001',
      name: 'Такой же артикул у другого селлера',
    });
    check(
      sameCodeOtherSeller.status === 201,
      'Тот же артикул у другого селлера допустим',
      `status=${sameCodeOtherSeller.status}`,
    );

    const expiryWithoutLot = await asOperator(request(http).post('/api/v1/skus')).send({
      sellerId: sellerA.body.id,
      skuCode: 'ACME-002',
      name: 'Йогурт',
      isExpiryTracked: true,
    });
    check(
      expiryWithoutLot.status === 400,
      'Учёт срока годности без партионного → 400',
      `status=${expiryWithoutLot.status}`,
    );

    const shelfLifeWithoutExpiry = await asOperator(request(http).post('/api/v1/skus')).send({
      sellerId: sellerA.body.id,
      skuCode: 'ACME-003',
      name: 'Печенье',
      shelfLifeDays: 180,
    });
    check(
      shelfLifeWithoutExpiry.status === 400,
      'Срок хранения без учёта срока годности → 400',
      `status=${shelfLifeWithoutExpiry.status}`,
    );

    const perishable = await asOperator(request(http).post('/api/v1/skus')).send({
      sellerId: sellerA.body.id,
      skuCode: 'ACME-004',
      name: 'Молоко',
      isLotTracked: true,
      isExpiryTracked: true,
      shelfLifeDays: 14,
    });
    check(perishable.status === 201, 'Партионный SKU со сроком годности создан', `status=${perishable.status}`);

    const pickerCreatesSku = await asPicker(request(http).post('/api/v1/skus')).send({
      sellerId: sellerA.body.id,
      skuCode: 'ACME-999',
      name: 'Из-под сборщика',
    });
    check(pickerCreatesSku.status === 403, 'PICKER не заводит SKU → 403', `status=${pickerCreatesSku.status}`);

    // ---------- 6. Штрихкоды ------------------------------------------------
    console.log('\n6. Штрихкоды');
    const withBarcode = await asOperator(
      request(http).post(`/api/v1/skus/${sku.body.id}/barcodes`),
    ).send({ barcode: '4600051000057', kind: 'EAN13', isPrimary: true });
    check(withBarcode.status === 201, 'Штрихкод добавлен', `status=${withBarcode.status}`);
    check(withBarcode.body.barcodes.length === 1, 'Штрихкод виден в карточке SKU');

    const globalDup = await asOperator(
      request(http).post(`/api/v1/skus/${sameCodeOtherSeller.body.id}/barcodes`),
    ).send({ barcode: '4600051000057', kind: 'EAN13' });
    check(globalDup.status === 409, 'Тот же штрихкод у другого селлера → 409 (глобальная уникальность)');
    check(
      typeof globalDup.body.message === 'string' && globalDup.body.message.includes('ACME-001'),
      'Сообщение о конфликте называет SKU-владельца',
      globalDup.body.message,
    );

    // Неудачная попытка сделать основным конфликтующий штрихкод не должна
    // оставить SKU без основного кода: снятие флага и вставка — одна транзакция.
    const failedPrimary = await asOperator(
      request(http).post(`/api/v1/skus/${sku.body.id}/barcodes`),
    ).send({ barcode: '9999999999999', kind: 'EAN13', isPrimary: true });
    const stillPrimary = await asOperator(request(http).get(`/api/v1/skus/${sku.body.id}`));
    const primaries = stillPrimary.body.barcodes.filter((b: { isPrimary: boolean }) => b.isPrimary);
    check(
      failedPrimary.status === 201 && primaries.length === 1,
      'Основной штрихкод ровно один после смены',
      `status=${failedPrimary.status}, основных: ${primaries.length}`,
    );

    // Тот же SKU, конфликтующий код и isPrimary: снятие флага с прежнего основного
    // обязано откатиться вместе с неудавшейся вставкой.
    const conflictPrimary = await asOperator(
      request(http).post(`/api/v1/skus/${sku.body.id}/barcodes`),
    ).send({ barcode: '4600051000057', kind: 'EAN13', isPrimary: true });
    const afterConflict = await asOperator(request(http).get(`/api/v1/skus/${sku.body.id}`));
    const primariesAfter = afterConflict.body.barcodes.filter(
      (b: { isPrimary: boolean }) => b.isPrimary,
    );
    check(
      conflictPrimary.status === 409 && primariesAfter.length === 1,
      'Конфликт при isPrimary откатывается целиком — SKU не остаётся без основного кода',
      `status=${conflictPrimary.status}, основных: ${primariesAfter.length}`,
    );

    const found = await asPicker(request(http).get('/api/v1/skus/by-barcode/4600051000057'));
    check(
      found.status === 200 && found.body.id === sku.body.id,
      'Поиск по штрихкоду находит SKU',
      `status=${found.status}`,
    );

    const notFound = await asPicker(request(http).get('/api/v1/skus/by-barcode/0000000000000'));
    check(notFound.status === 404, 'Неизвестный штрихкод → 404', `status=${notFound.status}`);

    // ---------- 7. Скоуп селлера -------------------------------------------
    console.log('\n7. Скоуп селлера');
    await createUser('seller-a@ff.local', ['SELLER'], sellerA.body.id);
    const sellerToken = await login('seller-a@ff.local');
    const asSeller = (r: request.Test) => r.set('Authorization', `Bearer ${sellerToken}`);

    const sellerSkus = await asSeller(request(http).get('/api/v1/skus'));
    const sellerIds: string[] = sellerSkus.body.map((s: { sellerId: string }) => s.sellerId);
    check(
      sellerSkus.status === 200 && sellerIds.every((id) => id === sellerA.body.id),
      'Селлер видит только свои SKU',
      JSON.stringify(sellerIds),
    );

    const foreignSku = await asSeller(request(http).get(`/api/v1/skus/${sameCodeOtherSeller.body.id}`));
    check(foreignSku.status === 404, 'Чужой SKU для селлера → 404, а не 403', `status=${foreignSku.status}`);

    const staffSees = await asPicker(request(http).get('/api/v1/skus'));
    check(
      staffSees.status === 200 && staffSees.body.length >= 3,
      'Сотрудник оператора видит SKU всех селлеров',
      `их ${staffSees.body.length}`,
    );

    const sellerWarehouses = await asSeller(request(http).get('/api/v1/warehouses'));
    check(
      sellerWarehouses.status === 403,
      'Селлер не видит склады оператора → 403',
      `status=${sellerWarehouses.status}`,
    );

    const sellerList = await asSeller(request(http).get('/api/v1/sellers'));
    check(
      sellerList.status === 200 && sellerList.body.length === 1,
      'В списке селлеров селлер видит только себя',
      `записей: ${sellerList.body.length}`,
    );

    // ---------- 8. Аудит ----------------------------------------------------
    console.log('\n8. Аудит справочников');
    const renamed = await asOperator(request(http).patch(`/api/v1/skus/${sku.body.id}`)).send({
      name: 'Чайник электрический 1.7 л',
    });
    check(renamed.status === 200, 'SKU переименован');

    const auditRows: Array<{ action: string; before: Record<string, unknown> | null; after: Record<string, unknown> | null }> =
      await dataSource.query(
        `SELECT action, before, after FROM audit_events
         WHERE entity_type='Sku' AND action='UPDATE' AND before IS NOT NULL
         ORDER BY occurred_at DESC LIMIT 1`,
      );
    check(auditRows.length === 1, 'UPDATE справочника попал в аудит');
    check(
      auditRows[0]?.before?.name === 'Чайник электрический' &&
        auditRows[0]?.after?.name === 'Чайник электрический 1.7 л',
      'Аудит хранит «было» и «стало»',
      JSON.stringify({ before: auditRows[0]?.before?.name, after: auditRows[0]?.after?.name }),
    );

    const createdSkus = [sku, sameCodeOtherSeller, perishable].filter((r) => r.status === 201).length;
    const createRows: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events WHERE action='CREATE' AND entity_type='Sku'`,
    );
    check(
      createRows[0].count === String(createdSkus),
      'Каждый успешно созданный SKU записан в аудит, отклонённые — нет',
      `создано ${createdSkus}, записей ${createRows[0].count}`,
    );

    // ---------- 9. Идемпотентность на справочнике ---------------------------
    console.log('\n9. Идемпотентность создания SKU');
    const key = 'sku-create-key-1';
    const body = { sellerId: sellerB.body.id, skuCode: 'BETA-777', name: 'Повторяемый' };
    const first = await asOperator(request(http).post('/api/v1/skus')).set('Idempotency-Key', key).send(body);
    const again = await asOperator(request(http).post('/api/v1/skus')).set('Idempotency-Key', key).send(body);
    check(first.status === 201 && again.status === 201, 'Повтор создания принят');
    check(again.body.id === first.body.id, 'Повтор вернул тот же SKU, а не создал второй');

    const betaCount: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM skus WHERE sku_code='BETA-777'`,
    );
    check(betaCount[0].count === '1', 'В БД ровно один BETA-777', `записей: ${betaCount[0].count}`);
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\nmdm e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
