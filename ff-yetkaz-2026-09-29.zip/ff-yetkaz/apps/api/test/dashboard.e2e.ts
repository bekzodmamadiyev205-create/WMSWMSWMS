// Сквозной тест этапа 1.9: сводка склада и витрина селлера.
//   npx ts-node -T test/dashboard.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { MetricDto, Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_dashboard_pg');
const PG_PORT = Number(process.env.FF_DASHBOARD_PGPORT || 5453);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

const metric = (list: MetricDto[], key: string): MetricDto | undefined =>
  list.find((item) => item.key === key);

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_dashboard');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_dashboard`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    const login = async (email: string): Promise<string> =>
      (await request(http).post('/api/v1/auth/login').send({ email, password: PASSWORD })).body
        .accessToken as string;

    await createUser('admin@ff.local', ['ADMIN'], null);
    const adminToken = await login('admin@ff.local');
    const as = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);

    // ---------- 1. Данные ----------------------------------------------------
    console.log('\n1. Подготовка данных');
    const seller = (await as(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'ООО Акме' })).body;
    const other = (await as(request(http).post('/api/v1/sellers')).send({ code: 'BETA', legalName: 'ООО Бета' })).body;
    const wh = (await as(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })).body;
    const mkBin = async (code: string, kind: string) =>
      (await as(request(http).post('/api/v1/bin-locations')).send({ warehouseId: wh.id, code, kind })).body;
    const store = await mkBin('S-01-01-01', 'STORAGE');
    await mkBin('P-01-01-01', 'PACKING');

    const mkSku = async (sellerId: string, code: string, barcode: string) => {
      const sku = (
        await as(request(http).post('/api/v1/skus')).send({
          sellerId,
          skuCode: code,
          name: code,
          weightG: 500,
        })
      ).body;
      await as(request(http).post(`/api/v1/skus/${sku.id}/barcodes`)).send({
        barcode,
        kind: 'EAN13',
        isPrimary: true,
      });
      return sku;
    };
    const skuA = await mkSku(seller.id, 'A', '7000000000010');
    const skuB = await mkSku(other.id, 'B', '7000000000027');

    const stockIn = (skuId: string, quantity: number) =>
      as(request(http).post('/api/v1/inventory/stock-in')).send({
        skuId,
        warehouseId: wh.id,
        binId: store.id,
        quantity,
      });
    await stockIn(skuA.id, 10);
    await stockIn(skuB.id, 5);

    const mkOrder = async (sellerId: string, skuId: string, externalId: string) =>
      (
        await as(request(http).post('/api/v1/orders')).send({
          sellerId,
          channel: 'uzum',
          externalId,
          recipientName: 'Иванов',
          recipientPhone: '+998901234567',
          address: 'Ташкент',
          lines: [{ skuId, quantity: 2 }],
        })
      ).body.order;
    const order1 = await mkOrder(seller.id, skuA.id, 'D-1');
    await mkOrder(seller.id, skuA.id, 'D-2');
    await mkOrder(other.id, skuB.id, 'D-3');

    // Один заказ доводим до собранного — он должен встать в очередь упаковки.
    const task = (await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [order1.id] })).body;
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/assign`)).send({});
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/scan`)).send({
      barcode: '7000000000010',
      quantity: 2,
    });
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/complete`)).send({});

    // ---------- 2. Сводка склада ---------------------------------------------
    console.log('\n2. Сводка склада');
    const ops = await as(request(http).get('/api/v1/dashboard/ops'));
    check(ops.status === 200, 'Сводка отдаётся', `status=${ops.status}`);

    check(
      metric(ops.body.queues, 'orders_to_pick')?.value === 2,
      'Два заказа ждут сборки',
      `${metric(ops.body.queues, 'orders_to_pick')?.value}`,
    );
    check(
      metric(ops.body.queues, 'orders_to_pack')?.value === 1,
      'Один заказ ждёт упаковки',
      `${metric(ops.body.queues, 'orders_to_pack')?.value}`,
    );
    check(
      metric(ops.body.today, 'picked_orders')?.value === 1,
      'За сегодня собран один заказ',
      `${metric(ops.body.today, 'picked_orders')?.value}`,
    );
    check(
      ops.body.problems.every((item: MetricDto) => item.attention === false),
      'Пока всё чисто — ни одна плитка не подсвечена',
      JSON.stringify(ops.body.problems.filter((i: MetricDto) => i.attention).map((i: MetricDto) => i.key)),
    );

    const statuses = Object.fromEntries(
      ops.body.ordersByStatus.map((row: { status: string; count: number }) => [row.status, row.count]),
    );
    check(
      statuses.RESERVED === 2 && statuses.PICKED === 1,
      'Воронка заказов по статусам',
      JSON.stringify(statuses),
    );

    // Разделённый заказ не должен считаться дважды: контейнер не исполняется,
    // его исполняют дети, и попадать в воронку должны только они.
    const splitTotalBefore = ops.body.ordersByStatus.reduce(
      (sum: number, row: { count: number }) => sum + row.count,
      0,
    );
    await dataSource.query(`UPDATE orders SET is_split = true WHERE external_id = 'D-3'`);
    const afterSplit = await as(request(http).get('/api/v1/dashboard/ops'));
    const splitTotalAfter = afterSplit.body.ordersByStatus.reduce(
      (sum: number, row: { count: number }) => sum + row.count,
      0,
    );
    check(
      splitTotalAfter === splitTotalBefore - 1,
      'Заказ-контейнер исключён из воронки',
      `${splitTotalBefore} → ${splitTotalAfter}`,
    );
    await dataSource.query(`UPDATE orders SET is_split = false WHERE external_id = 'D-3'`);

    // Пропущенный срез хранения — недосчитанные деньги, он обязан быть виден.
    await dataSource.query(
      `INSERT INTO storage_snapshots (snapshot_date, seller_id, units, volume_mm3)
       VALUES (current_date - 3, $1, 1, 1000)`,
      [seller.id],
    );
    const withGap = await as(request(http).get('/api/v1/dashboard/ops'));
    const gapTile = metric(withGap.body.problems, 'storage_snapshot_gaps');
    check(
      gapTile?.value === 2 && gapTile?.attention === true,
      'Два дня без среза хранения подсвечены',
      JSON.stringify(gapTile),
    );

    // Появилась проблема — плитка обязана загореться.
    await dataSource.query(
      `INSERT INTO integration_outbox (carrier_code, topic, entity_type, entity_id, payload, status)
       VALUES ('IPOST_GO', 'shipment.ready', 'Shipment', 'broken', '{}'::jsonb, 'FAILED')`,
    );
    const withProblem = await as(request(http).get('/api/v1/dashboard/ops'));
    const failedTile = metric(withProblem.body.problems, 'outbox_failed');
    check(
      failedTile?.value === 1 && failedTile?.attention === true,
      'Недоставленное сообщение подсвечено как проблема',
      JSON.stringify(failedTile),
    );

    // ---------- 3. Витрина селлера ---------------------------------------------
    console.log('\n3. Витрина селлера');
    await createUser('seller@ff.local', ['SELLER'], seller.id);
    const sellerToken = await login('seller@ff.local');
    const asSeller = (r: request.Test) => r.set('Authorization', `Bearer ${sellerToken}`);

    const portal = await asSeller(request(http).get('/api/v1/dashboard/seller'));
    check(portal.status === 200 && portal.body.sellerId === seller.id, 'Селлер видит свой кабинет');
    check(
      portal.body.stock.length === 1 && portal.body.stock[0].skuCode === 'A',
      'В остатках только свои товары',
      JSON.stringify(portal.body.stock.map((s: { skuCode: string }) => s.skuCode)),
    );
    check(
      portal.body.stock[0].available === 6 && portal.body.stock[0].inProgress === 2,
      'Остаток разложен по состояниям: доступно 6, в работе 2',
      JSON.stringify(portal.body.stock[0]),
    );

    // Подмена параметра не должна открывать чужие данные.
    const spoofed = await asSeller(request(http).get(`/api/v1/dashboard/seller?sellerId=${other.id}`));
    check(
      spoofed.status === 200 && spoofed.body.sellerId === seller.id,
      'Подмена sellerId в запросе игнорируется — область берётся из токена',
      spoofed.body.sellerId === other.id ? 'УТЕЧКА' : 'ок',
    );

    const sellerOps = await asSeller(request(http).get('/api/v1/dashboard/ops'));
    check(sellerOps.status === 403, 'Селлер не видит сводку склада → 403', `status=${sellerOps.status}`);

    const adminPortal = await as(request(http).get(`/api/v1/dashboard/seller?sellerId=${other.id}`));
    check(
      adminPortal.body.sellerId === other.id && adminPortal.body.stock[0].skuCode === 'B',
      'Оператор может посмотреть кабинет конкретного селлера',
      adminPortal.body.sellerName,
    );

    const adminNoSeller = await as(request(http).get('/api/v1/dashboard/seller'));
    check(
      adminNoSeller.status === 404,
      'Оператору без указания селлера отвечаем понятной ошибкой',
      `status=${adminNoSeller.status}`,
    );
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\ndashboard e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
