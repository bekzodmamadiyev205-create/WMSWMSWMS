// Сквозной тест этапа 0.1 против НАСТОЯЩЕГО PostgreSQL (embedded-postgres).
// Поднимает реальное Nest-приложение (тот же configureApp, что в проде) и проверяет
// миграцию, идемпотентность, auth, RBAC, неизменяемость аудита, FSM и инвариант seller-scope.
//
// Запуск из ff/apps/api (Windows: постгрес отказывается стартовать под админом —
// запускать де-элевированно):
//   npx ts-node -T test/phase-0.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import { Body, Controller, Get, Post, type INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import { orderFsm, type Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { Public, Roles } from '../src/presentation/http/decorators';
import { FsmService } from '../src/application/fsm/fsm.service';
import { SellerEntity, UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_phase0_pg');
const PG_PORT = Number(process.env.FF_TEST_PGPORT || 5441);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

/**
 * Сравнение JSON без учёта порядка ключей: jsonb в PostgreSQL хранит объект
 * нормализованно и возвращает ключи в своём порядке, а для JSON он не значим.
 */
function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value ?? null);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  const record = value as Record<string, unknown>;
  return `{${Object.keys(record)
    .sort()
    .map((k) => `${JSON.stringify(k)}:${canonicalJson(record[k])}`)
    .join(',')}}`;
}

async function expectRejected(run: () => Promise<unknown>, name: string): Promise<void> {
  try {
    await run();
    check(false, name, 'операция прошла, хотя должна была упасть');
  } catch {
    check(true, name);
  }
}

// --- тестовые ручки: проверяют глобальный интерцептор и RolesGuard ----------
let probeCalls = 0;

@Controller('probe')
class ProbeController {
  @Public()
  @Post()
  create(@Body() body: Record<string, unknown>): { calls: number; echo: Record<string, unknown> } {
    probeCalls += 1;
    return { calls: probeCalls, echo: body };
  }

  @Roles('FINANCE')
  @Get('finance-only')
  financeOnly(): { ok: true } {
    return { ok: true };
  }
}

async function createUser(
  dataSource: DataSource,
  passwords: PasswordService,
  email: string,
  roles: Role[],
  sellerId: string | null,
): Promise<UserEntity> {
  const passwordHash = await passwords.hash(PASSWORD);
  return dataSource.transaction(async (em) => {
    const users = em.getRepository(UserEntity);
    const user = await users.save(
      users.create({ email, passwordHash, fullName: `Тест ${email}`, isActive: true, sellerId }),
    );
    for (const role of roles) {
      await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
    }
    return user;
  });
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_test');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_test`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';
    process.env.IDEMPOTENCY_TTL_HOURS = '24';

    // Импорт динамический: ConfigModule.forRoot() валидирует окружение в момент
    // загрузки модуля, поэтому AppModule нельзя тянуть раньше, чем выставлен env.
    const { AppModule } = await import('../src/app.module');

    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
      controllers: [ProbeController],
    }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const fsm = app.get(FsmService);
    const http = app.getHttpServer();

    // ---------- 1. Миграция -------------------------------------------------
    console.log('\n1. Миграция');
    const applied = await dataSource.runMigrations();
    // Проверяем конкретную миграцию, а не их количество: следующие этапы
    // добавляют свои, и счётчик пришлось бы править каждый раз.
    check(
      applied.some((m) => m.name === 'InitAuthAudit1785801600000'),
      'Миграция этапа 0.1 применилась',
      `применено всего: ${applied.length}`,
    );

    const tables: Array<{ table_name: string }> = await dataSource.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY 1`,
    );
    const names = tables.map((t) => t.table_name);
    for (const expected of ['sellers', 'users', 'user_roles', 'audit_events', 'idempotency_keys']) {
      check(names.includes(expected), `Таблица ${expected} создана`);
    }
    const rerun = await dataSource.runMigrations();
    check(rerun.length === 0, 'Повторный прогон миграций ничего не делает (идемпотентность)');

    // ---------- 2. Идемпотентность -----------------------------------------
    console.log('\n2. Идемпотентность write-запросов');
    const before = probeCalls;

    const first = await request(http).post('/api/v1/probe').set('Idempotency-Key', 'key-1').send({ a: 1 });
    check(first.status === 201, 'Первый POST прошёл', `status=${first.status}`);

    const replay = await request(http).post('/api/v1/probe').set('Idempotency-Key', 'key-1').send({ a: 1 });
    check(replay.status === 201, 'Повтор с тем же ключом принят', `status=${replay.status}`);
    check(
      canonicalJson(replay.body) === canonicalJson(first.body),
      'Повтор вернул ПЕРВЫЙ ответ',
      `${JSON.stringify(first.body)} vs ${JSON.stringify(replay.body)}`,
    );
    check(replay.headers['idempotent-replay'] === 'true', 'Повтор помечен заголовком Idempotent-Replay');
    check(probeCalls === before + 1, 'Обработчик выполнился РОВНО один раз', `вызовов: ${probeCalls - before}`);

    // Порядок ключей в теле не должен считаться другим телом.
    const reordered = await request(http)
      .post('/api/v1/probe')
      .set('Idempotency-Key', 'key-ordered')
      .send({ x: 1, y: 2 });
    const reorderedAgain = await request(http)
      .post('/api/v1/probe')
      .set('Idempotency-Key', 'key-ordered')
      .send({ y: 2, x: 1 });
    check(
      reordered.status === 201 && reorderedAgain.status === 201,
      'Другой порядок ключей в теле — тот же запрос, а не конфликт',
      `${reordered.status}/${reorderedAgain.status}`,
    );

    const mismatch = await request(http).post('/api/v1/probe').set('Idempotency-Key', 'key-1').send({ a: 2 });
    check(mismatch.status === 409, 'Тот же ключ с другим телом → 409', `status=${mismatch.status}`);

    const other = await request(http).post('/api/v1/probe').set('Idempotency-Key', 'key-2').send({ a: 1 });
    check(other.status === 201 && probeCalls === before + 3, 'Другой ключ выполняется заново');

    const noKey = await request(http).post('/api/v1/probe').send({ a: 9 });
    check(noKey.status === 201, 'Без заголовка Idempotency-Key запрос идёт обычным путём');

    const keyRows: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM idempotency_keys`,
    );
    check(keyRows[0].count === '3', 'В idempotency_keys ровно 3 записи', `фактически ${keyRows[0].count}`);

    // ---------- 3. Auth и RBAC ---------------------------------------------
    console.log('\n3. Auth и RBAC');
    const seller = await dataSource
      .getRepository(SellerEntity)
      .save(dataSource.getRepository(SellerEntity).create({ code: 'ACME', legalName: 'ООО Акме', isActive: true }));

    await createUser(dataSource, passwords, 'admin@ff.local', ['ADMIN'], null);
    await createUser(dataSource, passwords, 'finance@ff.local', ['FINANCE'], null);

    const badLogin = await request(http)
      .post('/api/v1/auth/login')
      .send({ email: 'admin@ff.local', password: 'неверный' });
    check(badLogin.status === 401, 'Неверный пароль → 401', `status=${badLogin.status}`);
    check(
      typeof badLogin.body.error === 'string' && typeof badLogin.body.message === 'string',
      'Ошибка приходит в едином конверте {error, message, correlationId}',
      JSON.stringify(badLogin.body),
    );

    const unknownLogin = await request(http)
      .post('/api/v1/auth/login')
      .send({ email: 'нет-такого@ff.local', password: PASSWORD });
    check(
      unknownLogin.status === 401 && unknownLogin.body.message === badLogin.body.message,
      'Неизвестный email и неверный пароль отвечают одинаково (нет перечисления учёток)',
    );

    const okLogin = await request(http)
      .post('/api/v1/auth/login')
      .send({ email: 'ADMIN@ff.local', password: PASSWORD });
    check(okLogin.status === 200, 'Логин успешен (email регистронезависим)', `status=${okLogin.status}`);
    check(typeof okLogin.body.accessToken === 'string' && okLogin.body.accessToken.length > 20, 'Выдан accessToken');
    check(
      Array.isArray(okLogin.body.user?.roles) && okLogin.body.user.roles[0] === 'ADMIN',
      'В ответе приехали роли пользователя',
      JSON.stringify(okLogin.body.user),
    );

    const adminToken = okLogin.body.accessToken as string;

    const meAnon = await request(http).get('/api/v1/auth/me');
    check(meAnon.status === 401, 'GET /auth/me без токена → 401', `status=${meAnon.status}`);

    // Заголовки HTTP — только latin-1, поэтому «битый токен» тоже латиницей.
    const meBad = await request(http).get('/api/v1/auth/me').set('Authorization', 'Bearer broken.token.value');
    check(meBad.status === 401, 'Битый токен → 401', `status=${meBad.status}`);

    const me = await request(http).get('/api/v1/auth/me').set('Authorization', `Bearer ${adminToken}`);
    check(me.status === 200 && me.body.email === 'admin@ff.local', 'GET /auth/me отдаёт профиль', JSON.stringify(me.body));

    const financeLogin = await request(http)
      .post('/api/v1/auth/login')
      .send({ email: 'finance@ff.local', password: PASSWORD });
    const financeToken = financeLogin.body.accessToken as string;

    const forbidden = await request(http)
      .get('/api/v1/probe/finance-only')
      .set('Authorization', `Bearer ${adminToken}`);
    check(forbidden.status === 403, 'ADMIN не проходит на ручку с @Roles(FINANCE) → 403', `status=${forbidden.status}`);

    const allowed = await request(http)
      .get('/api/v1/probe/finance-only')
      .set('Authorization', `Bearer ${financeToken}`);
    check(allowed.status === 200, 'FINANCE проходит на свою ручку', `status=${allowed.status}`);

    // ---------- 4. Аудит ----------------------------------------------------
    console.log('\n4. Аудит');
    const successRows: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events WHERE action='LOGIN_SUCCESS'`,
    );
    check(Number(successRows[0].count) >= 2, 'Успешные логины записаны', `записей: ${successRows[0].count}`);

    const failedRows: Array<{ count: string; after: Record<string, unknown> }> = await dataSource.query(
      `SELECT count(*)::text AS count, min(after::text)::jsonb AS after FROM audit_events WHERE action='LOGIN_FAILED'`,
    );
    check(Number(failedRows[0].count) === 2, 'Оба неуспешных логина записаны', `записей: ${failedRows[0].count}`);

    await expectRejected(
      () => dataSource.query(`UPDATE audit_events SET action='HACKED'`),
      'UPDATE по audit_events запрещён на уровне БД',
    );
    await expectRejected(
      () => dataSource.query(`DELETE FROM audit_events`),
      'DELETE по audit_events запрещён на уровне БД',
    );
    await expectRejected(
      () => dataSource.query(`TRUNCATE audit_events`),
      'TRUNCATE по audit_events запрещён на уровне БД',
    );

    // ---------- 5. FSM + аудит ---------------------------------------------
    console.log('\n5. FSM и аудит переходов');
    await fsm.transition(orderFsm, 'NEW', 'VALIDATED', { entityType: 'Order', entityId: 'order-1' });
    const okTransition: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events WHERE action='STATE_TRANSITION' AND entity_id='order-1'`,
    );
    check(okTransition[0].count === '1', 'Разрешённый переход записан как STATE_TRANSITION');

    await expectRejected(
      () => fsm.transition(orderFsm, 'NEW', 'SHIPPED', { entityType: 'Order', entityId: 'order-2' }),
      'Недопустимый переход бросает исключение',
    );
    const badTransition: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events WHERE action='INVALID_STATE_TRANSITION' AND entity_id='order-2'`,
    );
    check(badTransition[0].count === '1', 'Отказ записан как INVALID_STATE_TRANSITION');

    // Запись об отказе не должна исчезнуть вместе с откатом бизнес-транзакции.
    await expectRejected(
      () =>
        dataSource.transaction(async () => {
          await fsm.transition(orderFsm, 'NEW', 'DELIVERED', { entityType: 'Order', entityId: 'order-3' });
        }),
      'Недопустимый переход внутри транзакции тоже падает',
    );
    const survived: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events WHERE action='INVALID_STATE_TRANSITION' AND entity_id='order-3'`,
    );
    check(survived[0].count === '1', 'Запись об отказе пережила откат транзакции');

    // ---------- 6. Инвариант seller-scope ----------------------------------
    console.log('\n6. Инвариант seller_id ↔ роль SELLER');
    const sellerUser = await createUser(dataSource, passwords, 'seller@ff.local', ['SELLER'], seller.id);
    check(sellerUser.sellerId === seller.id, 'SELLER с seller_id создаётся');

    await expectRejected(
      () => createUser(dataSource, passwords, 'bad-admin@ff.local', ['ADMIN'], seller.id),
      'ADMIN с seller_id отклонён триггером БД',
    );
    await expectRejected(
      () => createUser(dataSource, passwords, 'bad-seller@ff.local', ['SELLER'], null),
      'SELLER без seller_id отклонён триггером БД',
    );

    const sellerLogin = await request(http)
      .post('/api/v1/auth/login')
      .send({ email: 'seller@ff.local', password: PASSWORD });
    check(
      sellerLogin.status === 200 && sellerLogin.body.user.sellerId === seller.id,
      'sellerId доезжает до клиента в ответе логина',
      JSON.stringify(sellerLogin.body.user),
    );

    // ---------- 7. Health ---------------------------------------------------
    console.log('\n7. Health');
    const health = await request(http).get('/api/v1/health');
    check(health.status === 200 && health.body.db === 'up', 'GET /health отдаёт ok', JSON.stringify(health.body));
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\nphase-0 e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
