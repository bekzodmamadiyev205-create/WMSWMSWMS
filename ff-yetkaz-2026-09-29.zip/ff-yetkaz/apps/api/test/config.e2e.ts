// Сквозной тест этапа 1.6: конфигурация живёт в БД и реально влияет на поведение.
//   npx ts-node -T test/config.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import { SETTING_KEYS, type Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_config_pg');
const PG_PORT = Number(process.env.FF_CONFIG_PGPORT || 5450);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_config');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_config`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';
    delete process.env.FF_IPOST_GO_SECRET;

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    const login = async (email: string): Promise<string> =>
      (await request(http).post('/api/v1/auth/login').send({ email, password: PASSWORD })).body
        .accessToken as string;

    await createUser('admin@ff.local', ['ADMIN'], null);
    await createUser('packer@ff.local', ['PACKER'], null);
    const adminToken = await login('admin@ff.local');
    const packerToken = await login('packer@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);
    const asPacker = (r: request.Test) => r.set('Authorization', `Bearer ${packerToken}`);

    // ---------- 1. Схема и засев -------------------------------------------
    console.log('\n1. Схема и засев');
    check(
      applied.some((m) => m.name === 'Configuration1786492800000'),
      'Миграция Configuration применилась',
      `всего: ${applied.length}`,
    );

    const settings = await asAdmin(request(http).get('/api/v1/settings'));
    check(settings.status === 200 && settings.body.length === 5, 'Настройки засеяны', `${settings.body.length}`);
    const tolerance = settings.body.find(
      (s: { key: string }) => s.key === SETTING_KEYS.WEIGHT_TOLERANCE_PCT,
    );
    check(
      tolerance?.value === 5 && tolerance?.valueType === 'number',
      'Допуск по весу лежит в БД числом, а не константой в коде',
      JSON.stringify(tolerance),
    );
    check(
      settings.body.every((s: { description: string }) => s.description.length > 0),
      'У каждой настройки есть описание — иначе оператор не поймёт, что крутит',
    );

    const carriers = await asAdmin(request(http).get('/api/v1/carriers'));
    const ipost = carriers.body[0];
    check(
      carriers.body.length === 1 && ipost.code === 'IPOST_GO',
      'Перевозчик заведён заготовкой',
      JSON.stringify(carriers.body.map((c: { code: string }) => c.code)),
    );
    check(
      ipost.isActive === false && ipost.secretConfigured === false,
      'Заготовка выключена и без секрета — включать её осознанно',
      JSON.stringify({ active: ipost.isActive, secret: ipost.secretConfigured }),
    );
    check(
      !JSON.stringify(ipost).includes('FF_IPOST_GO_SECRET_VALUE'),
      'В ответе нет самого секрета — только имя переменной окружения',
      ipost.secretEnvKey,
    );

    // ---------- 2. Права и валидация ---------------------------------------
    console.log('\n2. Права и валидация');
    const packerRead = await asPacker(request(http).get('/api/v1/settings'));
    check(packerRead.status === 200, 'Сотрудник склада читает настройки — они влияют на его работу');

    const packerWrite = await asPacker(
      request(http).put(`/api/v1/settings/${SETTING_KEYS.WEIGHT_TOLERANCE_PCT}`),
    ).send({ value: 50 });
    check(packerWrite.status === 403, 'Менять настройки может только ADMIN → 403', `status=${packerWrite.status}`);

    const wrongType = await asAdmin(
      request(http).put(`/api/v1/settings/${SETTING_KEYS.WEIGHT_TOLERANCE_PCT}`),
    ).send({ value: 'пять' });
    check(wrongType.status === 400, 'Строка вместо числа отбита → 400', `status=${wrongType.status}`);

    const unknown = await asAdmin(request(http).put('/api/v1/settings/packing.no_such_key')).send({
      value: 1,
    });
    check(unknown.status === 404, 'Незаведённый ключ не создаётся на лету → 404', `status=${unknown.status}`);

    // Ограничение таблицы держит инвариант и в обход сервиса.
    let dbRejected = false;
    try {
      await dataSource.query(
        `UPDATE app_settings SET value = '"строка"'::jsonb WHERE key = $1`,
        [SETTING_KEYS.WEIGHT_TOLERANCE_PCT],
      );
    } catch {
      dbRejected = true;
    }
    check(dbRejected, 'Прямой SQL с неверным типом отбит ограничением таблицы');

    // ---------- 3. Настройка реально влияет на поведение --------------------
    console.log('\n3. Настройка влияет на поведение');
    const seller = (await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'Акме' })).body;
    const wh = (await asAdmin(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })).body;
    const mkBin = async (code: string, kind: string) =>
      (await asAdmin(request(http).post('/api/v1/bin-locations')).send({ warehouseId: wh.id, code, kind })).body;
    const store = await mkBin('S-01-01-01', 'STORAGE');
    await mkBin('P-01-01-01', 'PACKING');

    const sku = (
      await asAdmin(request(http).post('/api/v1/skus')).send({
        sellerId: seller.id,
        skuCode: 'W',
        name: 'W',
        weightG: 1000,
      })
    ).body;
    await asAdmin(request(http).post(`/api/v1/skus/${sku.id}/barcodes`)).send({
      barcode: '4000000000014',
      kind: 'EAN13',
      isPrimary: true,
    });
    await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: sku.id,
      warehouseId: wh.id,
      binId: store.id,
      quantity: 10,
    });

    const packOrder = async (externalId: string, weightG: number) => {
      const order = (
        await asAdmin(request(http).post('/api/v1/orders')).send({
          sellerId: seller.id,
          channel: 'uzum',
          externalId,
          recipientName: 'Иванов',
          recipientPhone: '+998901234567',
          address: 'Ташкент',
          lines: [{ skuId: sku.id, quantity: 1 }],
        })
      ).body.order;
      const task = (
        await asAdmin(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [order.id] })
      ).body;
      await asAdmin(request(http).post(`/api/v1/picking/tasks/${task.id}/assign`)).send({});
      await asAdmin(request(http).post(`/api/v1/picking/tasks/${task.id}/scan`)).send({
        barcode: '4000000000014',
        quantity: 1,
      });
      await asAdmin(request(http).post(`/api/v1/picking/tasks/${task.id}/complete`)).send({});
      const pkg = (await asAdmin(request(http).post(`/api/v1/packing/orders/${order.id}/start`)).send({})).body;
      const done = await asAdmin(request(http).post(`/api/v1/packing/orders/${order.id}/complete`)).send({
        weightG,
      });
      return { order, pkg, done };
    };

    // 1200 г при расчётных 1000 — отклонение 20%.
    const strict = await packOrder('CFG-1', 1200);
    check(
      strict.done.body.weightMismatch === true && strict.done.body.tolerancePct === 5,
      'При допуске 5% отклонение 20% считается расхождением',
      JSON.stringify({ mismatch: strict.done.body.weightMismatch, tol: strict.done.body.tolerancePct }),
    );
    check(
      strict.pkg.weightTolerancePct === 5,
      'Действующий допуск отдаётся клиенту вместе с упаковкой',
      `${strict.pkg.weightTolerancePct}`,
    );

    const relaxed = await asAdmin(
      request(http).put(`/api/v1/settings/${SETTING_KEYS.WEIGHT_TOLERANCE_PCT}`),
    ).send({ value: 25 });
    check(relaxed.status === 200 && relaxed.body.value === 25, 'Допуск поднят до 25%');

    const loose = await packOrder('CFG-2', 1200);
    check(
      loose.done.body.weightMismatch === false && loose.done.body.tolerancePct === 25,
      'То же отклонение при новом допуске расхождением уже не считается',
      JSON.stringify({ mismatch: loose.done.body.weightMismatch, tol: loose.done.body.tolerancePct }),
    );
    check(
      loose.pkg.weightTolerancePct === 25,
      'Новое значение сразу видно клиенту — кэш сброшен правкой',
      `${loose.pkg.weightTolerancePct}`,
    );

    const audited: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events
        WHERE action='CONFIG_UPDATED' AND entity_type='AppSetting' AND entity_id=$1`,
      [SETTING_KEYS.WEIGHT_TOLERANCE_PCT],
    );
    check(audited[0].count === '1', 'Правка настройки записана в аудит', audited[0].count);

    // ---------- 4. Перевозчик ------------------------------------------------
    console.log('\n4. Перевозчик');
    const noSecret = await asAdmin(request(http).put('/api/v1/carriers/IPOST_GO')).send({
      isActive: true,
    });
    check(
      noSecret.status === 409,
      'Включить перевозчика без секрета в окружении нельзя → 409',
      `status=${noSecret.status}`,
    );

    const badUrl = await asAdmin(request(http).put('/api/v1/carriers/IPOST_GO')).send({
      baseUrl: 'localhost:8080',
    });
    check(badUrl.status === 400, 'Адрес без схемы отбит → 400', `status=${badUrl.status}`);

    process.env.FF_IPOST_GO_SECRET = 'test-shared-secret';
    const activated = await asAdmin(request(http).put('/api/v1/carriers/IPOST_GO')).send({
      baseUrl: 'http://127.0.0.1:9099',
      isActive: true,
    });
    check(
      activated.status === 200 && activated.body.isActive === true && activated.body.secretConfigured === true,
      'С заданным секретом перевозчик включается',
      JSON.stringify({ active: activated.body.isActive, secret: activated.body.secretConfigured }),
    );
    check(
      activated.body.baseUrl === 'http://127.0.0.1:9099',
      'Адрес интеграции меняется без пересборки — он в БД',
      activated.body.baseUrl,
    );

    const carrierAudit: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events
        WHERE action='CONFIG_UPDATED' AND entity_type='Carrier'`,
    );
    check(Number(carrierAudit[0].count) >= 1, 'Правка перевозчика в аудите', carrierAudit[0].count);
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\nconfig e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
