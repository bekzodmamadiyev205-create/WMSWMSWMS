// Сквозной тест этапа 1.1 (Inventory) против настоящего PostgreSQL.
//   npx ts-node -T test/inventory.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_inventory_pg');
const PG_PORT = Number(process.env.FF_INV_PGPORT || 5444);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_inventory');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_inventory`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    async function login(email: string): Promise<string> {
      const response = await request(http)
        .post('/api/v1/auth/login')
        .send({ email, password: PASSWORD });
      return response.body.accessToken as string;
    }

    await createUser('admin@ff.local', ['ADMIN'], null);
    await createUser('picker@ff.local', ['PICKER'], null);
    const adminToken = await login('admin@ff.local');
    const pickerToken = await login('picker@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);
    const asPicker = (r: request.Test) => r.set('Authorization', `Bearer ${pickerToken}`);

    // ---------- 1. Миграция и справочники -----------------------------------
    console.log('\n1. Миграция');
    check(
      applied.some((m) => m.name === 'Inventory1785974400000'),
      'Миграция Inventory применилась',
      `всего: ${applied.length}`,
    );
    const tables: Array<{ table_name: string }> = await dataSource.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`,
    );
    const names = tables.map((t) => t.table_name);
    for (const expected of ['lots', 'stock', 'stock_movements', 'reservations']) {
      check(names.includes(expected), `Таблица ${expected} создана`);
    }

    const seller = (
      await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'Акме' })
    ).body;
    const warehouse = (
      await asAdmin(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })
    ).body;
    const binA = (
      await asAdmin(request(http).post('/api/v1/bin-locations')).send({
        warehouseId: warehouse.id,
        code: 'A-01-01-01',
      })
    ).body;
    const binB = (
      await asAdmin(request(http).post('/api/v1/bin-locations')).send({
        warehouseId: warehouse.id,
        code: 'A-01-01-02',
      })
    ).body;

    async function makeSku(code: string, extra: Record<string, unknown> = {}) {
      const response = await asAdmin(request(http).post('/api/v1/skus')).send({
        sellerId: seller.id,
        skuCode: code,
        name: code,
        ...extra,
      });
      return response.body;
    }
    const plainSku = await makeSku('PLAIN-1');
    const milk = await makeSku('MILK-1', { isLotTracked: true, isExpiryTracked: true, shelfLifeDays: 14 });

    // ---------- 2. Приход ---------------------------------------------------
    console.log('\n2. Приход');
    const received = await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      quantity: 10,
    });
    check(received.status === 201, 'Приход принят', `status=${received.status}`);
    check(received.body.available === 10, 'Доступный остаток 10', JSON.stringify(received.body.byStatus));

    const pickerStockIn = await asPicker(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      quantity: 1,
    });
    check(pickerStockIn.status === 403, 'PICKER не делает приход → 403', `status=${pickerStockIn.status}`);

    const lotOnPlain = await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      quantity: 1,
      lotCode: 'L-1',
    });
    check(lotOnPlain.status === 400, 'Партия у непартионного SKU → 400', `status=${lotOnPlain.status}`);

    const milkNoLot = await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: milk.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      quantity: 5,
    });
    check(milkNoLot.status === 400, 'Партионный SKU без lotCode → 400', `status=${milkNoLot.status}`);

    const milkNoExpiry = await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: milk.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      quantity: 5,
      lotCode: 'L-FAR',
    });
    check(milkNoExpiry.status === 400, 'SKU со сроком годности без expiryDate → 400', `status=${milkNoExpiry.status}`);

    // ---------- 3. Перемещение и статусы ------------------------------------
    console.log('\n3. Перемещение');
    const moved = await asAdmin(request(http).post('/api/v1/inventory/moves')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      fromBinId: binA.id,
      fromStatus: 'AVAILABLE',
      toBinId: binB.id,
      toStatus: 'AVAILABLE',
      quantity: 3,
    });
    check(moved.status === 201 && moved.body.available === 10, 'Перемещение не меняет общий доступный остаток', `available=${moved.body.available}`);

    const badTransition = await asAdmin(request(http).post('/api/v1/inventory/moves')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      fromBinId: binA.id,
      fromStatus: 'AVAILABLE',
      toBinId: binA.id,
      toStatus: 'SHIPPED',
      quantity: 1,
    });
    check(
      badTransition.status === 409 && badTransition.body.error === 'INVALID_TRANSITION',
      'AVAILABLE → SHIPPED отклонён статусной моделью',
      `status=${badTransition.status}, error=${badTransition.body.error}`,
    );

    const tooMuch = await asAdmin(request(http).post('/api/v1/inventory/moves')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      fromBinId: binA.id,
      fromStatus: 'AVAILABLE',
      toBinId: binB.id,
      toStatus: 'AVAILABLE',
      quantity: 999,
    });
    check(tooMuch.status === 409, 'Перемещение больше остатка → 409', `status=${tooMuch.status}`);

    // ---------- 4. Брак -----------------------------------------------------
    console.log('\n4. Брак');
    const damaged = await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      binId: binB.id,
      quantity: 4,
      status: 'DAMAGED',
    });
    check(
      damaged.status === 201 && damaged.body.available === 10 && damaged.body.byStatus.DAMAGED === 4,
      'Брак не попадает в доступный остаток',
      JSON.stringify(damaged.body.byStatus),
    );

    // ---------- 5. Инвентаризация ------------------------------------------
    console.log('\n5. Инвентаризация');
    const noReason = await asAdmin(request(http).post('/api/v1/inventory/adjustments')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      delta: 2,
    });
    check(noReason.status === 400, 'Корректировка без причины → 400', `status=${noReason.status}`);

    const surplus = await asAdmin(request(http).post('/api/v1/inventory/adjustments')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      delta: 2,
      comment: 'Пересчёт: нашли 2 лишних',
    });
    check(surplus.status === 201 && surplus.body.available === 12, 'Излишек добавлен', `available=${surplus.body.available}`);

    const shortage = await asAdmin(request(http).post('/api/v1/inventory/adjustments')).send({
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      delta: -100,
      comment: 'Недостача',
    });
    check(shortage.status === 409, 'Недостача больше остатка → 409', `status=${shortage.status}`);

    // ---------- 6. Инварианты БД -------------------------------------------
    console.log('\n6. Инварианты БД');
    let negativeRejected = false;
    try {
      await dataSource.query(`UPDATE stock SET quantity = -1 WHERE quantity > 0`);
    } catch {
      negativeRejected = true;
    }
    check(negativeRejected, 'Отрицательный остаток запрещён CHECK-ограничением');

    for (const [sql, name] of [
      [`UPDATE stock_movements SET quantity = 1`, 'UPDATE журнала движений запрещён'],
      [`DELETE FROM stock_movements`, 'DELETE журнала движений запрещён'],
    ] as const) {
      let rejected = false;
      try {
        await dataSource.query(sql);
      } catch {
        rejected = true;
      }
      check(rejected, name);
    }

    const mismatch: Array<{ mismatches: string }> = await dataSource.query(`
      WITH ledger AS (
        SELECT sku_id, warehouse_id, to_bin_id AS bin_id, lot_id, to_status AS status, quantity AS qty
          FROM stock_movements WHERE to_bin_id IS NOT NULL
        UNION ALL
        SELECT sku_id, warehouse_id, from_bin_id, lot_id, from_status, -quantity
          FROM stock_movements WHERE from_bin_id IS NOT NULL
      ), agg AS (
        SELECT sku_id, warehouse_id, bin_id, lot_id, status, SUM(qty)::int AS qty
          FROM ledger GROUP BY 1,2,3,4,5
      )
      SELECT count(*)::text AS mismatches
        FROM agg FULL JOIN stock s
          ON s.sku_id = agg.sku_id AND s.warehouse_id = agg.warehouse_id
         AND s.bin_id = agg.bin_id AND s.lot_id IS NOT DISTINCT FROM agg.lot_id
         AND s.status = agg.status
       WHERE COALESCE(s.quantity, 0) <> COALESCE(agg.qty, 0)
    `);
    check(mismatch[0].mismatches === '0', 'Сумма журнала сходится с остатком по каждому срезу', `расхождений: ${mismatch[0].mismatches}`);

    // ---------- 7. FEFO -----------------------------------------------------
    console.log('\n7. FEFO');
    await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: milk.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      quantity: 5,
      lotCode: 'L-FAR',
      expiryDate: '2027-01-01',
    });
    await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: milk.id,
      warehouseId: warehouse.id,
      binId: binB.id,
      quantity: 5,
      lotCode: 'L-NEAR',
      expiryDate: '2026-09-01',
    });
    const lots: Array<{ id: string; lot_code: string }> = await dataSource.query(
      `SELECT id, lot_code FROM lots WHERE sku_id = $1`,
      [milk.id],
    );
    const near = lots.find((l) => l.lot_code === 'L-NEAR');

    const fefo = await asAdmin(request(http).post('/api/v1/inventory/reservations')).send({
      ownerType: 'ORDER',
      ownerId: 'order-fefo',
      skuId: milk.id,
      warehouseId: warehouse.id,
      quantity: 2,
    });
    check(
      fefo.status === 201 && fefo.body.lines.length === 1 && fefo.body.lines[0].lotId === near?.id,
      'Резерв берёт партию с ближайшим сроком годности',
      JSON.stringify(fefo.body.lines?.map((l: { lotId: string }) => l.lotId)),
    );

    // ---------- 8. Резерв и снятие -----------------------------------------
    console.log('\n8. Резерв');
    const before = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${plainSku.id}`))
    ).body[0];

    const reserved = await asAdmin(request(http).post('/api/v1/inventory/reservations')).send({
      ownerType: 'ORDER',
      ownerId: 'order-1',
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      quantity: 4,
    });
    const afterReserve = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${plainSku.id}`))
    ).body[0];
    check(
      reserved.status === 201 && afterReserve.available === before.available - 4,
      'Резерв уменьшает доступный остаток',
      `${before.available} → ${afterReserve.available}`,
    );
    check(afterReserve.byStatus.RESERVED === 4, 'Зарезервировано 4', JSON.stringify(afterReserve.byStatus));

    const tooBig = await asAdmin(request(http).post('/api/v1/inventory/reservations')).send({
      ownerType: 'ORDER',
      ownerId: 'order-2',
      skuId: plainSku.id,
      warehouseId: warehouse.id,
      quantity: 9999,
    });
    check(tooBig.status === 409, 'Резерв больше доступного → 409', `status=${tooBig.status}`);

    const releaseResult = await asAdmin(request(http).post('/api/v1/inventory/reservations/release')).send({
      ownerType: 'ORDER',
      ownerId: 'order-1',
      reason: 'Заказ отменён',
    });
    const afterRelease = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${plainSku.id}`))
    ).body[0];
    check(
      releaseResult.status === 200 && afterRelease.available === before.available,
      'Снятие резерва возвращает остаток',
      `${afterReserve.available} → ${afterRelease.available}`,
    );

    const releaseAgain = await asAdmin(request(http).post('/api/v1/inventory/reservations/release')).send({
      ownerType: 'ORDER',
      ownerId: 'order-1',
    });
    check(releaseAgain.status === 404, 'Повторное снятие резерва → 404', `status=${releaseAgain.status}`);

    // ---------- 9. Гонка за последней единицей ------------------------------
    console.log('\n9. Конкурентный резерв последней единицы');
    const lastSku = await makeSku('LAST-1');
    await asAdmin(request(http).post('/api/v1/inventory/stock-in')).send({
      skuId: lastSku.id,
      warehouseId: warehouse.id,
      binId: binA.id,
      quantity: 1,
    });

    const racers = await Promise.all(
      [1, 2, 3].map((n) =>
        asAdmin(request(http).post('/api/v1/inventory/reservations')).send({
          ownerType: 'ORDER',
          ownerId: `race-${n}`,
          skuId: lastSku.id,
          warehouseId: warehouse.id,
          quantity: 1,
        }),
      ),
    );
    const ok = racers.filter((r) => r.status === 201).length;
    const conflicts = racers.filter((r) => r.status === 409).length;
    check(ok === 1, 'Ровно один параллельный резерв успешен', `успешных: ${ok}, конфликтов: ${conflicts}`);
    check(conflicts === 2, 'Остальные получили 409, а не молчаливый овербукинг');

    const reservedRows: Array<{ total: string }> = await dataSource.query(
      `SELECT COALESCE(SUM(quantity), 0)::text AS total FROM reservations
        WHERE sku_id = $1 AND status = 'ACTIVE'`,
      [lastSku.id],
    );
    check(reservedRows[0].total === '1', 'В резерве ровно одна единица', `в резерве: ${reservedRows[0].total}`);

    const lastStock: Array<{ status: string; quantity: number }> = await dataSource.query(
      `SELECT status, quantity FROM stock WHERE sku_id = $1 AND quantity > 0`,
      [lastSku.id],
    );
    check(
      lastStock.length === 1 && lastStock[0].status === 'RESERVED' && lastStock[0].quantity === 1,
      'Остаток целиком перешёл в RESERVED, ничего не потеряно',
      JSON.stringify(lastStock),
    );

    // ---------- 10. Скоуп селлера ------------------------------------------
    console.log('\n10. Скоуп селлера');
    const otherSeller = (
      await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'BETA', legalName: 'Бета' })
    ).body;
    await createUser('seller-b@ff.local', ['SELLER'], otherSeller.id);
    const sellerToken = await login('seller-b@ff.local');

    const foreignStock = await request(http)
      .get('/api/v1/inventory/stock')
      .set('Authorization', `Bearer ${sellerToken}`);
    check(
      foreignStock.status === 200 && foreignStock.body.length === 0,
      'Селлер не видит остатки чужих SKU',
      `записей: ${foreignStock.body.length}`,
    );

    const staffStock = await asPicker(request(http).get('/api/v1/inventory/stock'));
    check(
      staffStock.status === 200 && staffStock.body.length > 0,
      'Сотрудник склада видит остатки',
      `записей: ${staffStock.body.length}`,
    );

    const movements = await asAdmin(request(http).get(`/api/v1/inventory/movements?skuId=${plainSku.id}`));
    check(
      movements.status === 200 && movements.body.length >= 6,
      'Журнал движений доступен и содержит историю',
      `движений: ${movements.body.length}`,
    );
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\ninventory e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
