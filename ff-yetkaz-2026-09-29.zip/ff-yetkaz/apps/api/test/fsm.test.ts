// Чистый тест статусных моделей: без БД и без Nest.
//   npx ts-node -T test/fsm.test.ts
import { InvalidTransitionError, inventoryUnitFsm, orderFsm, shipmentFsm } from '@ff/shared';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

function expectRejected(run: () => void, name: string): void {
  try {
    run();
    check(false, name, 'исключения не было');
  } catch (error) {
    check(error instanceof InvalidTransitionError, name, error instanceof Error ? '' : String(error));
  }
}

console.log('FSM — таблицы переходов');

// --- Order ---------------------------------------------------------------
const orderChain = [
  'NEW',
  'VALIDATED',
  'RESERVED',
  'PICKING',
  'PICKED',
  'PACKING',
  'PACKED',
  'READY_TO_SHIP',
  'SHIPPED',
  'DELIVERED',
] as const;

let chainOk = true;
for (let i = 0; i < orderChain.length - 1; i++) {
  if (!orderFsm.can(orderChain[i], orderChain[i + 1])) chainOk = false;
}
check(chainOk, 'Order: полная цепочка из ТЗ проходима');
expectRejected(() => orderFsm.assert('NEW', 'SHIPPED'), 'Order: NEW → SHIPPED отклонён');
expectRejected(() => orderFsm.assert('PACKED', 'SHIPPED'), 'Order: PACKED → SHIPPED в обход READY_TO_SHIP отклонён');
expectRejected(() => orderFsm.assert('DELIVERED', 'NEW'), 'Order: из терминального DELIVERED переходов нет');
check(orderFsm.isTerminal('DELIVERED'), 'Order: DELIVERED терминальный');
check(orderFsm.isTerminal('CANCELLED'), 'Order: CANCELLED терминальный');
check(!orderFsm.isState('WAREHOUSE'), 'Order: неизвестное состояние не распознаётся');

// Решение PM: отмена доступна из любого статуса до доставки — иначе отменённый
// заказ держал бы резерв вечно.
for (const from of ['NEW', 'VALIDATED', 'RESERVED', 'PICKING', 'PACKED', 'READY_TO_SHIP'] as const) {
  check(orderFsm.can(from, 'CANCELLED'), `Order: отмена доступна из ${from}`);
}
check(!orderFsm.can('DELIVERED', 'CANCELLED'), 'Order: доставленный заказ отменить нельзя');

try {
  orderFsm.assert('NEW', 'DELIVERED');
  check(false, 'Order: текст ошибки перечисляет разрешённые переходы', 'исключения не было');
} catch (error) {
  check(
    error instanceof Error && error.message.includes('VALIDATED'),
    'Order: текст ошибки перечисляет разрешённые переходы',
  );
}

// --- InventoryUnit -------------------------------------------------------
check(
  inventoryUnitFsm.can('RESERVED', 'AVAILABLE'),
  'Inventory: снятие резерва RESERVED → AVAILABLE (событие inventory.released)',
);
check(
  inventoryUnitFsm.can('PICKED', 'AVAILABLE'),
  'Inventory: short-pick возвращает единицу в остаток',
);
expectRejected(
  () => inventoryUnitFsm.assert('EXPECTED', 'AVAILABLE'),
  'Inventory: EXPECTED → AVAILABLE в обход приёмки отклонён',
);
check(inventoryUnitFsm.isTerminal('DAMAGED'), 'Inventory: DAMAGED терминальный');
check(inventoryUnitFsm.can('QUARANTINE', 'AVAILABLE'), 'Inventory: карантин можно снять');

// --- Shipment ------------------------------------------------------------
check(shipmentFsm.can('READY', 'HANDED_OVER'), 'Shipment: READY → HANDED_OVER разрешён');
expectRejected(
  () => shipmentFsm.assert('READY', 'IN_TRANSIT'),
  'Shipment: READY → IN_TRANSIT в обход передачи отклонён',
);
check(shipmentFsm.isTerminal('DELIVERED'), 'Shipment: DELIVERED терминальный');
check(
  shipmentFsm.next('IN_TRANSIT').length === 3,
  'Shipment: из IN_TRANSIT три исхода (DELIVERED | FAILED | RETURNING)',
);

console.log(`\nfsm test: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
