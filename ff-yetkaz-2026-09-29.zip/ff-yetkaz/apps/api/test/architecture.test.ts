// Сторож слоистой архитектуры. Базы не поднимает — читает исходники.
//   npx ts-node -T test/architecture.test.ts
//
// Правило, которое проверяет только человек при ревью, живёт до первой спешки.
// Здесь каждое архитектурное правило — падающая проверка с именем нарушителя.
//
// ПАДАЕТ — разбираться в причине, а не расширять список исключений. Исключение
// вписывается ПОИМЁННО и С ПРИЧИНОЙ, иначе через полгода в нём окажется половина
// кодовой базы и сторож перестанет что-либо стеречь.
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';

const SRC = join(__dirname, '..', 'src');

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '\n        ' + detail : ''}`);
}

/** Все .ts-файлы слоя, путями относительно src и через '/'. */
function filesOf(...layers: string[]): string[] {
  const out: string[] = [];
  const walk = (dir: string): void => {
    for (const entry of readdirSync(dir)) {
      const full = join(dir, entry);
      if (statSync(full).isDirectory()) walk(full);
      else if (entry.endsWith('.ts')) out.push(relative(SRC, full).split(sep).join('/'));
    }
  };
  for (const layer of layers) {
    const root = join(SRC, layer);
    try {
      walk(root);
    } catch {
      /* слоя нет — это поймает отдельная проверка ниже */
    }
  }
  return out;
}

const read = (rel: string): string => readFileSync(join(SRC, rel), 'utf8');

/** Строки файла без комментариев: правило про код, а не про пояснения к нему. */
function codeLines(rel: string): string[] {
  return read(rel)
    .split('\n')
    .filter((line) => {
      const t = line.trim();
      return t !== '' && !t.startsWith('//') && !t.startsWith('*') && !t.startsWith('/*');
    });
}

/** Нарушители правила «в этих файлах не должно встречаться X». */
function offenders(files: string[], pattern: RegExp): string[] {
  return files.filter((f) => codeLines(f).some((line) => pattern.test(line)));
}

console.log('\nАрхитектура: слои, SQL, внешние вызовы\n');

// ---------- 1. Слои существуют ------------------------------------------
console.log('1. Слои на месте');
for (const layer of ['domain', 'application', 'infrastructure', 'presentation']) {
  check(filesOf(layer).length > 0, `Слой ${layer} существует и не пуст`);
}
for (const layer of [
  'infrastructure/database/repositories',
  'infrastructure/integrations',
  'infrastructure/queues',
  'infrastructure/auth',
  'infrastructure/logging',
  'infrastructure/cache',
]) {
  check(filesOf(layer).length > 0, `Слой ${layer} существует и не пуст`);
}

// ---------- 2. SQL живёт только в репозиториях ---------------------------
console.log('\n2. Изоляция SQL');
// Схему пишут миграции и сиды — это тоже инфраструктура БД, и им SQL положен.
const SQL_ALLOWED = /^infrastructure\/database\/(repositories|migrations|seeds)\//;
const sqlOffenders = offenders(
  filesOf('domain', 'application', 'presentation', 'infrastructure').filter(
    (f) => !SQL_ALLOWED.test(f) && !f.endsWith('data-source.ts'),
  ),
  /\.query\(/,
);
check(
  sqlOffenders.length === 0,
  'Сырого SQL вне infrastructure/database/repositories нет',
  sqlOffenders.join('\n        '),
);

// ---------- 3. Внешние API только в integrations -------------------------
console.log('\n3. Изоляция внешних вызовов');
// `fetch` со словом-границей: не ловим prefetch/refetch и подобное.
const HTTP_CALL = /\bfetch\(|\baxios\b|\bhttps?\.request\(|\bHttpService\b/;
const httpOffenders = offenders(
  filesOf('domain', 'application', 'presentation', 'infrastructure').filter(
    (f) => !f.startsWith('infrastructure/integrations/'),
  ),
  HTTP_CALL,
);
check(
  httpOffenders.length === 0,
  'Вызовов внешних API вне infrastructure/integrations нет',
  httpOffenders.join('\n        '),
);

// ---------- 4. Направление зависимостей ----------------------------------
console.log('\n4. Направление зависимостей между слоями');

/**
 * Модули Nest — это КОМПОЗИЦИЯ, а не слой. Модуль обязан объявить свой
 * контроллер (`controllers: [...]`), иначе маршрут не поднимется, — то есть
 * ссылка из модуля в презентацию заложена самим фреймворком. Считать её
 * нарушением значит требовать невозможного; поэтому `*.module.ts` вынесены
 * из правила ЦЕЛИКОМ и намеренно, а не по одному исключению.
 */
const isComposition = (f: string): boolean => f.endsWith('.module.ts');

const domainFiles = filesOf('domain');
const domainOffenders = offenders(domainFiles, /from '@nestjs\/|from 'typeorm'|from 'express'/);
check(
  domainOffenders.length === 0,
  'domain не знает про Nest, TypeORM и Express',
  domainOffenders.join('\n        '),
);

const domainOutward = offenders(domainFiles, /from '.*\.\.\/(application|infrastructure|presentation)\//);
check(
  domainOutward.length === 0,
  'domain не зависит ни от одного другого слоя',
  domainOutward.join('\n        '),
);

const appOffenders = offenders(
  filesOf('application').filter((f) => !isComposition(f)),
  /from '.*presentation\//,
);
check(
  appOffenders.length === 0,
  'application не зависит от presentation',
  appOffenders.join('\n        '),
);

const infraOffenders = offenders(
  filesOf('infrastructure').filter((f) => !isComposition(f)),
  /from '.*\/(application|presentation)\//,
);
check(
  infraOffenders.length === 0,
  'infrastructure не зависит от application и presentation',
  infraOffenders.join('\n        '),
);

// ---------- 5. Контроллеры не ходят в базу -------------------------------
console.log('\n5. Презентация не трогает хранилище');
const controllerDb = offenders(
  filesOf('presentation'),
  /from '.*infrastructure\/database\/|getRepository\(|InjectRepository|@InjectDataSource/,
);
check(
  controllerDb.length === 0,
  'Контроллеры и dto не обращаются к хранилищу напрямую',
  controllerDb.join('\n        '),
);

// ---------- 6. Корень композиции не размазан -----------------------------
console.log('\n6. Корень композиции');
const rootFiles = readdirSync(SRC).filter((f) => f.endsWith('.ts'));
check(
  rootFiles.length === 3 && ['app.module.ts', 'bootstrap.ts', 'main.ts'].every((f) => rootFiles.includes(f)),
  'В корне src ровно три файла: main, bootstrap, app.module',
  rootFiles.join(', '),
);

// ---------- 7. Репозитории не берут соединение сами ----------------------
console.log('\n7. Транзакции репозиториев');
/**
 * Самая дорогая ошибка этого слоя: репозиторий, внедривший себе `DataSource`,
 * выполнит запрос МИМО транзакции вызывающего. Он увидит незакоммиченное
 * состояние как отсутствующее, а его запись не откатится вместе с остальными —
 * и ломаются ровно те места, где это стоит денег: резерв под `FOR UPDATE`,
 * двойная запись, захват начислений счётом, транзакционный outbox.
 * Соединение обязано приходить параметром (`runner: SqlRunner`).
 */
const repos = filesOf('infrastructure/database/repositories');
const selfConnected = offenders(repos, /@InjectDataSource|@InjectRepository|private readonly dataSource/);
check(
  selfConnected.length === 0,
  'Репозитории не внедряют соединение — оно приходит параметром',
  selfConnected.join('\n        '),
);

/**
 * Проверяем не имя типа, а сам инвариант: соединение приходит ПАРАМЕТРОМ.
 * Обычно это `runner: SqlRunner` (сырой SQL), но репозиторий поверх ORM
 * законно принимает `DataSource` или `EntityManager` напрямую — важно, что
 * он его не добывает, а получает. Требовать одно конкретное имя значило бы
 * ловить форму вместо сути и однажды заставить обойти сторожа ради удобства.
 */
const CONNECTION_PARAM = /(runner: SqlRunner|dataSource: DataSource|manager: EntityManager|em: EntityManager)/;
const withoutRunner = repos.filter((f) => !CONNECTION_PARAM.test(read(f)));
check(
  withoutRunner.length === 0,
  'Каждый репозиторий получает соединение параметром, а не добывает сам',
  withoutRunner.join('\n        '),
);

console.log(`\narchitecture: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
