// Сквозной тест этапа 1.8: тарифы в БД, начисления, двойная запись, счета.
//   npx ts-node -T test/billing.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_billing_pg');
const PG_PORT = Number(process.env.FF_BILLING_PGPORT || 5452);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_billing');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_billing`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    const login = async (email: string): Promise<string> =>
      (await request(http).post('/api/v1/auth/login').send({ email, password: PASSWORD })).body
        .accessToken as string;

    await createUser('admin@ff.local', ['ADMIN'], null);
    const adminToken = await login('admin@ff.local');
    const as = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);

    // ---------- 1. Схема -----------------------------------------------------
    console.log('\n1. Схема и план счетов');
    check(
      applied.some((m) => m.name === 'Billing1786665600000'),
      'Миграция Billing применилась',
      `всего: ${applied.length}`,
    );
    const accounts: Array<{ code: string }> = await dataSource.query(
      `SELECT code FROM ledger_accounts ORDER BY code`,
    );
    check(
      accounts.length === 5 && accounts.some((a) => a.code === 'AR_SELLER'),
      'План счетов засеян',
      accounts.map((a) => a.code).join(', '),
    );

    // ---------- 2. Данные и полный цикл заказа --------------------------------
    console.log('\n2. Полный цикл заказа');
    const seller = (await as(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'ООО Акме' })).body;
    const wh = (await as(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })).body;
    const mkBin = async (code: string, kind: string) =>
      (await as(request(http).post('/api/v1/bin-locations')).send({ warehouseId: wh.id, code, kind })).body;
    const receiving = await mkBin('R-01-01-01', 'RECEIVING');
    const store = await mkBin('S-01-01-01', 'STORAGE');
    await mkBin('P-01-01-01', 'PACKING');
    await mkBin('X-01-01-01', 'SHIPPING');

    const sku = (
      await as(request(http).post('/api/v1/skus')).send({
        sellerId: seller.id,
        skuCode: 'W',
        name: 'Чайник',
        weightG: 1000,
        lengthMm: 300,
        widthMm: 200,
        heightMm: 150,
      })
    ).body;
    await as(request(http).post(`/api/v1/skus/${sku.id}/barcodes`)).send({
      barcode: '6000000000018',
      kind: 'EAN13',
      isPrimary: true,
    });

    // Приёмка по ASN — основание для начисления INBOUND.
    const asn = (
      await as(request(http).post('/api/v1/inbound/asns')).send({
        sellerId: seller.id,
        warehouseId: wh.id,
        lines: [{ skuId: sku.id, expectedQty: 10 }],
      })
    ).body;
    await as(request(http).post(`/api/v1/inbound/asns/${asn.id}/submit`)).send({});
    const receipt = (
      await as(request(http).post('/api/v1/inbound/receipts')).send({ asnId: asn.id })
    ).body;
    const scanned = await as(request(http).post(`/api/v1/inbound/receipts/${receipt.id}/scan`)).send({
      barcode: '6000000000018',
      quantity: 10,
    });
    await as(request(http).post(`/api/v1/inbound/receipts/${receipt.id}/put-away`)).send({
      receiptLineId: scanned.body.lines[0].id,
      qtyOk: 10,
      qtyDamaged: 0,
      binId: store.id,
    });
    const completed = await as(request(http).post(`/api/v1/inbound/receipts/${receipt.id}/complete`)).send({});
    check(completed.status === 201, 'Приёмка завершена', `status=${completed.status}`);
    check(receiving.id !== undefined, 'Ячейка приёмки заведена');

    const order = (
      await as(request(http).post('/api/v1/orders')).send({
        sellerId: seller.id,
        channel: 'uzum',
        externalId: 'BIL-1',
        recipientName: 'Иванов',
        recipientPhone: '+998901234567',
        address: 'Ташкент',
        codAmount: '500000.00',
        currency: 'UZS',
        lines: [{ skuId: sku.id, quantity: 2 }],
      })
    ).body.order;
    const task = (await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [order.id] })).body;
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/assign`)).send({});
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/scan`)).send({
      barcode: '6000000000018',
      quantity: 2,
    });
    await as(request(http).post(`/api/v1/picking/tasks/${task.id}/complete`)).send({});
    const pkg = (await as(request(http).post(`/api/v1/packing/orders/${order.id}/start`)).send({})).body;
    await as(request(http).post(`/api/v1/packing/orders/${order.id}/complete`)).send({ weightG: 2000 });
    const shipment = (await as(request(http).post(`/api/v1/packing/packages/${pkg.id}/label`)).send({})).body;

    // Передачу и доставку в этом тесте ставим напрямую: вебхуки проверены в
    // integration.e2e, здесь важны только основания для начислений.
    await dataSource.query(
      `UPDATE shipments
          SET status='DELIVERED', handed_over_at=now(), delivered_at=now(),
              cod_collected_amount='500000.00', cod_collected_at=now()
        WHERE id=$1`,
      [shipment.id],
    );
    await dataSource.query(`UPDATE orders SET status='DELIVERED' WHERE id=$1`, [order.id]);

    // ---------- 3. Без тарифов ничего не выдумывается --------------------------
    console.log('\n3. Без тарифов цена не выдумывается');
    const wideFrom = '2000-01-01T00:00:00.000Z';
    const wideTo = new Date(Date.now() + 86_400_000).toISOString();

    const dry = await as(request(http).post('/api/v1/billing/accrue')).send({
      from: wideFrom,
      to: wideTo,
    });
    check(
      dry.status === 201 && dry.body.created === 0 && dry.body.problems > 0,
      'Без тарифа начислений нет, но проблемы зафиксированы',
      JSON.stringify(dry.body),
    );
    const problems = await as(request(http).get('/api/v1/billing/problems'));
    check(
      problems.body.length > 0 && problems.body[0].reason.includes('Тариф не заведён'),
      'Причина видна оператору, а не спрятана в логах',
      problems.body[0]?.reason,
    );
    const zeroCharges: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM charges`,
    );
    check(zeroCharges[0].count === '0', 'Ни одного начисления по нулевой цене не создано');

    // ---------- 4. Тарифы -----------------------------------------------------
    console.log('\n4. Тарифы');
    const plan = (
      await as(request(http).post('/api/v1/billing/tariff-plans')).send({
        code: 'BASE',
        name: 'Базовый',
        currency: 'UZS',
        isDefault: true,
        isActive: true,
      })
    ).body;
    check(plan.isDefault && plan.isActive, 'Тарифный план заведён и активен');

    const badUnit = await as(request(http).post(`/api/v1/billing/tariff-plans/${plan.id}/rules`)).send({
      kind: 'STORAGE',
      unit: 'PER_ORDER',
      price: '100',
    });
    check(
      badUnit.status === 400,
      'Бессмысленная единица для услуги отбита → 400',
      `status=${badUnit.status}`,
    );

    const rules: Array<[string, string, string]> = [
      ['INBOUND', 'PER_UNIT', '500'],
      ['PICKING', 'PER_UNIT', '300'],
      ['PACKING', 'PER_ORDER', '2000'],
      ['DELIVERY', 'PER_KG', '1500'],
      ['COD_FEE', 'PERCENT_OF_COD', '2'],
      ['STORAGE', 'PER_M3_DAY', '10000'],
    ];
    for (const [kind, unit, price] of rules) {
      const response = await as(request(http).post(`/api/v1/billing/tariff-plans/${plan.id}/rules`)).send({
        kind,
        unit,
        price,
        effectiveFrom: '2000-01-01',
      });
      if (response.status !== 201) check(false, `Правило ${kind} не заведено`, JSON.stringify(response.body));
    }
    const plansAfter = await as(request(http).get('/api/v1/billing/tariff-plans'));
    check(plansAfter.body[0].rules.length === 6, 'Все шесть правил в плане', `${plansAfter.body[0].rules.length}`);

    // Две единицы измерения на одну услугу сделали бы цену неопределённой:
    // выбор между «за заказ» и «за кг» свёлся бы к порядку строк в выдаче.
    const ambiguous = await as(request(http).post(`/api/v1/billing/tariff-plans/${plan.id}/rules`)).send({
      kind: 'PACKING',
      unit: 'PER_KG',
      price: '700',
    });
    check(
      ambiguous.status === 409,
      'Вторая единица измерения для той же услуги отбита → 409',
      `status=${ambiguous.status}`,
    );

    // Второй план по умолчанию не может существовать одновременно с первым.
    const second = await as(request(http).post('/api/v1/billing/tariff-plans')).send({
      code: 'VIP',
      name: 'VIP',
      currency: 'UZS',
      isDefault: true,
      isActive: true,
    });
    const defaults: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM tariff_plans WHERE is_default`,
    );
    check(
      second.status === 201 && defaults[0].count === '1',
      'План по умолчанию остаётся ровно один',
      defaults[0].count,
    );
    // Возвращаем базовый план: VIP перехватил флаг по умолчанию.
    await as(request(http).post(`/api/v1/billing/sellers/${seller.id}/tariff-plan`)).send({
      planId: plan.id,
    });

    // ---------- 5. Начисления и книга ------------------------------------------
    console.log('\n5. Начисления и книга');
    const today = new Date().toISOString().slice(0, 10);
    await as(request(http).post('/api/v1/billing/storage-snapshots')).send({ date: today });
    const snapshots: Array<{ units: number; volume_mm3: string }> = await dataSource.query(
      `SELECT units, volume_mm3::text FROM storage_snapshots`,
    );
    check(
      snapshots.length === 1 && snapshots[0].units > 0,
      'Срез хранения снят по остатку на дату',
      JSON.stringify(snapshots[0]),
    );

    const accrued = await as(request(http).post('/api/v1/billing/accrue')).send({
      from: wideFrom,
      to: wideTo,
    });
    check(
      accrued.body.created === 6,
      'Начислены все шесть видов услуг',
      JSON.stringify(accrued.body.byKind),
    );

    const charges: Array<{ kind: string; quantity: string; unit_price: string; amount: string }> =
      await dataSource.query(
        `SELECT kind::text, quantity::text, unit_price::text, amount::text FROM charges ORDER BY kind`,
      );
    const byKind = Object.fromEntries(charges.map((c) => [c.kind, c]));
    check(byKind.INBOUND?.amount === '5000.00', 'Приёмка: 10 ед. × 500', byKind.INBOUND?.amount);
    check(byKind.PICKING?.amount === '600.00', 'Сборка: 2 ед. × 300', byKind.PICKING?.amount);
    check(byKind.PACKING?.amount === '2000.00', 'Упаковка: 1 заказ × 2000', byKind.PACKING?.amount);
    check(byKind.DELIVERY?.amount === '3000.00', 'Доставка: 2 кг × 1500', byKind.DELIVERY?.amount);
    check(byKind.COD_FEE?.amount === '10000.00', 'Комиссия: 2% от 500 000', byKind.COD_FEE?.amount);
    check(byKind.STORAGE !== undefined, 'Хранение начислено по срезу', byKind.STORAGE?.amount);

    const repeat = await as(request(http).post('/api/v1/billing/accrue')).send({
      from: wideFrom,
      to: wideTo,
    });
    check(
      repeat.body.created === 0 && repeat.body.skippedExisting === 6,
      'Повторный прогон ничего не удваивает',
      JSON.stringify(repeat.body),
    );

    const balances = await as(request(http).get('/api/v1/billing/ledger/balances'));
    const totalDebit = balances.body.reduce((sum: number, row: { debit: string }) => sum + Number(row.debit), 0);
    const totalCredit = balances.body.reduce((sum: number, row: { credit: string }) => sum + Number(row.credit), 0);
    check(
      Math.abs(totalDebit - totalCredit) < 0.001,
      'Книга сходится: дебет равен кредиту',
      `${totalDebit} / ${totalCredit}`,
    );

    const arSeller = balances.body.find((r: { accountCode: string }) => r.accountCode === 'AR_SELLER');
    const servicesSum = charges.reduce((sum, c) => sum + Number(c.amount), 0);
    check(
      Math.abs(Number(arSeller.debit) - servicesSum) < 0.001,
      'Задолженность селлера равна сумме начислений',
      `${arSeller.debit} против ${servicesSum.toFixed(2)}`,
    );
    const apSeller = balances.body.find((r: { accountCode: string }) => r.accountCode === 'AP_SELLER');
    check(
      apSeller.credit === '500000.00',
      'Собранный наложенный платёж — обязательство перед селлером',
      apSeller?.credit,
    );

    // ---------- 6. Инварианты книги на уровне БД -------------------------------
    console.log('\n6. Инварианты книги');
    let unbalancedRejected = false;
    try {
      await dataSource.transaction(async (em) => {
        const tx: Array<{ id: string }> = await em.query(
          `INSERT INTO ledger_transactions (occurred_at, description) VALUES (now(), 'кривая') RETURNING id`,
        );
        await em.query(
          `INSERT INTO ledger_entries (transaction_id, account_id, side, amount, currency)
           VALUES ($1, (SELECT id FROM ledger_accounts WHERE code='CASH'), 'DEBIT', 100, 'UZS')`,
          [tx[0].id],
        );
      });
    } catch {
      unbalancedRejected = true;
    }
    check(unbalancedRejected, 'Несходящаяся проводка отбита триггером на COMMIT');

    let updateRejected = false;
    try {
      await dataSource.query(`UPDATE ledger_entries SET amount = amount + 1`);
    } catch {
      updateRejected = true;
    }
    check(updateRejected, 'Правка книги задним числом запрещена триггером');

    // ---------- 7. Счёт ---------------------------------------------------------
    console.log('\n7. Счёт за период');
    const invoice = (
      await as(request(http).post('/api/v1/billing/invoices')).send({
        sellerId: seller.id,
        periodStart: today,
        periodEnd: today,
      })
    ).body;
    check(/^INV-\d{6}-\d{5}$/.test(invoice.number), 'Номер счёта выдан последовательностью', invoice.number);
    check(invoice.lines.length === 6, 'В счёте шесть строк услуг', `${invoice.lines.length}`);
    check(
      Number(invoice.servicesTotal) === servicesSum,
      'Итог услуг совпадает с начислениями',
      `${invoice.servicesTotal} против ${servicesSum.toFixed(2)}`,
    );
    check(
      invoice.codCollectedTotal === '500000.00',
      'Собранный COD попал в счёт',
      invoice.codCollectedTotal,
    );
    check(
      Number(invoice.payoutTotal).toFixed(2) === (500000 - servicesSum).toFixed(2),
      'К перечислению = собранный COD минус услуги',
      invoice.payoutTotal,
    );

    const linked: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM charges WHERE invoice_id IS NULL`,
    );
    check(linked[0].count === '0', 'Начисления привязаны к счёту и не попадут во второй');

    // Ключевой инвариант счёта: сумма строк равна сумме захваченных начислений.
    // Если сперва считать, а помечать потом, параллельное начисление успевает
    // попасть в «выставленные», но не в сумму — деньги пропадают молча.
    const consistency: Array<{ lines: string; charges: string }> = await dataSource.query(
      `SELECT (SELECT COALESCE(SUM(amount), 0)::text FROM invoice_lines WHERE invoice_id = $1) AS lines,
              (SELECT COALESCE(SUM(amount), 0)::text FROM charges WHERE invoice_id = $1) AS charges`,
      [invoice.id],
    );
    check(
      consistency[0].lines === consistency[0].charges,
      'Строки счёта покрывают ровно захваченные начисления',
      JSON.stringify(consistency[0]),
    );

    const again = await as(request(http).post('/api/v1/billing/invoices')).send({
      sellerId: seller.id,
      periodStart: today,
      periodEnd: today,
    });
    check(again.body.id === invoice.id, 'Повторное построение возвращает тот же счёт');

    const issued = await as(request(http).post(`/api/v1/billing/invoices/${invoice.id}/issue`)).send({});
    check(issued.body.status === 'ISSUED' && issued.body.issuedAt !== null, 'Счёт выставлен');

    const pdf = await as(request(http).get(`/api/v1/billing/invoices/${invoice.id}/pdf`)).responseType('blob');
    check(
      pdf.status === 200 && pdf.body.subarray(0, 5).toString('latin1') === '%PDF-',
      'PDF счёта отдаётся',
      `${pdf.body?.length} байт`,
    );
    const xlsx = await as(request(http).get(`/api/v1/billing/invoices/${invoice.id}/xlsx`)).responseType('blob');
    check(
      xlsx.status === 200 && xlsx.body.subarray(0, 2).toString('latin1') === 'PK',
      'Excel счёта отдаётся',
      `${xlsx.body?.length} байт`,
    );

    // ---------- 8. Сверка наложенного платежа ----------------------------------
    console.log('\n8. Сверка наложенного платежа');
    const reconciled = await as(
      request(http).get(`/api/v1/billing/cod-reconciliation?from=${today}&to=${today}`),
    );
    check(
      reconciled.body.rows.length === 1 && reconciled.body.rows[0].status === 'MATCHED',
      'Собранное сходится с ожидаемым',
      JSON.stringify(reconciled.body.rows[0]),
    );

    // Курьер сдал меньше — расхождение обязано быть видно.
    await dataSource.query(
      `UPDATE shipments SET cod_collected_amount='400000.00' WHERE id=$1`,
      [shipment.id],
    );
    const short = await as(
      request(http).get(`/api/v1/billing/cod-reconciliation?from=${today}&to=${today}`),
    );
    check(
      short.body.rows[0].status === 'SHORT' && short.body.rows[0].difference === '-100000.00',
      'Недосдача видна отдельной строкой',
      JSON.stringify({ st: short.body.rows[0].status, diff: short.body.rows[0].difference }),
    );

    // ---------- 9. Права -------------------------------------------------------
    console.log('\n9. Права');
    await createUser('seller@ff.local', ['SELLER'], seller.id);
    const sellerToken = await login('seller@ff.local');
    const asSeller = (r: request.Test) => r.set('Authorization', `Bearer ${sellerToken}`);

    const sellerInvoices = await asSeller(request(http).get('/api/v1/billing/invoices'));
    check(
      sellerInvoices.status === 200 && sellerInvoices.body.length === 1,
      'Селлер видит свой счёт',
      `${sellerInvoices.body.length}`,
    );
    const sellerTariffs = await asSeller(request(http).get('/api/v1/billing/tariff-plans'));
    check(sellerTariffs.status === 403, 'Селлер не видит чужие тарифы → 403', `status=${sellerTariffs.status}`);
    const sellerAccrue = await asSeller(request(http).post('/api/v1/billing/accrue')).send({
      from: wideFrom,
      to: wideTo,
    });
    check(sellerAccrue.status === 403, 'Селлер не запускает начисления → 403', `status=${sellerAccrue.status}`);

    // ---------- 10. Тара: неполная норма и микросумма ---------------------------
    console.log('\n10. Тара: неполная норма и микросумма');

    /** Приёмка одной поставкой: основание для INBOUND и остаток под хранение. */
    async function receive(
      sellerId: string,
      lines: Array<{ skuId: string; barcode: string; qty: number }>,
    ): Promise<void> {
      const asnBody = (
        await as(request(http).post('/api/v1/inbound/asns')).send({
          sellerId,
          warehouseId: wh.id,
          lines: lines.map((line) => ({ skuId: line.skuId, expectedQty: line.qty })),
        })
      ).body;
      await as(request(http).post(`/api/v1/inbound/asns/${asnBody.id}/submit`)).send({});
      const rcpt = (
        await as(request(http).post('/api/v1/inbound/receipts')).send({ asnId: asnBody.id })
      ).body;
      for (const line of lines) {
        const scan = await as(request(http).post(`/api/v1/inbound/receipts/${rcpt.id}/scan`)).send({
          barcode: line.barcode,
          quantity: line.qty,
        });
        const received = (scan.body.lines as Array<{ id: string; skuId: string }>).find(
          (row) => row.skuId === line.skuId,
        );
        await as(request(http).post(`/api/v1/inbound/receipts/${rcpt.id}/put-away`)).send({
          receiptLineId: received?.id,
          qtyOk: line.qty,
          qtyDamaged: 0,
          binId: store.id,
        });
      }
      await as(request(http).post(`/api/v1/inbound/receipts/${rcpt.id}/complete`)).send({});
    }

    const mkSku = async (
      sellerId: string,
      skuCode: string,
      name: string,
      barcode: string,
    ): Promise<{ id: string }> => {
      const created = (
        await as(request(http).post('/api/v1/skus')).send({
          sellerId,
          skuCode,
          name,
          weightG: 100,
          lengthMm: 100,
          widthMm: 100,
          heightMm: 100,
        })
      ).body;
      await as(request(http).post(`/api/v1/skus/${created.id}/barcodes`)).send({
        barcode,
        kind: 'EAN13',
        isPrimary: true,
      });
      return created;
    };

    // У ACME норма появляется у ОДНОГО товара из двух — ровно тот случай, когда
    // SUM молча пропускал NULL и селлер платил за хранение половины склада.
    await as(request(http).patch(`/api/v1/billing/skus/${sku.id}/packing-norms`)).send({
      unitsPerBox: 5,
      unitsPerPallet: 1000,
    });
    const skuNoNorms = await mkSku(seller.id, 'W2', 'Кружка', '6000000000049');
    await receive(seller.id, [{ skuId: skuNoNorms.id, barcode: '6000000000049', qty: 5 }]);

    // Второй селлер с ПОЛНОСТЬЮ заполненными нормами: только на нём видно
    // микросумму, у ACME тара честно не считается вовсе.
    const micro = (
      await as(request(http).post('/api/v1/sellers')).send({ code: 'MICRO', legalName: 'ООО Микро' })
    ).body;
    await as(request(http).post(`/api/v1/billing/sellers/${micro.id}/tariff-plan`)).send({
      planId: plan.id,
    });
    const microSku = await mkSku(micro.id, 'M', 'Гвоздь', '6000000000025');
    await as(request(http).patch(`/api/v1/billing/skus/${microSku.id}/packing-norms`)).send({
      unitsPerBox: 100,
      unitsPerPallet: 1000,
    });
    await receive(micro.id, [{ skuId: microSku.id, barcode: '6000000000025', qty: 4 }]);

    await as(request(http).post('/api/v1/billing/storage-snapshots')).send({ date: today });
    const tare: Array<{ seller_id: string; boxes: string; pallets: string }> =
      await dataSource.query(
        `SELECT seller_id, boxes::text, pallets::text FROM storage_snapshots WHERE snapshot_date = $1::date`,
        [today],
      );
    const acmeTare = tare.find((row) => row.seller_id === seller.id);
    const microTare = tare.find((row) => row.seller_id === micro.id);
    check(
      acmeTare?.boxes === '0.000' && acmeTare?.pallets === '0.000',
      'Норма есть не у всех товаров — в срезе ноль, а не заниженная тара (иначе было бы 2 коробки)',
      JSON.stringify(acmeTare),
    );
    check(
      microTare?.pallets === '0.004' && microTare?.boxes === '0.040',
      'Полная норма даёт дробную тару: 4 шт. при 1000 на паллете',
      JSON.stringify(microTare),
    );

    const palletRule = await as(
      request(http).post(`/api/v1/billing/tariff-plans/${plan.id}/rules`),
    ).send({
      kind: 'STORAGE',
      unit: 'PER_PALLET_DAY',
      component: 'PALLET',
      price: '1',
      effectiveFrom: '2000-01-01',
    });
    check(
      palletRule.status === 201,
      'Составляющая «паллето-сутки» добавлена к хранению',
      `status=${palletRule.status}`,
    );

    // Прогон с суммой 0.004: до починки он валился целиком на CHECK книги и не
    // чинился перезапуском — каждый раз спотыкался о ту же строку.
    const microAccrual = await as(request(http).post('/api/v1/billing/accrue')).send({
      from: wideFrom,
      to: wideTo,
    });
    check(
      microAccrual.status === 201,
      'Начисление меньше полкопейки не роняет весь прогон',
      `status=${microAccrual.status}`,
    );
    const microStorage: Array<{ quantity: string; amount: string; transaction_id: string | null }> =
      await dataSource.query(
        `SELECT quantity::text, amount::text, transaction_id FROM charges WHERE source_key = $1`,
        [`storage:${micro.id}:${today}:PALLET`],
      );
    check(
      microStorage.length === 1 &&
        microStorage[0].amount === '0.00' &&
        microStorage[0].transaction_id === null,
      'Нулевая после округления сумма в книгу не идёт',
      JSON.stringify(microStorage[0]),
    );
    const tareProblem: Array<{ reason: string }> = await dataSource.query(
      `SELECT reason FROM billing_problems WHERE source_key = $1 AND resolved_at IS NULL`,
      [`storage:${seller.id}:${today}:PALLET`],
    );
    check(
      tareProblem.length === 1 && tareProblem[0].reason.includes('норма'),
      'Неполная норма тары видна оператору как проблема, а не как заниженный счёт',
      tareProblem[0]?.reason,
    );

    // Позиция с нулевым отбором не должна отменять коробки по всему заказу.
    const microSku2 = await mkSku(micro.id, 'M2', 'Шуруп', '6000000000032');
    await receive(micro.id, [{ skuId: microSku2.id, barcode: '6000000000032', qty: 2 }]);
    const microOrder = (
      await as(request(http).post('/api/v1/orders')).send({
        sellerId: micro.id,
        channel: 'uzum',
        externalId: 'BIL-2',
        recipientName: 'Петров',
        recipientPhone: '+998901234568',
        address: 'Ташкент',
        lines: [
          { skuId: microSku.id, quantity: 2 },
          { skuId: microSku2.id, quantity: 2 },
        ],
      })
    ).body.order;
    const microTask = (
      await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [microOrder.id] })
    ).body;
    await as(request(http).post(`/api/v1/picking/tasks/${microTask.id}/assign`)).send({});
    await as(request(http).post(`/api/v1/picking/tasks/${microTask.id}/scan`)).send({
      barcode: '6000000000025',
      quantity: 2,
    });
    const shortLine = (microTask.lines as Array<{ id: string; skuId: string }>).find(
      (line) => line.skuId === microSku2.id,
    );
    await as(
      request(http).post(`/api/v1/picking/tasks/${microTask.id}/lines/${shortLine?.id}/short`),
    ).send({ reason: 'Товара нет в ячейке' });
    await as(request(http).post(`/api/v1/picking/tasks/${microTask.id}/complete`)).send({});

    await as(request(http).post(`/api/v1/billing/tariff-plans/${plan.id}/rules`)).send({
      kind: 'PICKING',
      unit: 'PER_BOX',
      component: 'BOX',
      price: '50',
      effectiveFrom: '2000-01-01',
    });
    await as(request(http).post('/api/v1/billing/accrue')).send({ from: wideFrom, to: wideTo });
    const pickBox: Array<{ quantity: string; amount: string }> = await dataSource.query(
      `SELECT quantity::text, amount::text FROM charges WHERE source_key = $1`,
      [`picking:${microOrder.id}:BOX`],
    );
    check(
      pickBox.length === 1 && pickBox[0].amount === '50.00',
      'Недобранная позиция без нормы не отменяет коробки по всему заказу',
      JSON.stringify(pickBox[0]),
    );

    // ---------- 11. Собранный платёж без валюты ---------------------------------
    console.log('\n11. Собранный платёж без валюты');
    const microPkg = (
      await as(request(http).post(`/api/v1/packing/orders/${microOrder.id}/start`)).send({})
    ).body;
    await as(request(http).post(`/api/v1/packing/orders/${microOrder.id}/complete`)).send({
      weightG: 500,
    });
    const microShipment = (
      await as(request(http).post(`/api/v1/packing/packages/${microPkg.id}/label`)).send({})
    ).body;
    check(
      microShipment.currency === null,
      'У заказа без валюты и отправление без валюты — как у дочернего заказа сплита',
      String(microShipment.currency),
    );

    // Курьер собрал деньги по ребёнку: вебхук пишет сумму, валюты по-прежнему нет.
    // `cod_amount` не трогаем — ожидаемая сумма без валюты запрещена CHECK
    // `shipments_cod_needs_currency`, а СОБРАННАЯ им не покрыта: в этом и дыра.
    await dataSource.query(
      `UPDATE shipments
          SET status='DELIVERED', handed_over_at=now(), delivered_at=now(),
              cod_collected_amount='1000.00', cod_collected_at=now()
        WHERE id=$1`,
      [microShipment.id],
    );
    const noCurrency = await as(request(http).post('/api/v1/billing/accrue')).send({
      from: wideFrom,
      to: wideTo,
    });
    check(
      noCurrency.status === 201,
      'Собранный платёж без валюты не роняет прогон',
      `status=${noCurrency.status}`,
    );
    const codProblem: Array<{ reason: string }> = await dataSource.query(
      `SELECT reason FROM billing_problems WHERE source_key = $1 AND resolved_at IS NULL`,
      [`cod_collected:${microShipment.id}`],
    );
    check(
      codProblem.length === 1 && codProblem[0].reason.includes('валюта'),
      'Платёж без валюты попадает в проблемы с внятной причиной',
      codProblem[0]?.reason,
    );
    const unposted: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM ledger_transactions
        WHERE reference_type='SHIPMENT_COD' AND reference_id=$1`,
      [microShipment.id],
    );
    check(unposted[0].count === '0', 'Проводки с валютой NULL в книге нет');

    // Валюту проставили на заказе уже после печати этикетки: у отправления она
    // так и осталась пустой (копируется в момент оформления). Сумма COD идёт
    // в паре с валютой — этого требует CHECK `orders_cod_needs_currency`.
    await dataSource.query(`UPDATE orders SET currency='UZS', cod_amount='1000.00' WHERE id=$1`, [
      microOrder.id,
    ]);
    const withCurrency = await as(request(http).post('/api/v1/billing/accrue')).send({
      from: wideFrom,
      to: wideTo,
    });
    check(
      withCurrency.status === 201,
      'Прогон после починки валюты проходит',
      `status=${withCurrency.status}`,
    );
    const posted: Array<{ currency: string; amount: string }> = await dataSource.query(
      `SELECT e.currency, e.amount::text AS amount
         FROM ledger_entries e JOIN ledger_transactions t ON t.id = e.transaction_id
        WHERE t.reference_type='SHIPMENT_COD' AND t.reference_id=$1 AND e.side='DEBIT'`,
      [microShipment.id],
    );
    check(
      posted.length === 1 && posted[0].currency === 'UZS' && posted[0].amount === '1000.00',
      'Валюта берётся с заказа, и собранный платёж проводится',
      JSON.stringify(posted[0]),
    );
    const codFee: Array<{ amount: string; currency: string }> = await dataSource.query(
      `SELECT amount::text, currency FROM charges WHERE source_key = $1`,
      [`cod_fee:${microShipment.id}`],
    );
    check(
      codFee.length === 1 && codFee[0].amount === '20.00' && codFee[0].currency === 'UZS',
      'Комиссия 2% посчитана в валюте заказа',
      JSON.stringify(codFee[0]),
    );

    // ---------- 12. Начисления после сборки счёта -------------------------------
    console.log('\n12. Начисления после сборки счёта');
    await as(request(http).post(`/api/v1/billing/tariff-plans/${plan.id}/rules`)).send({
      kind: 'PACKING',
      unit: 'PER_ORDER',
      component: 'HANDLING',
      price: '100',
      effectiveFrom: '2000-01-01',
    });
    await as(request(http).post('/api/v1/billing/accrue')).send({ from: wideFrom, to: wideTo });
    const handling: Array<{ invoice_id: string | null }> = await dataSource.query(
      `SELECT invoice_id FROM charges WHERE source_key = $1`,
      [`packing:${pkg.id}:HANDLING`],
    );
    check(
      handling.length === 1 && handling[0].invoice_id === null,
      'Начисление, посчитанное после счёта, остаётся незахваченным',
      JSON.stringify(handling[0]),
    );
    const closed = await as(request(http).post('/api/v1/billing/invoices')).send({
      sellerId: seller.id,
      periodStart: today,
      periodEnd: today,
    });
    check(
      closed.status === 409 && String(closed.body.message).includes('PACKING'),
      'Выставленный счёт не проглатывает новые начисления молча → 409 со списком',
      `status=${closed.status} ${closed.body?.message}`,
    );

    const microInvoice = (
      await as(request(http).post('/api/v1/billing/invoices')).send({
        sellerId: micro.id,
        periodStart: today,
        periodEnd: today,
      })
    ).body;
    check(
      microInvoice.status === 'DRAFT' && Number(microInvoice.servicesTotal) > 0,
      'Черновик счёта второму селлеру собран',
      `${microInvoice.status} / ${microInvoice.servicesTotal}`,
    );
    const beforeTotal = Number(microInvoice.servicesTotal);

    // Финансист завёл недостающую составляющую и перезапустил прогон за уже
    // закрытый период — ровно так и предписывает документация.
    await as(request(http).post(`/api/v1/billing/tariff-plans/${plan.id}/rules`)).send({
      kind: 'STORAGE',
      unit: 'PER_BOX_DAY',
      component: 'BOX',
      price: '1000',
      effectiveFrom: '2000-01-01',
    });
    await as(request(http).post('/api/v1/billing/accrue')).send({ from: wideFrom, to: wideTo });
    const rebuilt = await as(request(http).post('/api/v1/billing/invoices')).send({
      sellerId: micro.id,
      periodStart: today,
      periodEnd: today,
    });
    check(
      rebuilt.body.id === microInvoice.id &&
        Number(rebuilt.body.servicesTotal).toFixed(2) === (beforeTotal + 40).toFixed(2),
      'Черновик дозахватывает новые начисления и пересобирает строки',
      `${microInvoice.servicesTotal} → ${rebuilt.body?.servicesTotal}`,
    );
    const orphan: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM charges WHERE seller_id=$1 AND invoice_id IS NULL`,
      [micro.id],
    );
    check(orphan[0].count === '0', 'После пересборки начислений вне счёта не осталось');

    const tomorrow = new Date(Date.now() + 86_400_000).toISOString().slice(0, 10);
    const overlap = await as(request(http).post('/api/v1/billing/invoices')).send({
      sellerId: micro.id,
      periodStart: today,
      periodEnd: tomorrow,
    });
    check(
      overlap.status === 409 && String(overlap.body.message).includes(microInvoice.number),
      'Пересекающийся период отбит с номером мешающего счёта',
      `status=${overlap.status} ${overlap.body?.message}`,
    );
    const apart = await as(request(http).post('/api/v1/billing/invoices')).send({
      sellerId: micro.id,
      periodStart: '2000-01-01',
      periodEnd: '2000-01-31',
    });
    check(
      apart.status === 201 && apart.body.id !== microInvoice.id,
      'Непересекающийся период по-прежнему собирается',
      `status=${apart.status}`,
    );

    // ---------- 13. Права на счета и сверку COD ---------------------------------
    console.log('\n13. Права на счета и сверку COD');
    await createUser('packer@ff.local', ['PACKER'], null);
    const packerToken = await login('packer@ff.local');
    const asPacker = (r: request.Test) => r.set('Authorization', `Bearer ${packerToken}`);
    await createUser('finance@ff.local', ['FINANCE'], null);
    const financeToken = await login('finance@ff.local');
    const asFinance = (r: request.Test) => r.set('Authorization', `Bearer ${financeToken}`);

    const packerList = await asPacker(request(http).get('/api/v1/billing/invoices'));
    const packerOne = await asPacker(request(http).get(`/api/v1/billing/invoices/${invoice.id}`));
    const packerPdf = await asPacker(request(http).get(`/api/v1/billing/invoices/${invoice.id}/pdf`));
    const packerXlsx = await asPacker(
      request(http).get(`/api/v1/billing/invoices/${invoice.id}/xlsx`),
    );
    check(
      packerList.status === 403 &&
        packerOne.status === 403 &&
        packerPdf.status === 403 &&
        packerXlsx.status === 403,
      'Склад не видит счета: список, карточка, PDF и Excel → 403',
      `${packerList.status}/${packerOne.status}/${packerPdf.status}/${packerXlsx.status}`,
    );
    const packerCod = await asPacker(
      request(http).get(`/api/v1/billing/cod-reconciliation?from=${today}&to=${today}`),
    );
    const sellerCod = await asSeller(
      request(http).get(`/api/v1/billing/cod-reconciliation?from=${today}&to=${today}`),
    );
    check(
      packerCod.status === 403 && sellerCod.status === 403,
      'Сверка COD — только ADMIN и FINANCE',
      `packer=${packerCod.status} seller=${sellerCod.status}`,
    );
    const financeCod = await asFinance(
      request(http).get(`/api/v1/billing/cod-reconciliation?from=${today}&to=${today}`),
    );
    const financeList = await asFinance(request(http).get('/api/v1/billing/invoices'));
    const sellerOwn = await asSeller(request(http).get(`/api/v1/billing/invoices/${invoice.id}`));
    check(
      financeCod.status === 200 && financeList.status === 200 && sellerOwn.status === 200,
      'Финансисту доступны счета и сверка, селлеру — свой счёт',
      `${financeCod.status}/${financeList.status}/${sellerOwn.status}`,
    );

    // ---------- 14. Комбинированный тариф: порог, копейка, вес приёмки --------
    console.log('\n14. Комбинированный тариф: порог, копейка, вес приёмки');

    // Отдельные селлер и план: у ACME уже свои правила, а здесь важно, чтобы
    // у услуги были РОВНО две составляющие — базовая и пороговая.
    const combo = (
      await as(request(http).post('/api/v1/sellers')).send({ code: 'COMBO', legalName: 'ООО Комбо' })
    ).body;
    const comboPlan = (
      await as(request(http).post('/api/v1/billing/tariff-plans')).send({
        code: 'COMBO',
        name: 'Комбинированный',
        currency: 'UZS',
        isActive: true,
      })
    ).body;
    await as(request(http).post(`/api/v1/billing/sellers/${combo.id}/tariff-plan`)).send({
      planId: comboPlan.id,
    });

    // «Доплата за вес свыше 5 кг» — это WEIGHT/PER_KG/min_qty 5 рядом с
    // BASE/PER_ORDER/min_qty 0. Цена 0.05 выбрана не случайно: на ней и
    // ломался расчёт через double.
    const comboRules: Array<Record<string, string>> = [
      { kind: 'PACKING', unit: 'PER_ORDER', component: 'BASE', price: '1000', minQty: '0' },
      { kind: 'PACKING', unit: 'PER_KG', component: 'WEIGHT', price: '0.05', minQty: '5' },
      { kind: 'DELIVERY', unit: 'PER_KG', component: 'BASE', price: '0.05', minQty: '0' },
      { kind: 'INBOUND', unit: 'PER_KG', component: 'BASE', price: '1000', minQty: '0' },
    ];
    for (const comboRule of comboRules) {
      const added = await as(
        request(http).post(`/api/v1/billing/tariff-plans/${comboPlan.id}/rules`),
      ).send({ ...comboRule, effectiveFrom: '2000-01-01' });
      if (added.status !== 201) {
        check(false, `Правило ${comboRule.kind}/${comboRule.component} не заведено`, JSON.stringify(added.body));
      }
    }

    const comboSku = await mkSku(combo.id, 'C', 'Гиря', '6000000000056');
    await receive(combo.id, [{ skuId: comboSku.id, barcode: '6000000000056', qty: 4 }]);

    /** Заказ до закрытой коробки заданного веса — основание для PACKING. */
    const packOrder = async (
      externalId: string,
      quantity: number,
      weightG: number,
    ): Promise<{ orderId: string; packageId: string }> => {
      const created = (
        await as(request(http).post('/api/v1/orders')).send({
          sellerId: combo.id,
          channel: 'uzum',
          externalId,
          recipientName: 'Сидоров',
          recipientPhone: '+998901234569',
          address: 'Ташкент',
          lines: [{ skuId: comboSku.id, quantity }],
        })
      ).body.order;
      const pickTask = (
        await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [created.id] })
      ).body;
      await as(request(http).post(`/api/v1/picking/tasks/${pickTask.id}/assign`)).send({});
      await as(request(http).post(`/api/v1/picking/tasks/${pickTask.id}/scan`)).send({
        barcode: '6000000000056',
        quantity,
      });
      await as(request(http).post(`/api/v1/picking/tasks/${pickTask.id}/complete`)).send({});
      const box = (
        await as(request(http).post(`/api/v1/packing/orders/${created.id}/start`)).send({})
      ).body;
      await as(request(http).post(`/api/v1/packing/orders/${created.id}/complete`)).send({ weightG });
      return { orderId: created.id, packageId: box.id };
    };

    const lightBox = await packOrder('BIL-LIGHT', 2, 4100);
    const heavyBox = await packOrder('BIL-HEAVY', 2, 6100);

    // Передачу ставим напрямую: нужен только факт-основание для DELIVERY.
    const lightShipment = (
      await as(request(http).post(`/api/v1/packing/packages/${lightBox.packageId}/label`)).send({})
    ).body;
    await dataSource.query(`UPDATE shipments SET handed_over_at = now() WHERE id = $1`, [
      lightShipment.id,
    ]);

    // Товар без веса: приёмка по нему честно не считается в килограммах.
    const noWeightSku = (
      await as(request(http).post('/api/v1/skus')).send({
        sellerId: combo.id,
        skuCode: 'C-NW',
        name: 'Перо',
        lengthMm: 100,
        widthMm: 100,
        heightMm: 100,
      })
    ).body;
    await as(request(http).post(`/api/v1/skus/${noWeightSku.id}/barcodes`)).send({
      barcode: '6000000000063',
      kind: 'EAN13',
      isPrimary: true,
    });
    await receive(combo.id, [{ skuId: noWeightSku.id, barcode: '6000000000063', qty: 1 }]);

    await as(request(http).post('/api/v1/billing/accrue')).send({ from: wideFrom, to: wideTo });

    const lightCharges: Array<{ source_key: string; amount: string }> = await dataSource.query(
      `SELECT source_key, amount::text FROM charges WHERE source_key LIKE $1 ORDER BY source_key`,
      [`packing:${lightBox.packageId}%`],
    );
    check(
      lightCharges.length === 1 &&
        lightCharges[0].source_key === `packing:${lightBox.packageId}` &&
        lightCharges[0].amount === '1000.00',
      'Лёгкая коробка: одно начисление по базовой составляющей, доплаты за вес нет',
      JSON.stringify(lightCharges),
    );
    const lightProblems: Array<{ reason: string }> = await dataSource.query(
      `SELECT reason FROM billing_problems WHERE source_key LIKE $1`,
      [`packing:${lightBox.packageId}%`],
    );
    check(
      lightProblems.length === 0,
      'Объём ниже минимальной ступени — не проблема: порог выражает «свыше», а не сбой настройки',
      JSON.stringify(lightProblems),
    );

    const heavyCharges: Array<{ source_key: string; amount: string }> = await dataSource.query(
      `SELECT source_key, amount::text FROM charges WHERE source_key LIKE $1 ORDER BY source_key`,
      [`packing:${heavyBox.packageId}%`],
    );
    check(
      heavyCharges.length === 2 &&
        heavyCharges[0].amount === '1000.00' &&
        heavyCharges[1].source_key === `packing:${heavyBox.packageId}:WEIGHT` &&
        heavyCharges[1].amount === '0.31',
      'Тяжёлая коробка: база плюс доплата за вес (6.1 кг × 0.05 = 0.305 → 0.31)',
      JSON.stringify(heavyCharges),
    );

    // Через double `4.1 * 0.05` равно 0.20499999999999999, и `toFixed(2)`
    // отдавал «0.20» — копейка терялась на каждой такой коробке.
    const kopeck: Array<{ quantity: string; amount: string }> = await dataSource.query(
      `SELECT quantity::text, amount::text FROM charges WHERE source_key = $1`,
      [`delivery:${lightShipment.id}`],
    );
    check(
      kopeck.length === 1 && kopeck[0].quantity === '4.100' && kopeck[0].amount === '0.21',
      'Копейка не теряется: 4.1 кг × 0.05 = 0.21, а не 0.20',
      JSON.stringify(kopeck[0]),
    );

    const inboundKg: Array<{ quantity: string; amount: string }> = await dataSource.query(
      `SELECT c.quantity::text, c.amount::text FROM charges c
        WHERE c.seller_id = $1 AND c.kind = 'INBOUND'`,
      [combo.id],
    );
    check(
      inboundKg.length === 1 && inboundKg[0].quantity === '0.400' && inboundKg[0].amount === '400.00',
      'Приёмка за кг считается по весу товара: 4 шт. × 100 г = 0.4 кг',
      JSON.stringify(inboundKg[0]),
    );
    const noWeightProblem: Array<{ reason: string }> = await dataSource.query(
      `SELECT p.reason FROM billing_problems p
        WHERE p.seller_id = $1 AND p.kind = 'INBOUND' AND p.resolved_at IS NULL`,
      [combo.id],
    );
    check(
      noWeightProblem.length === 1 && noWeightProblem[0].reason.includes('вес'),
      'Приёмка товара без веса уходит в проблемы с внятной причиной, а не считается заниженной',
      noWeightProblem[0]?.reason,
    );

    // ---------- 15. Захват собранного платежа счётом ----------------------------
    console.log('\n15. Захват собранного платежа счётом');
    const captured: Array<{ payout_invoice_id: string | null }> = await dataSource.query(
      `SELECT payout_invoice_id FROM shipments WHERE id = $1`,
      [microShipment.id],
    );
    check(
      captured[0]?.payout_invoice_id === microInvoice.id,
      'Собранный платёж помечен счётом, который его посчитал',
      JSON.stringify(captured[0]),
    );
    const payoutSum: Array<{ total: string; stored: string }> = await dataSource.query(
      `SELECT (SELECT COALESCE(SUM(cod_collected_amount), 0)::text FROM shipments
                WHERE payout_invoice_id = $1) AS total,
              (SELECT cod_collected_total::text FROM invoices WHERE id = $1) AS stored`,
      [microInvoice.id],
    );
    check(
      payoutSum[0].total === payoutSum[0].stored,
      'Собранный COD в счёте равен сумме ровно захваченных им отправлений',
      JSON.stringify(payoutSum[0]),
    );
    // Захват — не «второй раз по периоду»: после него пересборка черновика
    // даёт ту же сумму, а не удвоенную.
    const rebuiltPayout = await as(request(http).post('/api/v1/billing/invoices')).send({
      sellerId: micro.id,
      periodStart: today,
      periodEnd: today,
    });
    check(
      rebuiltPayout.body.codCollectedTotal === payoutSum[0].stored,
      'Пересборка не удваивает собранный платёж',
      `${payoutSum[0].stored} → ${rebuiltPayout.body?.codCollectedTotal}`,
    );
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\nbilling e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
