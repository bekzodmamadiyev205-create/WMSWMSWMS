// Прогоняет тесты этапа по очереди. e2e поднимает встроенный PostgreSQL,
// поэтому запуск занимает пару минут.
//
// Windows: postgres не стартует под администратором — запускать де-элевированно:
//   runas /trustlevel:0x20000 "cmd /c cd /d <ff/apps/api> && node test/run-tests.cjs"
'use strict';
const { spawnSync } = require('node:child_process');
const path = require('node:path');

const files = [
  'test/architecture.test.ts',
  'test/fsm.test.ts',
  'test/label.test.ts',
  'test/migrations-v2.e2e.ts',
  'test/phase-0.e2e.ts',
  'test/users.e2e.ts',
  'test/departments.e2e.ts',
  'test/mdm.e2e.ts',
  'test/inventory.e2e.ts',
  'test/inbound.e2e.ts',
  'test/orders.e2e.ts',
  'test/picking.e2e.ts',
  'test/packing.e2e.ts',
  'test/cancellation.e2e.ts',
  'test/config.e2e.ts',
  'test/integration.e2e.ts',
  'test/billing.e2e.ts',
  'test/dashboard.e2e.ts',
  'test/cron.e2e.ts',
  'test/field-permissions.e2e.ts',
];
const cwd = path.join(__dirname, '..');
let failed = 0;

for (const file of files) {
  console.log(`\n=== ${file} ===`);
  const result = spawnSync('npx', ['ts-node', '-T', file], {
    cwd,
    encoding: 'utf8',
    shell: true,
    stdio: 'inherit',
  });
  if (result.status !== 0) failed++;
}

console.log(`\nSUITE: ${files.length - failed}/${files.length} файлов тестов прошли`);
process.exit(failed ? 1 : 0);
