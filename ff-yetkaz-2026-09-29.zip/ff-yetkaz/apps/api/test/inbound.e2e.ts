// Сквозной тест этапа 1.2 (Inbound) против настоящего PostgreSQL.
//   npx ts-node -T test/inbound.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_inbound_pg');
const PG_PORT = Number(process.env.FF_INB_PGPORT || 5445);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_inbound');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_inbound`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    async function login(email: string): Promise<string> {
      const response = await request(http)
        .post('/api/v1/auth/login')
        .send({ email, password: PASSWORD });
      return response.body.accessToken as string;
    }

    await createUser('admin@ff.local', ['ADMIN'], null);
    await createUser('picker@ff.local', ['PICKER'], null);
    const adminToken = await login('admin@ff.local');
    const pickerToken = await login('picker@ff.local');
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);
    const asPicker = (r: request.Test) => r.set('Authorization', `Bearer ${pickerToken}`);

    // ---------- 1. Миграция и подготовка ------------------------------------
    console.log('\n1. Миграция и справочники');
    check(
      applied.some((m) => m.name === 'Inbound1786060800000'),
      'Миграция Inbound применилась',
      `всего: ${applied.length}`,
    );
    const tables: Array<{ table_name: string }> = await dataSource.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`,
    );
    for (const expected of ['asns', 'asn_lines', 'receipts', 'receipt_lines']) {
      check(tables.some((t) => t.table_name === expected), `Таблица ${expected} создана`);
    }

    const sellerA = (
      await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'Акме' })
    ).body;
    const sellerB = (
      await asAdmin(request(http).post('/api/v1/sellers')).send({ code: 'BETA', legalName: 'Бета' })
    ).body;
    const warehouse = (
      await asAdmin(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })
    ).body;
    const bare = (
      await asAdmin(request(http).post('/api/v1/warehouses')).send({ code: 'SAM-1', name: 'Самарканд' })
    ).body;

    async function makeBin(warehouseId: string, code: string, kind: string) {
      return (
        await asAdmin(request(http).post('/api/v1/bin-locations')).send({ warehouseId, code, kind })
      ).body;
    }
    const receivingBin = await makeBin(warehouse.id, 'R-01', 'RECEIVING');
    const storageBin = await makeBin(warehouse.id, 'S-01-01-01', 'STORAGE');
    await makeBin(warehouse.id, 'D-01', 'DAMAGED');

    async function makeSku(sellerId: string, code: string, barcode: string) {
      const sku = (
        await asAdmin(request(http).post('/api/v1/skus')).send({
          sellerId,
          skuCode: code,
          name: code,
        })
      ).body;
      await asAdmin(request(http).post(`/api/v1/skus/${sku.id}/barcodes`)).send({
        barcode,
        kind: 'EAN13',
        isPrimary: true,
      });
      return sku;
    }
    const kettle = await makeSku(sellerA.id, 'ACME-KETTLE', '4600000000011');
    const lamp = await makeSku(sellerA.id, 'ACME-LAMP', '4600000000028');
    const foreign = await makeSku(sellerB.id, 'BETA-BOX', '4600000000035');

    // ---------- 2. ASN ------------------------------------------------------
    console.log('\n2. Заявка на поставку');
    const pickerAsn = await asPicker(request(http).post('/api/v1/inbound/asns')).send({
      sellerId: sellerA.id,
      warehouseId: warehouse.id,
      lines: [{ skuId: kettle.id, expectedQty: 1 }],
    });
    check(pickerAsn.status === 403, 'PICKER не заводит ASN → 403', `status=${pickerAsn.status}`);

    const wrongSeller = await asAdmin(request(http).post('/api/v1/inbound/asns')).send({
      sellerId: sellerA.id,
      warehouseId: warehouse.id,
      lines: [{ skuId: foreign.id, expectedQty: 1 }],
    });
    check(wrongSeller.status === 400, 'SKU чужого селлера в заявке → 400', `status=${wrongSeller.status}`);

    const asn = await asAdmin(request(http).post('/api/v1/inbound/asns')).send({
      sellerId: sellerA.id,
      warehouseId: warehouse.id,
      externalRef: 'PO-1001',
      lines: [
        { skuId: kettle.id, expectedQty: 12 },
        { skuId: lamp.id, expectedQty: 5 },
      ],
    });
    check(asn.status === 201 && asn.body.status === 'DRAFT', 'ASN создан в статусе DRAFT', `status=${asn.status}`);
    check(asn.body.lines.length === 2, 'Позиции заявки сохранены');

    const dupRef = await asAdmin(request(http).post('/api/v1/inbound/asns')).send({
      sellerId: sellerA.id,
      warehouseId: warehouse.id,
      externalRef: 'po-1001',
      lines: [{ skuId: kettle.id, expectedQty: 1 }],
    });
    check(dupRef.status === 409, 'Дубль номера поставки → 409', `status=${dupRef.status}`);

    const earlyReceipt = await asAdmin(request(http).post('/api/v1/inbound/receipts')).send({
      asnId: asn.body.id,
    });
    check(earlyReceipt.status === 409, 'Приёмка по черновику заявки → 409', `status=${earlyReceipt.status}`);

    const submitted = await asAdmin(request(http).post(`/api/v1/inbound/asns/${asn.body.id}/submit`)).send({});
    check(submitted.status === 201 && submitted.body.status === 'SUBMITTED', 'Заявка отправлена в работу');

    // ---------- 3. Ячейка приёмки обязательна -------------------------------
    console.log('\n3. Требование ячейки приёмки');
    const bareAsn = await asAdmin(request(http).post('/api/v1/inbound/asns')).send({
      sellerId: sellerA.id,
      warehouseId: bare.id,
      lines: [{ skuId: kettle.id, expectedQty: 1 }],
    });
    await asAdmin(request(http).post(`/api/v1/inbound/asns/${bareAsn.body.id}/submit`)).send({});
    const noReceivingBin = await asAdmin(request(http).post('/api/v1/inbound/receipts')).send({
      asnId: bareAsn.body.id,
    });
    check(
      noReceivingBin.status === 409,
      'Приёмка на складе без ячейки RECEIVING → 409',
      `status=${noReceivingBin.status}`,
    );

    // ---------- 4. Скан -----------------------------------------------------
    console.log('\n4. Скан');
    const receipt = await asAdmin(request(http).post('/api/v1/inbound/receipts')).send({
      asnId: asn.body.id,
    });
    check(receipt.status === 201 && receipt.body.status === 'OPEN', 'Приёмка открыта');

    const asnAfterReceipt = await asAdmin(request(http).get(`/api/v1/inbound/asns/${asn.body.id}`));
    check(asnAfterReceipt.body.status === 'RECEIVING', 'Заявка перешла в RECEIVING', asnAfterReceipt.body.status);

    const unknownBarcode = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/scan`),
    ).send({ barcode: '0000000000000', quantity: 1 });
    check(unknownBarcode.status === 404, 'Неизвестный штрихкод → 404', `status=${unknownBarcode.status}`);

    const notInAsn = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/scan`),
    ).send({ barcode: '4600000000035', quantity: 1 });
    check(notInAsn.status === 409, 'SKU не из заявки → 409 (решение PM: стоп)', `status=${notInAsn.status}`);

    const scanned = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/scan`),
    ).send({ barcode: '4600000000011', quantity: 10 });
    check(scanned.status === 201 && scanned.body.lines.length === 1, 'Скан принят', `status=${scanned.status}`);
    check(scanned.body.lines[0].status === 'RECEIVED', 'Позиция в статусе RECEIVED');

    const afterScan = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${kettle.id}`))
    ).body[0];
    check(
      afterScan.byStatus.RECEIVED === 10 && afterScan.available === 0,
      'Просканированное лежит в приёмке и НЕ доступно к продаже',
      JSON.stringify(afterScan.byStatus),
    );

    // ---------- 5. Инспекция и раскладка ------------------------------------
    console.log('\n5. Инспекция и put-away');
    const earlyComplete = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/complete`),
    ).send({});
    check(earlyComplete.status === 409, 'Завершение с неразложенными позициями → 409', `status=${earlyComplete.status}`);

    const partial = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/put-away`),
    ).send({
      receiptLineId: scanned.body.lines[0].id,
      qtyOk: 5,
      qtyDamaged: 2,
      binId: storageBin.id,
    });
    check(partial.status === 400, 'Неполная раскладка → 400', `status=${partial.status}`);

    const putAway = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/put-away`),
    ).send({
      receiptLineId: scanned.body.lines[0].id,
      qtyOk: 8,
      qtyDamaged: 2,
      binId: storageBin.id,
    });
    check(putAway.status === 201 && putAway.body.lines[0].status === 'PUT_AWAY', 'Позиция разложена');

    const afterPutAway = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${kettle.id}`))
    ).body[0];
    check(
      afterPutAway.available === 8 && afterPutAway.byStatus.DAMAGED === 2 && !afterPutAway.byStatus.RECEIVED,
      'Годное доступно, брак отдельно, приёмочная зона пуста',
      JSON.stringify(afterPutAway.byStatus),
    );

    const reasons: Array<{ reason: string }> = await dataSource.query(
      `SELECT DISTINCT reason FROM stock_movements WHERE sku_id = $1`,
      [kettle.id],
    );
    const reasonSet = reasons.map((r) => r.reason);
    check(
      ['RECEIPT', 'INSPECTION', 'PUTAWAY', 'DAMAGE'].every((r) => reasonSet.includes(r)),
      'В журнале есть приход, инспекция, раскладка и брак',
      reasonSet.join(', '),
    );

    const repeated = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/put-away`),
    ).send({
      receiptLineId: scanned.body.lines[0].id,
      qtyOk: 10,
      qtyDamaged: 0,
      binId: storageBin.id,
    });
    check(repeated.status === 409, 'Повторная раскладка той же позиции → 409', `status=${repeated.status}`);

    // ---------- 6. Завершение и сверка --------------------------------------
    console.log('\n6. Завершение и сверка с заявкой');
    const completed = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/complete`),
    ).send({});
    check(completed.status === 201 && completed.body.receipt.status === 'COMPLETED', 'Приёмка завершена');
    check(completed.body.hasDiscrepancy === true, 'Расхождение с заявкой зафиксировано');
    check(
      completed.body.discrepancies.length === 2,
      'Обе позиции расходятся: недовоз чайников и совсем не приехавшие лампы',
      JSON.stringify(completed.body.discrepancies),
    );
    check(
      completed.body.asnStatus === 'RECEIVING',
      'Заявка НЕ закрылась автоматически при недовозе',
      completed.body.asnStatus,
    );

    const scanClosed = await asAdmin(
      request(http).post(`/api/v1/inbound/receipts/${receipt.body.id}/scan`),
    ).send({ barcode: '4600000000011', quantity: 1 });
    check(scanClosed.status === 409, 'Скан в завершённую приёмку → 409', `status=${scanClosed.status}`);

    const closed = await asAdmin(request(http).post(`/api/v1/inbound/asns/${asn.body.id}/close`)).send({});
    check(
      closed.status === 201 && closed.body.status === 'COMPLETED' && closed.body.hasDiscrepancy,
      'Оператор закрыл заявку с недовозом вручную',
      `${closed.body.status}, расхождение=${closed.body.hasDiscrepancy}`,
    );

    const reopen = await asAdmin(request(http).post(`/api/v1/inbound/receipts`)).send({
      asnId: asn.body.id,
    });
    check(reopen.status === 409, 'По закрытой заявке новую приёмку не открыть → 409', `status=${reopen.status}`);

    // ---------- 7. Инварианты и скоуп ---------------------------------------
    console.log('\n7. Инварианты и доступ');
    const mismatch: Array<{ mismatches: string }> = await dataSource.query(`
      WITH ledger AS (
        SELECT sku_id, warehouse_id, to_bin_id AS bin_id, lot_id, to_status AS status, quantity AS qty
          FROM stock_movements WHERE to_bin_id IS NOT NULL
        UNION ALL
        SELECT sku_id, warehouse_id, from_bin_id, lot_id, from_status, -quantity
          FROM stock_movements WHERE from_bin_id IS NOT NULL
      ), agg AS (
        SELECT sku_id, warehouse_id, bin_id, lot_id, status, SUM(qty)::int AS qty
          FROM ledger GROUP BY 1,2,3,4,5
      )
      SELECT count(*)::text AS mismatches
        FROM agg FULL JOIN stock s
          ON s.sku_id = agg.sku_id AND s.warehouse_id = agg.warehouse_id
         AND s.bin_id = agg.bin_id AND s.lot_id IS NOT DISTINCT FROM agg.lot_id
         AND s.status = agg.status
       WHERE COALESCE(s.quantity, 0) <> COALESCE(agg.qty, 0)
    `);
    check(
      mismatch[0].mismatches === '0',
      'После всей цепочки приёмки журнал сходится с остатком',
      `расхождений: ${mismatch[0].mismatches}`,
    );

    const transitions: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events
        WHERE action = 'STATE_TRANSITION' AND entity_type IN ('Asn', 'Receipt')`,
    );
    check(Number(transitions[0].count) >= 4, 'Переходы статусов заявки и приёмки в аудите', `записей: ${transitions[0].count}`);

    await createUser('seller-a@ff.local', ['SELLER'], sellerA.id);
    await createUser('seller-b@ff.local', ['SELLER'], sellerB.id);
    const ownToken = await login('seller-a@ff.local');
    const foreignToken = await login('seller-b@ff.local');

    const own = await request(http)
      .get(`/api/v1/inbound/asns/${asn.body.id}`)
      .set('Authorization', `Bearer ${ownToken}`);
    check(own.status === 200, 'Селлер видит свою заявку', `status=${own.status}`);

    const alien = await request(http)
      .get(`/api/v1/inbound/asns/${asn.body.id}`)
      .set('Authorization', `Bearer ${foreignToken}`);
    check(alien.status === 404, 'Чужая заявка для селлера → 404', `status=${alien.status}`);

    const alienList = await request(http)
      .get('/api/v1/inbound/asns')
      .set('Authorization', `Bearer ${foreignToken}`);
    check(
      alienList.status === 200 && alienList.body.length === 0,
      'В списке заявок чужие не видны',
      `записей: ${alienList.body.length}`,
    );

    // ---------- 8. Приём товара без штрихкода -------------------------------
    // Живая авария: товар заводят без кода, заявку на него оформляют, а принять
    // его нечем — единственный путь в приёмку начинался с поиска штрихкода.
    console.log('\n8. Приём без штрихкода');

    const shirt = (
      await asAdmin(request(http).post('/api/v1/skus')).send({
        sellerId: sellerA.id,
        skuCode: 'ACME-SHIRT',
        name: 'Футболка',
      })
    ).body;

    const asn2 = await asAdmin(request(http).post('/api/v1/inbound/asns')).send({
      sellerId: sellerA.id,
      warehouseId: warehouse.id,
      externalRef: 'PO-2002',
      lines: [
        { skuId: shirt.id, expectedQty: 50 },
        { skuId: kettle.id, expectedQty: 3 },
      ],
    });
    check(asn2.status === 201, 'Заявка на товар без штрихкода заводится', `status=${asn2.status}`);
    await asAdmin(request(http).post(`/api/v1/inbound/asns/${asn2.body.id}/submit`)).send({});

    const shirtLine = asn2.body.lines.find((l: { skuId: string }) => l.skuId === shirt.id);
    const kettleLine = asn2.body.lines.find((l: { skuId: string }) => l.skuId === kettle.id);
    check(shirtLine.hasBarcode === false, 'Позиция без кода помечена hasBarcode=false');
    check(kettleLine.hasBarcode === true, 'Позиция с кодом помечена hasBarcode=true');

    const receipt2 = await asAdmin(request(http).post('/api/v1/inbound/receipts')).send({
      asnId: asn2.body.id,
    });
    check(receipt2.status === 201, 'Приёмка по второй заявке открыта', `status=${receipt2.status}`);
    const scan2 = `/api/v1/inbound/receipts/${receipt2.body.id}/scan`;

    // Стена, из-за которой всё встало: сканировать нечего, кода не существует.
    const noCode = await asAdmin(request(http).post(scan2)).send({
      barcode: '9999999999999',
      quantity: 1,
    });
    check(
      noCode.status === 404 && noCode.body.code === 'BARCODE_UNKNOWN',
      'Незнакомый штрихкод → 404 с машинным кодом BARCODE_UNKNOWN',
      `status=${noCode.status}, code=${noCode.body.code}`,
    );

    // Главная проверка починки: строка заявки называет товар однозначно.
    const byLine = await asAdmin(request(http).post(scan2)).send({
      asnLineId: shirtLine.id,
      quantity: 20,
    });
    check(byLine.status === 201, 'Товар без штрихкода принят по строке заявки', `status=${byLine.status}`);

    const shirtStock = (
      await asAdmin(request(http).get(`/api/v1/inventory/stock?skuId=${shirt.id}`))
    ).body[0];
    check(
      Boolean(shirtStock) && shirtStock.total === 20,
      'Принятое без скана попало в остаток',
      `остаток: ${shirtStock ? shirtStock.total : 'строки нет'}`,
    );

    // Ручной приём обязан быть отличим от отсканированного: иначе при разборе
    // расхождений неясно, где товар физически проверяли сканером, а где нет.
    const manualComment: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM stock_movements
        WHERE sku_id = $1 AND reason = 'RECEIPT' AND comment IS NOT NULL`,
      [shirt.id],
    );
    check(
      manualComment[0].count === '1',
      'Ручной приём помечен комментарием в журнале движений',
      `помеченных движений: ${manualComment[0].count}`,
    );

    const both = await asAdmin(request(http).post(scan2)).send({
      barcode: '4600000000011',
      asnLineId: kettleLine.id,
      quantity: 1,
    });
    check(both.status === 400, 'Штрихкод и строка заявки разом → 400', `status=${both.status}`);

    const neither = await asAdmin(request(http).post(scan2)).send({ quantity: 1 });
    check(neither.status === 400, 'Ни штрихкода, ни строки заявки → 400', `status=${neither.status}`);

    const blankBarcode = await asAdmin(request(http).post(scan2)).send({
      barcode: '   ',
      asnLineId: kettleLine.id,
      quantity: 1,
    });
    check(
      blankBarcode.status === 201,
      'Пробельный штрихкод рядом со строкой заявки считается отсутствующим',
      `status=${blankBarcode.status}`,
    );

    // Строка чужой заявки — это обход контроля: ASN и есть разрешение принять.
    const asn3 = await asAdmin(request(http).post('/api/v1/inbound/asns')).send({
      sellerId: sellerA.id,
      warehouseId: warehouse.id,
      externalRef: 'PO-3003',
      lines: [{ skuId: lamp.id, expectedQty: 4 }],
    });
    await asAdmin(request(http).post(`/api/v1/inbound/asns/${asn3.body.id}/submit`)).send({});
    const alienLine = await asAdmin(request(http).post(scan2)).send({
      asnLineId: asn3.body.lines[0].id,
      quantity: 1,
    });
    check(
      alienLine.status === 409 && alienLine.body.code === 'ASN_LINE_FOREIGN',
      'Строка из другой заявки → 409 ASN_LINE_FOREIGN',
      `status=${alienLine.status}, code=${alienLine.body.code}`,
    );

    // ---------- 9. Привязка штрихкода прямо на приёмке ----------------------
    console.log('\n9. Привязка штрихкода к позиции заявки');
    const lines2 = `/api/v1/inbound/receipts/${receipt2.body.id}/lines`;

    const linked = await asAdmin(request(http).post(`${lines2}/${shirtLine.id}/barcode`)).send({
      barcode: '4600000000042',
    });
    check(linked.status === 201, 'Код привязан к позиции заявки', `status=${linked.status}`);

    // Ради этого всё и затевалось: со следующей коробки скан работает сам.
    const afterLink = await asAdmin(request(http).post(scan2)).send({
      barcode: '4600000000042',
      quantity: 5,
    });
    check(
      afterLink.status === 201,
      'После привязки тот же товар принимается ОБЫЧНЫМ сканом',
      `status=${afterLink.status}`,
    );

    const alienLink = await asAdmin(
      request(http).post(`${lines2}/${asn3.body.lines[0].id}/barcode`),
    ).send({ barcode: '4600000000059' });
    check(
      alienLink.status === 409,
      'Код к строке чужой заявки не привязать → 409',
      `status=${alienLink.status}`,
    );

    // Приёмщик правит справочник только через свою поставку — общих прав
    // на каталог ему по-прежнему не выдано.
    await createUser('receiver@ff.local', ['RECEIVER'], null);
    const receiverToken = await login('receiver@ff.local');
    const catalogDirect = await request(http)
      .post(`/api/v1/skus/${shirt.id}/barcodes`)
      .set('Authorization', `Bearer ${receiverToken}`)
      .send({ barcode: '4600000000066', kind: 'EAN13', isPrimary: false });
    check(
      catalogDirect.status === 403,
      'Приёмщик не редактирует справочник напрямую → 403',
      `status=${catalogDirect.status}`,
    );
    const viaReceipt = await request(http)
      .post(`${lines2}/${shirtLine.id}/barcode`)
      .set('Authorization', `Bearer ${receiverToken}`)
      .send({ barcode: '4600000000073' });
    check(
      viaReceipt.status === 201,
      'Тот же приёмщик привязывает код через свою поставку',
      `status=${viaReceipt.status}`,
    );

    // Заявку закрыли руками — открытая приёмка не должна оставаться лазейкой
    // для дописывания остатка по завершённой поставке.
    await asAdmin(request(http).post(`/api/v1/inbound/asns/${asn2.body.id}/close`)).send({});
    const afterClose = await asAdmin(request(http).post(scan2)).send({
      asnLineId: shirtLine.id,
      quantity: 1,
    });
    check(
      afterClose.status === 409,
      'Приём по закрытой заявке через открытую приёмку → 409',
      `status=${afterClose.status}`,
    );

  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\ninbound e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
