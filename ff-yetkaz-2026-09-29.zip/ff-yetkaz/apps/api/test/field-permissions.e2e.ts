// Сквозной тест прав на уровне КОЛОНКИ против настоящего PostgreSQL.
//   npx ts-node -T test/field-permissions.e2e.ts
//
// Этот набор стережёт средство защиты, а не удобство. Дважды за разработку
// матрица прав оказывалась украшением: сначала право стояло на поле, которого
// в ответе не существует, потом выгрузка в Excel обходила фильтр целиком и
// отдавала сборщику суммы, скрытые от него на экране. Оба раза код проходил
// типизацию и выглядел рабочим. Поэтому проверяется не «есть ли фильтр», а
// «видно ли поле» — по КАЖДОМУ пути, которым данные покидают систему.
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_acl_pg');
const PG_PORT = Number(process.env.FF_ACL_PGPORT || 5462);
const PASSWORD = 'Sklad-2026-Admin!';
const PICKER_PASSWORD = 'Sborka-2026-Acl!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

interface MatrixRow {
  role: Role;
  entity: string;
  field: string;
  canView: boolean;
  canEdit: boolean;
  canDelete: boolean;
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_acl');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_acl`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    await dataSource.runMigrations();

    const passwordHash = await passwords.hash(PASSWORD);
    await dataSource.transaction(async (em) => {
      const users = em.getRepository(UserEntity);
      const admin = await users.save(
        users.create({
          email: 'admin@ff.local',
          passwordHash,
          fullName: 'Админ',
          isActive: true,
          sellerId: null,
        }),
      );
      await em.getRepository(UserRoleEntity).insert({ userId: admin.id, role: 'ADMIN' });
    });

    const login = async (email: string, password: string): Promise<string> => {
      const response = await request(http).post('/api/v1/auth/login').send({ email, password });
      return (response.body.accessToken as string) ?? '';
    };
    const adminToken = await login('admin@ff.local', PASSWORD);
    const asAdmin = (r: request.Test) => r.set('Authorization', `Bearer ${adminToken}`);

    await asAdmin(request(http).post('/api/v1/users')).send({
      email: 'picker@ff.local',
      fullName: 'Сборщик',
      password: PICKER_PASSWORD,
      roles: ['PICKER'] satisfies Role[],
    });
    const pickerToken = await login('picker@ff.local', PICKER_PASSWORD);
    const asPicker = (r: request.Test) => r.set('Authorization', `Bearer ${pickerToken}`);

    // Минимальные данные: один селлер, склад, товар и заказ с наложенным платежом.
    const seller = await asAdmin(request(http).post('/api/v1/sellers')).send({
      code: 'ACL',
      legalName: 'ООО «Права»',
    });
    const warehouse = await asAdmin(request(http).post('/api/v1/warehouses')).send({
      code: 'ACL-1',
      name: 'Склад прав',
      timezone: 'Asia/Tashkent',
    });
    const sku = await asAdmin(request(http).post('/api/v1/skus')).send({
      sellerId: seller.body.id,
      skuCode: 'ACL-001',
      name: 'Товар для проверки прав',
      weightG: 100,
    });
    const order = await asAdmin(request(http).post('/api/v1/orders')).send({
      sellerId: seller.body.id,
      channel: 'manual',
      externalId: 'ACL-ORDER-1',
      recipientName: 'Получатель',
      recipientPhone: '+998901112233',
      address: 'Ташкент, Навои 1',
      codAmount: '250000',
      currency: 'UZS',
      lines: [{ skuId: sku.body.id, quantity: 1 }],
    });
    check(order.status === 201, 'Подготовка: заказ с COD создан', `status=${order.status}`);
    const orderId = order.body.order?.id as string;

    console.log('\n1. Умолчание матрицы — «склад не видит деньги»');
    const adminSees = await asAdmin(request(http).get('/api/v1/orders?pageSize=5'));
    const pickerSees = await asPicker(request(http).get('/api/v1/orders?pageSize=5'));
    check(adminSees.status === 200 && pickerSees.status === 200, 'Список заказов открыт обоим');
    const adminRow = adminSees.body.rows?.[0] ?? {};
    const pickerRow = pickerSees.body.rows?.[0] ?? {};
    check('codAmount' in adminRow, 'ADMIN видит сумму наложенного платежа', String(adminRow.codAmount));
    check(!('codAmount' in pickerRow), 'PICKER суммы НЕ видит — ключа нет в ответе');
    check(!('currency' in pickerRow), 'PICKER не видит валюту');
    // Ключ должен ИСЧЕЗНУТЬ, а не обнулиться: `null` фронт и выгрузка прочитали
    // бы как настоящее значение «платежа нет».
    check(
      pickerRow.codAmount === undefined,
      'Закрытое поле удалено, а не обнулено',
      JSON.stringify(pickerRow.codAmount),
    );
    check('recipientName' in pickerRow, 'Рабочие поля у сборщика на месте', pickerRow.recipientName);

    console.log('\n2. Тот же запрет действует на КАРТОЧКЕ заказа');
    const card = await asPicker(request(http).get(`/api/v1/orders/${orderId}`));
    check(card.status === 200 && !('codAmount' in card.body), 'Карточка заказа тоже без суммы');

    console.log('\n3. Выгрузка в Excel обязана уважать матрицу');
    // Именно здесь была дыра: интерцептор фильтрует JSON, а поток xlsx не трогает.
    const adminFile = await asAdmin(request(http).get('/api/v1/orders/export')).responseType('blob');
    const pickerFile = await asPicker(request(http).get('/api/v1/orders/export')).responseType('blob');
    check(adminFile.status === 200 && pickerFile.status === 200, 'Выгрузка доступна обоим');
    const zip = (body: Buffer): boolean => body.subarray(0, 2).toString('latin1') === 'PK';
    check(zip(adminFile.body) && zip(pickerFile.body), 'Оба файла — настоящий xlsx');
    check(
      pickerFile.body.length < adminFile.body.length,
      'Файл сборщика меньше — колонок в нём меньше',
      `${pickerFile.body.length} < ${adminFile.body.length}`,
    );

    console.log('\n4. Действующие права отдаются самому пользователю');
    const effective = await asPicker(request(http).get('/api/v1/field-permissions/effective'));
    check(effective.status === 200, 'Ручка действующих прав открыта любому', `status=${effective.status}`);
    check(effective.body.unrestricted === false, 'У сборщика ограничения есть');
    check(
      effective.body.acl?.order?.codAmount?.view === false,
      'В действующих правах сумма закрыта',
      JSON.stringify(effective.body.acl?.order?.codAmount),
    );
    const adminEffective = await asAdmin(request(http).get('/api/v1/field-permissions/effective'));
    check(
      adminEffective.body.unrestricted === true,
      'Администратор не ограничивается матрицей вовсе',
    );

    console.log('\n5. Правка матрицы');
    const matrix = await asAdmin(request(http).get('/api/v1/field-permissions'));
    check(matrix.status === 200, 'Матрица доступна ADMIN', `status=${matrix.status}`);
    check(
      Array.isArray(matrix.body.entities) && matrix.body.entities.length > 0,
      'В матрице перечислены сущности и их поля',
      `сущностей: ${matrix.body.entities?.length}`,
    );
    const stockFields: string[] =
      matrix.body.entities?.find((e: { entity: string }) => e.entity === 'stock')?.fields ?? [];
    check(
      stockFields.includes('firstReceivedAt') && stockFields.includes('lastReceivedAt'),
      'Поля остатков названы так же, как ключи ответа',
      stockFields.join(','),
    );
    check(
      !stockFields.includes('receivedAt'),
      'Несуществующего поля receivedAt в матрице нет',
    );

    const pickerDenied = await asPicker(request(http).get('/api/v1/field-permissions'));
    check(pickerDenied.status === 403, 'Матрицу правит только ADMIN → 403', `status=${pickerDenied.status}`);

    // Снять запрет = прислать строку ПОЛНОСТЬЮ РАЗРЕШИТЕЛЬНОЙ, а не выкинуть
    // её из тела. Ручка работает как набор утверждений, а не как замена
    // состояния целиком: пропущенная строка остаётся нетронутой. Иначе
    // клиент, знающий о меньшем числе сущностей, стирал бы чужие правила
    // одним сохранением. Разрешительные строки сервис удаляет сам — в
    // таблице живут только исключения.
    const permissions: MatrixRow[] = (matrix.body.permissions as MatrixRow[]).map((row) =>
      row.role === 'PICKER' && row.entity === 'order' && row.field === 'codAmount'
        ? { ...row, canView: true, canEdit: true, canDelete: false }
        : row,
    );
    const opened = await asAdmin(request(http).put('/api/v1/field-permissions')).send({ permissions });
    check(opened.status === 200, 'Запрет снят сохранением матрицы', `status=${opened.status}`);

    const afterOpen = await asPicker(request(http).get('/api/v1/orders?pageSize=1'));
    check(
      'codAmount' in (afterOpen.body.rows?.[0] ?? {}),
      'После снятия запрета сумма снова видна — кэш прав сброшен записью',
    );

    console.log('5b. Пропущенная строка остаётся нетронутой');
    const denyAgain = await asAdmin(request(http).put('/api/v1/field-permissions')).send({
      permissions: [
        { role: 'PICKER', entity: 'order', field: 'codAmount', canView: false, canEdit: false, canDelete: false },
      ],
    });
    check(denyAgain.status === 200, 'Запрет возвращён одной строкой', `status=${denyAgain.status}`);
    // Сохранение НЕ связанной строки не должно стирать чужие правила: ручка —
    // набор утверждений, и клиент, не знающий про чужую сущность, не может
    // случайно открыть закрытое.
    const unrelated = await asAdmin(request(http).put('/api/v1/field-permissions')).send({
      permissions: [
        { role: 'PACKER', entity: 'order', field: 'region', canView: false, canEdit: false, canDelete: false },
      ],
    });
    check(unrelated.status === 200, 'Сохранение другой строки прошло', `status=${unrelated.status}`);
    const stillHidden = await asPicker(request(http).get('/api/v1/orders?pageSize=1'));
    check(
      !('codAmount' in (stillHidden.body.rows?.[0] ?? {})),
      'Чужой запрет сохранением другой строки не стёрт',
    );

    console.log('\n6. Администратора матрицей не ограничить');
    const adminRule = await asAdmin(request(http).put('/api/v1/field-permissions')).send({
      permissions: [
        ...permissions,
        { role: 'ADMIN', entity: 'order', field: 'codAmount', canView: false, canEdit: false, canDelete: false },
      ],
    });
    check(
      adminRule.status === 400,
      'Запрет для роли ADMIN отвергается → 400',
      `status=${adminRule.status}`,
    );

    console.log('\n7. Право на несуществующее поле не сохраняется');
    const bogus = await asAdmin(request(http).put('/api/v1/field-permissions')).send({
      permissions: [
        { role: 'PICKER', entity: 'order', field: 'выдуманное', canView: false, canEdit: false, canDelete: false },
      ],
    });
    check(
      bogus.status === 400,
      'Поле вне списка сущности отвергается → 400',
      `status=${bogus.status}`,
    );
  } catch (error) {
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      // Остановка встроенной базы не должна прятать результат прогона.
    }
  }

  console.log(`\nfield-permissions e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
