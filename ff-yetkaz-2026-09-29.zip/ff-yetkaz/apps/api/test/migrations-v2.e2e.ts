// Проверка миграций Platform v2 на настоящем PostgreSQL: схема, значения
// перечислений, триггеры и витрины BI.
//   npx ts-node -T test/migrations-v2.e2e.ts
//
// Отдельный тест, а не часть доменного: миграция — единственное, что нельзя
// откатить на боевой базе, и ошибку в её SQL надо ловить до деплоя, а не по
// падению приложения на старте.
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import { DataSource } from 'typeorm';
import { FF_ENTITIES } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_migrations_v2_pg');
const PG_PORT = Number(process.env.FF_MIGRATIONS_PGPORT || 5461);

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

/** Ожидаем, что выражение упадёт: триггеры проверяются только так. */
async function expectFailure(ds: DataSource, sql: string, name: string): Promise<void> {
  try {
    await ds.query(sql);
    check(false, name, 'запрос прошёл, хотя должен был упасть');
  } catch (error) {
    check(true, name, (error as Error).message.split('\n')[0].slice(0, 90));
  }
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let ds: DataSource | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_migrations_v2');

    ds = new DataSource({
      type: 'postgres',
      url: `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_migrations_v2`,
      entities: FF_ENTITIES,
      migrations: [join(__dirname, '..', 'src', 'infrastructure', 'database', 'migrations', '*.ts')],
      migrationsTableName: 'ff_migrations',
      synchronize: false,
      logging: ['error'],
    });
    await ds.initialize();

    console.log('Прогон всех миграций');
    const applied = await ds.runMigrations();
    check(applied.length > 0, 'миграции применились', `${applied.length} шт.`);
    check(
      applied.some((m) => m.name === 'PlatformV2Enums1787184000000'),
      'PlatformV2Enums применена',
    );
    check(
      applied.some((m) => m.name === 'PlatformV21787184060000'),
      'PlatformV2 применена',
    );

    console.log('\nЗначения перечислений');
    const orderStatuses: Array<{ v: string }> = await ds.query(
      `SELECT unnest(enum_range(NULL::order_status))::text AS v`,
    );
    const statusList = orderStatuses.map((r) => r.v);
    check(statusList.includes('DISPATCHED'), 'order_status содержит DISPATCHED');
    check(
      statusList.indexOf('DISPATCHED') === statusList.indexOf('READY_TO_SHIP') + 1,
      'DISPATCHED стоит сразу после READY_TO_SHIP',
      statusList.join(','),
    );

    const units: Array<{ v: string }> = await ds.query(
      `SELECT unnest(enum_range(NULL::tariff_unit))::text AS v`,
    );
    const unitList = units.map((r) => r.v);
    check(
      ['PER_BOX', 'PER_PALLET', 'PER_BOX_DAY', 'PER_PALLET_DAY'].every((u) =>
        unitList.includes(u),
      ),
      'tariff_unit содержит все четыре новые единицы',
      unitList.join(','),
    );

    const reasons: Array<{ v: string }> = await ds.query(
      `SELECT unnest(enum_range(NULL::movement_reason))::text AS v`,
    );
    check(
      reasons.some((r) => r.v === 'RETURN'),
      'movement_reason содержит RETURN',
    );

    console.log('\nТаблицы и колонки');
    const tableExists = async (name: string): Promise<boolean> => {
      const rows = await ds!.query(`SELECT to_regclass($1) AS reg`, [name]);
      return rows[0]?.reg !== null;
    };
    for (const table of [
      'order_categories',
      'order_status_history',
      'returns',
      'return_items',
      'return_status_history',
      'field_permissions',
    ]) {
      check(await tableExists(table), `таблица ${table} создана`);
    }

    const columnExists = async (table: string, column: string): Promise<boolean> => {
      const rows = await ds!.query(
        `SELECT 1 FROM information_schema.columns WHERE table_name = $1 AND column_name = $2`,
        [table, column],
      );
      return rows.length > 0;
    };
    check(await columnExists('orders', 'category_id'), 'orders.category_id');
    check(await columnExists('orders', 'dispatched_at'), 'orders.dispatched_at');
    check(await columnExists('skus', 'units_per_box'), 'skus.units_per_box');
    check(await columnExists('skus', 'units_per_pallet'), 'skus.units_per_pallet');
    check(await columnExists('tariff_rules', 'component'), 'tariff_rules.component');
    check(await columnExists('storage_snapshots', 'boxes'), 'storage_snapshots.boxes');
    check(await columnExists('storage_snapshots', 'pallets'), 'storage_snapshots.pallets');

    console.log('\nЗасеянные данные');
    const categories: Array<{ count: string }> = await ds.query(
      `SELECT count(*)::text AS count FROM order_categories`,
    );
    check(Number(categories[0].count) === 4, 'засеяно 4 категории заказа', categories[0].count);
    const perms: Array<{ count: string }> = await ds.query(
      `SELECT count(*)::text AS count FROM field_permissions WHERE can_view = false`,
    );
    check(Number(perms[0].count) === 6, 'засеяно 6 запретов на колонки', perms[0].count);

    console.log('\nИнварианты в БД');
    await expectFailure(
      ds,
      `UPDATE order_status_history SET comment = 'x'`,
      'order_status_history запрещает UPDATE',
    );
    await expectFailure(
      ds,
      `DELETE FROM order_status_history`,
      'order_status_history запрещает DELETE',
    );

    // Номер возврата выдаёт последовательность БД, а не приложение.
    const sellerRows: Array<{ id: string }> = await ds.query(
      `INSERT INTO sellers (code, legal_name) VALUES ('MIGT', 'Тест миграции') RETURNING id`,
    );
    const warehouseRows: Array<{ id: string }> = await ds.query(
      `INSERT INTO warehouses (code, name, timezone) VALUES ('MIGW', 'Склад', 'Asia/Tashkent') RETURNING id`,
    );
    const rma: Array<{ return_no: string }> = await ds.query(
      `INSERT INTO returns (seller_id, warehouse_id, reason) VALUES ($1, $2, 'OTHER') RETURNING return_no`,
      [sellerRows[0].id, warehouseRows[0].id],
    );
    check(/^RMA\d{9}$/.test(rma[0].return_no), 'номер возврата выдаёт БД', rma[0].return_no);

    await expectFailure(
      ds,
      `UPDATE returns SET status = 'COMPLETED'`,
      'нельзя завершить возврат без completed_at',
    );

    // Одна единица на составляющую — теперь это триггер, а не гонка в коде.
    const plan: Array<{ id: string }> = await ds.query(
      `INSERT INTO tariff_plans (code, name, currency, is_active) VALUES ('MIG', 'План', 'UZS', true) RETURNING id`,
    );
    await ds.query(
      `INSERT INTO tariff_rules (plan_id, kind, unit, price) VALUES ($1, 'PACKING', 'PER_ORDER', 2000)`,
      [plan[0].id],
    );
    const defaults: Array<{ component: string }> = await ds.query(
      `SELECT component FROM tariff_rules WHERE plan_id = $1`,
      [plan[0].id],
    );
    check(defaults[0].component === 'BASE', 'component по умолчанию = BASE', defaults[0].component);

    await expectFailure(
      ds,
      `INSERT INTO tariff_rules (plan_id, kind, unit, price)
       VALUES ('${plan[0].id}', 'PACKING', 'PER_KG', 1500)`,
      'вторая единица в той же составляющей отбита',
    );

    const combo = await ds.query(
      `INSERT INTO tariff_rules (plan_id, kind, unit, price, component)
       VALUES ($1, 'PACKING', 'PER_KG', 1500, 'WEIGHT') RETURNING id`,
      [plan[0].id],
    );
    check(combo.length === 1, 'комбинация «за заказ + за кг» разрешена разными составляющими');

    console.log('\nВитрины BI');
    for (const view of [
      'bi_orders',
      'bi_order_status_history',
      'bi_stock',
      'bi_returns',
      'bi_seller_daily',
    ]) {
      try {
        await ds.query(`SELECT * FROM ${view} LIMIT 1`);
        check(true, `витрина ${view} читается`);
      } catch (error) {
        check(false, `витрина ${view} читается`, (error as Error).message.slice(0, 90));
      }
    }

    console.log('\nИндексы под новые экраны');
    const indexes: Array<{ indexname: string }> = await ds.query(
      `SELECT indexname FROM pg_indexes WHERE schemaname = 'public'`,
    );
    const names = indexes.map((i) => i.indexname);
    for (const idx of [
      'idx_orders_category',
      'idx_orders_dispatched',
      'idx_orders_seller_created',
      'idx_movements_inbound',
      'uq_tariff_rules_step',
      'uq_field_permissions',
      'uq_return_items_sku',
    ]) {
      check(names.includes(idx), `индекс ${idx}`);
    }
  } catch (error) {
    check(false, 'прогон без исключений', (error as Error).message.slice(0, 200));
    console.error(error);
  } finally {
    if (ds?.isInitialized) await ds.destroy();
    await pg.stop().catch(() => undefined);
  }

  console.log(`\nmigrations v2: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
