// Сквозной тест этапа 1.5: отмена заказа на разных стадиях и возврат товара.
//   npx ts-node -T test/cancellation.e2e.ts
import 'reflect-metadata';
import { mkdirSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import type { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { DataSource } from 'typeorm';
import type { Role } from '@ff/shared';
import { PasswordService } from '../src/infrastructure/auth/password.service';
import { configureApp } from '../src/bootstrap';
import { UserEntity, UserRoleEntity } from '../src/infrastructure/database/entities';

const require2 = createRequire(join(__dirname, '..', 'package.json'));
const pgModule = require2('embedded-postgres');
const EmbeddedPostgres = pgModule.default ?? pgModule;

const DATA_DIR = join(process.env.TEMP || '/tmp', 'ff_cancel_pg');
const PG_PORT = Number(process.env.FF_CANCEL_PGPORT || 5449);
const PASSWORD = 'Sklad-2026!';

let pass = 0;
let fail = 0;

function check(ok: boolean, name: string, detail = ''): void {
  if (ok) pass++;
  else fail++;
  console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

(async () => {
  rmSync(DATA_DIR, { recursive: true, force: true });
  mkdirSync(DATA_DIR, { recursive: true });

  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: 'postgres',
    password: 'postgres',
    port: PG_PORT,
    persistent: false,
  });

  let app: INestApplication | null = null;

  try {
    await pg.initialise();
    await pg.start();
    await pg.createDatabase('ff_cancel');

    process.env.NODE_ENV = 'test';
    process.env.DATABASE_URL = `postgres://postgres:postgres@127.0.0.1:${PG_PORT}/ff_cancel`;
    process.env.JWT_SECRET = 'e2e-secret-0123456789-0123456789-0123456789';

    const { AppModule } = await import('../src/app.module');
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();

    app = moduleRef.createNestApplication();
    configureApp(app, app.get(ConfigService));
    await app.init();

    const dataSource = app.get(DataSource);
    const passwords = app.get(PasswordService);
    const http = app.getHttpServer();
    const applied = await dataSource.runMigrations();

    async function createUser(email: string, roles: Role[], sellerId: string | null) {
      const passwordHash = await passwords.hash(PASSWORD);
      return dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({ email, passwordHash, fullName: email, isActive: true, sellerId }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    }
    await createUser('admin@ff.local', ['ADMIN'], null);
    const token = (
      await request(http).post('/api/v1/auth/login').send({ email: 'admin@ff.local', password: PASSWORD })
    ).body.accessToken as string;
    const as = (r: request.Test) => r.set('Authorization', `Bearer ${token}`);

    // ---------- 1. Подготовка -----------------------------------------------
    console.log('\n1. Подготовка');
    check(
      applied.some((m) => m.name === 'OrderCancellation1786406400000'),
      'Миграция OrderCancellation применилась',
      `всего: ${applied.length}`,
    );

    const seller = (await as(request(http).post('/api/v1/sellers')).send({ code: 'ACME', legalName: 'Акме' })).body;
    const wh = (await as(request(http).post('/api/v1/warehouses')).send({ code: 'TAS-1', name: 'Ташкент' })).body;
    const mkBin = async (code: string, kind: string) =>
      (await as(request(http).post('/api/v1/bin-locations')).send({ warehouseId: wh.id, code, kind })).body;
    const store1 = await mkBin('S-01-01-01', 'STORAGE');
    const store2 = await mkBin('S-02-02-02', 'STORAGE');
    const packBin = await mkBin('P-01-01-01', 'PACKING');
    const shipBin = await mkBin('X-01-01-01', 'SHIPPING');

    const mkSku = async (code: string, barcode: string) => {
      const sku = (
        await as(request(http).post('/api/v1/skus')).send({
          sellerId: seller.id,
          skuCode: code,
          name: code,
          weightG: 500,
        })
      ).body;
      await as(request(http).post(`/api/v1/skus/${sku.id}/barcodes`)).send({
        barcode,
        kind: 'EAN13',
        isPrimary: true,
      });
      return sku;
    };
    const skuReserved = await mkSku('R', '3000000000017');
    const skuPicked = await mkSku('P', '3000000000024');
    const skuPacked = await mkSku('K', '3000000000031');
    const skuBatchA = await mkSku('BA', '3000000000048');
    const skuBatchB = await mkSku('BB', '3000000000055');

    const stockIn = (skuId: string, binId: string, quantity: number) =>
      as(request(http).post('/api/v1/inventory/stock-in')).send({
        skuId,
        warehouseId: wh.id,
        binId,
        quantity,
      });
    await stockIn(skuReserved.id, store1.id, 5);
    // Разложен по двум ячейкам: возврат обязан разойтись по исходным местам.
    await stockIn(skuPicked.id, store1.id, 2);
    await stockIn(skuPicked.id, store2.id, 3);
    await stockIn(skuPacked.id, store1.id, 4);
    await stockIn(skuBatchA.id, store1.id, 3);
    await stockIn(skuBatchB.id, store1.id, 3);

    let seq = 0;
    const mkOrder = async (lines: Array<{ skuId: string; quantity: number }>) => {
      seq += 1;
      return (
        await as(request(http).post('/api/v1/orders')).send({
          sellerId: seller.id,
          channel: 'uzum',
          externalId: `C-${seq}`,
          recipientName: 'Иванов',
          recipientPhone: '+998901234567',
          address: 'Ташкент',
          lines,
        })
      ).body.order;
    };

    const available = async (skuId: string, binId: string): Promise<number> => {
      const rows: Array<{ quantity: number }> = await dataSource.query(
        `SELECT quantity FROM stock WHERE sku_id=$1 AND bin_id=$2 AND status='AVAILABLE'`,
        [skuId, binId],
      );
      return rows[0]?.quantity ?? 0;
    };
    const totalByStatus = async (skuId: string): Promise<Record<string, number>> => {
      const rows: Array<{ status: string; total: string }> = await dataSource.query(
        `SELECT status, SUM(quantity)::text AS total FROM stock WHERE sku_id=$1 AND quantity>0 GROUP BY status`,
        [skuId],
      );
      return Object.fromEntries(rows.map((row) => [row.status, Number(row.total)]));
    };

    // ---------- 2. Отмена зарезервированного ---------------------------------
    console.log('\n2. Отмена зарезервированного заказа');
    const reserved = await mkOrder([{ skuId: skuReserved.id, quantity: 2 }]);
    check(reserved.status === 'RESERVED', 'Заказ зарезервирован');
    const cancelReserved = await as(request(http).post(`/api/v1/orders/${reserved.id}/cancel`)).send({
      reason: 'Клиент передумал',
    });
    check(cancelReserved.status === 201 && cancelReserved.body.status === 'CANCELLED', 'Заказ отменён');
    check(
      (await available(skuReserved.id, store1.id)) === 5,
      'Резерв вернулся в доступный остаток целиком',
      `${await available(skuReserved.id, store1.id)}`,
    );

    // ---------- 3. Отмена собранного -----------------------------------------
    console.log('\n3. Отмена собранного заказа');
    const picked = await mkOrder([{ skuId: skuPicked.id, quantity: 5 }]);
    const pickTask = (
      await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [picked.id] })
    ).body;
    await as(request(http).post(`/api/v1/picking/tasks/${pickTask.id}/assign`)).send({});
    await as(request(http).post(`/api/v1/picking/tasks/${pickTask.id}/scan`)).send({
      barcode: '3000000000024',
      quantity: 2,
    });
    await as(request(http).post(`/api/v1/picking/tasks/${pickTask.id}/scan`)).send({
      barcode: '3000000000024',
      quantity: 3,
    });
    await as(request(http).post(`/api/v1/picking/tasks/${pickTask.id}/complete`)).send({});
    const beforeCancel = await totalByStatus(skuPicked.id);
    check(beforeCancel.PICKED === 5, 'Пять единиц собраны в зону упаковки', JSON.stringify(beforeCancel));

    await as(request(http).post(`/api/v1/orders/${picked.id}/cancel`)).send({ reason: 'Отказ' });
    const afterCancel = await totalByStatus(skuPicked.id);
    check(
      afterCancel.PICKED === undefined && afterCancel.AVAILABLE === 5,
      'Собранное вернулось в доступный остаток',
      JSON.stringify(afterCancel),
    );
    check(
      (await available(skuPicked.id, store1.id)) === 2 && (await available(skuPicked.id, store2.id)) === 3,
      'Возврат разошёлся по исходным ячейкам, а не свалился в одну',
      `${await available(skuPicked.id, store1.id)} / ${await available(skuPicked.id, store2.id)}`,
    );
    const inPackBin: Array<{ quantity: number }> = await dataSource.query(
      `SELECT quantity FROM stock WHERE sku_id=$1 AND bin_id=$2 AND quantity>0`,
      [skuPicked.id, packBin.id],
    );
    check(inPackBin.length === 0, 'В зоне упаковки ничего не зависло');

    const putBackMoves: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM stock_movements
        WHERE reason='PUT_BACK' AND reference_id=$1`,
      [picked.id],
    );
    check(Number(putBackMoves[0].count) === 2, 'Возврат записан в журнал причиной PUT_BACK', putBackMoves[0].count);

    // ---------- 4. Отмена упакованного ---------------------------------------
    console.log('\n4. Отмена упакованного заказа с оформленным отправлением');
    const packed = await mkOrder([{ skuId: skuPacked.id, quantity: 2 }]);
    const packTask = (
      await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [packed.id] })
    ).body;
    await as(request(http).post(`/api/v1/picking/tasks/${packTask.id}/assign`)).send({});
    await as(request(http).post(`/api/v1/picking/tasks/${packTask.id}/scan`)).send({
      barcode: '3000000000031',
      quantity: 2,
    });
    await as(request(http).post(`/api/v1/picking/tasks/${packTask.id}/complete`)).send({});
    const pkg = (await as(request(http).post(`/api/v1/packing/orders/${packed.id}/start`)).send({})).body;
    await as(request(http).post(`/api/v1/packing/orders/${packed.id}/complete`)).send({ weightG: 1000 });
    const shipment = (await as(request(http).post(`/api/v1/packing/packages/${pkg.id}/label`)).send({})).body;
    check(shipment.status === 'READY', 'Отправление оформлено');

    const inShipBin: Array<{ quantity: number }> = await dataSource.query(
      `SELECT quantity FROM stock WHERE sku_id=$1 AND bin_id=$2 AND status='PACKED'`,
      [skuPacked.id, shipBin.id],
    );
    check(inShipBin[0]?.quantity === 2, 'Упакованное лежит в зоне отгрузки');

    const cancelPacked = await as(request(http).post(`/api/v1/orders/${packed.id}/cancel`)).send({
      reason: 'Клиент отказался до отгрузки',
    });
    check(cancelPacked.status === 201, 'Упакованный заказ отменён', `status=${cancelPacked.status}`);
    check(
      (await available(skuPacked.id, store1.id)) === 4,
      'Упакованное вскрыто и возвращено в исходную ячейку',
      `${await available(skuPacked.id, store1.id)}`,
    );

    const packedRow: Array<{ status: string; cancelled_at: string | null }> = await dataSource.query(
      `SELECT status, cancelled_at FROM packages WHERE id=$1`,
      [pkg.id],
    );
    check(
      packedRow[0].status === 'CANCELLED' && packedRow[0].cancelled_at !== null,
      'Упаковка помечена отменённой со временем',
      JSON.stringify(packedRow[0]),
    );
    const shipmentRow: Array<{ status: string; cancelled_at: string | null }> = await dataSource.query(
      `SELECT status, cancelled_at FROM shipments WHERE id=$1`,
      [shipment.id],
    );
    check(
      shipmentRow[0].status === 'CANCELLED' && shipmentRow[0].cancelled_at !== null,
      'Отправление отменено со временем',
      JSON.stringify(shipmentRow[0]),
    );
    const shipmentAudit: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM audit_events
        WHERE action='STATE_TRANSITION' AND entity_type='Shipment' AND entity_id=$1`,
      [shipment.id],
    );
    check(shipmentAudit[0].count === '1', 'Отмена отправления прошла через статусную машину и попала в аудит');

    // ---------- 5. Отмена посреди batch-сборки -------------------------------
    console.log('\n5. Отмена одного заказа из batch-задания');
    const batchA = await mkOrder([{ skuId: skuBatchA.id, quantity: 2 }]);
    const batchB = await mkOrder([{ skuId: skuBatchB.id, quantity: 2 }]);
    const batch = (
      await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [batchA.id, batchB.id] })
    ).body;
    await as(request(http).post(`/api/v1/picking/tasks/${batch.id}/assign`)).send({});
    await as(request(http).post(`/api/v1/picking/tasks/${batch.id}/scan`)).send({
      barcode: '3000000000048',
      quantity: 2,
    });

    await as(request(http).post(`/api/v1/orders/${batchA.id}/cancel`)).send({ reason: 'Отмена посреди сборки' });
    const linesAfter: Array<{ status: string }> = await dataSource.query(
      `SELECT status FROM pick_task_lines WHERE order_id=$1`,
      [batchA.id],
    );
    check(
      linesAfter.every((line) => line.status !== 'PENDING'),
      'Строки отменённого заказа больше не ждут сборщика',
      JSON.stringify(linesAfter.map((l) => l.status)),
    );
    check(
      (await available(skuBatchA.id, store1.id)) === 3,
      'Собранное по отменённому заказу вернулось на полку',
      `${await available(skuBatchA.id, store1.id)}`,
    );

    await as(request(http).post(`/api/v1/picking/tasks/${batch.id}/scan`)).send({
      barcode: '3000000000055',
      quantity: 2,
    });
    const batchDone = await as(request(http).post(`/api/v1/picking/tasks/${batch.id}/complete`)).send({});
    check(batchDone.status === 201, 'Задание завершается, несмотря на отменённый заказ внутри');
    const batchAState = await as(request(http).get(`/api/v1/orders/${batchA.id}`));
    const batchBState = await as(request(http).get(`/api/v1/orders/${batchB.id}`));
    check(
      batchAState.body.status === 'CANCELLED' && batchBState.body.status === 'PICKED',
      'Отменённый остался отменённым, соседний дошёл до PICKED',
      `${batchAState.body.status} / ${batchBState.body.status}`,
    );

    // ---------- 6. Отмена после передачи перевозчику -------------------------
    console.log('\n6. Отмена после передачи перевозчику');
    const shipped = await mkOrder([{ skuId: skuPacked.id, quantity: 1 }]);
    const shippedTask = (
      await as(request(http).post('/api/v1/picking/tasks')).send({ orderIds: [shipped.id] })
    ).body;
    await as(request(http).post(`/api/v1/picking/tasks/${shippedTask.id}/assign`)).send({});
    await as(request(http).post(`/api/v1/picking/tasks/${shippedTask.id}/scan`)).send({
      barcode: '3000000000031',
      quantity: 1,
    });
    await as(request(http).post(`/api/v1/picking/tasks/${shippedTask.id}/complete`)).send({});
    const pkg2 = (await as(request(http).post(`/api/v1/packing/orders/${shipped.id}/start`)).send({})).body;
    await as(request(http).post(`/api/v1/packing/orders/${shipped.id}/complete`)).send({ weightG: 500 });
    await as(request(http).post(`/api/v1/packing/packages/${pkg2.id}/label`)).send({});
    // Передачу перевозчику делает этап 1.7 — здесь достаточно поставить статус.
    await dataSource.query(
      `UPDATE shipments SET status='HANDED_OVER', handed_over_at=now() WHERE order_id=$1`,
      [shipped.id],
    );

    const tooLate = await as(request(http).post(`/api/v1/orders/${shipped.id}/cancel`)).send({
      reason: 'Поздно',
    });
    check(tooLate.status === 409, 'Отмена переданного перевозчику отбита → 409', `status=${tooLate.status}`);
    const stillReady = await as(request(http).get(`/api/v1/orders/${shipped.id}`));
    check(
      stillReady.body.status === 'READY_TO_SHIP',
      'Отказ не оставил заказ наполовину отменённым',
      stillReady.body.status,
    );

    // ---------- 7. Инварианты -------------------------------------------------
    console.log('\n7. Инварианты');
    const mismatch: Array<{ mismatches: string }> = await dataSource.query(`
      WITH ledger AS (
        SELECT sku_id, warehouse_id, to_bin_id AS bin_id, lot_id, to_status AS status, quantity AS qty
          FROM stock_movements WHERE to_bin_id IS NOT NULL
        UNION ALL
        SELECT sku_id, warehouse_id, from_bin_id, lot_id, from_status, -quantity
          FROM stock_movements WHERE from_bin_id IS NOT NULL
      ), agg AS (
        SELECT sku_id, warehouse_id, bin_id, lot_id, status, SUM(qty)::int AS qty
          FROM ledger GROUP BY 1,2,3,4,5
      )
      SELECT count(*)::text AS mismatches
        FROM agg FULL JOIN stock s
          ON s.sku_id = agg.sku_id AND s.warehouse_id = agg.warehouse_id
         AND s.bin_id = agg.bin_id AND s.lot_id IS NOT DISTINCT FROM agg.lot_id
         AND s.status = agg.status
       WHERE COALESCE(s.quantity, 0) <> COALESCE(agg.qty, 0)
    `);
    check(mismatch[0].mismatches === '0', 'Журнал сходится с остатком после всех отмен');

    const negative: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM stock WHERE quantity < 0`,
    );
    check(negative[0].count === '0', 'Отрицательных остатков не появилось');

    const orphans: Array<{ count: string }> = await dataSource.query(
      `SELECT count(*)::text AS count FROM reservations r
         JOIN orders o ON o.id = r.owner_id::uuid
        WHERE r.status='ACTIVE' AND o.status='CANCELLED'`,
    );
    check(orphans[0].count === '0', 'У отменённых заказов не осталось активных резервов');
  } catch (error) {
    fail++;
    console.error('\nФатальная ошибка теста:', error);
    // Упавший на старте прогон обязан быть КРАСНЫМ: без этого набор,
    // который не смог поднять базу, отчитывался «пройдено» и молча
    // пропускал все свои проверки.
    fail++;
  } finally {
    if (app) await app.close();
    try {
      await pg.stop();
    } catch {
      /* уже остановлен */
    }
  }

  console.log(`\ncancellation e2e: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
