import { join } from 'node:path';
import { MiddlewareConsumer, Module, type NestModule } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './application/auth/auth.module';
import { BillingModule } from './application/billing/billing.module';
import { AnalyticsModule } from './application/analytics/analytics.module';
import { AuditModule } from './infrastructure/logging/audit/audit.module';
import { ConfigStoreModule } from './application/config-store/config-store.module';
import { CronModule } from './application/cron/cron.module';
import { DashboardModule } from './application/dashboard/dashboard.module';
import { DepartmentsModule } from './application/departments/departments.module';
import { EventsModule } from './infrastructure/queues/events/events.module';
import { ExportModule } from './infrastructure/export/export.module';
import { FieldAclInterceptor } from './presentation/http/field-acl/field-acl.interceptor';
import { FieldAclModule } from './application/field-acl/field-acl.module';
import { FieldPermissionsModule } from './application/field-permissions/field-permissions.module';
import { FsmModule } from './application/fsm/fsm.module';
import { JwtAuthGuard } from './presentation/http/guards/jwt-auth.guard';
import { RolesGuard } from './presentation/http/guards/roles.guard';
import { IdempotencyInterceptor } from './presentation/http/idempotency.interceptor';
import { IdempotencyModule } from './infrastructure/idempotency/idempotency.module';
import { CorrelationIdMiddleware } from './presentation/http/middleware/correlation-id.middleware';
import { backgroundTimersSupported } from './infrastructure/runtime/runtime';
import { validateEnv } from './infrastructure/config/env.validation';
import { FF_ENTITIES } from './infrastructure/database/entities';
import { HealthModule } from './application/health/health.module';
import { InboundModule } from './application/inbound/inbound.module';
import { IntegrationModule } from './application/integration/integration.module';
import { InventoryModule } from './application/inventory/inventory.module';
import { MdmModule } from './application/mdm/mdm.module';
import { OrderCategoriesModule } from './application/order-categories/order-categories.module';
import { OrdersModule } from './application/orders/orders.module';
import { PackingModule } from './application/packing/packing.module';
import { PickingModule } from './application/picking/picking.module';
import { ReturnsModule } from './application/returns/returns.module';
import { UsersModule } from './application/users/users.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      validate: validateEnv,
      envFilePath: [join(__dirname, '..', '.env'), '.env'],
      // Тесты не читают локальный .env: набор переменных на машине разработчика
      // не должен влиять на результат прогона. Всё нужное e2e задаёт сам.
      ignoreEnvFile: process.env.NODE_ENV === 'test',
    }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres' as const,
        url: config.getOrThrow<string>('DATABASE_URL'),
        entities: FF_ENTITIES,
        migrations: [join(__dirname, 'infrastructure', 'database', 'migrations', '*.{ts,js}')],
        migrationsTableName: 'ff_migrations',
        // Схему меняют только миграции — ни synchronize, ни автопрогон на старте.
        synchronize: false,
        migrationsRun: false,
        logging: ['error'] as const,
        extra: {
          // На serverless инстансов много и живут они недолго: большой пул на
          // каждом исчерпает лимит соединений базы быстрее, чем принесёт пользу.
          // На долгоживущем процессе, наоборот, тесный пул станет узким местом.
          max: Number(config.get('DATABASE_POOL_MAX')) || (backgroundTimersSupported() ? 10 : 2),
        },
      }),
    }),
    JwtModule.registerAsync({
      global: true,
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.getOrThrow<string>('JWT_SECRET'),
        signOptions: { expiresIn: `${config.get<number>('JWT_TTL_HOURS') ?? 12}h` },
      }),
    }),
    EventEmitterModule.forRoot(),
    AuditModule,
    EventsModule,
    FsmModule,
    IdempotencyModule,
    ExportModule,
    FieldAclModule,
    ConfigStoreModule,
    AuthModule,
    UsersModule,
    DepartmentsModule,
    MdmModule,
    InventoryModule,
    InboundModule,
    OrderCategoriesModule,
    OrdersModule,
    PickingModule,
    PackingModule,
    IntegrationModule,
    ReturnsModule,
    BillingModule,
    AnalyticsModule,
    FieldPermissionsModule,
    DashboardModule,
    CronModule,
    HealthModule,
  ],
  providers: [
    // Порядок важен: сначала проверяем токен, потом роли.
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
    { provide: APP_INTERCEPTOR, useExisting: FieldAclInterceptor },
    { provide: APP_INTERCEPTOR, useExisting: IdempotencyInterceptor },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(CorrelationIdMiddleware).forRoutes('*');
  }
}
