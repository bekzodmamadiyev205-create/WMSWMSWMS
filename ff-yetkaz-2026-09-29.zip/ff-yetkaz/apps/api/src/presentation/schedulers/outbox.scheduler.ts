import { Injectable, Logger, type OnModuleDestroy, type OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { backgroundTimersReason, backgroundTimersSupported } from '../../infrastructure/runtime/runtime';
import { OutboxService } from '../../infrastructure/queues/outbox.service';

const TICK_MS = 10_000;

/**
 * Фоновый разбор очереди.
 *
 * В тестах выключен (`NODE_ENV=test`) и выключается флагом `FF_OUTBOX_DISABLED`:
 * иначе таймер стреляет посреди проверки и делает результат недетерминированным.
 * Планировщик намеренно примитивен — при переезде на несколько инстансов его
 * место займёт очередь, а `dispatch()` останется тем же (он уже безопасен для
 * параллельного запуска благодаря `FOR UPDATE SKIP LOCKED`).
 */
@Injectable()
export class OutboxScheduler implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(OutboxScheduler.name);
  private timer: NodeJS.Timeout | null = null;
  private running = false;

  constructor(
    private readonly outbox: OutboxService,
    private readonly config: ConfigService,
  ) {}

  onModuleInit(): void {
    const disabled =
      this.config.get<string>('NODE_ENV') === 'test' ||
      process.env.FF_OUTBOX_DISABLED === '1' ||
      !backgroundTimersSupported();
    if (disabled) {
      this.logger.log(`Фоновый разбор очереди выключен: ${backgroundTimersReason()}.`);
      return;
    }
    this.timer = setInterval(() => void this.tick(), TICK_MS);
    // Таймер не должен удерживать процесс живым при остановке сервиса.
    this.timer.unref();
  }

  onModuleDestroy(): void {
    if (this.timer) clearInterval(this.timer);
  }

  private async tick(): Promise<void> {
    // Пропуск такта вместо накопления параллельных проходов: медленный сосед
    // не должен превращаться в лавину одновременных попыток.
    if (this.running) return;
    this.running = true;
    try {
      const result = await this.outbox.dispatch();
      if (result.claimed > 0) {
        this.logger.log(
          `Очередь: взято ${result.claimed}, доставлено ${result.delivered}, ` +
            `повтор ${result.retried}, отказ ${result.failed}`,
        );
      }
    } catch (error) {
      this.logger.error(`Проход очереди не удался: ${(error as Error).message}`);
    } finally {
      this.running = false;
    }
  }
}
