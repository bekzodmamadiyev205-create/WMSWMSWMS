import { Injectable, Logger, type OnModuleDestroy, type OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { backgroundTimersReason, backgroundTimersSupported } from '../../infrastructure/runtime/runtime';
import { AccrualService } from '../../application/billing/accrual.service';

/** Час: срез идемпотентен (upsert), поэтому чаще незачем, а реже — рискованно. */
const TICK_MS = 60 * 60 * 1000;

/**
 * Ежедневный срез хранения.
 *
 * Без него тариф за хранение не начисляется вовсе — и это не падает, а тихо
 * недосчитывает деньги. Восстановить пропущенный день нельзя: остаток —
 * величина мгновенная, вчерашнего объёма в базе уже нет. Поэтому срез снимается
 * фоном, а пропуски видны отдельной плиткой в сводке склада.
 *
 * Почему час, а не «раз в сутки в 03:00»: перезапуск сервиса не должен приводить
 * к потере дня, а `ON CONFLICT DO UPDATE` делает повторный съём безопасным —
 * он просто уточняет цифру за сегодня.
 */
@Injectable()
export class StorageScheduler implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(StorageScheduler.name);
  private timer: NodeJS.Timeout | null = null;
  private running = false;

  constructor(
    private readonly accrual: AccrualService,
    private readonly config: ConfigService,
  ) {}

  onModuleInit(): void {
    const disabled =
      this.config.get<string>('NODE_ENV') === 'test' ||
      process.env.FF_STORAGE_SNAPSHOT_DISABLED === '1' ||
      !backgroundTimersSupported();
    if (disabled) {
      this.logger.log(`Фоновый съём среза хранения выключен: ${backgroundTimersReason()}.`);
      return;
    }
    // Первый съём — сразу: сервис мог простоять и пропустить сегодняшний день.
    void this.tick();
    this.timer = setInterval(() => void this.tick(), TICK_MS);
    this.timer.unref();
  }

  onModuleDestroy(): void {
    if (this.timer) clearInterval(this.timer);
  }

  private async tick(): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      const today = new Date().toISOString().slice(0, 10);
      const result = await this.accrual.snapshotStorage(today);
      this.logger.debug(`Срез хранения за ${result.date}: селлеров ${result.sellers}`);
    } catch (error) {
      this.logger.error(`Срез хранения не снят: ${(error as Error).message}`);
    } finally {
      this.running = false;
    }
  }
}
