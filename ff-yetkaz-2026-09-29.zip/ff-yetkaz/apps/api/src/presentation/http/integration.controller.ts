import { Controller, Get, Param, Post, Query, Req } from '@nestjs/common';
import type {
  OutboxDispatchResultDto,
  OutboxMessageDto,
  OutboxStatus,
  ShipmentStatusEventDto,
  WebhookAckDto,
} from '@ff/shared';
import { Public, Roles } from './decorators';
import type { FfRequest } from './types/request';
import { CarrierWebhookService } from '../../application/integration/carrier-webhook.service';
import { OutboxService } from '../../infrastructure/queues/outbox.service';
import { DELIVERY_HEADER, SIGNATURE_HEADER } from '../../infrastructure/integrations/carrier/signature';

@Controller('integration')
export class IntegrationController {
  constructor(
    private readonly outbox: OutboxService,
    private readonly webhooks: CarrierWebhookService,
  ) {}

  /**
   * Входящий вебхук перевозчика.
   *
   * `@Public` — но не «без авторизации»: аутентификация здесь другая, по
   * HMAC-подписи тела. JWT у перевозчика нет и быть не должно.
   */
  @Public()
  @Post('carriers/:code/webhook')
  webhook(@Param('code') code: string, @Req() request: FfRequest): Promise<WebhookAckDto> {
    return this.webhooks.handle({
      carrierCode: code.toUpperCase(),
      rawBody: request.rawBody ?? Buffer.alloc(0),
      signature: request.headers[SIGNATURE_HEADER] as string | undefined,
      deliveryId: request.headers[DELIVERY_HEADER] as string | undefined,
      correlationId: request.correlationId ?? null,
    });
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Get('outbox')
  list(@Query('status') status?: OutboxStatus): Promise<OutboxMessageDto[]> {
    return this.outbox.list(status);
  }

  /**
   * Ручной прогон очереди. Нужен эксплуатации (разобрать затор после аварии
   * соседа) и тестам — фоновый таймер в тестовом окружении выключен.
   */
  @Roles('ADMIN')
  @Post('outbox/dispatch')
  dispatch(): Promise<OutboxDispatchResultDto> {
    return this.outbox.dispatch();
  }

  @Roles('ADMIN')
  @Post('outbox/:id/retry')
  retry(@Param('id') id: string): Promise<OutboxMessageDto | null> {
    return this.outbox.retry(id);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PACKER')
  @Get('shipments/:id/history')
  history(@Param('id') id: string): Promise<ShipmentStatusEventDto[]> {
    return this.webhooks.history(id);
  }
}
