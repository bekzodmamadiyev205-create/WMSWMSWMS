import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { Role } from '@ff/shared';
import { ROLES_KEY } from '../decorators';
import type { FfRequest } from '../types/request';

/**
 * Отрабатывает после JwtAuthGuard. Ручка без @Roles доступна любому
 * авторизованному пользователю; список ролей сужает доступ.
 */
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!required || required.length === 0) return true;

    const user = context.switchToHttp().getRequest<FfRequest>().user;
    if (!user) throw new UnauthorizedException('Требуется авторизация.');

    if (!user.roles.some((role) => required.includes(role))) {
      throw new ForbiddenException(`Недостаточно прав. Нужна одна из ролей: ${required.join(', ')}.`);
    }
    return true;
  }
}
