import { timingSafeEqual } from 'node:crypto';
import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import type { FfRequest } from '../types/request';

/**
 * Системный актор фоновых задач. Ролей нет: cron не «кто-то из сотрудников»,
 * и в аудите он должен быть отличим от человека.
 */
export const CRON_PRINCIPAL = {
  id: '00000000-0000-0000-0000-000000000001',
  email: 'system:cron',
  roles: [] as never[],
  sellerId: null,
};

/**
 * Аутентификация планировщика по общему секрету.
 *
 * Vercel Cron ходит обычным HTTP-запросом и подставляет
 * `Authorization: Bearer <CRON_SECRET>` из переменной окружения проекта. JWT у
 * него взяться неоткуда, поэтому для фоновых ручек — отдельный вход.
 *
 * Секрет читается из `FF_CRON_SECRET`, иначе из `CRON_SECRET` (имя, которое
 * подставляет сама платформа). Не задан — ручка закрыта совсем: открытый
 * планировщик означает, что очередь и биллинг может дёрнуть кто угодно.
 */
@Injectable()
export class CronGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const secret = process.env.FF_CRON_SECRET || process.env.CRON_SECRET;
    if (!secret) {
      throw new UnauthorizedException('Планировщик не настроен.');
    }

    const request = context.switchToHttp().getRequest<FfRequest>();
    const [scheme, token] = (request.headers.authorization ?? '').split(' ');
    if (scheme?.toLowerCase() !== 'bearer' || !token) {
      throw new UnauthorizedException('Требуется секрет планировщика.');
    }

    const provided = Buffer.from(token);
    const expected = Buffer.from(secret);
    // Сравнение постоянного времени: посимвольная утечка позволяет подобрать
    // секрет за десятки запросов.
    if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) {
      throw new UnauthorizedException('Секрет планировщика не принят.');
    }

    request.user = CRON_PRINCIPAL;
    return true;
  }
}
