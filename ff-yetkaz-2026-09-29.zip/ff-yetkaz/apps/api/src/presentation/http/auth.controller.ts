import { Body, Controller, Get, HttpCode, HttpStatus, Post, Req } from '@nestjs/common';
import type { AuthPrincipal, AuthUser, LoginResponse } from '@ff/shared';
import { CurrentUser, Public } from './decorators';
import type { FfRequest } from './types/request';
import { AuthService } from '../../application/auth/auth.service';
import { LoginDto } from './dto/auth/login.dto';

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Public()
  @Post('login')
  @HttpCode(HttpStatus.OK)
  login(@Body() dto: LoginDto, @Req() request: FfRequest): Promise<LoginResponse> {
    return this.auth.login(dto, { ip: request.ip, correlationId: request.correlationId });
  }

  @Get('me')
  me(@CurrentUser() user: AuthPrincipal): Promise<AuthUser> {
    return this.auth.profile(user.id);
  }
}
