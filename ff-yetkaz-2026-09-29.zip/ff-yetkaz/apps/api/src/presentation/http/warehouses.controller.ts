import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import { STAFF_ROLES, type BinLocationDto, type WarehouseDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import { BinLocationsService } from '../../application/mdm/bin-locations.service';
import { CreateWarehouseDto, UpdateWarehouseDto } from './dto/mdm/warehouse.dto';
import { WarehousesService } from '../../application/mdm/warehouses.service';

// Склады — внутренняя инфраструктура оператора, селлеру не показываем.
@Roles(...STAFF_ROLES)
@Controller('warehouses')
export class WarehousesController {
  constructor(
    private readonly warehouses: WarehousesService,
    private readonly bins: BinLocationsService,
  ) {}

  @Get()
  list(): Promise<WarehouseDto[]> {
    return this.warehouses.list();
  }

  @Get(':id')
  get(@Param('id', ParseUUIDPipe) id: string): Promise<WarehouseDto> {
    return this.warehouses.get(id);
  }

  /** Ячейки склада в порядке обхода при сборке (сортировка по коду). */
  @Get(':id/bins')
  bins_(@Param('id', ParseUUIDPipe) id: string): Promise<BinLocationDto[]> {
    return this.bins.listByWarehouse(id);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post()
  create(@Body() dto: CreateWarehouseDto, @Actor() actor: ActorContext): Promise<WarehouseDto> {
    return this.warehouses.create(dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateWarehouseDto,
    @Actor() actor: ActorContext,
  ): Promise<WarehouseDto> {
    return this.warehouses.update(id, dto, actor);
  }
}
