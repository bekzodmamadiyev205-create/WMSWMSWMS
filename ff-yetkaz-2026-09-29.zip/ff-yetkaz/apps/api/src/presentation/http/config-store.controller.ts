import { Body, Controller, Get, Param, Put } from '@nestjs/common';
import type { AppSettingDto, CarrierDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import { CarriersService } from '../../infrastructure/config-store/carriers.service';
import { UpdateCarrierDto, UpdateSettingDto } from './dto/config-store/config.dto';
import { SettingsService } from '../../infrastructure/config-store/settings.service';

/**
 * Конфигурация системы. Читать может любой сотрудник — значения влияют на его
 * работу (тот же допуск по весу); менять — только ADMIN.
 */
@Controller()
export class ConfigStoreController {
  constructor(
    private readonly settings: SettingsService,
    private readonly carriers: CarriersService,
  ) {}

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER', 'PACKER', 'FINANCE')
  @Get('settings')
  listSettings(): Promise<AppSettingDto[]> {
    return this.settings.list();
  }

  @Roles('ADMIN')
  @Put('settings/:key')
  updateSetting(
    @Param('key') key: string,
    @Body() dto: UpdateSettingDto,
    @Actor() actor: ActorContext,
  ): Promise<AppSettingDto> {
    return this.settings.update(key, dto.value, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Get('carriers')
  listCarriers(): Promise<CarrierDto[]> {
    return this.carriers.list();
  }

  @Roles('ADMIN')
  @Put('carriers/:code')
  updateCarrier(
    @Param('code') code: string,
    @Body() dto: UpdateCarrierDto,
    @Actor() actor: ActorContext,
  ): Promise<CarrierDto> {
    return this.carriers.update(code, dto, actor);
  }
}
