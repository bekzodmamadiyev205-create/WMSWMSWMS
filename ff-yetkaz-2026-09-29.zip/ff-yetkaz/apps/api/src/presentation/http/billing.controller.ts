import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
  Res,
} from '@nestjs/common';
import type { Response } from 'express';
import type {
  AccrualResultDto,
  CodReconciliationDto,
  InvoiceDto,
  LedgerBalanceRowDto,
  TariffPlanDto,
  TariffRuleDto,
} from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import { AccrualService } from '../../application/billing/accrual.service';
import {
  AccrueDto,
  AssignPlanDto,
  BuildInvoiceDto,
  CreateTariffPlanDto,
  CreateTariffRuleDto,
  PackingNormsDto,
  PeriodQuery,
  SnapshotDto,
  UpdateTariffPlanDto,
  UpdateTariffRuleDto,
} from './dto/billing/billing.dto';
import { renderInvoicePdf, renderInvoiceXlsx } from '../../application/billing/invoice.renderer';
import { InvoicesService } from '../../application/billing/invoices.service';
import { LedgerService } from '../../application/billing/ledger.service';
import { TariffsService, type PackingNormsResult } from '../../application/billing/tariffs.service';

@Controller('billing')
export class BillingController {
  constructor(
    private readonly tariffs: TariffsService,
    private readonly accrual: AccrualService,
    private readonly invoices: InvoicesService,
    private readonly ledger: LedgerService,
  ) {}

  // ------------------------------------------------------------- тарифы

  @Roles('ADMIN', 'FINANCE')
  @Get('tariff-plans')
  listPlans(): Promise<TariffPlanDto[]> {
    return this.tariffs.listPlans();
  }

  @Roles('ADMIN', 'FINANCE')
  @Post('tariff-plans')
  createPlan(
    @Body() dto: CreateTariffPlanDto,
    @Actor() actor: ActorContext,
  ): Promise<TariffPlanDto> {
    return this.tariffs.createPlan(dto, actor);
  }

  @Roles('ADMIN', 'FINANCE')
  @Patch('tariff-plans/:id')
  updatePlan(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateTariffPlanDto,
    @Actor() actor: ActorContext,
  ): Promise<TariffPlanDto> {
    return this.tariffs.updatePlan(id, dto, actor);
  }

  @Roles('ADMIN', 'FINANCE')
  @Post('tariff-plans/:id/rules')
  addRule(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: CreateTariffRuleDto,
    @Actor() actor: ActorContext,
  ): Promise<TariffRuleDto> {
    return this.tariffs.addRule(id, dto, actor);
  }

  @Roles('ADMIN', 'FINANCE')
  @Patch('tariff-rules/:id')
  updateRule(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateTariffRuleDto,
    @Actor() actor: ActorContext,
  ): Promise<TariffRuleDto> {
    return this.tariffs.updateRule(id, dto, actor);
  }

  /** 204: удалять нечего возвращать, а тело с `null` клиент разбирать не должен. */
  @Roles('ADMIN', 'FINANCE')
  @Delete('tariff-rules/:id')
  @HttpCode(204)
  deleteRule(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<void> {
    return this.tariffs.deleteRule(id, actor);
  }

  /**
   * Нормы упаковки товара живут здесь, а не в каталоге: они существуют ради
   * цены — только тарифы `PER_BOX`/`PER_PALLET` превращают штуки в тару.
   * Кладовщику норма тоже нужна, поэтому он в списке ролей.
   */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'FINANCE')
  @Patch('skus/:id/packing-norms')
  setPackingNorms(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: PackingNormsDto,
    @Actor() actor: ActorContext,
  ): Promise<PackingNormsResult> {
    return this.tariffs.setPackingNorms(id, dto, actor);
  }

  @Roles('ADMIN', 'FINANCE')
  @Post('sellers/:id/tariff-plan')
  assignPlan(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: AssignPlanDto,
    @Actor() actor: ActorContext,
  ): Promise<void> {
    return this.tariffs.assignPlan(id, dto.planId ?? null, actor);
  }

  // --------------------------------------------------------- начисления

  /**
   * Срез хранения на дату. Считается по остатку «здесь и сейчас», поэтому
   * запускается ежедневно — задним числом объём восстановить нельзя.
   */
  @Roles('ADMIN', 'FINANCE')
  @Post('storage-snapshots')
  snapshot(@Body() dto: SnapshotDto): Promise<{ date: string; sellers: number }> {
    return this.accrual.snapshotStorage(dto.date ?? new Date().toISOString().slice(0, 10));
  }

  @Roles('ADMIN', 'FINANCE')
  @Post('accrue')
  accrue(@Body() dto: AccrueDto, @Actor() actor: ActorContext): Promise<AccrualResultDto> {
    return this.accrual.accrue(dto.from, dto.to, actor);
  }

  @Roles('ADMIN', 'FINANCE')
  @Get('problems')
  problems(): Promise<Array<Record<string, unknown>>> {
    return this.accrual.problems();
  }

  @Roles('ADMIN', 'FINANCE')
  @Get('ledger/balances')
  balances(@Query('sellerId') sellerId?: string): Promise<LedgerBalanceRowDto[]> {
    return this.ledger.balances(sellerId);
  }

  // -------------------------------------------------------------- счета

  @Roles('ADMIN', 'FINANCE')
  @Post('invoices')
  build(@Body() dto: BuildInvoiceDto, @Actor() actor: ActorContext): Promise<InvoiceDto> {
    return this.invoices.build(dto.sellerId, dto.periodStart, dto.periodEnd, actor);
  }

  @Roles('ADMIN', 'FINANCE')
  @Post('invoices/:id/issue')
  issue(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<InvoiceDto> {
    return this.invoices.issue(id, actor);
  }

  /**
   * Счета — деньги, а не складская операция.
   *
   * Без `@Roles` сюда попадал ЛЮБОЙ сотрудник: сборщик, от которого суммы COD
   * специально прячут в заказах (`field_permissions`), получал их же построчно
   * и сразу по всем селлерам. Селлер в списке ролей нужен — свой счёт он
   * смотрит сам, а скоуп в сервисе сузит выборку до его собственных.
   */
  @Roles('ADMIN', 'FINANCE', 'SELLER')
  @Get('invoices')
  list(@Actor() actor: ActorContext, @Query('sellerId') sellerId?: string): Promise<InvoiceDto[]> {
    return this.invoices.list(actor, sellerId);
  }

  @Roles('ADMIN', 'FINANCE', 'SELLER')
  @Get('invoices/:id')
  get(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<InvoiceDto> {
    return this.invoices.get(id, actor);
  }

  @Roles('ADMIN', 'FINANCE', 'SELLER')
  @Get('invoices/:id/pdf')
  async pdf(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
    @Res() response: Response,
  ): Promise<void> {
    const invoice = await this.invoices.get(id, actor);
    const file = await renderInvoicePdf(invoice);
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader('Content-Disposition', `inline; filename="${invoice.number}.pdf"`);
    response.setHeader('Content-Length', file.length);
    response.end(file);
  }

  @Roles('ADMIN', 'FINANCE', 'SELLER')
  @Get('invoices/:id/xlsx')
  async xlsx(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
    @Res() response: Response,
  ): Promise<void> {
    const invoice = await this.invoices.get(id, actor);
    const file = await renderInvoiceXlsx(invoice);
    response.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    response.setHeader('Content-Disposition', `attachment; filename="${invoice.number}.xlsx"`);
    response.setHeader('Content-Length', file.length);
    response.end(file);
  }

  /** Сверка COD — внутренняя финансовая работа: суммы по всем отправлениям сразу. */
  @Roles('ADMIN', 'FINANCE')
  @Get('cod-reconciliation')
  reconcile(
    @Query() query: PeriodQuery,
    @Actor() actor: ActorContext,
  ): Promise<CodReconciliationDto> {
    return this.invoices.reconcileCod(query.from, query.to, actor);
  }
}
