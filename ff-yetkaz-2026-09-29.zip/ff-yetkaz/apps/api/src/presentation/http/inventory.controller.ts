import { Body, Controller, Get, HttpCode, HttpStatus, Post, Query, Res } from '@nestjs/common';
import type { Response } from 'express';
import type {
  PageDto,
  ReserveResultDto,
  StockMovementDto,
  StockSummaryDto,
  StockTableRowDto,
  StockTableTotalsDto,
} from '@ff/shared';
import { Actor, Roles } from './decorators';
import { AclEntity } from './field-acl/acl-entity.decorator';
import type { ActorContext } from '../../domain/types/actor';
import {
  AdjustStockDto,
  MoveStockDto,
  MovementsQuery,
  ReleaseDto,
  ReserveDto,
  StockInDto,
  StockQuery,
  StockTableQueryDto,
} from './dto/inventory/inventory.dto';
import { InventoryService } from '../../application/inventory/inventory.service';
import { StockTableService } from '../../application/inventory/stock-table.service';

@Controller('inventory')
export class InventoryController {
  constructor(
    private readonly inventory: InventoryService,
    private readonly stockTable: StockTableService,
  ) {}

  /**
   * Остатки по SKU × склад в разрезе статусов. Селлер видит только свои SKU.
   *
   * Метка та же, что у табличной ручки, и это не дублирование: без неё
   * администратор закрывал поле, витрина `stock/table` его прятала, а соседний
   * свод по тому же остатку продолжал отдавать — обход прав на один запрос.
   * Общих с матрицей ключей у свода меньше (`skuCode`, `skuName`, `available`,
   * `bins`), но вырезаются они здесь по тем же правилам.
   */
  @AclEntity('stock')
  @Get('stock')
  stock(@Query() query: StockQuery, @Actor() actor: ActorContext): Promise<StockSummaryDto[]> {
    return this.inventory.summary(query, actor);
  }

  /**
   * Витрина остатков: постранично, строка = SKU × склад × статус.
   *
   * Литеральные маршруты объявлены ДО любых ':param' — иначе `stock/table`
   * попал бы в обработчик вида `stock/:id` и вернул бы 404 вместо таблицы.
   */
  @AclEntity('stock')
  @Get('stock/table')
  stockTableRows(
    @Query() query: StockTableQueryDto,
    @Actor() actor: ActorContext,
  ): Promise<PageDto<StockTableRowDto>> {
    return this.stockTable.table(query, actor);
  }

  /** Итоги по всему фильтру (а не по странице) — отдельной ручкой. */
  @AclEntity('stock')
  @Get('stock/table/totals')
  stockTableTotals(
    @Query() query: StockTableQueryDto,
    @Actor() actor: ActorContext,
  ): Promise<StockTableTotalsDto> {
    return this.stockTable.totals(query, actor);
  }

  /** Та же выборка в xlsx. Фильтры ровно те же — в этом весь смысл выгрузки. */
  @Get('stock/export')
  async stockExport(
    @Query() query: StockTableQueryDto,
    @Actor() actor: ActorContext,
    @Res({ passthrough: false }) response: Response,
  ): Promise<void> {
    await this.stockTable.export(query, actor, response);
  }

  /** Журнал движений — ответ на вопрос «откуда взялось это количество». */
  @Get('movements')
  movements(
    @Query() query: MovementsQuery,
    @Actor() actor: ActorContext,
  ): Promise<StockMovementDto[]> {
    return this.inventory.movements(query, actor);
  }

  // Приход. В этапе 1.2 эту же операцию будет вызывать приёмка по ASN.
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post('stock-in')
  stockIn(@Body() dto: StockInDto, @Actor() actor: ActorContext): Promise<StockSummaryDto> {
    return this.inventory.stockIn(dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post('moves')
  move(@Body() dto: MoveStockDto, @Actor() actor: ActorContext): Promise<StockSummaryDto> {
    return this.inventory.move(dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post('adjustments')
  adjust(@Body() dto: AdjustStockDto, @Actor() actor: ActorContext): Promise<StockSummaryDto> {
    return this.inventory.adjust(dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post('reservations')
  reserve(@Body() dto: ReserveDto, @Actor() actor: ActorContext): Promise<ReserveResultDto> {
    return this.inventory.reserve(dto, actor);
  }

  // POST, а не DELETE: снятие резерва принимает тело с владельцем и причиной.
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post('reservations/release')
  @HttpCode(HttpStatus.OK)
  release(@Body() dto: ReleaseDto, @Actor() actor: ActorContext): Promise<{ released: number }> {
    return this.inventory.release(dto, actor);
  }
}
