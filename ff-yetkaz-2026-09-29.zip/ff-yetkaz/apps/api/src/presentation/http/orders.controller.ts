import {
  Body,
  Controller,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
  Res,
} from '@nestjs/common';
import type { Response } from 'express';
import type {
  OrderDto,
  OrderImportResultDto,
  OrderIntakeResultDto,
  OrderListTotalsDto,
  OrderTrackDto,
  PageDto,
} from '@ff/shared';
import { Actor, Roles } from './decorators';
import { AclEntity } from './field-acl/acl-entity.decorator';
import type { ActorContext } from '../../domain/types/actor';
import {
  CancelOrderDto,
  CreateOrderDto,
  ImportOrdersDto,
  OrderByCodeQueryDto,
  OrderListQueryDto,
  UpdateOrderDto,
} from './dto/orders/orders.dto';
import { OrderImportService } from '../../application/orders/order-import.service';
import { OrdersService } from '../../application/orders/orders.service';

// Матрица прав на колонки применяется ко всему, что отдаёт заказ.
@AclEntity('order')
@Controller('orders')
export class OrdersController {
  constructor(
    private readonly orders: OrdersService,
    private readonly ordersImport: OrderImportService,
  ) {}

  /**
   * Список заказов страницами. Ответ — конверт `PageDto`, а не голый массив:
   * без общего числа строк список невозможно листать честно.
   */
  @Get()
  list(
    @Query() query: OrderListQueryDto,
    @Actor() actor: ActorContext,
  ): Promise<PageDto<OrderDto>> {
    return this.orders.list(query, actor);
  }

  /**
   * Найти заказ по коду: наш FF-код, номер клиента или номер отправления.
   *
   * Параметр разбирается DTO, а не берётся из `@Query('code')` сырым: сканер
   * шлёт что угодно, и массив либо объект в `code` обязан получить внятное 400,
   * а не пятисотку на первом же `.trim()`.
   */
  @Get('by-code')
  byCode(@Query() query: OrderByCodeQueryDto, @Actor() actor: ActorContext): Promise<OrderDto> {
    return this.orders.getByCode(query.code, actor);
  }

  /** Счётчики по статусам для ТЕКУЩЕГО фильтра — колонки канбана. */
  @Get('totals')
  totals(
    @Query() query: OrderListQueryDto,
    @Actor() actor: ActorContext,
  ): Promise<OrderListTotalsDto> {
    return this.orders.totals(query, actor);
  }

  /** Выгрузка в Excel потоком, фильтры те же, что и у списка. */
  @Get('export')
  async export(
    @Query() query: OrderListQueryDto,
    @Actor() actor: ActorContext,
    @Res({ passthrough: false }) response: Response,
  ): Promise<void> {
    await this.orders.export(query, actor, response);
  }

  // ВНИМАНИЕ: литеральные пути объявлены ВЫШЕ ':id'. Nest сопоставляет маршруты
  // в порядке объявления, и ':id' поглотил бы и by-code, и totals, и export.
  @Get(':id')
  get(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<OrderDto> {
    return this.orders.get(id, actor);
  }

  /** Трек статусов заказа: append-only журнал переходов. */
  @Get(':id/track')
  track(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<OrderTrackDto> {
    return this.orders.track(id, actor);
  }

  /**
   * Order Gateway — приём заказа из внешнего канала.
   * Повтор защищён и заголовком Idempotency-Key, и естественным ключом канала.
   */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @AclEntity('order', { path: 'order' })
  @Post()
  intake(@Body() dto: CreateOrderDto, @Actor() actor: ActorContext): Promise<OrderIntakeResultDto> {
    return this.orders.intake(dto, actor);
  }

  /**
   * Загрузка заказов файлом. Позиции приходят артикулами селлера — внутренних
   * идентификаторов FF в выгрузке клиента нет, сопоставляет их сервер.
   */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post('import')
  importOrders(
    @Body() dto: ImportOrdersDto,
    @Actor() actor: ActorContext,
  ): Promise<OrderImportResultDto> {
    return this.ordersImport.import(dto, actor);
  }

  /** Повторная попытка резерва — после того как товар приехал. */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post(':id/reserve')
  @AclEntity('order', { path: 'order' })
  reserve(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<OrderIntakeResultDto> {
    return this.orders.reserve(id, actor);
  }

  /**
   * «Расходный»: коробка выдана со склада. Упаковщику это разрешено — выдаёт
   * тот же человек, кто закрывал коробку, и отдельного «выдающего» на складе нет.
   */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PACKER')
  @Post(':id/dispatch')
  dispatch(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<OrderDto> {
    return this.orders.dispatch(id, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post(':id/cancel')
  cancel(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: CancelOrderDto,
    @Actor() actor: ActorContext,
  ): Promise<OrderDto> {
    return this.orders.cancel(id, dto, actor);
  }

  /** Правка карточки: категория, регион, получатель, телефон, адрес, вес. */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateOrderDto,
    @Actor() actor: ActorContext,
  ): Promise<OrderDto> {
    return this.orders.update(id, dto, actor);
  }
}
