import { Controller, Get } from '@nestjs/common';
import { HealthService } from '../../application/health/health.service';
import { Public } from './decorators';

@Controller('health')
export class HealthController {
  constructor(private readonly health: HealthService) {}

  @Public()
  @Get()
  check(): Promise<{ status: 'ok'; db: 'up'; time: string }> {
    return this.health.check();
  }
}
