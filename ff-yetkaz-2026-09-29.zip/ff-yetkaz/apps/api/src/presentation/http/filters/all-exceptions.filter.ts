import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import type { Response } from 'express';
import { InvalidTransitionError } from '@ff/shared';
import type { FfRequest } from '../types/request';

export interface FfErrorBody {
  error: string;
  message: string;
  /**
   * Машинный код причины (см. `coded-exception.ts`). Необязателен: подавляющее
   * большинство ошибок клиенту достаточно показать текстом, код появляется там,
   * где по нему строится развилка в интерфейсе.
   */
  code?: string;
  details?: unknown;
  correlationId: string | null;
}

/**
 * Единый конверт ошибки для всего API: `{ error, message, details, correlationId }`.
 * Nest по умолчанию отдаёт для HttpException `{statusCode, message, error}`, а для
 * доменных исключений — стектрейс в 500; разнобой заставляет клиента разбирать
 * два формата, поэтому нормализуем здесь.
 */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger(AllExceptionsFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<FfRequest>();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let error = 'INTERNAL_ERROR';
    let message = 'Внутренняя ошибка сервера.';
    let details: unknown;
    let code: string | undefined;

    if (exception instanceof InvalidTransitionError) {
      status = HttpStatus.CONFLICT;
      error = 'INVALID_TRANSITION';
      message = exception.message;
      details = {
        machine: exception.machine,
        from: exception.from,
        to: exception.to,
        allowed: exception.allowed,
      };
    } else if (exception instanceof HttpException) {
      status = exception.getStatus();
      const payload = exception.getResponse();
      error = HttpStatus[status] ?? 'HTTP_ERROR';
      if (typeof payload === 'string') {
        message = payload;
      } else if (payload && typeof payload === 'object') {
        const body = payload as { message?: unknown; error?: unknown; code?: unknown };
        if (Array.isArray(body.message)) {
          // Ошибки ValidationPipe приходят массивом строк.
          message = 'Некорректные данные запроса.';
          details = body.message;
        } else if (typeof body.message === 'string') {
          message = body.message;
        }
        if (typeof body.error === 'string') error = body.error;
        if (typeof body.code === 'string') code = body.code;
      }
    } else {
      this.logger.error(
        `Необработанное исключение на ${request.method} ${request.url}`,
        exception instanceof Error ? exception.stack : String(exception),
      );
    }

    const body: FfErrorBody = {
      error,
      message,
      correlationId: request.correlationId ?? null,
    };
    if (code !== undefined) body.code = code;
    if (details !== undefined) body.details = details;

    response.status(status).json(body);
  }
}
