import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Query } from '@nestjs/common';
import type { PickScanResultDto, PickTaskDto, ShortPickResultDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import {
  AssignPickTaskDto,
  CreatePickTaskDto,
  ListPickTasksQuery,
  ManualPickDto,
  PickScanDto,
  ShortPickDto,
} from './dto/picking/picking.dto';
import { PickingService } from '../../application/picking/picking.service';

@Controller('picking/tasks')
export class PickingController {
  constructor(private readonly picking: PickingService) {}

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER')
  @Get()
  list(@Query() query: ListPickTasksQuery, @Actor() actor: ActorContext): Promise<PickTaskDto[]> {
    return this.picking.list(query, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER')
  @Get(':id')
  get(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<PickTaskDto> {
    return this.picking.get(id, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post()
  create(@Body() dto: CreatePickTaskDto, @Actor() actor: ActorContext): Promise<PickTaskDto> {
    return this.picking.createTask(dto, actor);
  }

  /** Без userId сборщик берёт задание на себя. */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER')
  @Post(':id/assign')
  assign(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: AssignPickTaskDto,
    @Actor() actor: ActorContext,
  ): Promise<PickTaskDto> {
    return this.picking.assign(id, dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER')
  @Post(':id/scan')
  scan(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: PickScanDto,
    @Actor() actor: ActorContext,
  ): Promise<PickScanResultDto> {
    return this.picking.scan(id, dto, actor);
  }

  /** Отбор без скана: товар в руках, штрихкода нет — строка задания и есть разрешение. */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER')
  @Post(':id/lines/:lineId/pick')
  pick(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('lineId', ParseUUIDPipe) lineId: string,
    @Body() dto: ManualPickDto,
    @Actor() actor: ActorContext,
  ): Promise<PickScanResultDto> {
    return this.picking.pickManual(id, lineId, dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER')
  @Post(':id/lines/:lineId/short')
  short(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('lineId', ParseUUIDPipe) lineId: string,
    @Body() dto: ShortPickDto,
    @Actor() actor: ActorContext,
  ): Promise<ShortPickResultDto> {
    return this.picking.short(id, lineId, dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER')
  @Post(':id/complete')
  complete(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<PickTaskDto> {
    return this.picking.complete(id, actor);
  }
}
