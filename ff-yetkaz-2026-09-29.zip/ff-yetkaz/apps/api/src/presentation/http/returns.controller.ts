import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Query, Res } from '@nestjs/common';
import type { Response } from 'express';
import type { PageDto, ReturnDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import { AclEntity } from './field-acl/acl-entity.decorator';
import type { ActorContext } from '../../domain/types/actor';
import {
  CancelReturnDto,
  CreateReturnDto,
  MoveReturnDto,
  ReturnListQueryDto,
  StoreReturnDto,
} from './dto/returns/returns.dto';
import { ReturnsService } from '../../application/returns/returns.service';

@AclEntity('return')
@Controller('returns')
export class ReturnsController {
  constructor(private readonly returns: ReturnsService) {}

  // --- Чтение: без @Roles. Селлер обязан видеть свои возвраты, а сужение
  //     делает скоуп по seller_id, а не гвард по роли. -----------------------

  @Get()
  list(
    @Query() query: ReturnListQueryDto,
    @Actor() actor: ActorContext,
  ): Promise<PageDto<ReturnDto>> {
    return this.returns.list(query, actor);
  }

  /**
   * Объявлен ДО `:id` намеренно: иначе параметрический роут перехватит
   * `/returns/export` и вернёт 400 на «export не является UUID».
   *
   * Фильтры те же, что у списка: выгрузка, которая не совпадает с экраном,
   * бесполезна для сверки.
   */
  @Get('export')
  async export(
    @Query() query: ReturnListQueryDto,
    @Actor() actor: ActorContext,
    @Res({ passthrough: false }) response: Response,
  ): Promise<void> {
    await this.returns.export(query, actor, response);
  }

  @Get(':id')
  get(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<ReturnDto> {
    return this.returns.get(id, actor);
  }

  // --- Приём и обработка: склад ---------------------------------------------

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post()
  create(@Body() dto: CreateReturnDto, @Actor() actor: ActorContext): Promise<ReturnDto> {
    return this.returns.create(dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post(':id/store')
  store(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: StoreReturnDto,
    @Actor() actor: ActorContext,
  ): Promise<ReturnDto> {
    return this.returns.store(id, dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post(':id/move')
  move(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: MoveReturnDto,
    @Actor() actor: ActorContext,
  ): Promise<ReturnDto> {
    return this.returns.move(id, dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post(':id/complete')
  complete(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<ReturnDto> {
    return this.returns.complete(id, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post(':id/cancel')
  cancel(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: CancelReturnDto,
    @Actor() actor: ActorContext,
  ): Promise<ReturnDto> {
    return this.returns.cancel(id, dto, actor);
  }
}
