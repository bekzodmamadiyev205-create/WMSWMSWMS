import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import type { OrderCategoryDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import {
  CreateOrderCategoryDto,
  ListOrderCategoriesQuery,
  UpdateOrderCategoryDto,
} from './dto/order-categories/order-categories.dto';
import { OrderCategoriesService } from '../../application/order-categories/order-categories.service';

/**
 * Роль объявляется на каждой ручке, а не на классе: чтение справочника нужно
 * всем, кто оформляет или смотрит заказы, а правка — администрирование.
 */
@Controller('order-categories')
export class OrderCategoriesController {
  constructor(private readonly categories: OrderCategoriesService) {}

  /** Без @Roles — любой авторизованный: список нужен форме заказа. */
  @Get()
  list(
    @Query() query: ListOrderCategoriesQuery,
    @Actor() actor: ActorContext,
  ): Promise<OrderCategoryDto[]> {
    return this.categories.list(query, actor);
  }

  @Roles('ADMIN')
  @Post()
  create(
    @Body() dto: CreateOrderCategoryDto,
    @Actor() actor: ActorContext,
  ): Promise<OrderCategoryDto> {
    return this.categories.create(dto, actor);
  }

  @Roles('ADMIN')
  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateOrderCategoryDto,
    @Actor() actor: ActorContext,
  ): Promise<OrderCategoryDto> {
    return this.categories.update(id, dto, actor);
  }

  @Roles('ADMIN')
  @Delete(':id')
  remove(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<{ deleted: boolean }> {
    return this.categories.remove(id, actor);
  }
}
