import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import type { SkuDto, SkuImportResultDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import { AclEntity } from './field-acl/acl-entity.decorator';
import type { ActorContext } from '../../domain/types/actor';
import {
  CreateSkuBarcodeDto,
  CreateSkuDto,
  ImportSkusDto,
  ListSkusQuery,
  UpdateSkuDto,
} from './dto/mdm/sku.dto';
import { SkusService } from '../../application/mdm/skus.service';

@AclEntity('sku')
@Controller('skus')
export class SkusController {
  constructor(private readonly skus: SkusService) {}

  @Get()
  list(@Query() query: ListSkusQuery, @Actor() actor: ActorContext): Promise<SkuDto[]> {
    return this.skus.list(query, actor);
  }

  // Объявлено до `:id`, иначе Express примет by-barcode за идентификатор.
  @Get('by-barcode/:barcode')
  byBarcode(@Param('barcode') barcode: string, @Actor() actor: ActorContext): Promise<SkuDto> {
    return this.skus.findByBarcode(barcode, actor);
  }

  @Get(':id')
  get(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<SkuDto> {
    return this.skus.get(id, actor);
  }

  // Решение PM: справочник SKU ведёт только оператор, селлер его читает.
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post()
  create(@Body() dto: CreateSkuDto, @Actor() actor: ActorContext): Promise<SkuDto> {
    return this.skus.create(dto, actor);
  }

  /**
   * Загрузка каталога списком. Путь объявлен ДО `:id`-маршрутов сознательно:
   * иначе `import` был бы разобран как идентификатор.
   */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post('import')
  import(@Body() dto: ImportSkusDto, @Actor() actor: ActorContext): Promise<SkuImportResultDto> {
    return this.skus.import(dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateSkuDto,
    @Actor() actor: ActorContext,
  ): Promise<SkuDto> {
    return this.skus.update(id, dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Post(':id/barcodes')
  addBarcode(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: CreateSkuBarcodeDto,
    @Actor() actor: ActorContext,
  ): Promise<SkuDto> {
    return this.skus.addBarcode(id, dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR')
  @Delete(':id/barcodes/:barcodeId')
  removeBarcode(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('barcodeId', ParseUUIDPipe) barcodeId: string,
    @Actor() actor: ActorContext,
  ): Promise<SkuDto> {
    return this.skus.removeBarcode(id, barcodeId, actor);
  }
}
