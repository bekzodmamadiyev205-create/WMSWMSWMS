import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import type { DepartmentDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import { CreateDepartmentDto, UpdateDepartmentDto } from './dto/departments/departments.dto';
import { DepartmentsService } from '../../application/departments/departments.service';

/** Весь контроллер — только ADMIN: структура подразделений это администрирование. */
@Roles('ADMIN')
@Controller('departments')
export class DepartmentsController {
  constructor(private readonly departments: DepartmentsService) {}

  @Get()
  list(): Promise<DepartmentDto[]> {
    return this.departments.list();
  }

  @Post()
  create(@Body() dto: CreateDepartmentDto, @Actor() actor: ActorContext): Promise<DepartmentDto> {
    return this.departments.create(dto, actor);
  }

  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateDepartmentDto,
    @Actor() actor: ActorContext,
  ): Promise<DepartmentDto> {
    return this.departments.update(id, dto, actor);
  }
}
