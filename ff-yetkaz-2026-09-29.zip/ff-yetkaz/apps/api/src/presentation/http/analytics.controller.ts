import { BadRequestException, Controller, Get, Query, Res } from '@nestjs/common';
import type { Response } from 'express';
import type { AnalyticsOverviewDto, BiViewDto, SellerAnalyticsDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import { resolveSellerScope } from '../../application/scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { AnalyticsService } from '../../application/analytics/analytics.service';
import {
  AnalyticsOverviewQueryDto,
  SellerAnalyticsExportQueryDto,
  SellerAnalyticsQueryDto,
} from './dto/analytics/analytics.dto';

@Controller('analytics')
export class AnalyticsController {
  constructor(private readonly analytics: AnalyticsService) {}

  /** Сводка оператора: цифры по всем селлерам либо по выбранному. */
  @Get('overview')
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'FINANCE')
  overview(
    @Query() query: AnalyticsOverviewQueryDto,
    @Actor() actor: ActorContext,
  ): Promise<AnalyticsOverviewDto> {
    return this.analytics.overview(query, actor);
  }

  /**
   * Та же сводка в области видимости селлера.
   *
   * Ролей тут раньше не было вовсе — «доступ решает область видимости». Для
   * СЕЛЛЕРА это правда: `resolveSellerScope` возвращает его `seller_id`, и
   * подставленный чужой `?sellerId=` ничего не открывает. Но у сотрудника
   * области нет (`null`), поэтому та же ручка отдавала складским ТСД-логинам
   * (PICKER/PACKER/RECEIVER) финансовую сводку СРАЗУ ПО ВСЕМ селлерам: выручку,
   * собранный COD, ряд по дням. Сотруднику эта витрина не нужна — у него есть
   * `/analytics/overview` под своими ролями.
   */
  @Get('seller-summary')
  @Roles('SELLER', 'ADMIN', 'FINANCE')
  sellerSummary(
    @Query() query: AnalyticsOverviewQueryDto,
    @Actor() actor: ActorContext,
  ): Promise<AnalyticsOverviewDto> {
    // Условие — по СКОУПУ, а не по наличию роли SELLER в списке: у учётки,
    // совмещающей SELLER со штатной ролью, скоуп штатный (см. STAFF_ROLES),
    // то есть сводка снова получилась бы по всем селлерам.
    if (resolveSellerScope(actor.user) === null && !query.sellerId) {
      throw new BadRequestException(
        'Укажите sellerId: витрина строится по одному селлеру. Сводка по всем — /analytics/overview.',
      );
    }
    return this.analytics.sellerSummary(query, actor);
  }

  @Get('sellers')
  @Roles('ADMIN', 'FINANCE')
  sellers(
    @Query() query: SellerAnalyticsQueryDto,
    @Actor() actor: ActorContext,
  ): Promise<SellerAnalyticsDto> {
    return this.analytics.sellers(query, actor);
  }

  /**
   * Выгрузка тех же строк с теми же фильтрами. Совпадение фильтров — не
   * деталь реализации, а весь смысл ручки: отчёт, отличающийся от экрана,
   * порождает спор о том, какая из двух цифр настоящая.
   */
  @Get('sellers/export')
  @Roles('ADMIN', 'FINANCE')
  async exportSellers(
    @Query() query: SellerAnalyticsExportQueryDto,
    @Actor() actor: ActorContext,
    @Res({ passthrough: false }) response: Response,
  ): Promise<void> {
    await this.analytics.exportSellers(query, actor, response);
  }

  /** Контракт витрин для внешнего BI (Metabase / Superset). */
  @Get('bi-views')
  @Roles('ADMIN', 'FINANCE')
  biViews(): { views: BiViewDto[] } {
    return this.analytics.biViews();
  }
}
