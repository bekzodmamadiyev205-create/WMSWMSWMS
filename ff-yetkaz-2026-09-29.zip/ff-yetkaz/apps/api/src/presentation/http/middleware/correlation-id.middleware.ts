import { randomUUID } from 'node:crypto';
import { Injectable, type NestMiddleware } from '@nestjs/common';
import type { NextFunction, Response } from 'express';
import type { FfRequest } from '../types/request';

/**
 * Сквозной id запроса: принимаем внешний `X-Request-Id`, иначе генерируем свой.
 * Он же уходит в audit_events и в конверт ошибки — по нему собирается вся история
 * одного обращения.
 */
@Injectable()
export class CorrelationIdMiddleware implements NestMiddleware {
  use(request: FfRequest, response: Response, next: NextFunction): void {
    const incoming = request.headers['x-request-id'];
    const value = Array.isArray(incoming) ? incoming[0] : incoming;
    request.correlationId = value && value.trim() !== '' ? value.trim() : randomUUID();
    response.setHeader('X-Request-Id', request.correlationId);
    next();
  }
}
