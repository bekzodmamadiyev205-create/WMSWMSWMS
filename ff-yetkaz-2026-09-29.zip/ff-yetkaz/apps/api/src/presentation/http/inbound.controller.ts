import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Query } from '@nestjs/common';
import type { AsnDto, ReceiptCompletionDto, ReceiptDto, SkuDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import {
  CreateAsnDto,
  CreateReceiptDto,
  LinkAsnLineBarcodeDto,
  ListAsnsQuery,
  PutAwayDto,
  ScanDto,
} from './dto/inbound/inbound.dto';
import { InboundService } from '../../application/inbound/inbound.service';

@Controller('inbound')
export class InboundController {
  constructor(private readonly inbound: InboundService) {}

  // --- ASN: заводит оператор, селлер читает свои (решение PM) ---------------

  @Get('asns')
  listAsns(@Query() query: ListAsnsQuery, @Actor() actor: ActorContext): Promise<AsnDto[]> {
    return this.inbound.listAsns(query, actor);
  }

  @Get('asns/:id')
  getAsn(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<AsnDto> {
    return this.inbound.getAsn(id, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('asns')
  createAsn(@Body() dto: CreateAsnDto, @Actor() actor: ActorContext): Promise<AsnDto> {
    return this.inbound.createAsn(dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('asns/:id/submit')
  submitAsn(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<AsnDto> {
    return this.inbound.submitAsn(id, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('asns/:id/cancel')
  cancelAsn(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<AsnDto> {
    return this.inbound.cancelAsn(id, actor);
  }

  /** Закрыть заявку при недовозе — решение оператора, а не автоматика. */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('asns/:id/close')
  closeAsn(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<AsnDto> {
    return this.inbound.closeAsn(id, actor);
  }

  // --- Приёмка --------------------------------------------------------------

  @Get('receipts/:id')
  getReceipt(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<ReceiptDto> {
    return this.inbound.getReceipt(id, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('receipts')
  createReceipt(
    @Body() dto: CreateReceiptDto,
    @Actor() actor: ActorContext,
  ): Promise<ReceiptDto> {
    return this.inbound.createReceipt(dto, actor);
  }

  /**
   * Приём позиции: товар встаёт в ячейку приёмки со статусом RECEIVED.
   * Опознаётся штрихкодом ИЛИ строкой заявки — для товара, у которого кода нет.
   */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('receipts/:id/scan')
  scan(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: ScanDto,
    @Actor() actor: ActorContext,
  ): Promise<ReceiptDto> {
    return this.inbound.scan(id, dto, actor);
  }

  /**
   * Привязать штрихкод к позиции заявки. Узкая ручка вместо прав на справочник:
   * приёмщик дописывает код товару из своей поставки, а каталог по-прежнему
   * ведёт оператор (решение PM).
   */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('receipts/:id/lines/:asnLineId/barcode')
  linkAsnLineBarcode(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('asnLineId', ParseUUIDPipe) asnLineId: string,
    @Body() dto: LinkAsnLineBarcodeDto,
    @Actor() actor: ActorContext,
  ): Promise<SkuDto> {
    return this.inbound.linkAsnLineBarcode(id, asnLineId, dto, actor);
  }

  /** Инспекция и раскладка: годное — в хранение, брак — в ячейку брака. */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('receipts/:id/put-away')
  putAway(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: PutAwayDto,
    @Actor() actor: ActorContext,
  ): Promise<ReceiptDto> {
    return this.inbound.putAway(id, dto, actor);
  }

  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER')
  @Post('receipts/:id/complete')
  complete(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<ReceiptCompletionDto> {
    return this.inbound.completeReceipt(id, actor);
  }
}
