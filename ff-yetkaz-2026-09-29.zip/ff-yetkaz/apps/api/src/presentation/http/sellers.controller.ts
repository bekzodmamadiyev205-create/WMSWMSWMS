import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
} from '@nestjs/common';
import type { SellerDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import { AclEntity } from './field-acl/acl-entity.decorator';
import type { ActorContext } from '../../domain/types/actor';
import { CreateSellerDto, UpdateSellerDto } from './dto/mdm/seller.dto';
import { SellersService } from '../../application/mdm/sellers.service';

@AclEntity('seller')
@Controller('sellers')
export class SellersController {
  constructor(private readonly sellers: SellersService) {}

  @Get()
  list(@Actor() actor: ActorContext): Promise<SellerDto[]> {
    return this.sellers.list(actor);
  }

  @Get(':id')
  get(@Param('id', ParseUUIDPipe) id: string, @Actor() actor: ActorContext): Promise<SellerDto> {
    return this.sellers.get(id, actor);
  }

  // Селлер — договорная сущность, заводит только администратор.
  @Roles('ADMIN')
  @Post()
  create(@Body() dto: CreateSellerDto, @Actor() actor: ActorContext): Promise<SellerDto> {
    return this.sellers.create(dto, actor);
  }

  @Roles('ADMIN')
  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateSellerDto,
    @Actor() actor: ActorContext,
  ): Promise<SellerDto> {
    return this.sellers.update(id, dto, actor);
  }

  @Roles('ADMIN')
  @Delete(':id')
  @HttpCode(204)
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<void> {
    await this.sellers.remove(id, actor);
  }
}
