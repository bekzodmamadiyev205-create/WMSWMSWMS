import { SetMetadata } from '@nestjs/common';
import type { AclEntity as AclEntityName } from '@ff/shared';

export const ACL_ENTITY_KEY = 'ff:aclEntity';

export interface AclEntityOptions {
  /**
   * Путь до полезной нагрузки внутри ответа, если она не сам ответ и не `rows`
   * постраничного конверта (например `{ order: … }`).
   */
  path?: string;
}

export interface AclEntityMetadata extends AclEntityOptions {
  entity: AclEntityName;
}

/**
 * Помечает контроллер или ручку сущностью, чьи поля закрывает матрица прав.
 *
 * Метка обязательна и ставится руками. Угадывать сущность по URL нельзя: рано
 * или поздно совпадение имён вырежет поле не из того ответа, а сокрытие «не
 * того» ломает данные молча — клиент увидит объект без ключа и решит, что
 * значения просто нет.
 */
export const AclEntity = (entity: AclEntityName, options: AclEntityOptions = {}) =>
  SetMetadata<string, AclEntityMetadata>(ACL_ENTITY_KEY, { entity, ...options });
