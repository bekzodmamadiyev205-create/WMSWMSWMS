import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { mergeMap, type Observable } from 'rxjs';
import type { Role } from '@ff/shared';
import type { FfRequest } from '../types/request';
import { ACL_ENTITY_KEY, type AclEntityMetadata } from './acl-entity.decorator';
import { FieldAclService } from '../../../application/field-acl/field-acl.service';

/**
 * Вырезает из ответа поля, закрытые для ролей вызывающего.
 *
 * Работает ТОЛЬКО там, где стоит `@AclEntity(...)`: без метки ответ не трогается.
 *
 * ПОРЯДОК РЕГИСТРАЦИИ ВАЖЕН. Этот интерцептор регистрируется в AppModule ПЕРЕД
 * IdempotencyInterceptor, потому что Nest выполняет пост-фазу интерцепторов в
 * ОБРАТНОМ порядке регистрации: зарегистрированный первым отработает последним,
 * то есть уже после того, как идемпотентность сохранила ПОЛНОЕ тело ответа.
 * Обратный порядок был бы дырой: в кэш идемпотентности легло бы тело, урезанное
 * под роли ПЕРВОГО вызвавшего, и повтор с тем же ключом от финансиста вернул бы
 * ему выдачу сборщика — без сумм. Заодно фильтр применяется и к воспроизведённому
 * телу: повтор проходит через ту же пост-фазу.
 */
@Injectable()
export class FieldAclInterceptor implements NestInterceptor {
  constructor(
    private readonly reflector: Reflector,
    private readonly acl: FieldAclService,
  ) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    if (context.getType() !== 'http') return next.handle();

    // Сначала ручка, потом класс — точечная метка перекрывает контроллерную.
    const meta = this.reflector.getAllAndOverride<AclEntityMetadata | undefined>(ACL_ENTITY_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!meta) return next.handle();

    const user = context.switchToHttp().getRequest<FfRequest>().user;
    // Ручка без авторизации (`@Public`) ролей не имеет — фильтровать нечем.
    if (!user) return next.handle();

    return next
      .handle()
      .pipe(mergeMap(async (body: unknown) => this.apply(meta, body, user.roles)));
  }

  private async apply(
    meta: AclEntityMetadata,
    body: unknown,
    roles: Role[],
  ): Promise<unknown> {
    if (body === null || body === undefined) return body;
    // Поток и буфер (выгрузка, PDF) фильтровать нечем: там нет ключей — зато
    // обход по ключам превратил бы поток в бесполезный пустой объект.
    if (Buffer.isBuffer(body) || typeof body !== 'object') return body;
    if (typeof (body as { pipe?: unknown }).pipe === 'function') return body;

    // Явно указанный путь: `{ order: … }`, `{ shipment: … | null }`.
    if (meta.path) {
      const record = body as Record<string, unknown>;
      const target = record[meta.path];
      if (target === null || target === undefined) return body;
      return { ...record, [meta.path]: await this.acl.filter(meta.entity, target, roles) };
    }

    // Постраничный конверт распознаём сам: иначе каждая ручка списка вынуждена
    // была бы дублировать `{ path: 'rows' }`, и первая же забытая метка отдала бы
    // страницу без фильтрации.
    if (isPageEnvelope(body)) {
      return { ...body, rows: await this.acl.filter(meta.entity, body.rows, roles) };
    }

    // Голый DTO и массив DTO — общий случай, `filter` обрабатывает оба.
    return this.acl.filter(meta.entity, body, roles);
  }
}

function isPageEnvelope(body: object): body is { rows: unknown[] } & Record<string, unknown> {
  const record = body as Record<string, unknown>;
  return (
    Array.isArray(record.rows) &&
    typeof record.total === 'number' &&
    typeof record.page === 'number'
  );
}
