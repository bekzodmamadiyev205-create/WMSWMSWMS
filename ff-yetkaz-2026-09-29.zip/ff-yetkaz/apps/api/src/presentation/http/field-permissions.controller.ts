import { Body, Controller, Get, Put } from '@nestjs/common';
import type { EffectiveFieldAclDto, FieldPermissionMatrixDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import { UpdateFieldPermissionsDto } from './dto/field-permissions/field-permissions.dto';
import { FieldPermissionsService } from '../../application/field-permissions/field-permissions.service';

/**
 * Матрица прав на колонки.
 *
 * `@Roles` стоит на ручках, а не на классе: правит матрицу только ADMIN, но
 * СВОИ права обязан получать каждый — интерфейс без них не знает, какие колонки
 * прятать, и покажет пустые ячейки вместо честного отсутствия поля.
 */
@Controller('field-permissions')
export class FieldPermissionsController {
  constructor(private readonly permissions: FieldPermissionsService) {}

  @Get()
  @Roles('ADMIN')
  list(): Promise<FieldPermissionMatrixDto> {
    return this.permissions.matrix();
  }

  @Put()
  @Roles('ADMIN')
  update(
    @Body() dto: UpdateFieldPermissionsDto,
    @Actor() actor: ActorContext,
  ): Promise<FieldPermissionMatrixDto> {
    return this.permissions.update(dto.permissions, actor);
  }

  /** Права текущего пользователя: этим фронт прячет колонки и гасит поля ввода. */
  @Get('effective')
  effective(@Actor() actor: ActorContext): Promise<EffectiveFieldAclDto> {
    return this.permissions.effective(actor);
  }
}
