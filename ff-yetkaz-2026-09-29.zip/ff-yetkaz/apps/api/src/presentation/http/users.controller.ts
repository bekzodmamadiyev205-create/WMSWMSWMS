import { Body, Controller, Get, HttpCode, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import type { UserSummaryDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import { AclEntity } from './field-acl/acl-entity.decorator';
import type { ActorContext } from '../../domain/types/actor';
import { CreateUserDto, SetPasswordDto, UpdateUserDto } from './dto/users/users.dto';
import { UsersService } from '../../application/users/users.service';

/** Весь контроллер — только ADMIN: выдача доступа это административное действие. */
@Roles('ADMIN')
@AclEntity('user')
@Controller('users')
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get()
  list(): Promise<UserSummaryDto[]> {
    return this.users.list();
  }

  @Post()
  create(@Body() dto: CreateUserDto, @Actor() actor: ActorContext): Promise<UserSummaryDto> {
    return this.users.create(dto, actor);
  }

  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateUserDto,
    @Actor() actor: ActorContext,
  ): Promise<UserSummaryDto> {
    return this.users.update(id, dto, actor);
  }

  @Post(':id/password')
  @HttpCode(204)
  async setPassword(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: SetPasswordDto,
    @Actor() actor: ActorContext,
  ): Promise<void> {
    await this.users.setPassword(id, dto.password, actor);
  }
}
