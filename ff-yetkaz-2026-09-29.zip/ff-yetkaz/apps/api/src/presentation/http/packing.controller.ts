import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Query, Res } from '@nestjs/common';
import type { Response } from 'express';
import type {
  PackCompletionDto,
  PackageDto,
  PackageShipmentDto,
  PackingQueueItemDto,
  ShipmentDto,
} from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import { CompletePackingDto, PackingQueueQuery } from './dto/packing/packing.dto';
import { renderLabel } from '../../infrastructure/labels/label.renderer';
import { PackingService } from '../../application/packing/packing.service';

@Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'PACKER')
@Controller('packing')
export class PackingController {
  constructor(private readonly packing: PackingService) {}

  @Get('queue')
  queue(
    @Query() query: PackingQueueQuery,
    @Actor() actor: ActorContext,
  ): Promise<PackingQueueItemDto[]> {
    return this.packing.queue(query, actor);
  }

  @Get('packages/:id')
  getPackage(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<PackageDto> {
    return this.packing.getPackage(id, actor);
  }

  @Get('packages/:id/shipment')
  getShipment(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<PackageShipmentDto> {
    return this.packing.getShipmentByPackage(id, actor);
  }

  @Post('orders/:orderId/start')
  start(
    @Param('orderId', ParseUUIDPipe) orderId: string,
    @Actor() actor: ActorContext,
  ): Promise<PackageDto> {
    return this.packing.start(orderId, actor);
  }

  @Post('orders/:orderId/complete')
  complete(
    @Param('orderId', ParseUUIDPipe) orderId: string,
    @Body() dto: CompletePackingDto,
    @Actor() actor: ActorContext,
  ): Promise<PackCompletionDto> {
    return this.packing.complete(orderId, dto, actor);
  }

  /** Оформление отправления: заказ уходит в READY_TO_SHIP — граница зоны FF. */
  @Post('packages/:id/label')
  issue(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
  ): Promise<ShipmentDto> {
    return this.packing.issueShipment(id, actor);
  }

  /**
   * Печать этикетки. Отдельным GET и без побочных эффектов: перепечатать
   * потерянную наклейку можно сколько угодно раз, и статус заказа при этом
   * меняться не должен.
   */
  @Get('packages/:id/label.pdf')
  async label(
    @Param('id', ParseUUIDPipe) id: string,
    @Actor() actor: ActorContext,
    @Res() response: Response,
  ): Promise<void> {
    const data = await this.packing.labelData(id, actor);
    const pdf = await renderLabel(data);
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader(
      'Content-Disposition',
      `inline; filename="label-${data.shipmentNo}.pdf"`,
    );
    response.setHeader('Content-Length', pdf.length);
    response.end(pdf);
  }
}
