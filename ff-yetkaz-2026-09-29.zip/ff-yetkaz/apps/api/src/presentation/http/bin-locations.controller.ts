import { Body, Controller, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import type { BinLocationDto } from '@ff/shared';
import { Actor, Roles } from './decorators';
import type { ActorContext } from '../../domain/types/actor';
import { BinLocationsService } from '../../application/mdm/bin-locations.service';
import { CreateBinLocationDto, UpdateBinLocationDto } from './dto/mdm/bin-location.dto';

@Roles('ADMIN', 'WAREHOUSE_OPERATOR')
@Controller('bin-locations')
export class BinLocationsController {
  constructor(private readonly bins: BinLocationsService) {}

  @Post()
  create(@Body() dto: CreateBinLocationDto, @Actor() actor: ActorContext): Promise<BinLocationDto> {
    return this.bins.create(dto, actor);
  }

  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateBinLocationDto,
    @Actor() actor: ActorContext,
  ): Promise<BinLocationDto> {
    return this.bins.update(id, dto, actor);
  }
}
