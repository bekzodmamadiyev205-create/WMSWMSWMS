import type { Request } from 'express';
import type { AuthPrincipal } from '@ff/shared';

export interface FfRequest extends Request {
  /** Проставляется JwtAuthGuard после проверки подписи токена. */
  user?: AuthPrincipal;
  /** Сквозной id запроса: попадает в audit_events и в заголовок ответа. */
  correlationId?: string;
  /**
   * Тело запроса ровно в том виде, в каком оно пришло. Нужно вебхукам:
   * подпись считается по байтам, а `JSON.stringify(req.body)` их не
   * восстанавливает — порядок ключей и пробелы уже потеряны.
   */
  rawBody?: Buffer;
}
