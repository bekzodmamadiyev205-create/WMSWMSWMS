import { Type } from 'class-transformer';
import {
  IsBoolean,
  IsIn,
  IsInt,
  IsISO8601,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Matches,
  Min,
} from 'class-validator';
import { CHARGE_KINDS, TARIFF_UNITS, type ChargeKind, type TariffUnit } from '@ff/shared';
import type {
  CreateTariffPlanInput,
  CreateTariffRuleInput,
  PackingNormsInput,
  UpdateTariffPlanInput,
  UpdateTariffRuleInput,
} from '../../../../application/billing/billing.input';

/** Дата без времени: период биллинга — календарный, а не по секундам. */
const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;

/** Тот же шаблон, что у CHECK `tariff_rules_component_shape` в БД. */
const COMPONENT_RE = /^[A-Z][A-Z0-9_]*$/;

export class CreateTariffPlanDto implements CreateTariffPlanInput {
  @IsString()
  @Length(2, 32)
  code: string;

  @IsString()
  @Length(2, 120)
  name: string;

  @Matches(/^[A-Za-z]{3}$/, { message: 'currency — трёхбуквенный код валюты' })
  currency: string;

  @IsOptional()
  @IsBoolean()
  isDefault?: boolean;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

/**
 * Правка плана. Код не меняется — на него ссылаются в переписке и в отчётах;
 * нужен другой код, заводится другой план.
 */
export class UpdateTariffPlanDto implements UpdateTariffPlanInput {
  @IsOptional()
  @IsString()
  @Length(2, 120)
  name?: string;

  @IsOptional()
  @Matches(/^[A-Za-z]{3}$/, { message: 'currency — трёхбуквенный код валюты' })
  currency?: string;

  @IsOptional()
  @IsBoolean()
  isDefault?: boolean;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class CreateTariffRuleDto implements CreateTariffRuleInput {
  @IsIn(CHARGE_KINDS as unknown as string[])
  kind: ChargeKind;

  @IsIn(TARIFF_UNITS as unknown as string[])
  unit: TariffUnit;

  /**
   * Составляющая цены. Не задана — `BASE`, то есть ровно то поведение, которое
   * было до комбинированных тарифов.
   */
  @IsOptional()
  @IsString()
  @Length(1, 32)
  @Matches(COMPONENT_RE, {
    message: 'component — латиница в верхнем регистре, например WEIGHT.',
  })
  component?: string;

  /** Строкой: деньги через float недопустимы даже на входе. */
  @Matches(/^\d+(\.\d{1,4})?$/, { message: 'price — неотрицательное число с точкой' })
  price: string;

  @IsOptional()
  @Matches(/^\d+(\.\d{1,3})?$/, { message: 'minQty — неотрицательное число' })
  minQty?: string;

  @IsOptional()
  @Matches(DATE_ONLY, { message: 'effectiveFrom — дата в формате YYYY-MM-DD' })
  effectiveFrom?: string;

  @IsOptional()
  @Matches(DATE_ONLY, { message: 'effectiveTo — дата в формате YYYY-MM-DD' })
  effectiveTo?: string;
}

/**
 * Правка правила. `kind`, `unit` и `component` не меняются: на правило уже
 * могут ссылаться начисления, и подмена того, ЗА ЧТО была взята цена, переписала
 * бы историю. Вывести правило из обращения — это `effectiveTo`.
 */
export class UpdateTariffRuleDto implements UpdateTariffRuleInput {
  @IsOptional()
  @Matches(/^\d+(\.\d{1,4})?$/, { message: 'price — неотрицательное число с точкой' })
  price?: string;

  @IsOptional()
  @Matches(/^\d+(\.\d{1,3})?$/, { message: 'minQty — неотрицательное число' })
  minQty?: string;

  @IsOptional()
  @Matches(DATE_ONLY, { message: 'effectiveFrom — дата в формате YYYY-MM-DD' })
  effectiveFrom?: string;

  /** `null` снимает дату окончания — правило снова бессрочное. */
  @IsOptional()
  @Matches(DATE_ONLY, { message: 'effectiveTo — дата в формате YYYY-MM-DD' })
  effectiveTo?: string | null;
}

/**
 * Нормы упаковки товара. Живут в биллинге, потому что существуют ради цены:
 * склад считает штуки, а коробки и паллеты — производная от них, и нужна она
 * только тарифам `PER_BOX`/`PER_PALLET`.
 */
export class PackingNormsDto implements PackingNormsInput {
  /** `null` снимает норму: у товара её нет, и коробки по нему не считаются. */
  @IsOptional()
  @IsInt()
  @Min(1)
  unitsPerBox?: number | null;

  @IsOptional()
  @IsInt()
  @Min(1)
  unitsPerPallet?: number | null;
}

export class AssignPlanDto {
  @IsOptional()
  @IsUUID()
  planId?: string | null;
}

export class PeriodQuery {
  @Matches(DATE_ONLY, { message: 'from — дата в формате YYYY-MM-DD' })
  from: string;

  @Matches(DATE_ONLY, { message: 'to — дата в формате YYYY-MM-DD' })
  to: string;

  @IsOptional()
  @IsUUID()
  sellerId?: string;
}

export class SnapshotDto {
  @IsOptional()
  @Matches(DATE_ONLY, { message: 'date — дата в формате YYYY-MM-DD' })
  date?: string;
}

export class BuildInvoiceDto {
  @IsUUID()
  sellerId: string;

  @Matches(DATE_ONLY, { message: 'periodStart — дата в формате YYYY-MM-DD' })
  periodStart: string;

  @Matches(DATE_ONLY, { message: 'periodEnd — дата в формате YYYY-MM-DD' })
  periodEnd: string;
}

export class AccrueDto {
  @IsISO8601()
  @Type(() => String)
  from: string;

  @IsISO8601()
  to: string;
}
