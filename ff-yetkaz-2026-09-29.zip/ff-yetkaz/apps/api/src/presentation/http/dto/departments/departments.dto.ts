import { IsBoolean, IsOptional, IsString, Length, Matches } from 'class-validator';
import { DEPARTMENT_CODE_RE } from '@ff/shared';

export class CreateDepartmentDto {
  @IsString()
  @Length(2, 32)
  @Matches(DEPARTMENT_CODE_RE, {
    message: 'Код отдела — латиница в верхнем регистре, например WAREHOUSE.',
  })
  code: string;

  @IsString()
  @Length(1, 128)
  name: string;

  @IsOptional()
  @IsString()
  @Length(0, 512)
  description?: string;
}

export class UpdateDepartmentDto {
  // Код не меняется: на него ссылаются в отчётах и на словах. Нужен другой —
  // заводится новый отдел, старый выключается.
  @IsOptional()
  @IsString()
  @Length(1, 128)
  name?: string;

  @IsOptional()
  @IsString()
  @Length(0, 512)
  description?: string;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}
