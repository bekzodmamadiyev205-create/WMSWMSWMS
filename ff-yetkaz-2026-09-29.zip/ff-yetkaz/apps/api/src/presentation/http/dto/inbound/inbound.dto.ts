import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsDateString,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Min,
  ValidateNested,
} from 'class-validator';
import { ASN_STATUSES, type AsnStatus } from '@ff/shared';
import type {
  CreateAsnInput,
  CreateAsnLineInput,
  CreateReceiptInput,
  LinkAsnLineBarcodeInput,
  ListAsnsQueryInput,
  PutAwayInput,
  ScanInput,
} from '../../../../application/inbound/inbound.input';

export class AsnLineInput implements CreateAsnLineInput {
  @IsUUID()
  skuId: string;

  @IsInt()
  @Min(1)
  expectedQty: number;
}

export class CreateAsnDto implements CreateAsnInput {
  @IsUUID()
  sellerId: string;

  @IsUUID()
  warehouseId: string;

  /** Номер поставки на стороне селлера. Защищён уникальным индексом от дублей. */
  @IsOptional()
  @IsString()
  @Length(1, 64)
  externalRef?: string;

  @IsOptional()
  @IsDateString()
  expectedAt?: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => AsnLineInput)
  lines: AsnLineInput[];
}

export class CreateReceiptDto implements CreateReceiptInput {
  @IsUUID()
  asnId: string;
}

export class ScanDto implements ScanInput {
  /**
   * Штрихкод с коробки. SKU ищется глобально — селлера знать не нужно.
   * Необязателен: товар опознаётся ЛИБО кодом, ЛИБО строкой заявки (см. ниже).
   */
  @IsOptional()
  @IsString()
  @Length(1, 64)
  barcode?: string;

  /**
   * Приём по строке заявки — для товара, у которого штрихкода ещё нет.
   * Это не послабление контроля, а его усиление: скан ищет SKU по всему
   * справочнику, строка же называет ровно один товар ровно этой поставки.
   */
  @IsOptional()
  @IsUUID()
  asnLineId?: string;

  @IsInt()
  @Min(1)
  quantity: number;

  @IsOptional()
  @IsString()
  @Length(1, 64)
  lotCode?: string;

  @IsOptional()
  @IsDateString()
  expiryDate?: string;
}

export class PutAwayDto implements PutAwayInput {
  @IsUUID()
  receiptLineId: string;

  /** Годное количество. Вместе с браком должно давать ровно принятое. */
  @IsInt()
  @Min(0)
  qtyOk: number;

  @IsInt()
  @Min(0)
  qtyDamaged: number;

  /** Ячейка хранения для годного товара. */
  @IsUUID()
  binId: string;
}

/**
 * Привязка штрихкода к позиции заявки прямо с терминала приёмки.
 *
 * Узкая ручка вместо расширения прав на справочник: приёмщик дописывает код
 * товару, который сейчас держит в руках, но редактором каталога не становится
 * (решение PM «справочник ведёт только оператор» остаётся в силе).
 */
export class LinkAsnLineBarcodeDto implements LinkAsnLineBarcodeInput {
  @IsString()
  @Length(1, 64)
  barcode: string;
}

export class ListAsnsQuery implements ListAsnsQueryInput {
  @IsOptional()
  @IsUUID()
  sellerId?: string;

  @IsOptional()
  @IsIn(ASN_STATUSES as unknown as string[])
  status?: AsnStatus;
}
