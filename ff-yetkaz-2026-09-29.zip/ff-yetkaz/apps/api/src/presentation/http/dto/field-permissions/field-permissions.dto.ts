import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  IsArray,
  IsBoolean,
  IsIn,
  IsString,
  Length,
  ValidateNested,
} from 'class-validator';
import { ACL_ENTITIES, ROLES, type AclEntity, type Role } from '@ff/shared';

export class FieldPermissionInput {
  @IsIn(ROLES, { message: 'Неизвестная роль.' })
  role: Role;

  @IsIn(ACL_ENTITIES, { message: 'Неизвестная сущность.' })
  entity: AclEntity;

  @IsString()
  @Length(1, 64)
  field: string;

  @IsBoolean()
  canView: boolean;

  @IsBoolean()
  canEdit: boolean;

  @IsBoolean()
  canDelete: boolean;
}

export class UpdateFieldPermissionsDto {
  /**
   * Присылается только то, что администратор трогал. Полная матрица — это
   * роли × сущности × поля, несколько сотен строк на каждое сохранение;
   * потолок стоит, чтобы случайная выгрузка не превратилась в запрос на мегабайт.
   */
  @IsArray()
  @ArrayMaxSize(2000)
  @ValidateNested({ each: true })
  @Type(() => FieldPermissionInput)
  permissions: FieldPermissionInput[];
}
