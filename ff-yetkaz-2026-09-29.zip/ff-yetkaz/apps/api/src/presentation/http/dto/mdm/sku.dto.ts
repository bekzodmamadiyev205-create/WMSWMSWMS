import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';
import { BARCODE_KINDS, type BarcodeKind, type SkuImportRowDto } from '@ff/shared';
import type {
  CreateSkuBarcodeInput,
  CreateSkuInput,
  ImportSkusInput,
  ListSkusQueryInput,
  UpdateSkuInput,
} from '../../../../application/mdm/mdm.input';

/** Габариты — миллиметры, вес — граммы. Целые: плавающая точка тут не нужна. */
const MAX_DIMENSION_MM = 100_000;
const MAX_WEIGHT_G = 2_000_000;

export class CreateSkuDto implements CreateSkuInput {
  @IsUUID()
  sellerId: string;

  @IsString()
  @Length(1, 64)
  skuCode: string;

  @IsString()
  @Length(1, 512)
  name: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  lengthMm?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  widthMm?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  heightMm?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(MAX_WEIGHT_G)
  weightG?: number;

  @IsOptional()
  @IsBoolean()
  isLotTracked?: boolean;

  /** Требует партионного учёта: сама дата истечения хранится на партии. */
  @IsOptional()
  @IsBoolean()
  isExpiryTracked?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(36_500)
  shelfLifeDays?: number;
}

export class UpdateSkuDto implements UpdateSkuInput {
  @IsOptional()
  @IsString()
  @Length(1, 512)
  name?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  lengthMm?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  widthMm?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  heightMm?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(MAX_WEIGHT_G)
  weightG?: number;

  @IsOptional()
  @IsBoolean()
  isLotTracked?: boolean;

  @IsOptional()
  @IsBoolean()
  isExpiryTracked?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(36_500)
  shelfLifeDays?: number;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class CreateSkuBarcodeDto implements CreateSkuBarcodeInput {
  @IsString()
  @Length(1, 64)
  barcode: string;

  @IsOptional()
  @IsIn(BARCODE_KINDS as unknown as string[])
  kind?: BarcodeKind;

  @IsOptional()
  @IsBoolean()
  isPrimary?: boolean;
}

/** Одна строка загрузки каталога. Разбор файла — на клиенте, здесь уже данные. */
export class SkuImportRow implements SkuImportRowDto {
  @IsString()
  @Length(1, 64)
  skuCode: string;

  @IsString()
  @Length(1, 512)
  name: string;

  @IsOptional()
  @IsString()
  @Length(1, 64)
  barcode?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(MAX_WEIGHT_G)
  weightG?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  lengthMm?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  widthMm?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(MAX_DIMENSION_MM)
  heightMm?: number;
}

export class ImportSkusDto implements ImportSkusInput {
  @IsUUID()
  sellerId: string;

  @IsArray()
  @ArrayMinSize(1)
  @ArrayMaxSize(2000)
  @ValidateNested({ each: true })
  @Type(() => SkuImportRow)
  rows: SkuImportRow[];
}

export class ListSkusQuery implements ListSkusQueryInput {
  @IsOptional()
  @IsUUID()
  sellerId?: string;

  /** Поиск по артикулу и названию. */
  @IsOptional()
  @IsString()
  @Length(1, 128)
  q?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(500)
  limit?: number;

  @IsOptional()
  @IsIn(['true', 'false'])
  activeOnly?: 'true' | 'false';
}
