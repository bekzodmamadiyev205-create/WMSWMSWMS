import { IsBoolean, IsOptional, IsString, Length, MaxLength } from 'class-validator';
import type {
  CreateWarehouseInput,
  UpdateWarehouseInput,
} from '../../../../application/mdm/mdm.input';

export class CreateWarehouseDto implements CreateWarehouseInput {
  @IsString()
  @Length(2, 32)
  code: string;

  @IsString()
  @Length(2, 256)
  name: string;

  @IsOptional()
  @IsString()
  @MaxLength(512)
  address?: string;

  /** IANA-зона, например Asia/Tashkent. Проверяется на существование в сервисе. */
  @IsOptional()
  @IsString()
  @MaxLength(64)
  timezone?: string;
}

export class UpdateWarehouseDto implements UpdateWarehouseInput {
  @IsOptional()
  @IsString()
  @Length(2, 256)
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(512)
  address?: string;

  @IsOptional()
  @IsString()
  @MaxLength(64)
  timezone?: string;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}
