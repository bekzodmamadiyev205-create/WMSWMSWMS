import {
  Allow,
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsEmail,
  IsIn,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  MinLength,
} from 'class-validator';
import { PASSWORD_MIN_LENGTH, ROLES, type Role } from '@ff/shared';

export class CreateUserDto {
  @IsEmail({}, { message: 'Нужен корректный email.' })
  email: string;

  @IsString()
  @Length(1, 256)
  fullName: string;

  @MinLength(PASSWORD_MIN_LENGTH, {
    message: `Пароль не короче ${PASSWORD_MIN_LENGTH} символов.`,
  })
  password: string;

  @IsArray()
  @ArrayMinSize(1, { message: 'Пользователь без ролей ничего не сможет — выберите хотя бы одну.' })
  @IsIn(ROLES as unknown as string[], { each: true })
  roles: Role[];

  /** Обязателен для роли SELLER и запрещён для сотрудников оператора. */
  @IsOptional()
  @IsUUID()
  sellerId?: string;

  /** Отдел сотрудника — необязателен; селлеру не назначается. */
  @IsOptional()
  @IsUUID()
  departmentId?: string;
}

export class UpdateUserDto {
  @IsOptional()
  @IsString()
  @Length(1, 256)
  fullName?: string;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @IsOptional()
  @IsArray()
  @ArrayMinSize(1, { message: 'Пользователь без ролей ничего не сможет — выберите хотя бы одну.' })
  @IsIn(ROLES as unknown as string[], { each: true })
  roles?: Role[];

  /**
   * null — снять отдел, uuid — назначить, отсутствие поля — не трогать.
   *
   * `@Allow()` — страховка, чтобы явный `null` гарантированно доходил до сервиса
   * при `whitelist: true`, а не «терялся» в undefined («не трогать»). Само снятие
   * отдела выполняет UsersService.update отдельным апдейтом FK-колонки.
   */
  @Allow()
  @IsOptional()
  @IsUUID()
  departmentId?: string | null;
}

export class SetPasswordDto {
  @MinLength(PASSWORD_MIN_LENGTH, {
    message: `Пароль не короче ${PASSWORD_MIN_LENGTH} символов.`,
  })
  password: string;
}
