import { Type } from 'class-transformer';
import { IsInt, IsOptional, IsString, IsUUID, Length, Min } from 'class-validator';
import type {
  CompletePackingInput,
  PackingQueueQueryInput,
} from '../../../../application/packing/packing.input';

export class PackingQueueQuery implements PackingQueueQueryInput {
  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number;
}

export class CompletePackingDto implements CompletePackingInput {
  /** Фактический вес коробки в граммах — целым, как и вес в справочнике. */
  @IsInt()
  @Min(1)
  weightG: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  lengthMm?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  widthMm?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  heightMm?: number;

  /** Комментарий упаковщика — прежде всего объяснение расхождения по весу. */
  @IsOptional()
  @IsString()
  @Length(3, 512)
  comment?: string;
}
