import { IsBoolean, IsIn, IsOptional, IsString, IsUUID, Length } from 'class-validator';
import { BIN_KINDS, type BinKind } from '@ff/shared';
import type {
  CreateBinLocationInput,
  UpdateBinLocationInput,
} from '../../../../application/mdm/mdm.input';

export class CreateBinLocationDto implements CreateBinLocationInput {
  @IsUUID()
  warehouseId: string;

  /**
   * Плоский код ячейки. Маршрут сборки строится сортировкой по нему,
   * поэтому используйте ведущие нули: A-01-03-02, а не A-1-3-2.
   */
  @IsString()
  @Length(1, 64)
  code: string;

  @IsOptional()
  @IsIn(BIN_KINDS as unknown as string[])
  kind?: BinKind;
}

export class UpdateBinLocationDto implements UpdateBinLocationInput {
  @IsOptional()
  @IsString()
  @Length(1, 64)
  code?: string;

  @IsOptional()
  @IsIn(BIN_KINDS as unknown as string[])
  kind?: BinKind;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}
