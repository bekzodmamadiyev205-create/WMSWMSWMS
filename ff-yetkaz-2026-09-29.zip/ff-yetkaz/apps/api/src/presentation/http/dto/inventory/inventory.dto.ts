import { Transform, Type } from 'class-transformer';
import {
  IsBoolean,
  IsDateString,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Min,
  NotEquals,
} from 'class-validator';
import {
  INVENTORY_UNIT_STATUSES,
  STOCK_SORT_FIELDS,
  type InventoryUnitStatus,
  type SortDirection,
  type StockSortField,
  type StockTableQuery,
} from '@ff/shared';
import type {
  AdjustStockInput,
  MoveStockInput,
  MovementsQueryInput,
  ReleaseInput,
  ReserveInput,
  StockInInput,
  StockQueryInput,
} from '../../../../application/inventory/inventory.input';

export class StockInDto implements StockInInput {
  @IsUUID()
  skuId: string;

  @IsUUID()
  warehouseId: string;

  @IsUUID()
  binId: string;

  @IsInt()
  @Min(1)
  quantity: number;

  /** Обязателен для SKU с партионным учётом. */
  @IsOptional()
  @IsString()
  @Length(1, 64)
  lotCode?: string;

  /** Обязателен для SKU с учётом срока годности. */
  @IsOptional()
  @IsDateString()
  expiryDate?: string;

  /** Куда кладём: обычно AVAILABLE, при браке — DAMAGED или QUARANTINE. */
  @IsOptional()
  @IsIn(INVENTORY_UNIT_STATUSES as unknown as string[])
  status?: InventoryUnitStatus;

  @IsOptional()
  @IsString()
  @Length(1, 512)
  comment?: string;
}

export class MoveStockDto implements MoveStockInput {
  @IsUUID()
  skuId: string;

  @IsUUID()
  warehouseId: string;

  @IsUUID()
  fromBinId: string;

  @IsIn(INVENTORY_UNIT_STATUSES as unknown as string[])
  fromStatus: InventoryUnitStatus;

  @IsUUID()
  toBinId: string;

  @IsIn(INVENTORY_UNIT_STATUSES as unknown as string[])
  toStatus: InventoryUnitStatus;

  @IsOptional()
  @IsUUID()
  lotId?: string;

  @IsInt()
  @Min(1)
  quantity: number;

  @IsOptional()
  @IsString()
  @Length(1, 512)
  comment?: string;
}

export class AdjustStockDto implements AdjustStockInput {
  @IsUUID()
  skuId: string;

  @IsUUID()
  warehouseId: string;

  @IsUUID()
  binId: string;

  @IsOptional()
  @IsUUID()
  lotId?: string;

  @IsOptional()
  @IsIn(INVENTORY_UNIT_STATUSES as unknown as string[])
  status?: InventoryUnitStatus;

  /** Со знаком: +5 — нашли лишнее, −3 — недостача. Ноль бессмысленен. */
  @IsInt()
  @NotEquals(0)
  delta: number;

  /** Причина обязательна: корректировка без объяснения обесценивает журнал. */
  @IsString()
  @IsNotEmpty({ message: 'Причина корректировки обязательна.' })
  @Length(3, 512)
  comment: string;
}

export class ReserveDto implements ReserveInput {
  @IsString()
  @Length(1, 32)
  ownerType: string;

  @IsString()
  @Length(1, 64)
  ownerId: string;

  @IsUUID()
  skuId: string;

  @IsUUID()
  warehouseId: string;

  @IsInt()
  @Min(1)
  quantity: number;
}

export class ReleaseDto implements ReleaseInput {
  @IsString()
  @Length(1, 32)
  ownerType: string;

  @IsString()
  @Length(1, 64)
  ownerId: string;

  @IsOptional()
  @IsString()
  @Length(1, 512)
  reason?: string;
}

export class StockQuery implements StockQueryInput {
  @IsOptional()
  @IsUUID()
  skuId?: string;

  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  /** Для оператора: чей товар смотрим. У селлера область берётся из токена. */
  @IsOptional()
  @IsUUID()
  sellerId?: string;
}

export class MovementsQuery implements MovementsQueryInput {
  @IsOptional()
  @IsUUID()
  skuId?: string;

  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number;
}

// ------------------------------------------------- витрина остатков (таблица)

export class StockTableQueryDto implements StockTableQuery {
  /** Для оператора: чей товар смотрим. У селлера область берётся из токена. */
  @IsOptional()
  @IsUUID()
  sellerId?: string;

  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @IsOptional()
  @IsIn(INVENTORY_UNIT_STATUSES as unknown as string[])
  status?: InventoryUnitStatus;

  /** Артикул, название, штрихкод — либо номер заказа (наш FF-код или клиентский). */
  @IsOptional()
  @IsString()
  @Length(1, 128)
  search?: string;

  @IsOptional()
  @IsDateString()
  dateFrom?: string;

  @IsOptional()
  @IsDateString()
  dateTo?: string;

  /**
   * Строка остатка не удаляется никогда — обнулённых срезов со временем
   * становится больше, чем настоящих, поэтому по умолчанию их не показываем.
   */
  @IsOptional()
  @Transform(({ value }) => value === true || value === 'true' || value === '1')
  @IsBoolean()
  includeZero?: boolean;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  pageSize?: number;

  @IsOptional()
  @IsIn(STOCK_SORT_FIELDS as unknown as string[])
  sort?: StockSortField;

  @IsOptional()
  @IsIn(['asc', 'desc'])
  direction?: SortDirection;
}
