import { Allow, IsBoolean, IsIn, IsInt, IsOptional, IsString, Length, Matches, Max, Min } from 'class-validator';
import type { CreateOrderCategoryPayload } from '@ff/shared';
import type {
  ListOrderCategoriesQueryInput,
  UpdateOrderCategoryInput,
} from '../../../../application/order-categories/order-categories.input';

/**
 * Форма кода повторяет CHECK `order_categories_code_shape` в БД. Дублирование
 * намеренное: без проверки в DTO пользователь получил бы вместо подсказки
 * сырое нарушение ограничения, а без проверки в БД код мог бы приехать мимо API.
 */
export const ORDER_CATEGORY_CODE_RE = /^[A-Z][A-Z0-9_]*$/;

const ORDER_CATEGORY_COLOR_RE = /^#[0-9a-f]{6}$/i;

const CODE_MESSAGE = 'Код категории — латиница в верхнем регистре, например MARKETPLACE.';
const COLOR_MESSAGE = 'Цвет — hex вида #6366f1.';

export class CreateOrderCategoryDto implements CreateOrderCategoryPayload {
  @IsString()
  @Length(2, 32)
  @Matches(ORDER_CATEGORY_CODE_RE, { message: CODE_MESSAGE })
  code: string;

  @IsString()
  @Length(1, 128)
  name: string;

  @Allow()
  @IsOptional()
  @IsString()
  @Length(0, 512)
  description?: string | null;

  /** Не задан — сервис берёт следующий свободный цвет из палитры. */
  @Allow()
  @IsOptional()
  @IsString()
  @Matches(ORDER_CATEGORY_COLOR_RE, { message: COLOR_MESSAGE })
  color?: string | null;

  @IsOptional()
  @IsInt()
  @Min(0)
  @Max(9999)
  sortOrder?: number;
}

export class UpdateOrderCategoryDto implements UpdateOrderCategoryInput {
  /**
   * Код неизменяем — как у селлера и отдела: по нему связаны выгрузки и отчёты.
   * Поле объявлено с `@Allow()` НЕ для того, чтобы его принимать, а чтобы оно
   * дошло до сервиса и получило внятный отказ. Иначе `forbidNonWhitelisted`
   * ответил бы безличным «property code should not exist».
   */
  @Allow()
  code?: string;

  @IsOptional()
  @IsString()
  @Length(1, 128)
  name?: string;

  @Allow()
  @IsOptional()
  @IsString()
  @Length(0, 512)
  description?: string | null;

  @Allow()
  @IsOptional()
  @IsString()
  @Matches(ORDER_CATEGORY_COLOR_RE, { message: COLOR_MESSAGE })
  color?: string | null;

  @IsOptional()
  @IsInt()
  @Min(0)
  @Max(9999)
  sortOrder?: number;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class ListOrderCategoriesQuery implements ListOrderCategoriesQueryInput {
  /**
   * Строка, а не boolean: в query всё приходит текстом, а глобальный
   * ValidationPipe включён без `enableImplicitConversion` — «false» иначе
   * превратился бы в истинную строку.
   */
  @IsOptional()
  @IsIn(['true', 'false'])
  includeInactive?: 'true' | 'false';
}
