import {
  IsBoolean,
  IsDefined,
  IsInt,
  IsOptional,
  IsString,
  Length,
  Matches,
  Max,
  Min,
} from 'class-validator';
import type { UpdateCarrierInput } from '../../../../infrastructure/config-store/config-store.input';

export class UpdateSettingDto {
  /** Тип проверяется сервисом по объявленному типу настройки. */
  @IsDefined()
  value: unknown;
}

export class UpdateCarrierDto implements UpdateCarrierInput {
  @IsOptional()
  @IsString()
  @Length(2, 120)
  name?: string;

  @IsOptional()
  @Matches(/^https?:\/\/\S+$/, { message: 'baseUrl должен начинаться с http:// или https://' })
  baseUrl?: string;

  @IsOptional()
  @Matches(/^\/\S*$/, { message: 'handoffPath должен начинаться со слэша' })
  handoffPath?: string;

  @IsOptional()
  @IsInt()
  @Min(1000)
  @Max(120_000)
  timeoutMs?: number;

  /** Имя переменной окружения, а не сам секрет. */
  @IsOptional()
  @Matches(/^[A-Z][A-Z0-9_]*$/, { message: 'secretEnvKey — имя переменной окружения' })
  secretEnvKey?: string;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}
