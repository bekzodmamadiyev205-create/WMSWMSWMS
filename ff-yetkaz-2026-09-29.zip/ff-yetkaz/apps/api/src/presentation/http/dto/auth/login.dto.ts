import { IsEmail, IsNotEmpty, IsString, MaxLength } from 'class-validator';
import type { LoginRequest } from '@ff/shared';

export class LoginDto implements LoginRequest {
  @IsEmail({}, { message: 'Некорректный email.' })
  @MaxLength(320)
  email: string;

  // На логине длину не проверяем: политика паролей — дело регистрации,
  // а здесь такая проверка лишь подсказывает атакующему формат.
  @IsString()
  @IsNotEmpty({ message: 'Пароль обязателен.' })
  @MaxLength(1024)
  password: string;
}
