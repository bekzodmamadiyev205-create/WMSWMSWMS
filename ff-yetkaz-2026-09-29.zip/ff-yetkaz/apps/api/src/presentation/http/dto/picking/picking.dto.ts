import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Min,
} from 'class-validator';
import { PICK_TASK_STATUSES, type PickTaskStatus } from '@ff/shared';
import type {
  AssignPickTaskInput,
  CreatePickTaskInput,
  ListPickTasksInput,
  ManualPickInput,
  PickScanInput,
  ShortPickInput,
} from '../../../../application/picking/picking.input';

export class CreatePickTaskDto implements CreatePickTaskInput {
  /** Список заказов. Несколько — batch-задание (решение PM: выбирает оператор). */
  @IsArray()
  @ArrayMinSize(1)
  @IsUUID('4', { each: true })
  orderIds: string[];
}

export class AssignPickTaskDto implements AssignPickTaskInput {
  /** Не указан — сборщик берёт задание на себя. */
  @IsOptional()
  @IsUUID()
  userId?: string;
}

export class PickScanDto implements PickScanInput {
  @IsString()
  @Length(1, 64)
  barcode: string;

  @IsInt()
  @Min(1)
  quantity: number;
}

/**
 * Ручное подтверждение отбора по строке задания.
 *
 * Штрихкода тут нет намеренно: строка задания уже однозначно задаёт SKU, ячейку
 * и партию — идентифицировать товар ещё раз нечем и незачем.
 */
export class ManualPickDto implements ManualPickInput {
  @IsInt()
  @Min(1)
  quantity: number;
}

export class ShortPickDto implements ShortPickInput {
  /** Причина обязательна: недобор — это расхождение, его нужно объяснить. */
  @IsString()
  @Length(3, 512)
  reason: string;
}

export class ListPickTasksQuery implements ListPickTasksInput {
  @IsOptional()
  @IsIn(PICK_TASK_STATUSES as unknown as string[])
  status?: PickTaskStatus;

  /** 'true' — только мои задания. */
  @IsOptional()
  @IsIn(['true', 'false'])
  mine?: 'true' | 'false';

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number;
}
