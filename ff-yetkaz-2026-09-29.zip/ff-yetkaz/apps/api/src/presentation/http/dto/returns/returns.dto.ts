import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Matches,
  Min,
  ValidateNested,
} from 'class-validator';
import {
  EXPORT_FORMATS,
  RETURN_ITEM_CONDITIONS,
  RETURN_REASONS,
  RETURN_SORT_FIELDS,
  RETURN_STATUSES,
  SORT_DIRECTIONS,
  type CreateReturnPayload,
  type ExportFormat,
  type MoveReturnPayload,
  type ReturnItemCondition,
  type ReturnListQuery,
  type ReturnReason,
  type ReturnSortField,
  type ReturnStatus,
  type SortDirection,
  type StoreReturnPayload,
} from '@ff/shared';
import type { CancelReturnInput } from '../../../../application/returns/returns.input';

const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export class CreateReturnItemDto {
  @IsUUID()
  skuId: string;

  @IsInt()
  @Min(1)
  quantity: number;

  @IsOptional()
  @IsIn(RETURN_ITEM_CONDITIONS as unknown as string[])
  condition?: ReturnItemCondition;
}

export class CreateReturnDto implements CreateReturnPayload {
  @IsUUID()
  sellerId: string;

  @IsUUID()
  warehouseId: string;

  /** Возврат без заказа допустим: клиент вернул мимо нас, перепутанная посылка. */
  @IsOptional()
  @IsUUID()
  orderId?: string | null;

  // Причина — закрытый справочник, а не свободный текст: по ней строится
  // аналитика, а свободный текст в отчёте превращается в сто вариантов «брак».
  @IsIn(RETURN_REASONS as unknown as string[])
  reason: ReturnReason;

  @IsOptional()
  @IsString()
  @Length(1, 1024)
  comment?: string | null;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => CreateReturnItemDto)
  items: CreateReturnItemDto[];

  @IsOptional()
  @IsBoolean()
  markOrderReturned?: boolean;
}

export class StoreReturnLineDto {
  @IsUUID()
  itemId: string;

  /** Годное — в доступный остаток. Остальное из строки уходит в брак. */
  @IsInt()
  @Min(0)
  goodQuantity: number;

  @IsInt()
  @Min(0)
  damagedQuantity: number;

  /** Пусто — берётся ячейка STORAGE склада. */
  @IsOptional()
  @IsUUID()
  binId?: string | null;
}

export class StoreReturnDto implements StoreReturnPayload {
  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => StoreReturnLineDto)
  lines: StoreReturnLineDto[];

  @IsOptional()
  @IsString()
  @Length(1, 512)
  comment?: string | null;
}

export class MoveReturnDto implements MoveReturnPayload {
  @IsUUID()
  binId: string;

  @IsOptional()
  @IsString()
  @Length(1, 512)
  comment?: string | null;
}

export class CancelReturnDto implements CancelReturnInput {
  // Причина обязательна: отменённый возврат без объяснения — это пропавший со
  // склада товар, о котором некого спросить.
  @IsString()
  @Length(3, 512)
  comment: string;
}

export class ReturnListQueryDto implements ReturnListQuery {
  @IsOptional()
  @IsUUID()
  sellerId?: string;

  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @IsOptional()
  @IsIn(RETURN_STATUSES as unknown as string[])
  status?: ReturnStatus;

  @IsOptional()
  @IsIn(RETURN_REASONS as unknown as string[])
  reason?: ReturnReason;

  /** Номер возврата, номер заказа или артикул/название товара. */
  @IsOptional()
  @IsString()
  @Length(1, 128)
  search?: string;

  // Границы периода — календарные даты `ГГГГ-ММ-ДД`, обе включительно.
  // Время сюда не принимается намеренно: «по 20 августа 14:00» в отчёте о
  // возвратах не значит ничего, а правый край сервер сам двигает на сутки.
  @IsOptional()
  @Matches(ISO_DATE_RE, { message: 'dateFrom — дата в формате ГГГГ-ММ-ДД.' })
  dateFrom?: string;

  @IsOptional()
  @Matches(ISO_DATE_RE, { message: 'dateTo — дата в формате ГГГГ-ММ-ДД.' })
  dateTo?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  pageSize?: number;

  @IsOptional()
  @IsIn(RETURN_SORT_FIELDS as unknown as string[])
  sort?: ReturnSortField;

  @IsOptional()
  @IsIn(SORT_DIRECTIONS as unknown as string[])
  direction?: SortDirection;

  // Формат выгрузки. Пока он один, но параметр принимается: при
  // `forbidNonWhitelisted` клиент, который честно шлёт `?format=xlsx`,
  // иначе получал бы 400 вместо файла.
  @IsOptional()
  @IsIn(EXPORT_FORMATS as unknown as string[])
  format?: ExportFormat;
}
