import { IsBoolean, IsEmail, IsOptional, IsString, Length, MaxLength } from 'class-validator';
import type {
  CreateSellerInput,
  UpdateSellerInput,
} from '../../../../application/mdm/mdm.input';

export class CreateSellerDto implements CreateSellerInput {
  @IsString()
  @Length(2, 32)
  code: string;

  @IsString()
  @Length(2, 256)
  legalName: string;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  taxId?: string;

  @IsOptional()
  @IsEmail({}, { message: 'Некорректный контактный email.' })
  @MaxLength(320)
  contactEmail?: string;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  contactPhone?: string;

  @IsOptional()
  @IsString()
  @MaxLength(512)
  address?: string;
}

export class UpdateSellerDto implements UpdateSellerInput {
  @IsOptional()
  @IsString()
  @Length(2, 256)
  legalName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  taxId?: string;

  @IsOptional()
  @IsEmail({}, { message: 'Некорректный контактный email.' })
  @MaxLength(320)
  contactEmail?: string;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  contactPhone?: string;

  @IsOptional()
  @IsString()
  @MaxLength(512)
  address?: string;

  /** Удаления нет — справочник только деактивируется. */
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}
