import { IsIn, IsOptional, IsUUID, Matches } from 'class-validator';
import {
  ANALYTICS_GRANULARITIES,
  EXPORT_FORMATS,
  type AnalyticsGranularity,
  type ExportFormat,
} from '@ff/shared';

/** Границы отчёта — календарные даты, не мгновения: BI считает по дням. */
const DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Общие параметры среза. Пустой запрос — валидный: сервис сам подставит
 * последние 30 дней, включая сегодня.
 */
export class AnalyticsRangeQueryDto {
  @IsOptional()
  @Matches(DATE_ONLY, { message: 'dateFrom — дата в формате YYYY-MM-DD' })
  dateFrom?: string;

  @IsOptional()
  @Matches(DATE_ONLY, { message: 'dateTo — дата в формате YYYY-MM-DD' })
  dateTo?: string;

  /**
   * Для роли SELLER параметр игнорируется — область берётся из токена.
   * Оставлен в схеме, чтобы подстановка чужого идентификатора отвечала
   * собственными данными, а не ошибкой валидации: молчаливый отказ здесь
   * информативнее для атакующего, чем 400.
   */
  @IsOptional()
  @IsUUID()
  sellerId?: string;

  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @IsOptional()
  @IsUUID()
  categoryId?: string;
}

export class AnalyticsOverviewQueryDto extends AnalyticsRangeQueryDto {
  @IsOptional()
  @IsIn(ANALYTICS_GRANULARITIES as unknown as string[], {
    message: 'granularity — day, week или month',
  })
  granularity?: AnalyticsGranularity;
}

export class SellerAnalyticsQueryDto extends AnalyticsRangeQueryDto {}

/**
 * Параметры выгрузки повторяют параметры списка ОДИН В ОДИН: выгрузка,
 * которая отдаёт не то, что человек видит на экране, хуже отсутствующей.
 * `format` пока принимает единственное значение, но принимается уже сейчас —
 * чтобы добавление CSV не меняло контракт ручки.
 */
export class SellerAnalyticsExportQueryDto extends AnalyticsRangeQueryDto {
  @IsOptional()
  @IsIn(EXPORT_FORMATS as unknown as string[], { message: 'format — только xlsx' })
  format?: ExportFormat;
}
