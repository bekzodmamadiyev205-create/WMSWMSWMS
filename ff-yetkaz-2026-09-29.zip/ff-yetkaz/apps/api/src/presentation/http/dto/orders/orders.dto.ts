import { Transform, Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsIn,
  IsInt,
  IsNumberString,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Matches,
  Min,
  ValidateIf,
  ValidateNested,
} from 'class-validator';
import {
  ORDER_SORT_FIELDS,
  ORDER_STATUSES,
  SORT_DIRECTIONS,
  type OrderImportLineDto,
  type OrderImportOrderDto,
  type OrderListQuery,
  type OrderSortField,
  type OrderStatus,
  type SortDirection,
  type UpdateOrderPayload,
} from '@ff/shared';
import type {
  CancelOrderInput,
  CreateOrderInput,
  CreateOrderLineInput,
  ImportOrdersInput,
} from '../../../../application/orders/orders.input';

/** Границы периода — только календарная дата: время задаёт сервер. */
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Булев параметр в query приходит строкой. `@IsBoolean()` без приведения
 * отбивает `?includeSplitChildren=true` как «не булево» — и фильтр молча
 * перестаёт работать ровно тогда, когда им пользуются.
 */
const toBoolean = ({ value }: { value: unknown }): unknown =>
  value === undefined ? undefined : value === true || value === 'true' || value === '1';

/**
 * «Поле прислали» — в отличие от `@IsOptional()`, который пропускает и
 * `undefined`, и `null`.
 *
 * Нужно там, где `null` значит не «не трогай», а «очисти» — и очищать нельзя.
 * С `@IsOptional()` такой `null` доезжал до сервиса и падал `TypeError`'ом на
 * `.trim()`, то есть пятисоткой вместо внятного 400.
 */
const isSubmitted = (_object: unknown, value: unknown): boolean => value !== undefined;

export class OrderLineInput implements CreateOrderLineInput {
  @IsUUID()
  skuId: string;

  @IsInt()
  @Min(1)
  quantity: number;
}

export class CreateOrderDto implements CreateOrderInput {
  @IsUUID()
  sellerId: string;

  /** Канал-источник: маркетплейс, сайт селлера, ручной ввод. */
  @IsString()
  @Length(1, 32)
  channel: string;

  /** Номер заказа в канале. Вместе с каналом и селлером даёт естественный ключ. */
  @IsString()
  @Length(1, 64)
  externalId: string;

  @IsString()
  @Length(1, 256)
  recipientName: string;

  @IsString()
  @Length(3, 32)
  recipientPhone: string;

  @IsString()
  @Length(3, 512)
  address: string;

  @IsOptional()
  @IsString()
  @Length(1, 128)
  region?: string;

  /**
   * Строкой: деньги через float недопустимы. Тип допускает `null` не для
   * красоты — `@IsOptional()` его пропускает, и сервис обязан считать «сумма
   * есть, валюта null» тем же нарушением правила «только вместе», что и
   * «валюты нет вовсе».
   */
  @IsOptional()
  @IsNumberString({}, { message: 'codAmount должен быть числом в виде строки.' })
  codAmount?: string | null;

  @IsOptional()
  @IsString()
  @Length(3, 3)
  currency?: string | null;

  @IsOptional()
  @IsNumberString({}, { message: 'weightKg должен быть числом в виде строки.' })
  weightKg?: string;

  /** Категория заказа из справочника. Не задана — заказ попадёт в «без категории». */
  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => OrderLineInput)
  lines: OrderLineInput[];
}

export class OrderImportLineInput implements OrderImportLineDto {
  /** Артикул селлера, а не `skuId`: в выгрузке клиента идентификаторов FF нет. */
  @IsString()
  @Length(1, 64)
  skuCode: string;

  @IsInt()
  @Min(1)
  quantity: number;
}

export class OrderImportOrderInput implements OrderImportOrderDto {
  /** Номер строки файла — отчёт должен указывать на то, что оператор видит в Excel. */
  @IsInt()
  @Min(1)
  fileLine: number;

  @IsString()
  @Length(1, 64)
  externalId: string;

  @IsString()
  @Length(1, 256)
  recipientName: string;

  @IsString()
  @Length(3, 32)
  recipientPhone: string;

  @IsString()
  @Length(3, 512)
  address: string;

  @IsOptional()
  @IsString()
  @Length(1, 128)
  region?: string;

  @IsOptional()
  @IsNumberString({}, { message: 'codAmount должен быть числом в виде строки.' })
  codAmount?: string;

  @IsOptional()
  @IsString()
  @Length(3, 3)
  currency?: string;

  @IsOptional()
  @IsNumberString({}, { message: 'weightKg должен быть числом в виде строки.' })
  weightKg?: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => OrderImportLineInput)
  lines: OrderImportLineInput[];
}

export class ImportOrdersDto implements ImportOrdersInput {
  @IsUUID()
  sellerId: string;

  @IsString()
  @Length(1, 32)
  channel: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => OrderImportOrderInput)
  orders: OrderImportOrderInput[];
}

/**
 * Поиск заказа по отсканированному коду.
 *
 * Отдельный DTO, а не проверка внутри сервиса: правило «код — ровно одна строка»
 * должно быть видно в сигнатуре ручки. Express складывает повторённый
 * `?code=A&code=B` в МАССИВ, а `?code[$ne]=x` — в объект; и то и другое доезжало
 * до `code.trim()` и превращало кривой ввод сканера в 500 INTERNAL_ERROR —
 * в журнале это выглядит отказом сервера, хотя виноват запрос.
 */
export class OrderByCodeQueryDto {
  @IsString({ message: 'code должен быть строкой и указываться ровно один раз.' })
  @Length(1, 128, { message: 'code — от 1 до 128 символов.' })
  code: string;
}

export class CancelOrderDto implements CancelOrderInput {
  @IsOptional()
  @IsString()
  @Length(1, 512)
  reason?: string;
}

/**
 * Запрос списка заказов: фильтры, поиск, период, страница и сортировка.
 *
 * Тот же класс принимают `/orders/totals` и `/orders/export` — выгрузка,
 * которая отдаёт не то же, что видно на экране, бесполезна, а гарантировать
 * это можно только общим набором параметров.
 *
 * Параметра `limit` больше нет: страница задаётся парой page/pageSize, и
 * глобальный `forbidNonWhitelisted` отобьёт старый вызов явной ошибкой,
 * а не тихо отдаст первую сотню строк.
 */
export class OrderListQueryDto implements OrderListQuery {
  @IsOptional()
  @IsUUID()
  sellerId?: string;

  @IsOptional()
  @IsIn(ORDER_STATUSES as unknown as string[])
  status?: OrderStatus;

  /** Несколько статусов через запятую: канбан просит сразу пачку колонок. */
  @IsOptional()
  @IsString()
  @Length(1, 256)
  statuses?: string;

  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @IsOptional()
  @IsString()
  @Length(1, 32)
  channel?: string;

  /** Код FF, номер клиента, получатель или телефон — одним полем. */
  @IsOptional()
  @IsString()
  @Length(1, 128)
  search?: string;

  @IsOptional()
  @Matches(ISO_DATE, { message: 'dateFrom — дата в формате ГГГГ-ММ-ДД.' })
  dateFrom?: string;

  @IsOptional()
  @Matches(ISO_DATE, { message: 'dateTo — дата в формате ГГГГ-ММ-ДД.' })
  dateTo?: string;

  /** По умолчанию список показывает только заказы канала, без частей сплита. */
  @IsOptional()
  @Transform(toBoolean)
  @IsBoolean()
  includeSplitChildren?: boolean;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  pageSize?: number;

  @IsOptional()
  @IsIn(ORDER_SORT_FIELDS as unknown as string[])
  sort?: OrderSortField;

  @IsOptional()
  @IsIn(SORT_DIRECTIONS as unknown as string[])
  direction?: SortDirection;
}

/**
 * Правка заказа. Все поля необязательны, и `null` здесь значит «очистить»,
 * а `undefined` — «не трогать»: без этого различия нельзя снять категорию,
 * не снеся заодно адрес.
 *
 * `@IsOptional()` в class-validator пропускает и `undefined`, и `null` — это
 * нужно там, где очистка законна (категория, регион, вес). Там, где очистка
 * означала бы заказ без получателя или без адреса, стоит `@ValidateIf`:
 * присланный `null` обязан получить 400, а не доехать до `.trim()`.
 */
export class UpdateOrderDto implements UpdateOrderPayload {
  @IsOptional()
  @IsUUID()
  categoryId?: string | null;

  @IsOptional()
  @IsString()
  @Length(1, 128)
  region?: string | null;

  /**
   * Получатель, телефон и адрес очистке НЕ подлежат: заказ без них никуда не
   * поедет, а колонки в схеме `NOT NULL`. Поэтому здесь `@ValidateIf`, а не
   * `@IsOptional()` — присланный `null` доходит до `@IsString` и получает 400.
   */
  @ValidateIf(isSubmitted)
  @IsString({ message: 'recipientName нельзя очистить: поле обязательно.' })
  @Length(1, 256)
  recipientName?: string;

  @ValidateIf(isSubmitted)
  @IsString({ message: 'recipientPhone нельзя очистить: поле обязательно.' })
  @Length(3, 32)
  recipientPhone?: string;

  @ValidateIf(isSubmitted)
  @IsString({ message: 'address нельзя очистить: поле обязательно.' })
  @Length(3, 512)
  address?: string;

  /** Строкой и тем же правилом, что при создании: деньги и вес без float. */
  @IsOptional()
  @IsNumberString({}, { message: 'weightKg должен быть числом в виде строки.' })
  weightKg?: string | null;
}
