import { createHash } from 'node:crypto';
import {
  CallHandler,
  ConflictException,
  ExecutionContext,
  HttpStatus,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { Response } from 'express';
import { from, mergeMap, of, throwError, type Observable } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import type { FfRequest } from './types/request';
import { IdempotencyService } from '../../infrastructure/idempotency/idempotency.service';

const WRITE_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

/** Ключ метаданных @HttpCode() из @nestjs/common — статус, который отдаст роут. */
const HTTP_CODE_METADATA = '__httpCode__';

/** Детерминированная сериализация: порядок ключей не должен менять хэш тела. */
function canonicalize(value: unknown): string {
  if (value === null || value === undefined) return 'null';
  if (typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(',')}]`;
  const record = value as Record<string, unknown>;
  const keys = Object.keys(record).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalize(record[k])}`).join(',')}}`;
}

/**
 * Дедупликация write-запросов по заголовку `Idempotency-Key`.
 * Заголовок необязателен: без него запрос идёт обычным путём.
 */
@Injectable()
export class IdempotencyInterceptor implements NestInterceptor {
  constructor(
    private readonly service: IdempotencyService,
    private readonly reflector: Reflector,
  ) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    if (context.getType() !== 'http') return next.handle();

    const request = context.switchToHttp().getRequest<FfRequest>();
    if (!WRITE_METHODS.has(request.method)) return next.handle();

    const rawKey = request.headers['idempotency-key'];
    const key = (Array.isArray(rawKey) ? rawKey[0] : rawKey)?.trim();
    if (!key) return next.handle();

    const endpoint = `${request.method} ${request.route?.path ?? request.path}`;
    const requestHash = createHash('sha256').update(canonicalize(request.body ?? null)).digest('hex');

    return from(this.service.begin(key, endpoint, requestHash)).pipe(
      switchMap((begin) => {
        if (begin.kind === 'conflict') {
          throw new ConflictException(
            begin.reason === 'BODY_MISMATCH'
              ? 'Idempotency-Key уже использован с другим телом запроса.'
              : 'Запрос с этим Idempotency-Key ещё выполняется.',
          );
        }

        if (begin.kind === 'replay') {
          // Статус ответа детерминирован маршрутом, поэтому повтор отдаёт тот же
          // код; помечаем ответ заголовком, чтобы повтор был виден клиенту.
          context.switchToHttp().getResponse<Response>().setHeader('Idempotent-Replay', 'true');
          return of(begin.body);
        }

        const status =
          this.reflector.get<number>(HTTP_CODE_METADATA, context.getHandler()) ??
          (request.method === 'POST' ? HttpStatus.CREATED : HttpStatus.OK);

        return next.handle().pipe(
          mergeMap(async (body) => {
            await this.service.complete(begin.id, status, body ?? null);
            return body;
          }),
          catchError((error: unknown) =>
            // Неуспех не кэшируем — освобождаем ключ под повторную попытку.
            from(this.service.abandon(begin.id)).pipe(mergeMap(() => throwError(() => error))),
          ),
        );
      }),
    );
  }
}
