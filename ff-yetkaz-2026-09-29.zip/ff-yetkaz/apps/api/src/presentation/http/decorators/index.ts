import { SetMetadata, createParamDecorator, type ExecutionContext } from '@nestjs/common';
import type { AuthPrincipal, Role } from '@ff/shared';
import type { FfRequest } from '../types/request';

export const IS_PUBLIC_KEY = 'ff:isPublic';
/** Снимает требование авторизации с ручки (логин, health). */
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);

export const ROLES_KEY = 'ff:roles';
/** Доступ разрешён, если у пользователя есть ХОТЯ БЫ одна из перечисленных ролей. */
export const Roles = (...roles: Role[]) => SetMetadata(ROLES_KEY, roles);

export const CurrentUser = createParamDecorator(
  (field: keyof AuthPrincipal | undefined, context: ExecutionContext) => {
    const request = context.switchToHttp().getRequest<FfRequest>();
    return field ? request.user?.[field] : request.user;
  },
);

/** Пользователь + ip + correlationId одним объектом — то, что нужно аудиту. */
export const Actor = createParamDecorator((_data: unknown, context: ExecutionContext) => {
  const request = context.switchToHttp().getRequest<FfRequest>();
  return {
    user: request.user,
    ip: request.ip ?? null,
    correlationId: request.correlationId ?? null,
  };
});
