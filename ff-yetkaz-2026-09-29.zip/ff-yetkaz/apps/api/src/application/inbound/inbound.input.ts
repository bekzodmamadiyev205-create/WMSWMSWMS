import type { AsnStatus } from '@ff/shared';

/**
 * Формы входных данных приёмки.
 *
 * Живут рядом с сервисом, а не в presentation: прикладному слою нужна ФОРМА
 * данных, а декораторы class-validator существуют ради разбора HTTP-запроса.
 * Классы DTO в presentation объявляют `implements` этих интерфейсов — так
 * расхождение формы поймает сборка, а не боевой запрос.
 */

export interface CreateAsnLineInput {
  skuId: string;
  expectedQty: number;
}

export interface CreateAsnInput {
  sellerId: string;
  warehouseId: string;
  /** Номер поставки на стороне селлера. Защищён уникальным индексом от дублей. */
  externalRef?: string;
  expectedAt?: string;
  lines: CreateAsnLineInput[];
}

export interface CreateReceiptInput {
  asnId: string;
}

export interface ScanInput {
  /**
   * Штрихкод с коробки. Необязателен: товар опознаётся ЛИБО кодом, ЛИБО
   * строкой заявки — какой именно, решает уже сервис.
   */
  barcode?: string;
  /** Приём по строке заявки — для товара, у которого штрихкода ещё нет. */
  asnLineId?: string;
  quantity: number;
  lotCode?: string;
  expiryDate?: string;
}

export interface PutAwayInput {
  receiptLineId: string;
  /** Годное количество. Вместе с браком должно давать ровно принятое. */
  qtyOk: number;
  qtyDamaged: number;
  /** Ячейка хранения для годного товара. */
  binId: string;
}

export interface LinkAsnLineBarcodeInput {
  barcode: string;
}

export interface ListAsnsQueryInput {
  sellerId?: string;
  status?: AsnStatus;
}
