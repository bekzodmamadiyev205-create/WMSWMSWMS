import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import {
  asnFsm,
  receiptFsm,
  type AsnDto,
  type AsnStatus,
  type ReceiptCompletionDto,
  type ReceiptDto,
  type ReceiptLineDto,
  type SkuDto,
} from '@ff/shared';
import { FsmService } from '../fsm/fsm.service';
import {
  CodedConflictException,
  CodedNotFoundException,
} from '../errors/coded-exception';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import { isSellerVisible, resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { findBinByKind } from '../../infrastructure/database/repositories/bin-location.repository';
import { InboundRepository } from '../../infrastructure/database/repositories/inbound.repository';
import {
  AsnEntity,
  AsnLineEntity,
  BinLocationEntity,
  ReceiptEntity,
  ReceiptLineEntity,
  SellerEntity,
  SkuBarcodeEntity,
  SkuEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { InventoryService } from '../inventory/inventory.service';
import { SkusService } from '../mdm/skus.service';
import type {
  CreateAsnInput,
  CreateReceiptInput,
  LinkAsnLineBarcodeInput,
  ListAsnsQueryInput,
  PutAwayInput,
  ScanInput,
} from './inbound.input';

@Injectable()
export class InboundService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly inventory: InventoryService,
    private readonly fsm: FsmService,
    private readonly skus: SkusService,
    private readonly inbound: InboundRepository,
  ) {}

  // -------------------------------------------------------------------- ASN

  async createAsn(dto: CreateAsnInput, actor: ActorContext): Promise<AsnDto> {
    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: dto.sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    if (!seller.isActive) throw new ConflictException('Селлер деактивирован.');

    const warehouse = await this.dataSource
      .getRepository(WarehouseEntity)
      .findOne({ where: { id: dto.warehouseId } });
    if (!warehouse) throw new NotFoundException('Склад не найден.');
    if (!warehouse.isActive) throw new ConflictException('Склад деактивирован.');

    const skuIds = dto.lines.map((line) => line.skuId);
    if (new Set(skuIds).size !== skuIds.length) {
      throw new BadRequestException('В заявке повторяется один и тот же SKU.');
    }

    const skus = await this.dataSource.getRepository(SkuEntity).find({ where: skuIds.map((id) => ({ id })) });
    if (skus.length !== skuIds.length) throw new NotFoundException('Часть SKU не найдена.');
    for (const sku of skus) {
      // Заявка на чужой товар — почти наверняка ошибка оператора, а не бизнес-кейс.
      if (sku.sellerId !== dto.sellerId) {
        throw new BadRequestException(`SKU «${sku.skuCode}» принадлежит другому селлеру.`);
      }
      if (!sku.isActive) throw new ConflictException(`SKU «${sku.skuCode}» деактивирован.`);
    }

    const asnId = await this.dataSource.transaction(async (em) => {
      const asns = em.getRepository(AsnEntity);
      let asn: AsnEntity;
      try {
        asn = await asns.save(
          asns.create({
            sellerId: dto.sellerId,
            warehouseId: dto.warehouseId,
            externalRef: dto.externalRef?.trim() ?? null,
            status: 'DRAFT',
            expectedAt: dto.expectedAt ? new Date(dto.expectedAt) : null,
            hasDiscrepancy: false,
            createdBy: actor.user.id,
          }),
        );
      } catch (error) {
        if (uniqueViolationConstraint(error) === 'uq_asns_external_ref') {
          throw new ConflictException(
            `Заявка с номером «${dto.externalRef}» у этого селлера уже заведена.`,
          );
        }
        throw error;
      }

      const lines = em.getRepository(AsnLineEntity);
      for (const line of dto.lines) {
        await lines.insert({ asnId: asn.id, skuId: line.skuId, expectedQty: line.expectedQty });
      }
      return asn.id;
    });

    return this.getAsn(asnId, actor);
  }

  async submitAsn(id: string, actor: ActorContext): Promise<AsnDto> {
    await this.transitionAsn(id, 'SUBMITTED', actor);
    return this.getAsn(id, actor);
  }

  async cancelAsn(id: string, actor: ActorContext): Promise<AsnDto> {
    await this.transitionAsn(id, 'CANCELLED', actor);
    return this.getAsn(id, actor);
  }

  /**
   * Принудительное закрытие заявки. Нужно при недовозе: иначе ASN навсегда
   * останется в RECEIVING и будет висеть в очереди склада.
   */
  async closeAsn(id: string, actor: ActorContext): Promise<AsnDto> {
    await this.transitionAsn(id, 'COMPLETED', actor);
    return this.getAsn(id, actor);
  }

  async listAsns(query: ListAsnsQueryInput, actor: ActorContext): Promise<AsnDto[]> {
    const scope = resolveSellerScope(actor.user);

    const builder = this.dataSource
      .getRepository(AsnEntity)
      .createQueryBuilder('asn')
      .orderBy('asn.createdAt', 'DESC')
      .take(200);

    if (scope !== null) builder.andWhere('asn.sellerId = :scope', { scope });
    else if (query.sellerId) builder.andWhere('asn.sellerId = :sellerId', { sellerId: query.sellerId });
    if (query.status) builder.andWhere('asn.status = :status', { status: query.status });

    const asns = await builder.getMany();
    return Promise.all(asns.map((asn) => this.buildAsnDto(asn)));
  }

  async getAsn(id: string, actor: ActorContext): Promise<AsnDto> {
    const scope = resolveSellerScope(actor.user);
    const asn = await this.dataSource.getRepository(AsnEntity).findOne({ where: { id } });
    if (!asn || !isSellerVisible(scope, asn.sellerId)) {
      throw new NotFoundException('Заявка на поставку не найдена.');
    }
    return this.buildAsnDto(asn);
  }

  // ---------------------------------------------------------------- приёмка

  async createReceipt(dto: CreateReceiptInput, actor: ActorContext): Promise<ReceiptDto> {
    const asn = await this.dataSource.getRepository(AsnEntity).findOne({ where: { id: dto.asnId } });
    if (!asn) throw new NotFoundException('Заявка на поставку не найдена.');
    if (asn.status !== 'SUBMITTED' && asn.status !== 'RECEIVING') {
      throw new ConflictException(
        `Принимать можно только по отправленной заявке, текущий статус: ${asn.status}.`,
      );
    }

    // Ячейка приёмки должна быть заведена заранее: иначе товар пришлось бы
    // положить в первую попавшуюся, и «принято, но не разложено» стало бы неотличимо.
    await this.findBinByKind(asn.warehouseId, 'RECEIVING', true);

    const receiptId = await this.dataSource.transaction(async (em) => {
      if (asn.status === 'SUBMITTED') {
        await this.fsm.transition(
          asnFsm,
          'SUBMITTED',
          'RECEIVING',
          this.fsmContext('Asn', asn.id, actor),
          em,
        );
        await em.getRepository(AsnEntity).update({ id: asn.id }, { status: 'RECEIVING' });
      }

      const receipts = em.getRepository(ReceiptEntity);
      const receipt = await receipts.save(
        receipts.create({
          asnId: asn.id,
          warehouseId: asn.warehouseId,
          status: 'OPEN',
          receivedBy: actor.user.id,
          startedAt: new Date(),
          completedAt: null,
        }),
      );
      return receipt.id;
    });

    return this.buildReceiptDto(receiptId);
  }

  /**
   * Приём позиции: товар попадает в ячейку приёмки со статусом RECEIVED.
   * Раскладка по местам хранения — отдельным шагом (решение PM).
   *
   * Опознать товар можно двумя способами, и оба одинаково строгие:
   * штрихкодом (SKU ищется по всему справочнику, затем сверяется с заявкой)
   * или прямой ссылкой на строку заявки (товар назван однозначно). Второй путь
   * существует потому, что «есть штрихкод» и «товар заведён» — разные вещи:
   * без него позиция без кода не принимается вообще никак.
   */
  async scan(receiptId: string, dto: ScanInput, actor: ActorContext): Promise<ReceiptDto> {
    // Проверяем ДО всего остального: whitelist ValidationPipe пропускает оба
    // поля разом, а «принять и то и другое» означало бы молчаливый выбор одного.
    const barcode = dto.barcode?.trim() ?? '';
    if ((barcode !== '') === (dto.asnLineId !== undefined)) {
      throw new BadRequestException(
        'Укажите ровно одно: штрихкод товара или позицию заявки, по которой принимаете.',
      );
    }

    const receipt = await this.loadOpenReceipt(receiptId);
    const asn = await this.dataSource
      .getRepository(AsnEntity)
      .findOne({ where: { id: receipt.asnId } });
    if (!asn) throw new NotFoundException('Заявка на поставку не найдена.');
    // Приёмка живёт дольше заявки: её могли открыть, а ASN — закрыть руками при
    // недовозе. Без этой проверки через открытую приёмку товар доезжал бы до
    // остатка по формально завершённой поставке.
    if (asn.status !== 'SUBMITTED' && asn.status !== 'RECEIVING') {
      throw new ConflictException(
        `Заявка в статусе ${asn.status} — принимать по ней нельзя. Откройте новую заявку.`,
      );
    }

    // Резолв SKU — единственное, что различается у двух путей. Всё, что ниже
    // (ячейка приёмки, строка приёмки, движение остатка), общее: второй путь
    // записи в остаток появиться не должен.
    const { sku, comment } =
      dto.asnLineId !== undefined
        ? await this.resolveSkuByAsnLine(asn, dto.asnLineId)
        : await this.resolveSkuByBarcode(asn, barcode);

    const receivingBin = await this.findBinByKind(receipt.warehouseId, 'RECEIVING', true);

    await this.dataSource.transaction(async (em) => {
      const lotId = await this.inventory.resolveLot(em, sku, dto.lotCode, dto.expiryDate);

      await em.getRepository(ReceiptLineEntity).insert({
        receiptId: receipt.id,
        skuId: sku.id,
        lotId,
        qtyReceived: dto.quantity,
        qtyOk: 0,
        qtyDamaged: 0,
        binId: null,
        status: 'RECEIVED',
      });

      await this.inventory.applyMovement(
        em,
        {
          skuId: sku.id,
          warehouseId: receipt.warehouseId,
          lotId,
          to: { binId: receivingBin.id, status: 'RECEIVED' },
          quantity: dto.quantity,
          reason: 'RECEIPT',
          referenceType: 'RECEIPT',
          referenceId: receipt.id,
          comment,
        },
        actor,
      );
    });

    return this.buildReceiptDto(receipt.id);
  }

  /**
   * Привязка штрихкода к позиции заявки прямо с терминала приёмки.
   *
   * Права на справочник при этом НЕ расширяются: приёмщик может дописать код
   * только тому товару, который заявлен в поставке, которую он сейчас
   * принимает. Сама вставка идёт через SkusService — там уже разобран конфликт
   * глобальной уникальности и снятие прежнего основного флага.
   */
  async linkAsnLineBarcode(
    receiptId: string,
    asnLineId: string,
    dto: LinkAsnLineBarcodeInput,
    actor: ActorContext,
  ): Promise<SkuDto> {
    const receipt = await this.loadOpenReceipt(receiptId);
    const asnLine = await this.loadAsnLineOfReceipt(receipt.asnId, asnLineId);

    // Основным код становится, только если он первый: частичный индекс
    // uq_sku_barcodes_primary не даёт SKU двух основных кодов.
    const existingCodes = await this.dataSource
      .getRepository(SkuBarcodeEntity)
      .count({ where: { skuId: asnLine.skuId } });

    return this.skus.addBarcode(
      asnLine.skuId,
      {
        barcode: dto.barcode,
        // Код, который склад присвоил товару сам, — внутренний: выдавать его за
        // EAN нельзя, проверка контрольной цифры на нём не сойдётся.
        kind: 'INTERNAL',
        isPrimary: existingCodes === 0,
      },
      actor,
    );
  }

  /**
   * Инспекция и раскладка. Годное едет в ячейку хранения, брак — в ячейку брака.
   *
   * Статусная модель не разрешает RECEIVED → AVAILABLE напрямую, поэтому годное
   * проходит через INSPECTED: в журнале видно, что товар осмотрели, а не просто
   * «стал доступен».
   */
  async putAway(receiptId: string, dto: PutAwayInput, actor: ActorContext): Promise<ReceiptDto> {
    const receipt = await this.loadOpenReceipt(receiptId);

    const line = await this.dataSource
      .getRepository(ReceiptLineEntity)
      .findOne({ where: { id: dto.receiptLineId, receiptId: receipt.id } });
    if (!line) throw new NotFoundException('Позиция приёмки не найдена.');
    if (line.status === 'PUT_AWAY') {
      throw new ConflictException('Позиция уже разложена.');
    }
    if (dto.qtyOk + dto.qtyDamaged !== line.qtyReceived) {
      throw new BadRequestException(
        `Раскладка должна покрывать всё принятое: принято ${line.qtyReceived}, ` +
          `указано ${dto.qtyOk + dto.qtyDamaged}.`,
      );
    }

    const storageBin = await this.dataSource
      .getRepository(BinLocationEntity)
      .findOne({ where: { id: dto.binId } });
    if (!storageBin) throw new NotFoundException('Ячейка хранения не найдена.');
    if (storageBin.warehouseId !== receipt.warehouseId) {
      throw new BadRequestException('Ячейка принадлежит другому складу.');
    }
    if (!storageBin.isActive) throw new ConflictException('Ячейка деактивирована.');

    const receivingBin = await this.findBinByKind(receipt.warehouseId, 'RECEIVING', true);
    const damagedBin = await this.findBinByKind(receipt.warehouseId, 'DAMAGED', false);

    await this.dataSource.transaction(async (em) => {
      const common = {
        skuId: line.skuId,
        warehouseId: receipt.warehouseId,
        lotId: line.lotId,
        referenceType: 'RECEIPT' as const,
        referenceId: receipt.id,
      };

      if (dto.qtyOk > 0) {
        await this.inventory.applyMovement(
          em,
          {
            ...common,
            from: { binId: receivingBin.id, status: 'RECEIVED' },
            to: { binId: receivingBin.id, status: 'INSPECTED' },
            quantity: dto.qtyOk,
            reason: 'INSPECTION',
          },
          actor,
        );
        await this.inventory.applyMovement(
          em,
          {
            ...common,
            from: { binId: receivingBin.id, status: 'INSPECTED' },
            to: { binId: storageBin.id, status: 'AVAILABLE' },
            quantity: dto.qtyOk,
            reason: 'PUTAWAY',
          },
          actor,
        );
      }

      if (dto.qtyDamaged > 0) {
        // Если ячейка брака не заведена, брак остаётся в приёмочной зоне —
        // но уже со статусом DAMAGED, то есть вне доступного остатка.
        await this.inventory.applyMovement(
          em,
          {
            ...common,
            from: { binId: receivingBin.id, status: 'RECEIVED' },
            to: { binId: (damagedBin ?? receivingBin).id, status: 'DAMAGED' },
            quantity: dto.qtyDamaged,
            reason: 'DAMAGE',
          },
          actor,
        );
      }

      await em.getRepository(ReceiptLineEntity).update(
        { id: line.id },
        {
          qtyOk: dto.qtyOk,
          qtyDamaged: dto.qtyDamaged,
          binId: storageBin.id,
          status: 'PUT_AWAY',
        },
      );
    });

    return this.buildReceiptDto(receipt.id);
  }

  async completeReceipt(receiptId: string, actor: ActorContext): Promise<ReceiptCompletionDto> {
    const receipt = await this.loadOpenReceipt(receiptId);

    const pending = await this.dataSource
      .getRepository(ReceiptLineEntity)
      .count({ where: { receiptId: receipt.id, status: 'RECEIVED' } });
    if (pending > 0) {
      throw new ConflictException(
        `Нельзя завершить приёмку: ${pending} позиц. ещё не разложено по ячейкам.`,
      );
    }

    const asn = await this.dataSource
      .getRepository(AsnEntity)
      .findOne({ where: { id: receipt.asnId } });
    if (!asn) throw new NotFoundException('Заявка на поставку не найдена.');

    const lines = await this.asnProgress(asn.id);
    const discrepancies = lines
      .filter((line) => line.receivedQty !== line.expectedQty)
      .map((line) => ({
        skuId: line.skuId,
        expectedQty: line.expectedQty,
        receivedQty: line.receivedQty,
      }));
    const fullyReceived = lines.every((line) => line.receivedQty >= line.expectedQty);

    await this.dataSource.transaction(async (em) => {
      await this.fsm.transition(
        receiptFsm,
        'OPEN',
        'COMPLETED',
        this.fsmContext('Receipt', receipt.id, actor),
        em,
      );
      await em
        .getRepository(ReceiptEntity)
        .update({ id: receipt.id }, { status: 'COMPLETED', completedAt: new Date() });

      await em
        .getRepository(AsnEntity)
        .update({ id: asn.id }, { hasDiscrepancy: discrepancies.length > 0 });

      // Заявку закрываем автоматически только когда план выполнен целиком.
      // Недовоз оператор закрывает руками через closeAsn — это его решение.
      if (fullyReceived && asn.status === 'RECEIVING') {
        await this.fsm.transition(
          asnFsm,
          'RECEIVING',
          'COMPLETED',
          this.fsmContext('Asn', asn.id, actor),
          em,
        );
        await em.getRepository(AsnEntity).update({ id: asn.id }, { status: 'COMPLETED' });
      }
    });

    return {
      receipt: await this.buildReceiptDto(receipt.id),
      asnStatus: fullyReceived && asn.status === 'RECEIVING' ? 'COMPLETED' : asn.status,
      hasDiscrepancy: discrepancies.length > 0,
      discrepancies,
    };
  }

  async getReceipt(receiptId: string, actor: ActorContext): Promise<ReceiptDto> {
    const receipt = await this.dataSource
      .getRepository(ReceiptEntity)
      .findOne({ where: { id: receiptId } });
    if (!receipt) throw new NotFoundException('Приёмка не найдена.');

    const scope = resolveSellerScope(actor.user);
    if (scope !== null) {
      const asn = await this.dataSource
        .getRepository(AsnEntity)
        .findOne({ where: { id: receipt.asnId } });
      if (!asn || !isSellerVisible(scope, asn.sellerId)) {
        throw new NotFoundException('Приёмка не найдена.');
      }
    }
    return this.buildReceiptDto(receiptId);
  }

  // ------------------------------------------------------------- внутреннее

  private fsmContext(entityType: string, entityId: string, actor: ActorContext) {
    return {
      entityType,
      entityId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
    };
  }

  private async transitionAsn(id: string, to: AsnStatus, actor: ActorContext): Promise<void> {
    const asn = await this.dataSource.getRepository(AsnEntity).findOne({ where: { id } });
    if (!asn) throw new NotFoundException('Заявка на поставку не найдена.');

    await this.dataSource.transaction(async (em) => {
      await this.fsm.transition(asnFsm, asn.status, to, this.fsmContext('Asn', asn.id, actor), em);
      await em.getRepository(AsnEntity).update({ id: asn.id }, { status: to });
    });
  }

  /**
   * Путь скана: код → SKU → сверка с заявкой. Проверка «SKU заявлен в поставке»
   * живёт именно здесь, потому что только здесь товар найден по всему
   * справочнику и мог оказаться из чужой поставки.
   */
  private async resolveSkuByBarcode(
    asn: AsnEntity,
    barcode: string,
  ): Promise<{ sku: SkuEntity; comment: string | null }> {
    const found = await this.dataSource
      .getRepository(SkuBarcodeEntity)
      .findOne({ where: { barcode } });
    if (!found) {
      throw new CodedNotFoundException(
        'BARCODE_UNKNOWN',
        `Штрихкод «${barcode}» не найден в справочнике. ` +
          'Найдите товар в списке заявки и привяжите к нему этот код.',
      );
    }

    const sku = await this.dataSource.getRepository(SkuEntity).findOne({ where: { id: found.skuId } });
    if (!sku) throw new NotFoundException('SKU не найден.');

    // Решение PM: SKU не из заявки — стоп. Иначе ASN перестаёт быть контролем.
    const asnLine = await this.dataSource
      .getRepository(AsnLineEntity)
      .findOne({ where: { asnId: asn.id, skuId: sku.id } });
    if (!asnLine) {
      throw new CodedConflictException(
        'SKU_NOT_IN_ASN',
        `SKU «${sku.skuCode}» не заявлен в этой поставке. Принять его нельзя — ` +
          'проверьте заявку или добавьте позицию в неё.',
      );
    }

    return { sku, comment: null };
  }

  /**
   * Путь без скана: строка заявки уже называет товар однозначно, искать нечего.
   * Метка в журнале обязательна — при разборе расхождений «отсканировано» и
   * «введено руками» должны различаться.
   */
  private async resolveSkuByAsnLine(
    asn: AsnEntity,
    asnLineId: string,
  ): Promise<{ sku: SkuEntity; comment: string | null }> {
    const asnLine = await this.loadAsnLineOfReceipt(asn.id, asnLineId);

    const sku = await this.dataSource
      .getRepository(SkuEntity)
      .findOne({ where: { id: asnLine.skuId } });
    if (!sku) throw new NotFoundException('SKU не найден.');

    return { sku, comment: 'Приём по строке заявки (без скана)' };
  }

  /** Строка заявки, принадлежащая именно этой поставке. Чужая — 409. */
  private async loadAsnLineOfReceipt(asnId: string, asnLineId: string): Promise<AsnLineEntity> {
    const asnLine = await this.dataSource
      .getRepository(AsnLineEntity)
      .findOne({ where: { id: asnLineId } });
    if (!asnLine) throw new NotFoundException('Позиция заявки не найдена.');
    if (asnLine.asnId !== asnId) {
      throw new CodedConflictException(
        'ASN_LINE_FOREIGN',
        'Эта позиция относится к другой заявке. Обновите экран и выберите позицию текущей поставки.',
      );
    }
    return asnLine;
  }

  private async loadOpenReceipt(receiptId: string): Promise<ReceiptEntity> {
    const receipt = await this.dataSource
      .getRepository(ReceiptEntity)
      .findOne({ where: { id: receiptId } });
    if (!receipt) throw new NotFoundException('Приёмка не найдена.');
    if (receipt.status !== 'OPEN') {
      throw new ConflictException(`Приёмка уже в статусе ${receipt.status}.`);
    }
    return receipt;
  }

  private findBinByKind(
    warehouseId: string,
    kind: 'RECEIVING' | 'DAMAGED',
    required: boolean,
  ): Promise<BinLocationEntity> {
    return findBinByKind(this.dataSource, warehouseId, kind, required) as Promise<BinLocationEntity>;
  }

  /** Сколько принято по каждой позиции заявки всеми не отменёнными приёмками. */
  private async asnProgress(
    asnId: string,
  ): Promise<
    Array<{
      id: string;
      skuId: string;
      skuCode: string;
      skuName: string;
      expectedQty: number;
      receivedQty: number;
      hasBarcode: boolean;
    }>
  > {
    const rows = await this.inbound.asnLineProgress(this.dataSource, asnId);

    return rows.map((row) => ({
      id: row.id,
      skuId: row.sku_id,
      skuCode: row.sku_code,
      skuName: row.sku_name,
      expectedQty: Number(row.expected_qty),
      receivedQty: Number(row.received),
      hasBarcode: row.has_barcode,
    }));
  }

  private async buildAsnDto(asn: AsnEntity): Promise<AsnDto> {
    const lines = await this.asnProgress(asn.id);
    return {
      id: asn.id,
      sellerId: asn.sellerId,
      warehouseId: asn.warehouseId,
      externalRef: asn.externalRef,
      status: asn.status,
      expectedAt: asn.expectedAt ? asn.expectedAt.toISOString() : null,
      hasDiscrepancy: asn.hasDiscrepancy,
      lines: lines.map((line) => ({
        id: line.id,
        skuId: line.skuId,
        skuCode: line.skuCode,
        skuName: line.skuName,
        expectedQty: line.expectedQty,
        receivedQty: line.receivedQty,
        hasBarcode: line.hasBarcode,
      })),
    };
  }

  private async buildReceiptDto(receiptId: string): Promise<ReceiptDto> {
    const receipt = await this.dataSource
      .getRepository(ReceiptEntity)
      .findOne({ where: { id: receiptId } });
    if (!receipt) throw new NotFoundException('Приёмка не найдена.');

    const lines: Array<Record<string, unknown>> = await this.inbound.receiptLinesWithSku(
      this.dataSource,
      receiptId,
    );

    return {
      id: receipt.id,
      asnId: receipt.asnId,
      warehouseId: receipt.warehouseId,
      status: receipt.status,
      receivedBy: receipt.receivedBy,
      completedAt: receipt.completedAt ? receipt.completedAt.toISOString() : null,
      lines: lines.map((line) => ({
        id: line.id as string,
        receiptId: line.receipt_id as string,
        skuId: line.sku_id as string,
        skuCode: line.sku_code as string,
        skuName: line.sku_name as string,
        lotId: (line.lot_id as string | null) ?? null,
        qtyReceived: Number(line.qty_received),
        qtyOk: Number(line.qty_ok),
        qtyDamaged: Number(line.qty_damaged),
        binId: (line.bin_id as string | null) ?? null,
        status: line.status as ReceiptLineDto['status'],
      })),
    };
  }
}
