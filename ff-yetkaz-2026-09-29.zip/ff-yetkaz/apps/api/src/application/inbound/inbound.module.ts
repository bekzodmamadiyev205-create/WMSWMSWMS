import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  AsnEntity,
  AsnLineEntity,
  BinLocationEntity,
  ReceiptEntity,
  ReceiptLineEntity,
  SellerEntity,
  SkuBarcodeEntity,
  SkuEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { InboundRepository } from '../../infrastructure/database/repositories/inbound.repository';
import { InventoryModule } from '../inventory/inventory.module';
import { MdmModule } from '../mdm/mdm.module';
import { InboundController } from '../../presentation/http/inbound.controller';
import { InboundService } from './inbound.service';

@Module({
  imports: [
    InventoryModule,
    // Прямой импорт без forwardRef: зависимость односторонняя — MDM про приёмку
    // ничего не знает, приёмка берёт у него SkusService для привязки штрихкода.
    MdmModule,
    TypeOrmModule.forFeature([
      AsnEntity,
      AsnLineEntity,
      ReceiptEntity,
      ReceiptLineEntity,
      SellerEntity,
      WarehouseEntity,
      SkuEntity,
      SkuBarcodeEntity,
      BinLocationEntity,
    ]),
  ],
  controllers: [InboundController],
  providers: [InboundService, InboundRepository],
  exports: [InboundService],
})
export class InboundModule {}
