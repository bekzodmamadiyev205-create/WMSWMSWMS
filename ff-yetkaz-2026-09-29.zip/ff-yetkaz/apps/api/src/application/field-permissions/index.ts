export * from './field-permissions.module';
export * from './field-permissions.service';
// Готовый к применению помощник для чужих контроллеров: список полей, реально
// присланных на запись. Сюда он вынесен нарочно — чтобы модулям не пришлось
// знать про внутреннюю раскладку common/field-acl.
export { submittedFields } from '../field-acl/submitted-fields';
