import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FieldAclModule } from '../field-acl/field-acl.module';
import { FieldPermissionEntity } from '../../infrastructure/database/entities';
import { FieldPermissionsRepository } from '../../infrastructure/database/repositories/field-permissions.repository';
import { FieldPermissionsController } from '../../presentation/http/field-permissions.controller';
import { FieldPermissionsService } from './field-permissions.service';

/**
 * FieldAclModule импортирован явно, хотя он @Global: так модуль администрирования
 * тянет за собой ядро прав сам, и матрицу нельзя включить, не включив то, что её
 * применяет. Забытый импорт дал бы работающий экран настройки прав, которые не
 * действуют ни на один ответ.
 */
@Module({
  imports: [TypeOrmModule.forFeature([FieldPermissionEntity]), FieldAclModule],
  controllers: [FieldPermissionsController],
  providers: [FieldPermissionsService, FieldPermissionsRepository],
})
export class FieldPermissionsModule {}
