import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import {
  ACL_ENTITIES,
  ACL_ENTITY_TITLES,
  ACL_FIELDS,
  type AclEntity,
  type EffectiveFieldAclDto,
  type FieldPermissionDto,
  type FieldPermissionMatrixDto,
} from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { FieldAclService } from '../field-acl/field-acl.service';
import { FieldPermissionsRepository } from '../../infrastructure/database/repositories/field-permissions.repository';
import type { ActorContext } from '../../domain/types/actor';
import { FieldPermissionEntity } from '../../infrastructure/database/entities';

/** Умолчание таблицы: строка, равная ему, не несёт информации и не хранится. */
function isFullyPermissive(permission: FieldPermissionDto): boolean {
  return permission.canView && permission.canEdit && !permission.canDelete;
}

/**
 * Администрирование матрицы «роль × сущность × поле».
 *
 * Таблица — СПИСОК ИСКЛЮЧЕНИЙ, а не полное декартово произведение: отсутствие
 * строки означает «разрешено». Поэтому сохранение не только пишет ограничения,
 * но и удаляет строки, ставшие полностью разрешающими — иначе таблица за месяц
 * распухнет до нескольких сотен строк, из которых значащими будут единицы, и
 * ответить на вопрос «что у нас вообще закрыто» станет невозможно.
 */
@Injectable()
export class FieldPermissionsService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
    private readonly acl: FieldAclService,
    private readonly permissions: FieldPermissionsRepository,
  ) {}

  async matrix(): Promise<FieldPermissionMatrixDto> {
    const rows = await this.dataSource
      .getRepository(FieldPermissionEntity)
      .find({ order: { entity: 'ASC', field: 'ASC', role: 'ASC' } });

    const known = new Set<string>(ACL_ENTITIES);

    return {
      entities: ACL_ENTITIES.map((entity) => ({
        entity,
        title: ACL_ENTITY_TITLES[entity],
        fields: [...ACL_FIELDS[entity]],
      })),
      // Строки на неизвестную сущность (появиться могут только ручным SQL)
      // не показываем: они всё равно ни на что не влияют — фильтрация спрашивает
      // права по конкретной сущности из ACL_ENTITIES и до них не доходит.
      permissions: rows
        .filter((row) => known.has(row.entity))
        .map((row) => ({
          role: row.role,
          entity: row.entity as AclEntity,
          field: row.field,
          canView: row.canView,
          canEdit: row.canEdit,
          canDelete: row.canDelete,
        })),
    };
  }

  async update(
    permissions: FieldPermissionDto[],
    actor: ActorContext,
  ): Promise<FieldPermissionMatrixDto> {
    const deduped = this.validate(permissions);

    const toRemove = deduped.filter(isFullyPermissive);
    const toStore = deduped.filter((permission) => !isFullyPermissive(permission));

    await this.dataSource.transaction(async (manager) => {
      // Один заход: половина применённой матрицы прав — это состояние, в котором
      // непонятно, что именно закрыто, и разбирать его придётся по аудиту.
      await this.remove(manager, toRemove);
      await this.store(manager, toStore);
    });

    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'FieldPermission',
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: {
        stored: toStore.map(describe),
        removed: toRemove.map(describe),
      },
    });

    // Матрица участвует в каждом ответе — сброс кэша обязателен сразу после
    // коммита, иначе администратор минуту смотрит на своё же старое правило.
    this.acl.invalidate();

    return this.matrix();
  }

  effective(actor: ActorContext): Promise<EffectiveFieldAclDto> {
    return this.acl.effectiveFor(actor.user.roles);
  }

  // ------------------------------------------------------------- внутреннее

  private validate(permissions: FieldPermissionDto[]): FieldPermissionDto[] {
    // Последнее вхождение ключа побеждает: дубли в одном INSERT'е Postgres
    // отвергает целиком («ON CONFLICT DO UPDATE cannot affect row a second
    // time»), то есть сохранение упало бы на двойном клике по чек-боксу.
    const byKey = new Map<string, FieldPermissionDto>();

    for (const permission of permissions) {
      const { role, entity, field } = permission;

      if (role === 'ADMIN') {
        throw new BadRequestException(
          'Администратор не ограничивается матрицей полей: первый же чек-бокс отрезал бы его от системы, включая саму матрицу.',
        );
      }
      if (!(ACL_ENTITIES as readonly string[]).includes(entity)) {
        throw new BadRequestException(`Неизвестная сущность «${entity}».`);
      }

      const allowed = ACL_FIELDS[entity];
      if (!allowed.includes(field) && !isFullyPermissive(permission)) {
        // Право на несуществующее поле не выполнимо ничем: оно не относится ни к
        // одному ключу ответа, значит навсегда останется мёртвой строкой.
        // Исключение — полностью разрешающая строка: это УДАЛЕНИЕ, и запретить
        // его значило бы запереть мусор от прошлой схемы в таблице навсегда.
        throw new BadRequestException(
          `Поле «${field}» не описано у сущности «${ACL_ENTITY_TITLES[entity]}».`,
        );
      }

      byKey.set(`${role}|${entity}|${field}`, permission);
    }

    return [...byKey.values()];
  }

  private async remove(manager: EntityManager, permissions: FieldPermissionDto[]): Promise<void> {
    if (permissions.length === 0) return;
    await this.permissions.removeExceptions(manager, permissions);
  }

  private async store(manager: EntityManager, permissions: FieldPermissionDto[]): Promise<void> {
    if (permissions.length === 0) return;
    await this.permissions.upsertExceptions(manager, permissions);
  }
}

function describe(permission: FieldPermissionDto): string {
  return `${permission.role}.${permission.entity}.${permission.field}`;
}
