import type { PickTaskStatus } from '@ff/shared';

/**
 * Формы входных данных операций сборки.
 *
 * Живут рядом с сервисом, а не в presentation: прикладному слою нужна ФОРМА
 * данных, а декораторы class-validator существуют ради разбора HTTP-запроса.
 * Классы DTO в presentation объявляют `implements` этих интерфейсов — так
 * расхождение формы поймает сборка, а не боевой запрос.
 */

export interface CreatePickTaskInput {
  /** Список заказов. Несколько — batch-задание (решение PM: выбирает оператор). */
  orderIds: string[];
}

export interface AssignPickTaskInput {
  /** Не указан — сборщик берёт задание на себя. */
  userId?: string;
}

export interface PickScanInput {
  barcode: string;
  quantity: number;
}

/**
 * Ручное подтверждение отбора по строке задания.
 *
 * Штрихкода тут нет намеренно: строка задания уже однозначно задаёт SKU, ячейку
 * и партию — идентифицировать товар ещё раз нечем и незачем.
 */
export interface ManualPickInput {
  quantity: number;
}

export interface ShortPickInput {
  /** Причина обязательна: недобор — это расхождение, его нужно объяснить. */
  reason: string;
}

export interface ListPickTasksInput {
  status?: PickTaskStatus;
  /** 'true' — только мои задания. Строка, а не boolean: это query-параметр. */
  mine?: 'true' | 'false';
  limit?: number;
}
