import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  BinLocationEntity,
  OrderEntity,
  PickTaskEntity,
  PickTaskLineEntity,
  PickTaskOrderEntity,
  SkuBarcodeEntity,
  SkuEntity,
} from '../../infrastructure/database/entities';
import { PickingRepository } from '../../infrastructure/database/repositories/picking.repository';
import { InventoryModule } from '../inventory/inventory.module';
import { PickingController } from '../../presentation/http/picking.controller';
import { PickingService } from './picking.service';

@Module({
  imports: [
    InventoryModule,
    TypeOrmModule.forFeature([
      PickTaskEntity,
      PickTaskOrderEntity,
      PickTaskLineEntity,
      OrderEntity,
      SkuEntity,
      SkuBarcodeEntity,
      BinLocationEntity,
    ]),
  ],
  controllers: [PickingController],
  providers: [PickingService, PickingRepository],
  exports: [PickingService],
})
export class PickingModule {}
