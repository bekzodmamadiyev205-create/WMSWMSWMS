import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import {
  FF_EVENTS,
  orderFsm,
  pickTaskFsm,
  STAFF_ROLES,
  type PickScanResultDto,
  type PickTaskDto,
  type PickTaskLineDto,
  type ShortPickResultDto,
} from '@ff/shared';
import { createEvent, EVENT_BUS, type EventBus } from '../../infrastructure/queues/events/event-bus';
import {
  CodedConflictException,
  CodedNotFoundException,
} from '../errors/coded-exception';
import { FsmService } from '../fsm/fsm.service';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { findBinByKind } from '../../infrastructure/database/repositories/bin-location.repository';
import { PickingRepository } from '../../infrastructure/database/repositories/picking.repository';
import {
  OrderEntity,
  PickTaskEntity,
  PickTaskLineEntity,
  PickTaskOrderEntity,
  SkuBarcodeEntity,
  SkuEntity,
} from '../../infrastructure/database/entities';
import { InventoryService } from '../inventory/inventory.service';
import type {
  AssignPickTaskInput,
  CreatePickTaskInput,
  ListPickTasksInput,
  ManualPickInput,
  PickScanInput,
  ShortPickInput,
} from './picking.input';

const OWNER_TYPE = 'ORDER';

/**
 * Метка в append-only журнале движений. Без неё при разборе расхождений
 * отобранное руками не отличить от отсканированного — а это разные степени
 * доверия к факту.
 */
const MANUAL_PICK_COMMENT = 'Ручное подтверждение отбора по строке задания, без скана.';

@Injectable()
export class PickingService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly repo: PickingRepository,
    private readonly inventory: InventoryService,
    private readonly fsm: FsmService,
    @Inject(EVENT_BUS) private readonly events: EventBus,
  ) {}

  // ------------------------------------------------------------ задания

  /**
   * Задание собирается из АКТИВНЫХ РЕЗЕРВОВ заказов: резерв уже знает ячейку и
   * партию, поэтому маршрут — это сортировка строк по коду ячейки.
   */
  async createTask(dto: CreatePickTaskInput, actor: ActorContext): Promise<PickTaskDto> {
    const orderIds = [...new Set(dto.orderIds)];
    const orders = await this.dataSource
      .getRepository(OrderEntity)
      .find({ where: orderIds.map((id) => ({ id })) });
    if (orders.length !== orderIds.length) throw new NotFoundException('Часть заказов не найдена.');

    for (const order of orders) {
      if (order.status !== 'RESERVED') {
        throw new ConflictException(
          `Заказ ${order.externalId} в статусе ${order.status}: собирать можно только зарезервированные.`,
        );
      }
      if (!order.warehouseId) {
        throw new ConflictException(`У заказа ${order.externalId} не назначен склад.`);
      }
    }

    const warehouseId = orders[0].warehouseId as string;
    if (orders.some((order) => order.warehouseId !== warehouseId)) {
      // Маршрут сборщика не бывает межскладским.
      throw new BadRequestException('Все заказы задания должны быть с одного склада.');
    }

    const busy = await this.dataSource
      .getRepository(PickTaskOrderEntity)
      .find({ where: orderIds.map((id) => ({ orderId: id })) });
    if (busy.length > 0) {
      throw new ConflictException('Часть заказов уже включена в другое задание на сборку.');
    }

    await findBinByKind(this.dataSource, warehouseId, 'PACKING', true);

    const reservations: Array<{
      id: string;
      owner_id: string;
      sku_id: string;
      bin_id: string;
      lot_id: string | null;
      quantity: number;
    }> = await this.repo.findActiveReservations(this.dataSource, [OWNER_TYPE, orderIds]);
    if (reservations.length === 0) {
      throw new ConflictException('У заказов нет активных резервов — собирать нечего.');
    }

    const taskId = await this.dataSource.transaction(async (em) => {
      const tasks = em.getRepository(PickTaskEntity);
      const task = await tasks.save(
        tasks.create({
          warehouseId,
          kind: orderIds.length > 1 ? 'BATCH' : 'SINGLE',
          status: 'NEW',
          assigneeUserId: null,
          createdBy: actor.user.id,
          startedAt: null,
          completedAt: null,
        }),
      );

      for (const orderId of orderIds) {
        await em.getRepository(PickTaskOrderEntity).insert({ taskId: task.id, orderId });
      }
      for (const reservation of reservations) {
        await em.getRepository(PickTaskLineEntity).insert({
          taskId: task.id,
          orderId: reservation.owner_id,
          skuId: reservation.sku_id,
          binId: reservation.bin_id,
          lotId: reservation.lot_id,
          reservationId: reservation.id,
          qtyRequested: reservation.quantity,
          qtyPicked: 0,
          status: 'PENDING',
        });
      }

      for (const order of orders) {
        await this.fsm.transition(
          orderFsm,
          'RESERVED',
          'PICKING',
          this.fsmContext('Order', order.id, actor),
          em,
        );
        await em.getRepository(OrderEntity).update({ id: order.id }, { status: 'PICKING' });
      }
      return task.id;
    });

    return this.buildTaskDto(taskId);
  }

  async assign(taskId: string, dto: AssignPickTaskInput, actor: ActorContext): Promise<PickTaskDto> {
    const task = await this.loadTask(taskId);
    const assignee = dto.userId ?? actor.user.id;

    await this.dataSource.transaction(async (em) => {
      await this.fsm.transition(
        pickTaskFsm,
        task.status,
        'ASSIGNED',
        this.fsmContext('PickTask', task.id, actor),
        em,
      );
      await em
        .getRepository(PickTaskEntity)
        .update({ id: task.id }, { status: 'ASSIGNED', assigneeUserId: assignee });
    });

    return this.buildTaskDto(taskId);
  }

  // -------------------------------------------------------------- сборка

  async scan(taskId: string, dto: PickScanInput, actor: ActorContext): Promise<PickScanResultDto> {
    const task = await this.loadTask(taskId);
    this.assertPickable(task, actor);

    const barcode = dto.barcode.trim();
    const found = await this.dataSource
      .getRepository(SkuBarcodeEntity)
      .findOne({ where: { barcode } });
    if (!found) {
      // Машинный код — чтобы экран сборщика предложил ручное подтверждение
      // вместо тупика: разбирать русский текст сообщения клиент не должен.
      throw new CodedNotFoundException(
        'BARCODE_UNKNOWN',
        `Штрихкод «${barcode}» не найден в справочнике.`,
      );
    }

    // Первая по маршруту незакрытая строка этого SKU.
    const candidates: Array<{ id: string }> = await this.repo.findNextLineForSku(this.dataSource, [
      taskId,
      found.skuId,
    ]);
    if (candidates.length === 0) {
      throw new CodedConflictException(
        'NOT_IN_TASK',
        'Этот товар не входит в задание или уже собран полностью. Проверьте штрихкод.',
      );
    }

    const line = await this.dataSource
      .getRepository(PickTaskLineEntity)
      .findOne({ where: { id: candidates[0].id } });
    if (!line) throw new NotFoundException('Строка задания не найдена.');

    return this.pickLine(task, line, dto.quantity, actor, null);
  }

  /**
   * Ручное подтверждение отбора по строке задания: товар у сборщика в руках, а
   * штрихкода у него нет или он не читается.
   *
   * Это НЕ послабление контроля, а его ужесточение: скан ищет SKU по всему
   * справочнику, строка задания задаёт SKU, ячейку и партию однозначно. Раньше
   * единственным не-сканерным выходом был «недобор» — то есть склад получал
   * заведомо ложное расхождение и лишний пересчёт по товару, который сборщик
   * держит в руках, а задание без этого зависало в работе навсегда.
   */
  async pickManual(
    taskId: string,
    lineId: string,
    dto: ManualPickInput,
    actor: ActorContext,
  ): Promise<PickScanResultDto> {
    const task = await this.loadTask(taskId);
    this.assertPickable(task, actor);

    const line = await this.dataSource
      .getRepository(PickTaskLineEntity)
      .findOne({ where: { id: lineId, taskId } });
    if (!line) throw new NotFoundException('Строка задания не найдена.');

    return this.pickLine(task, line, dto.quantity, actor, MANUAL_PICK_COMMENT);
  }

  /**
   * Общая часть отбора: и скан, и ручное подтверждение списывают остаток здесь.
   * Второго пути списания быть не должно — иначе гашение резерва, перевод
   * задания в работу и обработка гонок неминуемо разъедутся между ветками.
   *
   * @param comment метка для журнала движений: у скана её нет, ручной отбор
   *   обязан быть отличим при разборе расхождений.
   */
  private async pickLine(
    task: PickTaskEntity,
    line: PickTaskLineEntity,
    quantity: number,
    actor: ActorContext,
    comment: string | null,
  ): Promise<PickScanResultDto> {
    if (line.status !== 'PENDING') {
      throw new ConflictException(`Строка уже закрыта со статусом ${line.status}.`);
    }

    const remaining = line.qtyRequested - line.qtyPicked;
    if (quantity > remaining) {
      throw new ConflictException(
        `По этой строке осталось собрать ${remaining}, а заявлено ${quantity}.`,
      );
    }

    const packingBin = await findBinByKind(this.dataSource, task.warehouseId, 'PACKING', true);

    await this.dataSource.transaction(async (em) => {
      if (task.status === 'ASSIGNED') {
        await this.fsm.transition(
          pickTaskFsm,
          'ASSIGNED',
          'IN_PROGRESS',
          this.fsmContext('PickTask', task.id, actor),
          em,
        );
        await em
          .getRepository(PickTaskEntity)
          .update({ id: task.id }, { status: 'IN_PROGRESS', startedAt: new Date() });
      }

      await this.inventory.applyMovement(
        em,
        {
          skuId: line.skuId,
          warehouseId: task.warehouseId,
          lotId: line.lotId,
          from: { binId: line.binId, status: 'RESERVED' },
          to: { binId: packingBin!.id, status: 'PICKED' },
          quantity,
          reason: 'PICK',
          referenceType: OWNER_TYPE,
          referenceId: line.orderId,
          comment,
        },
        actor,
      );

      await this.consumeReservation(em, line.reservationId, quantity);

      const picked = line.qtyPicked + quantity;
      await em
        .getRepository(PickTaskLineEntity)
        .update(
          { id: line.id },
          { qtyPicked: picked, status: picked === line.qtyRequested ? 'PICKED' : 'PENDING' },
        );
    });

    return {
      task: await this.buildTaskDto(task.id),
      lineId: line.id,
      picked: line.qtyPicked + quantity,
      remaining: remaining - quantity,
    };
  }

  /**
   * Недобор: в ячейке меньше, чем считала система.
   *
   * Недостача уходит в QUARANTINE ТОЙ ЖЕ ячейки, а не обратно в AVAILABLE.
   * Иначе перерезерв тут же выбрал бы эту же ячейку и сборщик зациклился бы;
   * плюс карантин честно отражает «состояние неизвестно, нужен пересчёт».
   * Затем система ищет недостающее в других ячейках того же склада (решение PM).
   */
  async short(
    taskId: string,
    lineId: string,
    dto: ShortPickInput,
    actor: ActorContext,
  ): Promise<ShortPickResultDto> {
    const task = await this.loadTask(taskId);
    this.assertCanPick(task, actor);

    const line = await this.dataSource
      .getRepository(PickTaskLineEntity)
      .findOne({ where: { id: lineId, taskId } });
    if (!line) throw new NotFoundException('Строка задания не найдена.');
    if (line.status !== 'PENDING') {
      throw new ConflictException(`Строка уже закрыта со статусом ${line.status}.`);
    }

    const missing = line.qtyRequested - line.qtyPicked;
    if (missing <= 0) throw new ConflictException('По строке нечего объявлять недобором.');

    const order = await this.dataSource
      .getRepository(OrderEntity)
      .findOne({ where: { id: line.orderId } });
    if (!order) throw new NotFoundException('Заказ не найден.');

    await this.dataSource.transaction(async (em) => {
      if (task.status === 'ASSIGNED') {
        await this.fsm.transition(
          pickTaskFsm,
          'ASSIGNED',
          'IN_PROGRESS',
          this.fsmContext('PickTask', task.id, actor),
          em,
        );
        await em
          .getRepository(PickTaskEntity)
          .update({ id: task.id }, { status: 'IN_PROGRESS', startedAt: new Date() });
      }

      const common = {
        skuId: line.skuId,
        warehouseId: task.warehouseId,
        lotId: line.lotId,
        referenceType: OWNER_TYPE,
        referenceId: line.orderId,
        comment: dto.reason,
      };

      await this.inventory.applyMovement(
        em,
        {
          ...common,
          from: { binId: line.binId, status: 'RESERVED' },
          to: { binId: line.binId, status: 'AVAILABLE' },
          quantity: missing,
          reason: 'RELEASE',
        },
        actor,
      );
      await this.inventory.applyMovement(
        em,
        {
          ...common,
          from: { binId: line.binId, status: 'AVAILABLE' },
          to: { binId: line.binId, status: 'QUARANTINE' },
          quantity: missing,
          reason: 'ADJUSTMENT',
        },
        actor,
      );

      await this.repo.releaseReservation(em, line.reservationId);
      await em.getRepository(PickTaskLineEntity).update({ id: line.id }, { status: 'SHORT' });
    });

    // Перерезерв — вне транзакции недобора: он уже свершившийся факт, и его
    // не должно откатывать неудачей поиска замены.
    let reallocated = false;
    let orderFlagged = false;
    try {
      const result = await this.inventory.reserve(
        {
          ownerType: OWNER_TYPE,
          ownerId: line.orderId,
          skuId: line.skuId,
          warehouseId: task.warehouseId,
          quantity: missing,
        },
        actor,
      );
      for (const reservation of result.lines) {
        await this.dataSource.getRepository(PickTaskLineEntity).insert({
          taskId,
          orderId: line.orderId,
          skuId: line.skuId,
          binId: reservation.binId,
          lotId: reservation.lotId,
          reservationId: reservation.id,
          qtyRequested: reservation.quantity,
          qtyPicked: 0,
          status: 'PENDING',
        });
      }
      reallocated = true;
    } catch (error) {
      if (!(error instanceof ConflictException)) throw error;
      await this.dataSource
        .getRepository(OrderEntity)
        .update({ id: order.id }, { hasShortage: true });
      orderFlagged = true;
    }

    return { task: await this.buildTaskDto(taskId), missing, reallocated, orderFlagged };
  }

  async complete(taskId: string, actor: ActorContext): Promise<PickTaskDto> {
    const task = await this.loadTask(taskId);
    this.assertCanPick(task, actor);

    if (task.status !== 'IN_PROGRESS') {
      throw new ConflictException(`Завершить можно задание в работе, текущий статус: ${task.status}.`);
    }

    const pending = await this.dataSource
      .getRepository(PickTaskLineEntity)
      .count({ where: { taskId, status: 'PENDING' } });
    if (pending > 0) {
      throw new ConflictException(
        `Нельзя завершить сборку: ${pending} строк. не собрано и не помечено недобором.`,
      );
    }

    const links = await this.dataSource
      .getRepository(PickTaskOrderEntity)
      .find({ where: { taskId } });
    const orders = await this.dataSource
      .getRepository(OrderEntity)
      .find({ where: links.map((link) => ({ id: link.orderId })) });

    await this.dataSource.transaction(async (em) => {
      await this.fsm.transition(
        pickTaskFsm,
        'IN_PROGRESS',
        'COMPLETED',
        this.fsmContext('PickTask', task.id, actor),
        em,
      );
      await em
        .getRepository(PickTaskEntity)
        .update({ id: task.id }, { status: 'COMPLETED', completedAt: new Date() });

      for (const order of orders) {
        // Заказ могли отменить посреди сборки — тогда его строки уже закрыты
        // как CANCELLED, товар возвращён, и переводить его некуда.
        if (order.status !== 'PICKING') continue;
        // Заказ с недобором тоже уходит в PICKED: собранное надо упаковать,
        // а отметка нехватки уже стоит на самом заказе.
        await this.fsm.transition(
          orderFsm,
          'PICKING',
          'PICKED',
          this.fsmContext('Order', order.id, actor),
          em,
        );
        await em.getRepository(OrderEntity).update({ id: order.id }, { status: 'PICKED' });
      }
    });

    // Событие — после коммита: на in-memory шине откат уже не отменит доставку.
    // Упаковка узнаёт о готовом к коробке заказе именно отсюда.
    const shortLines = await this.dataSource
      .getRepository(PickTaskLineEntity)
      .find({ where: { taskId, status: 'SHORT' } });
    const shortByOrder = new Set(shortLines.map((line) => line.orderId));

    for (const link of links) {
      await this.events.publish(
        createEvent(
          FF_EVENTS.PICK_COMPLETED,
          {
            orderId: link.orderId,
            pickTaskId: taskId,
            pickerUserId: task.assigneeUserId ?? actor.user.id,
            shortPicked: shortByOrder.has(link.orderId),
          },
          { actorUserId: actor.user.id, correlationId: actor.correlationId },
        ),
      );
    }

    return this.buildTaskDto(taskId);
  }

  // -------------------------------------------------------------- чтение

  async list(query: ListPickTasksInput, actor: ActorContext): Promise<PickTaskDto[]> {
    // Сборка — внутренняя операция склада, селлеру не показываем.
    resolveSellerScope(actor.user);
    if (!actor.user.roles.some((role) => STAFF_ROLES.includes(role))) {
      throw new ForbiddenException('Задания на сборку доступны только сотрудникам склада.');
    }

    const builder = this.dataSource
      .getRepository(PickTaskEntity)
      .createQueryBuilder('t')
      .orderBy('t.createdAt', 'DESC')
      .take(query.limit ?? 50);

    if (query.status) builder.andWhere('t.status = :status', { status: query.status });
    if (query.mine === 'true') {
      builder.andWhere('t.assigneeUserId = :me', { me: actor.user.id });
    }

    const tasks = await builder.getMany();
    return Promise.all(tasks.map((task) => this.buildTaskDto(task.id)));
  }

  async get(taskId: string, actor: ActorContext): Promise<PickTaskDto> {
    resolveSellerScope(actor.user);
    if (!actor.user.roles.some((role) => STAFF_ROLES.includes(role))) {
      throw new ForbiddenException('Задания на сборку доступны только сотрудникам склада.');
    }
    await this.loadTask(taskId);
    return this.buildTaskDto(taskId);
  }

  // ---------------------------------------------------------- внутреннее

  /** Гасит резерв по мере сборки: иначе отмена вернула бы в AVAILABLE собранное. */
  private async consumeReservation(
    em: EntityManager,
    reservationId: string,
    quantity: number,
  ): Promise<void> {
    const rows: Array<{ quantity: number }> = await this.repo.lockReservation(em, reservationId);
    if (rows.length === 0) throw new NotFoundException('Резерв не найден.');

    if (rows[0].quantity === quantity) {
      await this.repo.consumeReservation(em, reservationId);
    } else {
      await this.repo.decreaseReservation(em, [reservationId, quantity]);
    }
  }

  /** Кто отбирает и можно ли вообще отбирать — одинаково для скана и ручного ввода. */
  private assertPickable(task: PickTaskEntity, actor: ActorContext): void {
    this.assertCanPick(task, actor);
    if (task.status !== 'ASSIGNED' && task.status !== 'IN_PROGRESS') {
      throw new ConflictException(`Задание в статусе ${task.status}: отбирать нельзя.`);
    }
  }

  private assertCanPick(task: PickTaskEntity, actor: ActorContext): void {
    const isPrivileged = actor.user.roles.some(
      (role) => role === 'ADMIN' || role === 'WAREHOUSE_OPERATOR',
    );
    if (isPrivileged) return;
    if (task.assigneeUserId !== actor.user.id) {
      throw new ForbiddenException('Это задание назначено другому сборщику.');
    }
  }

  private fsmContext(entityType: string, entityId: string, actor: ActorContext) {
    return {
      entityType,
      entityId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
    };
  }

  private async loadTask(taskId: string): Promise<PickTaskEntity> {
    const task = await this.dataSource
      .getRepository(PickTaskEntity)
      .findOne({ where: { id: taskId } });
    if (!task) throw new NotFoundException('Задание на сборку не найдено.');
    return task;
  }

  private async buildTaskDto(taskId: string): Promise<PickTaskDto> {
    const task = await this.loadTask(taskId);

    const links = await this.dataSource
      .getRepository(PickTaskOrderEntity)
      .find({ where: { taskId } });

    // Сортировка по коду ячейки — это и есть маршрут обхода.
    const rows: Array<{
      id: string;
      order_id: string;
      sku_id: string;
      sku_code: string;
      sku_name: string;
      bin_id: string;
      bin_code: string;
      lot_id: string | null;
      qty_requested: number;
      qty_picked: number;
      status: string;
    }> = await this.repo.findTaskLines(this.dataSource, taskId);

    const lines: PickTaskLineDto[] = rows.map((row) => ({
      id: row.id,
      taskId,
      orderId: row.order_id,
      skuId: row.sku_id,
      skuCode: row.sku_code,
      skuName: row.sku_name,
      binId: row.bin_id,
      binCode: row.bin_code,
      lotId: row.lot_id,
      qtyRequested: Number(row.qty_requested),
      qtyPicked: Number(row.qty_picked),
      status: row.status as PickTaskLineDto['status'],
    }));

    return {
      id: task.id,
      warehouseId: task.warehouseId,
      kind: task.kind,
      status: task.status,
      assigneeUserId: task.assigneeUserId,
      orderIds: links.map((link) => link.orderId),
      startedAt: task.startedAt ? task.startedAt.toISOString() : null,
      completedAt: task.completedAt ? task.completedAt.toISOString() : null,
      lines,
    };
  }
}
