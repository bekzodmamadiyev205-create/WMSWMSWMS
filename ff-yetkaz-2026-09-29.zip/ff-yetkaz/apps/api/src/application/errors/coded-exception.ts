import { ConflictException, NotFoundException } from '@nestjs/common';

/**
 * Машинные коды ошибок.
 *
 * Текст сообщения адресован человеку: он переводится и переписывается, поэтому
 * опознавать причину отказа по нему клиент не может. Код — стабильный контракт,
 * по которому фронт решает, что предложить оператору (привязать штрихкод,
 * открыть заявку, ввести количество руками), а не показывать голый текст.
 */
export const FF_ERROR_CODES = [
  /** Штрихкод не найден в справочнике — привязать его к позиции заявки. */
  'BARCODE_UNKNOWN',
  /** SKU не заявлен в этой поставке — ASN и есть контроль (решение PM). */
  'SKU_NOT_IN_ASN',
  /** Строка заявки относится к другой поставке. */
  'ASN_LINE_FOREIGN',
  /** Позиции нет в задании на сборку. */
  'NOT_IN_TASK',
] as const;

export type FfErrorCode = (typeof FF_ERROR_CODES)[number];

/**
 * Тело исключения с кодом. `error` дублирует то, что подставил бы сам Nest, —
 * иначе конверт ответа у кодированных ошибок разъехался бы с остальными.
 */
function codedBody(code: FfErrorCode, message: string, error: string) {
  return { message, error, code };
}

export class CodedNotFoundException extends NotFoundException {
  constructor(code: FfErrorCode, message: string) {
    super(codedBody(code, message, 'Not Found'));
  }
}

export class CodedConflictException extends ConflictException {
  constructor(code: FfErrorCode, message: string) {
    super(codedBody(code, message, 'Conflict'));
  }
}
