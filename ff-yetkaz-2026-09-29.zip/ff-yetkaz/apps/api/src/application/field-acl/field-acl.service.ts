import { ForbiddenException, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import {
  ACL_ENTITY_TITLES,
  mergeFieldAcl,
  type AclEntity,
  type EffectiveFieldAcl,
  type EffectiveFieldAclDto,
  type Role,
} from '@ff/shared';
import { TtlCache } from '../../infrastructure/cache';
import { FieldPermissionEntity } from '../../infrastructure/database/entities';

/**
 * Права на уровне колонки: что показывать и что позволять писать.
 *
 * Матрица читается на КАЖДОМ ответе, который помечен `@AclEntity(...)`, поэтому
 * запрос в базу «по требованию» здесь недопустим: это +1 round-trip к каждому
 * ответу API ради таблицы в десяток строк, которая меняется раз в месяц руками
 * администратора. Держим её в памяти; TTL 60 секунд нужен не для свежести на
 * этом процессе (правка сбрасывает кэш явно), а для инстансов, которые правку
 * не выполняли: на serverless их несколько, и они узнают о новой матрице только
 * по истечении TTL.
 */
const CACHE_TTL_MS = 60_000;

/** Умолчание, когда строки в таблице нет: видно и можно править, но не удалять. */
const DEFAULT_RIGHTS = { view: true, edit: true, delete: false } as const;

/**
 * Глубина обхода при фильтрации ответа. Настоящий DTO столько уровней не имеет —
 * ограничение защищает от случайной циклической ссылки в объекте: без него
 * интерцептор ушёл бы в бесконечную рекурсию на каждом ответе.
 */
const MAX_DEPTH = 16;

interface AclSnapshot {
  /** Права по каждой роли отдельно — объединяются уже под конкретного пользователя. */
  byRole: Map<Role, EffectiveFieldAcl>;
  /** Готовые объединения по набору ролей: пользователей много, наборов ролей — единицы. */
  merged: Map<string, EffectiveFieldAcl>;
}

@Injectable()
export class FieldAclService {
  /**
   * Снимок матрицы в памяти процесса. Про то, что на serverless экземпляров
   * несколько и сброс доходит только до одного из них, — в `TtlCache`.
   */
  private readonly snapshots = new TtlCache<AclSnapshot>(CACHE_TTL_MS, () => this.read());

  constructor(@InjectDataSource() private readonly dataSource: DataSource) {}

  /** Сбрасывает кэш после правки матрицы. Вызывается из FieldPermissionsService. */
  invalidate(): void {
    this.snapshots.invalidate();
  }

  /**
   * Что реально можно этому пользователю. Отдаётся фронту, чтобы он прятал
   * колонки и гасил поля ввода теми же правилами, что применяет сервер.
   */
  async effectiveFor(roles: Role[]): Promise<EffectiveFieldAclDto> {
    const acl = await this.aclFor(roles);
    return acl === null
      ? { roles, unrestricted: true, acl: {} }
      : { roles, unrestricted: false, acl };
  }

  /**
   * Имена полей сущности, которые этим ролям смотреть НЕЛЬЗЯ.
   *
   * Нужен там, где ответ собирается в обход `FieldAclInterceptor`. Интерцептор
   * умеет вырезать ключи только из объекта: поток и буфер он намеренно
   * пропускает нетронутыми (обход по ключам превратил бы их в пустой объект).
   * Выгрузка в xlsx — как раз поток: книга пишется прямо в `Response`, и к
   * моменту пост-фазы интерцептора байты уже у клиента. Поэтому колонку надо
   * выбросить ДО записи файла, и сделать это может только сама выгрузка,
   * спросив здесь список скрытых полей.
   *
   * Пустое множество для ADMIN и для принципала без ролей — это `unrestricted`
   * из `effectiveFor`, а не «ничего не скрыто по матрице»: у них ограничений
   * нет вовсе.
   */
  async hiddenFields(entity: AclEntity, roles: Role[]): Promise<Set<string>> {
    const effective = await this.effectiveFor(roles);
    const hidden = new Set<string>();
    if (effective.unrestricted) return hidden;

    for (const [field, rights] of Object.entries(effective.acl[entity] ?? {})) {
      if (!rights.view) hidden.add(field);
    }
    return hidden;
  }

  /**
   * Копия ответа без полей, которые роли видеть не положено.
   *
   * Ключ именно УДАЛЯЕТСЯ, а не обнуляется: `null` и клиент, и выгрузка в Excel
   * читают как настоящее значение — «наложенного платежа нет» вместо «сумма вам
   * не показана», и это уже ошибка в данных, а не сокрытие.
   */
  async filter<T>(entity: AclEntity, payload: T, roles: Role[]): Promise<T> {
    // Через тот же `hiddenFields`, что и выгрузка: два независимых способа
    // вычислить «что скрыто» рано или поздно разойдутся, и разойдутся молча —
    // экран покажет одно, файл отдаст другое.
    const hidden = await this.hiddenFields(entity, roles);
    // Ничего не скрыто — отдаём тот же объект. Копировать ответ ради копии
    // значит платить сериализацией за каждый запрос впустую.
    if (hidden.size === 0) return payload;

    return this.strip(payload, hidden, 0) as T;
  }

  /**
   * Проверка перед записью. Бросает 403 с ИМЕНЕМ поля: «недостаточно прав» без
   * указания, какое именно поле не прошло, превращает правку формы в угадайку.
   */
  async assertEditable(entity: AclEntity, fields: string[], roles: Role[]): Promise<void> {
    if (fields.length === 0) return;
    const acl = await this.aclFor(roles);
    if (acl === null) return;

    const entityAcl = acl[entity];
    if (!entityAcl) return;

    for (const field of fields) {
      // `hasOwnProperty`, а не просто `entityAcl[field]`: имена полей приходят
      // из тела запроса, а у объекта-карты есть прототип. Поле с именем
      // `constructor` или `toString` дало бы «права» из Object.prototype —
      // объект без `edit`, то есть 403 на ровном месте.
      if (!Object.prototype.hasOwnProperty.call(entityAcl, field)) continue;
      const rights = entityAcl[field];
      // Отсутствие строки в матрице означает РАЗРЕШЕНО (см. `pruneDefaults`),
      // поэтому запрещаем только по явному `edit: false`.
      if (rights && !rights.edit) {
        throw new ForbiddenException(
          `Поле «${field}» (${ACL_ENTITY_TITLES[entity]}) недоступно для изменения вашей ролью.`,
        );
      }
    }
  }

  /** Разрешено ли роли очищать значение поля / удалять запись по нему. */
  async canDelete(entity: AclEntity, field: string, roles: Role[]): Promise<boolean> {
    const acl = await this.aclFor(roles);
    if (acl === null) return true;
    return acl[entity]?.[field]?.delete ?? DEFAULT_RIGHTS.delete;
  }

  // ------------------------------------------------------------- внутреннее

  /** `null` = ограничений нет вовсе (администратор и служебный принципал). */
  private async aclFor(roles: Role[]): Promise<EffectiveFieldAcl | null> {
    // ADMIN не ограничивается никогда: иначе первый же неаккуратный чек-бокс
    // отрезал бы администратора от собственной системы, включая эту матрицу.
    // Пустой набор ролей — это служебный принципал (крон), у него не UI, а работа.
    if (roles.length === 0 || roles.includes('ADMIN')) return null;

    const snapshot = await this.snapshots.get();
    const key = [...roles].sort().join('|');
    const cached = snapshot.merged.get(key);
    if (cached) return cached;

    const merged = mergeFieldAcl(this.partsFor(roles, snapshot));
    // Полностью умолчательные записи выбрасываем: фронт и так считает
    // неупомянутое поле открытым, а лишние сотни ключей едут в каждый ответ.
    const pruned = pruneDefaults(merged);
    snapshot.merged.set(key, pruned);
    return pruned;
  }

  /**
   * Слагаемые объединения — по одному на роль.
   *
   * Ключевая тонкость: отсутствие строки означает РАЗРЕШЕНО, поэтому роль без
   * строки обязана участвовать в объединении явным разрешением. Если этого не
   * сделать, «PICKER + FINANCE» унаследует запрет PICKER'а — то есть выдача
   * сотруднику дополнительной роли ОТНИМЕТ у него доступ. Объяснить такое
   * администратору невозможно, поэтому объединение, а не пересечение.
   */
  private partsFor(roles: Role[], snapshot: AclSnapshot): EffectiveFieldAcl[] {
    const maps = roles.map((role) => snapshot.byRole.get(role) ?? {});

    // Множество всех (сущность, поле), про которые хоть одна роль что-то говорит.
    const mentioned = new Map<string, Set<string>>();
    for (const map of maps) {
      for (const [entity, fields] of Object.entries(map)) {
        const set = mentioned.get(entity) ?? new Set<string>();
        for (const field of Object.keys(fields)) set.add(field);
        mentioned.set(entity, set);
      }
    }

    return maps.map((map) => {
      const part: EffectiveFieldAcl = {};
      for (const [entity, fields] of mentioned) {
        const target: Record<string, { view: boolean; edit: boolean; delete: boolean }> = {};
        for (const field of fields) {
          target[field] = map[entity]?.[field] ?? { ...DEFAULT_RIGHTS };
        }
        part[entity] = target;
      }
      return part;
    });
  }

  private async read(): Promise<AclSnapshot> {
    const rows = await this.dataSource.getRepository(FieldPermissionEntity).find();
    const byRole = new Map<Role, EffectiveFieldAcl>();
    for (const row of rows) {
      const map = byRole.get(row.role) ?? {};
      const entity = (map[row.entity] ??= {});
      entity[row.field] = { view: row.canView, edit: row.canEdit, delete: row.canDelete };
      byRole.set(row.role, map);
    }
    return { byRole, merged: new Map() };
  }

  private strip(value: unknown, hidden: ReadonlySet<string>, depth: number): unknown {
    if (value === null || typeof value !== 'object') return value;
    if (depth >= MAX_DEPTH) return value;
    // Дата и бинарник — значения, а не структуры: разбор по ключам превратил бы
    // их в пустой объект.
    if (value instanceof Date || Buffer.isBuffer(value)) return value;

    if (Array.isArray(value)) {
      return value.map((item) => this.strip(item, hidden, depth + 1));
    }

    const source = value as Record<string, unknown>;
    const result: Record<string, unknown> = {};
    for (const key of Object.keys(source)) {
      if (hidden.has(key)) continue;
      // Рекурсия обязательна: у заказа есть `lines`, а у разделённого — `children`
      // с такими же полями. Фильтрация только верхнего уровня оставила бы сумму
      // наложенного платежа во вложенной части заказа.
      result[key] = this.strip(source[key], hidden, depth + 1);
    }
    return result;
  }
}

/** Запись без ограничений (всё по умолчанию) не несёт информации — убираем. */
function pruneDefaults(acl: EffectiveFieldAcl): EffectiveFieldAcl {
  const result: EffectiveFieldAcl = {};
  for (const [entity, fields] of Object.entries(acl)) {
    const kept: Record<string, { view: boolean; edit: boolean; delete: boolean }> = {};
    for (const [field, rights] of Object.entries(fields)) {
      const isDefault =
        rights.view === DEFAULT_RIGHTS.view &&
        rights.edit === DEFAULT_RIGHTS.edit &&
        rights.delete === DEFAULT_RIGHTS.delete;
      if (!isDefault) kept[field] = rights;
    }
    if (Object.keys(kept).length > 0) result[entity] = kept;
  }
  return result;
}
