import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FieldPermissionEntity } from '../../infrastructure/database/entities';
import { FieldAclInterceptor } from '../../presentation/http/field-acl/field-acl.interceptor';
import { FieldAclService } from './field-acl.service';

/**
 * @Global намеренно: `@AclEntity(...)` должна работать в любом контроллере без
 * импорта модуля. Метка прав, которую забыли включить импортом, тихо ничего не
 * фильтрует — а это ровно тот отказ, который не заметят.
 */
@Global()
@Module({
  imports: [TypeOrmModule.forFeature([FieldPermissionEntity])],
  providers: [FieldAclService, FieldAclInterceptor],
  exports: [FieldAclService, FieldAclInterceptor],
})
export class FieldAclModule {}
