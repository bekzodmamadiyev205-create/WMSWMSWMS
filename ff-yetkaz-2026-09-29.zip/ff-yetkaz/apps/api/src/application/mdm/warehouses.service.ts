import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import type { WarehouseDto } from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import type { ActorContext } from '../../domain/types/actor';
import { WarehouseEntity } from '../../infrastructure/database/entities';
import type { CreateWarehouseInput, UpdateWarehouseInput } from './mdm.input';

const DEFAULT_TIMEZONE = 'Asia/Tashkent';

export function toWarehouseDto(warehouse: WarehouseEntity): WarehouseDto {
  return {
    id: warehouse.id,
    code: warehouse.code,
    name: warehouse.name,
    address: warehouse.address,
    timezone: warehouse.timezone,
    isActive: warehouse.isActive,
  };
}

/**
 * Проверяем зону через Intl, а не списком в БД: неверная таймзона проявилась бы
 * позже и молча — сдвигом дедлайнов SLA, а не понятной ошибкой при создании.
 */
function assertValidTimezone(timezone: string): void {
  try {
    new Intl.DateTimeFormat('ru-RU', { timeZone: timezone }).format(new Date());
  } catch {
    throw new BadRequestException(`Неизвестная таймзона «${timezone}». Ожидается IANA, например Asia/Tashkent.`);
  }
}

@Injectable()
export class WarehousesService {
  constructor(
    @InjectRepository(WarehouseEntity) private readonly repo: Repository<WarehouseEntity>,
    private readonly audit: AuditService,
  ) {}

  async list(): Promise<WarehouseDto[]> {
    const warehouses = await this.repo.find({ order: { code: 'ASC' } });
    return warehouses.map(toWarehouseDto);
  }

  async get(id: string): Promise<WarehouseDto> {
    const warehouse = await this.repo.findOne({ where: { id } });
    if (!warehouse) throw new NotFoundException('Склад не найден.');
    return toWarehouseDto(warehouse);
  }

  async create(dto: CreateWarehouseInput, actor: ActorContext): Promise<WarehouseDto> {
    const timezone = dto.timezone?.trim() || DEFAULT_TIMEZONE;
    assertValidTimezone(timezone);

    const entity = this.repo.create({
      code: dto.code.trim(),
      name: dto.name.trim(),
      address: dto.address?.trim() ?? null,
      timezone,
      isActive: true,
    });

    let saved: WarehouseEntity;
    try {
      saved = await this.repo.save(entity);
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_warehouses_code') {
        throw new ConflictException(`Склад с кодом «${dto.code}» уже существует.`);
      }
      throw error;
    }

    const after = toWarehouseDto(saved);
    await this.audit.record({
      action: 'CREATE',
      entityType: 'Warehouse',
      entityId: saved.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: after as unknown as Record<string, unknown>,
    });
    return after;
  }

  async update(id: string, dto: UpdateWarehouseInput, actor: ActorContext): Promise<WarehouseDto> {
    const warehouse = await this.repo.findOne({ where: { id } });
    if (!warehouse) throw new NotFoundException('Склад не найден.');

    const before = toWarehouseDto(warehouse);

    if (dto.name !== undefined) warehouse.name = dto.name.trim();
    if (dto.address !== undefined) warehouse.address = dto.address.trim();
    if (dto.timezone !== undefined) {
      const timezone = dto.timezone.trim();
      assertValidTimezone(timezone);
      warehouse.timezone = timezone;
    }
    if (dto.isActive !== undefined) warehouse.isActive = dto.isActive;

    const saved = await this.repo.save(warehouse);
    const after = toWarehouseDto(saved);

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Warehouse',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: before as unknown as Record<string, unknown>,
      after: after as unknown as Record<string, unknown>,
    });
    return after;
  }
}
