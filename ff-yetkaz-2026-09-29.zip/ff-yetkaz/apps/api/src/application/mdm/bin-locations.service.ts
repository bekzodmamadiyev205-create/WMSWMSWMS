import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import type { BinLocationDto } from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import type { ActorContext } from '../../domain/types/actor';
import { BinLocationEntity, WarehouseEntity } from '../../infrastructure/database/entities';
import type { CreateBinLocationInput, UpdateBinLocationInput } from './mdm.input';

export function toBinLocationDto(bin: BinLocationEntity): BinLocationDto {
  return {
    id: bin.id,
    warehouseId: bin.warehouseId,
    code: bin.code,
    kind: bin.kind,
    isActive: bin.isActive,
  };
}

@Injectable()
export class BinLocationsService {
  constructor(
    @InjectRepository(BinLocationEntity) private readonly repo: Repository<BinLocationEntity>,
    @InjectRepository(WarehouseEntity) private readonly warehouses: Repository<WarehouseEntity>,
    private readonly audit: AuditService,
  ) {}

  /** Сортировка по коду = порядок обхода при сборке (ячейки адресуются плоским кодом). */
  async listByWarehouse(warehouseId: string): Promise<BinLocationDto[]> {
    const warehouse = await this.warehouses.findOne({ where: { id: warehouseId } });
    if (!warehouse) throw new NotFoundException('Склад не найден.');

    const bins = await this.repo.find({ where: { warehouseId }, order: { code: 'ASC' } });
    return bins.map(toBinLocationDto);
  }

  async create(dto: CreateBinLocationInput, actor: ActorContext): Promise<BinLocationDto> {
    const warehouse = await this.warehouses.findOne({ where: { id: dto.warehouseId } });
    if (!warehouse) throw new NotFoundException('Склад не найден.');
    if (!warehouse.isActive) {
      throw new ConflictException('Нельзя заводить ячейки на деактивированном складе.');
    }

    const entity = this.repo.create({
      warehouseId: dto.warehouseId,
      code: dto.code.trim(),
      kind: dto.kind ?? 'STORAGE',
      isActive: true,
    });

    let saved: BinLocationEntity;
    try {
      saved = await this.repo.save(entity);
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_bin_locations_code') {
        throw new ConflictException(
          `Ячейка «${dto.code}» на складе «${warehouse.code}» уже существует.`,
        );
      }
      throw error;
    }

    const after = toBinLocationDto(saved);
    await this.audit.record({
      action: 'CREATE',
      entityType: 'BinLocation',
      entityId: saved.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: after as unknown as Record<string, unknown>,
    });
    return after;
  }

  async update(id: string, dto: UpdateBinLocationInput, actor: ActorContext): Promise<BinLocationDto> {
    const bin = await this.repo.findOne({ where: { id } });
    if (!bin) throw new NotFoundException('Ячейка не найдена.');

    const before = toBinLocationDto(bin);

    if (dto.code !== undefined) bin.code = dto.code.trim();
    if (dto.kind !== undefined) bin.kind = dto.kind;
    if (dto.isActive !== undefined) bin.isActive = dto.isActive;

    let saved: BinLocationEntity;
    try {
      saved = await this.repo.save(bin);
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_bin_locations_code') {
        throw new ConflictException(`Ячейка «${dto.code}» на этом складе уже существует.`);
      }
      throw error;
    }

    const after = toBinLocationDto(saved);
    await this.audit.record({
      action: 'UPDATE',
      entityType: 'BinLocation',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: before as unknown as Record<string, unknown>,
      after: after as unknown as Record<string, unknown>,
    });
    return after;
  }
}
