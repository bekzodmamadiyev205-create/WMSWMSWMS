import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  BinLocationEntity,
  SellerEntity,
  SkuBarcodeEntity,
  SkuEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { BinLocationsController } from '../../presentation/http/bin-locations.controller';
import { BinLocationsService } from './bin-locations.service';
import { SellersController } from '../../presentation/http/sellers.controller';
import { SellersService } from './sellers.service';
import { SkusRepository } from '../../infrastructure/database/repositories/skus.repository';
import { SkusController } from '../../presentation/http/skus.controller';
import { SkusService } from './skus.service';
import { WarehousesController } from '../../presentation/http/warehouses.controller';
import { WarehousesService } from './warehouses.service';

/** Master Data: единый реестр справочников, на который ссылаются все модули. */
@Module({
  imports: [
    TypeOrmModule.forFeature([
      SellerEntity,
      WarehouseEntity,
      BinLocationEntity,
      SkuEntity,
      SkuBarcodeEntity,
    ]),
  ],
  controllers: [SellersController, WarehousesController, BinLocationsController, SkusController],
  providers: [SellersService, WarehousesService, BinLocationsService, SkusService, SkusRepository],
  exports: [SellersService, WarehousesService, BinLocationsService, SkusService],
})
export class MdmModule {}
