import type { BarcodeKind, BinKind, SkuImportRowDto } from '@ff/shared';

/**
 * Формы входных данных операций MDM.
 *
 * Прикладному слою нужна ФОРМА запроса, а не класс из presentation: декораторы
 * class-validator существуют ради разбора HTTP и к бизнес-операции отношения не
 * имеют. Импорт классов DTO делал бы зависимость вверх — сервис знал бы про
 * транспорт и не переиспользовался бы ничем, кроме контроллера.
 *
 * Классы DTO объявлены `implements` этих интерфейсов: разъехавшаяся форма
 * ловится сборкой, а не на боевом запросе.
 */

export interface CreateSellerInput {
  code: string;
  legalName: string;
  taxId?: string;
  contactEmail?: string;
  contactPhone?: string;
  address?: string;
}

export interface UpdateSellerInput {
  legalName?: string;
  taxId?: string;
  contactEmail?: string;
  contactPhone?: string;
  address?: string;
  isActive?: boolean;
}

export interface CreateWarehouseInput {
  code: string;
  name: string;
  address?: string;
  timezone?: string;
}

export interface UpdateWarehouseInput {
  name?: string;
  address?: string;
  timezone?: string;
  isActive?: boolean;
}

export interface CreateBinLocationInput {
  warehouseId: string;
  code: string;
  kind?: BinKind;
}

export interface UpdateBinLocationInput {
  code?: string;
  kind?: BinKind;
  isActive?: boolean;
}

export interface CreateSkuInput {
  sellerId: string;
  skuCode: string;
  name: string;
  lengthMm?: number;
  widthMm?: number;
  heightMm?: number;
  weightG?: number;
  isLotTracked?: boolean;
  isExpiryTracked?: boolean;
  shelfLifeDays?: number;
}

export interface UpdateSkuInput {
  name?: string;
  lengthMm?: number;
  widthMm?: number;
  heightMm?: number;
  weightG?: number;
  isLotTracked?: boolean;
  isExpiryTracked?: boolean;
  shelfLifeDays?: number;
  isActive?: boolean;
}

export interface CreateSkuBarcodeInput {
  barcode: string;
  kind?: BarcodeKind;
  isPrimary?: boolean;
}

/** Строка загрузки описана контрактом `SkuImportRowDto` — второй копии не заводим. */
export interface ImportSkusInput {
  sellerId: string;
  rows: SkuImportRowDto[];
}

export interface ListSkusQueryInput {
  sellerId?: string;
  q?: string;
  limit?: number;
  /** Приходит из строки запроса, поэтому строка, а не boolean. */
  activeOnly?: 'true' | 'false';
}
