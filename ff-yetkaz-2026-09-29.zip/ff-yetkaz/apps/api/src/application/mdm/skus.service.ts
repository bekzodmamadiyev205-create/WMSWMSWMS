import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, type EntityManager } from 'typeorm';
import type {
  SkuBarcodeDto,
  SkuDto,
  SkuImportResultDto,
  SkuImportResultRowDto,
} from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import { SkusRepository } from '../../infrastructure/database/repositories/skus.repository';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { SellerEntity, SkuBarcodeEntity, SkuEntity } from '../../infrastructure/database/entities';
import type {
  CreateSkuBarcodeInput,
  CreateSkuInput,
  ImportSkusInput,
  ListSkusQueryInput,
  UpdateSkuInput,
} from './mdm.input';

const DEFAULT_LIMIT = 100;

function toBarcodeDto(barcode: SkuBarcodeEntity): SkuBarcodeDto {
  return {
    id: barcode.id,
    skuId: barcode.skuId,
    barcode: barcode.barcode,
    kind: barcode.kind,
    isPrimary: barcode.isPrimary,
  };
}

export function toSkuDto(sku: SkuEntity): SkuDto {
  return {
    id: sku.id,
    sellerId: sku.sellerId,
    skuCode: sku.skuCode,
    name: sku.name,
    lengthMm: sku.lengthMm,
    widthMm: sku.widthMm,
    heightMm: sku.heightMm,
    weightG: sku.weightG,
    volumeMm3: sku.volumeMm3,
    isLotTracked: sku.isLotTracked,
    isExpiryTracked: sku.isExpiryTracked,
    shelfLifeDays: sku.shelfLifeDays,
    isActive: sku.isActive,
    barcodes: (sku.barcodes ?? []).map(toBarcodeDto),
  };
}

@Injectable()
export class SkusService {
  constructor(
    @InjectRepository(SkuEntity) private readonly repo: Repository<SkuEntity>,
    @InjectRepository(SkuBarcodeEntity) private readonly barcodes: Repository<SkuBarcodeEntity>,
    @InjectRepository(SellerEntity) private readonly sellers: Repository<SellerEntity>,
    private readonly audit: AuditService,
    private readonly sql: SkusRepository,
  ) {}

  async list(query: ListSkusQueryInput, actor: ActorContext): Promise<SkuDto[]> {
    const scope = resolveSellerScope(actor.user);

    // Везде имена СВОЙСТВ, а не колонок: при take() с join'ом TypeORM строит
    // отдельный запрос идентификаторов и резолвит orderBy через метаданные —
    // с «sku.sku_code» он не находит колонку и падает.
    const builder = this.repo
      .createQueryBuilder('sku')
      .leftJoinAndSelect('sku.barcodes', 'barcode')
      .orderBy('sku.skuCode', 'ASC')
      .take(query.limit ?? DEFAULT_LIMIT);

    if (scope !== null) {
      builder.andWhere('sku.sellerId = :scope', { scope });
    } else if (query.sellerId) {
      builder.andWhere('sku.sellerId = :sellerId', { sellerId: query.sellerId });
    }

    if (query.activeOnly !== 'false') builder.andWhere('sku.isActive = true');

    if (query.q) {
      builder.andWhere('(sku.skuCode ILIKE :q OR sku.name ILIKE :q)', { q: `%${query.q}%` });
    }

    const skus = await builder.getMany();
    return skus.map(toSkuDto);
  }

  async get(id: string, actor: ActorContext): Promise<SkuDto> {
    const scope = resolveSellerScope(actor.user);
    const sku = await this.repo.findOne({ where: { id }, relations: { barcodes: true } });
    // Чужой SKU — 404, а не 403: иначе перебором подтверждается его существование.
    if (!sku || (scope !== null && sku.sellerId !== scope)) {
      throw new NotFoundException('SKU не найден.');
    }
    return toSkuDto(sku);
  }

  /** Ручка сканера: штрихкод уникален глобально, поэтому селлер не нужен. */
  async findByBarcode(barcode: string, actor: ActorContext): Promise<SkuDto> {
    const scope = resolveSellerScope(actor.user);
    const found = await this.barcodes.findOne({ where: { barcode: barcode.trim() } });
    if (!found) throw new NotFoundException(`Штрихкод «${barcode}» не найден.`);

    const sku = await this.repo.findOne({
      where: { id: found.skuId },
      relations: { barcodes: true },
    });
    if (!sku || (scope !== null && sku.sellerId !== scope)) {
      throw new NotFoundException(`Штрихкод «${barcode}» не найден.`);
    }
    return toSkuDto(sku);
  }

  async create(dto: CreateSkuInput, actor: ActorContext): Promise<SkuDto> {
    const seller = await this.sellers.findOne({ where: { id: dto.sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    if (!seller.isActive) {
      throw new ConflictException('Нельзя заводить SKU для деактивированного селлера.');
    }

    const isLotTracked = dto.isLotTracked ?? false;
    const isExpiryTracked = dto.isExpiryTracked ?? false;
    this.assertTrackingConsistent(isLotTracked, isExpiryTracked, dto.shelfLifeDays ?? null);

    const entity = this.repo.create({
      sellerId: dto.sellerId,
      skuCode: dto.skuCode.trim(),
      name: dto.name.trim(),
      lengthMm: dto.lengthMm ?? null,
      widthMm: dto.widthMm ?? null,
      heightMm: dto.heightMm ?? null,
      weightG: dto.weightG ?? null,
      isLotTracked,
      isExpiryTracked,
      shelfLifeDays: dto.shelfLifeDays ?? null,
      isActive: true,
    });

    let saved: SkuEntity;
    try {
      saved = await this.repo.save(entity);
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_skus_seller_code') {
        throw new ConflictException(
          `У селлера «${seller.code}» уже есть артикул «${dto.skuCode}».`,
        );
      }
      throw error;
    }

    const after = await this.reload(saved.id);
    await this.audit.record({
      action: 'CREATE',
      entityType: 'Sku',
      entityId: saved.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: after as unknown as Record<string, unknown>,
    });
    return after;
  }

  /**
   * Загрузка каталога клиента списком.
   *
   * Каждая строка обрабатывается в СВОЁМ savepoint: файл на тысячу позиций не
   * должен целиком отвергаться из-за одной опечатки в весе. Оператор получает
   * построчный отчёт с номерами строк — иначе непонятно, что чинить.
   *
   * Повторная загрузка того же файла безопасна: существующий артикул
   * обновляется, а не задваивается.
   */
  async import(dto: ImportSkusInput, actor: ActorContext): Promise<SkuImportResultDto> {
    const seller = await this.sellers.findOne({ where: { id: dto.sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    if (!seller.isActive) {
      throw new ConflictException('Нельзя загружать каталог деактивированному селлеру.');
    }

    const result: SkuImportResultDto = { created: 0, updated: 0, failed: 0, rows: [] };

    await this.repo.manager.transaction(async (em) => {
      const skus = em.getRepository(SkuEntity);
      const barcodes = em.getRepository(SkuBarcodeEntity);

      for (const [index, row] of dto.rows.entries()) {
        const rowNumber = index + 1;
        const skuCode = row.skuCode.trim();

        await this.sql.openImportRowSavepoint(em);
        try {
          const existing = await skus
            .createQueryBuilder('sku')
            .where('sku.sellerId = :sellerId', { sellerId: dto.sellerId })
            .andWhere('lower(sku.skuCode) = :code', { code: skuCode.toLowerCase() })
            .getOne();

          let sku: SkuEntity;
          let outcome: SkuImportResultRowDto['outcome'];
          if (existing) {
            // Пустые поля файла не затирают заполненные: клиент часто
            // присылает частичный список, где веса есть не у всех позиций.
            existing.name = row.name.trim();
            if (row.weightG !== undefined) existing.weightG = row.weightG;
            if (row.lengthMm !== undefined) existing.lengthMm = row.lengthMm;
            if (row.widthMm !== undefined) existing.widthMm = row.widthMm;
            if (row.heightMm !== undefined) existing.heightMm = row.heightMm;
            sku = await skus.save(existing);
            outcome = 'UPDATED';
          } else {
            sku = await skus.save(
              skus.create({
                sellerId: dto.sellerId,
                skuCode,
                name: row.name.trim(),
                weightG: row.weightG ?? null,
                lengthMm: row.lengthMm ?? null,
                widthMm: row.widthMm ?? null,
                heightMm: row.heightMm ?? null,
                isLotTracked: false,
                isExpiryTracked: false,
                shelfLifeDays: null,
                isActive: true,
              }),
            );
            outcome = 'CREATED';
          }

          const barcode = row.barcode?.trim();
          if (barcode) {
            const owner = await barcodes.findOne({ where: { barcode } });
            if (!owner) {
              await barcodes.save(
                barcodes.create({ skuId: sku.id, barcode, kind: 'EAN13', isPrimary: true }),
              );
            } else if (owner.skuId !== sku.id) {
              throw new ConflictException(await this.describeBarcodeConflict(barcode, em));
            }
          }

          await this.sql.releaseImportRowSavepoint(em);
          if (outcome === 'CREATED') result.created += 1;
          else result.updated += 1;
          result.rows.push({ row: rowNumber, skuCode, outcome, message: null });
        } catch (error) {
          await this.sql.rollbackImportRowSavepoint(em);
          result.failed += 1;
          result.rows.push({
            row: rowNumber,
            skuCode,
            outcome: 'FAILED',
            message: error instanceof Error ? error.message : 'Неизвестная ошибка.',
          });
        }
      }
    });

    await this.audit.record({
      action: 'CREATE',
      entityType: 'SkuImport',
      entityId: dto.sellerId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: { created: result.created, updated: result.updated, failed: result.failed },
    });

    return result;
  }

  async update(id: string, dto: UpdateSkuInput, actor: ActorContext): Promise<SkuDto> {
    const sku = await this.repo.findOne({ where: { id }, relations: { barcodes: true } });
    if (!sku) throw new NotFoundException('SKU не найден.');

    const before = toSkuDto(sku);

    if (dto.name !== undefined) sku.name = dto.name.trim();
    if (dto.lengthMm !== undefined) sku.lengthMm = dto.lengthMm;
    if (dto.widthMm !== undefined) sku.widthMm = dto.widthMm;
    if (dto.heightMm !== undefined) sku.heightMm = dto.heightMm;
    if (dto.weightG !== undefined) sku.weightG = dto.weightG;
    if (dto.isLotTracked !== undefined) sku.isLotTracked = dto.isLotTracked;
    if (dto.isExpiryTracked !== undefined) sku.isExpiryTracked = dto.isExpiryTracked;
    if (dto.shelfLifeDays !== undefined) sku.shelfLifeDays = dto.shelfLifeDays;
    if (dto.isActive !== undefined) sku.isActive = dto.isActive;

    // Проверяем итоговое состояние, а не присланные поля: выключить партионный
    // учёт, оставив включённым учёт срока, — тоже недопустимо.
    this.assertTrackingConsistent(sku.isLotTracked, sku.isExpiryTracked, sku.shelfLifeDays);

    await this.repo.save(sku);
    const after = await this.reload(id);

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Sku',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: before as unknown as Record<string, unknown>,
      after: after as unknown as Record<string, unknown>,
    });
    return after;
  }

  async addBarcode(skuId: string, dto: CreateSkuBarcodeInput, actor: ActorContext): Promise<SkuDto> {
    const sku = await this.repo.findOne({ where: { id: skuId } });
    if (!sku) throw new NotFoundException('SKU не найден.');

    const barcode = dto.barcode.trim();

    try {
      await this.barcodes.manager.transaction(async (em) => {
        const barcodes = em.getRepository(SkuBarcodeEntity);
        if (dto.isPrimary) {
          // Снятие флага с прежнего основного идёт в одной транзакции со вставкой:
          // иначе конфликт штрихкода оставил бы SKU вовсе без основного кода.
          await barcodes.update({ skuId, isPrimary: true }, { isPrimary: false });
        }
        await barcodes.save(
          barcodes.create({
            skuId,
            barcode,
            kind: dto.kind ?? 'INTERNAL',
            isPrimary: dto.isPrimary ?? false,
          }),
        );
      });
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_sku_barcodes_barcode') {
        throw new ConflictException(await this.describeBarcodeConflict(barcode));
      }
      throw error;
    }

    const after = await this.reload(skuId);
    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Sku',
      entityId: skuId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: { addedBarcode: barcode },
    });
    return after;
  }

  async removeBarcode(skuId: string, barcodeId: string, actor: ActorContext): Promise<SkuDto> {
    const barcode = await this.barcodes.findOne({ where: { id: barcodeId, skuId } });
    if (!barcode) throw new NotFoundException('Штрихкод не найден у этого SKU.');

    await this.barcodes.delete({ id: barcodeId });

    const after = await this.reload(skuId);
    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Sku',
      entityId: skuId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: { removedBarcode: barcode.barcode },
    });
    return after;
  }

  /**
   * Глобальная уникальность штрихкода — решение PM. Когда она срабатывает,
   * оператору нужно знать, за кем код уже закреплён, иначе конфликт не разрулить.
   */
  private async describeBarcodeConflict(barcode: string, em?: EntityManager): Promise<string> {
    // Внутри загрузки смотрим ТОЙ ЖЕ транзакцией: конфликт может быть со
    // строкой, вставленной парой строк выше, а снаружи её ещё не видно.
    const barcodes = em ? em.getRepository(SkuBarcodeEntity) : this.barcodes;
    const skus = em ? em.getRepository(SkuEntity) : this.repo;

    const existing = await barcodes.findOne({ where: { barcode } });
    if (!existing) return `Штрихкод «${barcode}» уже занят.`;

    const owner = await skus.findOne({
      where: { id: existing.skuId },
      relations: { seller: true },
    });
    if (!owner) return `Штрихкод «${barcode}» уже занят.`;

    return (
      `Штрихкод «${barcode}» уже закреплён за SKU «${owner.skuCode}» ` +
      `селлера «${owner.seller?.code ?? owner.sellerId}». ` +
      'Штрихкоды в системе уникальны глобально.'
    );
  }

  private assertTrackingConsistent(
    isLotTracked: boolean,
    isExpiryTracked: boolean,
    shelfLifeDays: number | null,
  ): void {
    if (isExpiryTracked && !isLotTracked) {
      throw new BadRequestException(
        'Учёт срока годности требует партионного учёта: сама дата хранится на партии, а не на SKU.',
      );
    }
    if (shelfLifeDays !== null && !isExpiryTracked) {
      throw new BadRequestException('Срок хранения задаётся только при включённом учёте срока годности.');
    }
  }

  private async reload(id: string): Promise<SkuDto> {
    const sku = await this.repo.findOne({ where: { id }, relations: { barcodes: true } });
    if (!sku) throw new NotFoundException('SKU не найден.');
    return toSkuDto(sku);
  }
}
