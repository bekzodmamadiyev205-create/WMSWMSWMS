import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import type { SellerDto } from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { isForeignKeyViolation, uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { SellerEntity } from '../../infrastructure/database/entities';
import type { CreateSellerInput, UpdateSellerInput } from './mdm.input';

export function toSellerDto(seller: SellerEntity): SellerDto {
  return {
    id: seller.id,
    code: seller.code,
    legalName: seller.legalName,
    taxId: seller.taxId,
    contactEmail: seller.contactEmail,
    contactPhone: seller.contactPhone,
    address: seller.address,
    isActive: seller.isActive,
  };
}

@Injectable()
export class SellersService {
  constructor(
    @InjectRepository(SellerEntity) private readonly repo: Repository<SellerEntity>,
    private readonly audit: AuditService,
  ) {}

  async list(actor: ActorContext): Promise<SellerDto[]> {
    const scope = resolveSellerScope(actor.user);
    const sellers = await this.repo.find({
      where: scope === null ? {} : { id: scope },
      order: { code: 'ASC' },
    });
    return sellers.map(toSellerDto);
  }

  async get(id: string, actor: ActorContext): Promise<SellerDto> {
    const scope = resolveSellerScope(actor.user);
    if (scope !== null && scope !== id) {
      // 404, а не 403: чужой селлер не должен подтверждать даже своё существование.
      throw new NotFoundException('Селлер не найден.');
    }
    const seller = await this.repo.findOne({ where: { id } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    return toSellerDto(seller);
  }

  async create(dto: CreateSellerInput, actor: ActorContext): Promise<SellerDto> {
    const entity = this.repo.create({
      code: dto.code.trim(),
      legalName: dto.legalName.trim(),
      taxId: dto.taxId?.trim() ?? null,
      contactEmail: dto.contactEmail?.trim().toLowerCase() ?? null,
      contactPhone: dto.contactPhone?.trim() ?? null,
      address: dto.address?.trim() ?? null,
      isActive: true,
    });

    let saved: SellerEntity;
    try {
      saved = await this.repo.save(entity);
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_sellers_code') {
        throw new ConflictException(`Селлер с кодом «${dto.code}» уже существует.`);
      }
      throw error;
    }

    const after = toSellerDto(saved);
    await this.audit.record({
      action: 'CREATE',
      entityType: 'Seller',
      entityId: saved.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: after as unknown as Record<string, unknown>,
    });
    return after;
  }

  async update(id: string, dto: UpdateSellerInput, actor: ActorContext): Promise<SellerDto> {
    const seller = await this.repo.findOne({ where: { id } });
    if (!seller) throw new NotFoundException('Селлер не найден.');

    const before = toSellerDto(seller);

    if (dto.legalName !== undefined) seller.legalName = dto.legalName.trim();
    if (dto.taxId !== undefined) seller.taxId = dto.taxId.trim();
    if (dto.contactEmail !== undefined) seller.contactEmail = dto.contactEmail.trim().toLowerCase();
    if (dto.contactPhone !== undefined) seller.contactPhone = dto.contactPhone.trim();
    if (dto.address !== undefined) seller.address = dto.address.trim();
    if (dto.isActive !== undefined) seller.isActive = dto.isActive;

    const saved = await this.repo.save(seller);
    const after = toSellerDto(saved);

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Seller',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: before as unknown as Record<string, unknown>,
      after: after as unknown as Record<string, unknown>,
    });
    return after;
  }

  /**
   * Удаление селлера. Разрешено, только пока на него никто не ссылается
   * (нет заказов, товаров, пользователей). Иначе — 409 с подсказкой отключить:
   * снести селлера с историей значило бы осиротить заказы и движения товара.
   */
  async remove(id: string, actor: ActorContext): Promise<void> {
    const seller = await this.repo.findOne({ where: { id } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    const before = toSellerDto(seller);

    try {
      await this.repo.delete(id);
    } catch (error) {
      if (isForeignKeyViolation(error)) {
        throw new ConflictException(
          'Нельзя удалить селлера: на него ссылаются заказы, товары или пользователи. ' +
            'Отключите его вместо удаления.',
        );
      }
      throw error;
    }

    await this.audit.record({
      action: 'DELETE',
      entityType: 'Seller',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: before as unknown as Record<string, unknown>,
    });
  }
}
