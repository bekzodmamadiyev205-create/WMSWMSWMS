import { Global, Module } from '@nestjs/common';
import { FsmService } from './fsm.service';
import { StatusHistoryRepository } from '../../infrastructure/database/repositories/status-history.repository';
import { StatusHistoryService } from './status-history.service';

@Global()
@Module({
  providers: [FsmService, StatusHistoryService, StatusHistoryRepository],
  exports: [FsmService, StatusHistoryService],
})
export class FsmModule {}
