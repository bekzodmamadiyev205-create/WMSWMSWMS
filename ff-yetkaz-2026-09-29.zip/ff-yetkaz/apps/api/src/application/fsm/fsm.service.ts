import { Injectable } from '@nestjs/common';
import { InvalidTransitionError, type StateMachine } from '@ff/shared';
import type { EntityManager } from 'typeorm';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { StatusHistoryService } from './status-history.service';

export interface TransitionContext {
  entityType: string;
  entityId: string;
  actorUserId?: string | null;
  actorRole?: string | null;
  correlationId?: string | null;
  /** Дополнительные поля, которые нужно сохранить в `after` записи аудита. */
  extra?: Record<string, unknown>;
  /** Источник перехода для трека статусов: по умолчанию — роль актора. */
  source?: string | null;
  /** Комментарий в трек: причина отмены, номер накладной и т.п. */
  comment?: string | null;
}

@Injectable()
export class FsmService {
  constructor(
    private readonly audit: AuditService,
    private readonly history: StatusHistoryService,
  ) {}

  /**
   * Проверяет переход по таблице машины, пишет его в аудит и в трек статусов.
   *
   * Отказ тоже журналируется — отдельным соединением, поэтому запись
   * INVALID_STATE_TRANSITION остаётся в БД даже после отката транзакции вызова.
   *
   * Почему трек пишется ЗДЕСЬ, а не в каждом вызывающем сервисе: статус заказа
   * двигают семь мест в четырёх модулях (приём, резерв, сборка, упаковка,
   * оформление отправления, расход, вебхук перевозчика). Требование «каждый
   * переход виден в треке» при записи по месту держится только на дисциплине —
   * восьмое место неизбежно её нарушит, и дыру в истории заметят через месяц
   * по кривой воронке. Здесь же единственный проход, через который обязан
   * пройти любой переход: не записать трек можно только в обход FsmService.
   *
   * Запись идёт ТЕМ ЖЕ `manager`, что и аудит с самим статусом: трека без
   * перехода и перехода без трека быть не должно. Ошибку не глушим —
   * потерянный трек это потерянный журнал, а не мелочь оформления.
   */
  async transition<S extends string>(
    machine: StateMachine<S>,
    from: S,
    to: S,
    context: TransitionContext,
    manager?: EntityManager,
  ): Promise<void> {
    try {
      machine.assert(from, to);
    } catch (error) {
      if (error instanceof InvalidTransitionError) {
        await this.audit.recordSafe({
          action: 'INVALID_STATE_TRANSITION',
          entityType: context.entityType,
          entityId: context.entityId,
          actorUserId: context.actorUserId,
          actorRole: context.actorRole,
          correlationId: context.correlationId,
          before: { status: from },
          after: { status: to, allowed: machine.next(from) },
        });
      }
      // Пробрасываем исходную ошибку: AllExceptionsFilter отдаст 409 с кодом
      // INVALID_TRANSITION и списком разрешённых переходов. Если завернуть её
      // в ConflictException, тот же отказ приходил бы клиенту под двумя разными
      // кодами — смотря через FsmService он прошёл или через machine.assert().
      throw error;
    }

    await this.audit.record(
      {
        action: 'STATE_TRANSITION',
        entityType: context.entityType,
        entityId: context.entityId,
        actorUserId: context.actorUserId,
        actorRole: context.actorRole,
        correlationId: context.correlationId,
        before: { status: from },
        after: { status: to, ...(context.extra ?? {}) },
      },
      manager,
    );

    await this.history.record(
      machine,
      context.entityId,
      from,
      to,
      {
        actorUserId: context.actorUserId,
        actorRole: context.actorRole,
        source: context.source,
        comment: context.comment,
      },
      manager,
    );
  }
}
