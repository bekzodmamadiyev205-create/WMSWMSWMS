import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import { orderFsm, returnFsm, type StateMachine } from '@ff/shared';
import { StatusHistoryRepository } from '../../infrastructure/database/repositories/status-history.repository';

/** Чем сопроводить запись трека: кто перевёл и с какой формулировкой. */
export interface StatusHistoryContext {
  actorUserId?: string | null;
  actorRole?: string | null;
  /** Источник перехода: роль пользователя, `carrier:<code>`, `system`. */
  source?: string | null;
  comment?: string | null;
}

/**
 * Журналы статусов: `order_status_history` и `return_status_history`.
 *
 * Журнал заказа append-only на уровне БД: UPDATE/DELETE запрещены триггером,
 * так что «поправить трек» невозможно by design. У журнала возвратов такого
 * триггера нет, но и здесь есть только вставка — правок не бывает.
 *
 * Машина выбирается по `machine.name`, а не по строке `entityType` из
 * контекста: `entityType` пишет каждый вызывающий руками, и опечатка «Orders»
 * вместо «Order» молча выключила бы трек. Имя машины приходит из общей модели
 * состояний и опечататься не может.
 */
/**
 * Идентификаторы заказов и возвратов — uuid, и колонки журналов это FK на них.
 * FsmService глобальный: его зовут четыре модуля, а в тестах — и с синтетическим
 * идентификатором. Запись трека не имеет права уронить бизнес-переход из-за того,
 * что вызывающий передал не uuid: такой идентификатор в этой схеме заказом быть
 * не может, поэтому журнала для него просто нет.
 */
const UUID_SHAPE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

@Injectable()
export class StatusHistoryService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly history: StatusHistoryRepository,
  ) {}

  async record<S extends string>(
    machine: StateMachine<S>,
    entityId: string,
    from: S | null,
    to: S,
    context: StatusHistoryContext,
    manager?: EntityManager,
  ): Promise<void> {
    const em = manager ?? this.dataSource.manager;
    const source = context.source ?? context.actorRole ?? 'system';

    if (!UUID_SHAPE.test(entityId)) return;

    if (machine.name === orderFsm.name) {
      await this.history.insertOrderTransition(em, [
        entityId,
        from,
        to,
        source,
        context.actorUserId ?? null,
        context.comment ?? null,
      ]);
      return;
    }

    if (machine.name === returnFsm.name) {
      // У возвратов колонки `source` нет: возврат двигает только человек,
      // внешних инициаторов у него не бывает.
      await this.history.insertReturnTransition(em, [
        entityId,
        from,
        to,
        context.actorUserId ?? null,
        context.comment ?? null,
      ]);
      return;
    }

    // Отправление, поставка, задание на сборку и единица хранения своих
    // журналов статусов не имеют — у них есть аудит и собственные таблицы
    // событий. Молча ничего не делаем: это не ошибка, а отсутствие журнала.
  }
}
