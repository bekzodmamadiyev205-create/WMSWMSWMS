import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import type { LedgerBalanceRowDto, LedgerSide } from '@ff/shared';
import { LedgerRepository } from '../../infrastructure/database/repositories/ledger.repository';

export interface LedgerLeg {
  accountCode: string;
  side: LedgerSide;
  /** Строкой: деньги через float недопустимы. */
  amount: string;
  sellerId?: string | null;
}

export interface LedgerPosting {
  occurredAt: Date;
  description: string;
  sellerId: string | null;
  /** Пара (тип, id) делает проводку идемпотентной — её держит индекс в БД. */
  referenceType: string;
  referenceId: string;
  currency: string;
  legs: LedgerLeg[];
}

/**
 * Бухгалтерская книга: двойная запись, только добавление.
 *
 * Сходимость дебета и кредита проверяет отложенный триггер БД, а не этот код:
 * сервисный слой можно обойти скриптом, а триггер — нет. Здесь остаётся
 * идемпотентность и удобная форма записи.
 */
@Injectable()
export class LedgerService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly repo: LedgerRepository,
  ) {}

  /**
   * Проводит операцию. Возвращает id проводки либо `null`, если такая уже
   * была проведена: повторный прогон начисления не должен удваивать деньги.
   */
  async post(em: EntityManager, posting: LedgerPosting): Promise<string | null> {
    // ON CONFLICT, а не try/catch: повторный прогон начислений — штатная
    // ситуация, и заваливать журнал PostgreSQL ошибками уникальности из-за
    // штатного сценария незачем.
    const rows = await this.repo.insertTransactionIfNew(
      em,
      posting.occurredAt.toISOString(),
      posting.description,
      posting.sellerId,
      posting.referenceType,
      posting.referenceId,
    );
    if (rows.length === 0) return null;
    const transactionId = rows[0].id;

    for (const leg of posting.legs) {
      await this.repo.insertEntry(
        em,
        transactionId,
        leg.accountCode,
        leg.sellerId ?? posting.sellerId,
        leg.side,
        leg.amount,
        posting.currency,
      );
    }

    return transactionId;
  }

  /** Оборотно-сальдовая ведомость: чем и заканчивается любая проверка книги. */
  async balances(sellerId?: string): Promise<LedgerBalanceRowDto[]> {
    const rows = await this.repo.accountBalances(this.dataSource, sellerId);

    return rows.map((row) => ({
      accountCode: row.code,
      accountName: row.name,
      currency: row.currency,
      debit: row.debit,
      credit: row.credit,
      balance: (Number(row.debit) - Number(row.credit)).toFixed(2),
    }));
  }
}
