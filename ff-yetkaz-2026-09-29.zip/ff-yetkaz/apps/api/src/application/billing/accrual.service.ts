import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import {
  DEFAULT_TARIFF_COMPONENT,
  FF_EVENTS,
  type AccrualResultDto,
  type ChargeKind,
  type TariffUnit,
} from '@ff/shared';
import { createEvent, EVENT_BUS, type EventBus } from '../../infrastructure/queues/events/event-bus';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import {
  AccrualRepository,
  type AccrualRow,
  type AccrualSource,
} from '../../infrastructure/database/repositories/accrual.repository';
import type { ActorContext } from '../../domain/types/actor';
import { LedgerService } from './ledger.service';
import { TariffsService, type ResolvedTariff, type TariffComponentRules } from './tariffs.service';

/** Какая мера объёма соответствует единице тарификации. */
const UNIT_COLUMN: Record<TariffUnit, keyof AccrualRow | null> = {
  PER_ORDER: 'qty_orders',
  PER_UNIT: 'qty_units',
  PER_KG: 'qty_kg',
  PER_M3_DAY: 'qty_m3day',
  PERCENT_OF_COD: 'qty_cod',
  FLAT: null,
  PER_BOX: 'qty_boxes',
  PER_PALLET: 'qty_pallets',
  PER_BOX_DAY: 'qty_boxday',
  PER_PALLET_DAY: 'qty_palletday',
};

/**
 * Единицы, где объём округляется ВВЕРХ — ровно один раз, по итогу всей строки.
 *
 * Разовая операция с тарой штучная: 2.3 коробки означает, что кладовщик взял в
 * руки три, и оператор берёт деньги за три. А хранение — не операция, а время:
 * 2.3 паллеты действительно занимают 2.3 паллетоместа, и округление каждого
 * дня вверх за месяц превратилось бы в заметную приписку. Поэтому
 * `PER_BOX_DAY`/`PER_PALLET_DAY` считаются дробными.
 */
const ROUND_UP_UNITS: ReadonlySet<TariffUnit> = new Set<TariffUnit>(['PER_BOX', 'PER_PALLET']);

/**
 * Разряды колонок `charges`: количество `numeric(14,3)`, цена `numeric(14,4)`,
 * сумма `numeric(14,2)`. Деньги считаются в ЦЕЛЫХ долях этих разрядов.
 */
const QTY_SCALE = 3;
const PRICE_SCALE = 4;
const AMOUNT_SCALE = 2;

/** Делитель, приводящий произведение «количество × цена» к разряду денег. */
const AMOUNT_DIVISOR = 10n ** BigInt(QTY_SCALE + PRICE_SCALE - AMOUNT_SCALE);
/** Тот же перевод для цены без количества (`FLAT`). */
const PRICE_DIVISOR = 10n ** BigInt(PRICE_SCALE - AMOUNT_SCALE);

/**
 * Десятичная строка → целое в заданном разряде.
 *
 * Через `Number` этот путь идти НЕЛЬЗЯ: `4.1 * 0.05` в double равно
 * 0.20499999999999999, и `toFixed(2)` отдаёт «0.20» вместо «0.21» — копейка
 * теряется на каждой такой коробке. Оба множителя приходят готовыми
 * десятичными строками ровно своего разряда (numeric из БД и `toFixed`),
 * поэтому разбираются посимвольно и перемножаются уже в `BigInt`.
 */
function toScaled(value: string, scale: number): bigint {
  const parsed = /^(-?)(\d*)(?:\.(\d*))?$/.exec(value.trim());
  if (!parsed) throw new Error(`Не десятичное число: ${value}`);
  const [, sign, whole, fraction = ''] = parsed;
  return BigInt(`${sign}${whole || '0'}${fraction.padEnd(scale, '0').slice(0, scale)}`);
}

/** Целое в заданном разряде → десятичная строка для колонки `numeric`. */
function fromScaled(value: bigint, scale: number): string {
  const negative = value < 0n;
  const digits = (negative ? -value : value).toString().padStart(scale + 1, '0');
  const point = digits.length - scale;
  return `${negative ? '-' : ''}${digits.slice(0, point)}.${digits.slice(point)}`;
}

/**
 * Деление целых с округлением ПОЛОВИНЫ ВВЕРХ — так округляют деньги.
 * `BigInt` делит с усечением к нулю, поэтому половину добавляем руками.
 */
function divideHalfUp(value: bigint, divisor: bigint): bigint {
  const half = divisor / 2n;
  return value < 0n ? (value - half) / divisor : (value + half) / divisor;
}

/** Итог по одной строке-основанию: составляющих у неё может быть несколько. */
interface RowOutcome {
  created: number;
  exists: number;
  problems: number;
}

/**
 * Ключ идемпотентности начисления для составляющей цены.
 *
 * `BASE` сохраняет ИСТОРИЧЕСКИЙ ключ (`packing:<id>`) — без этого первый же
 * прогон после выката не узнал бы уже посчитанные начисления и создал их
 * заново, удвоив счета за все прошлые периоды.
 */
function componentSourceKey(baseKey: string, component: string): string {
  return component === DEFAULT_TARIFF_COMPONENT ? baseKey : `${baseKey}:${component}`;
}

@Injectable()
export class AccrualService {
  private readonly logger = new Logger(AccrualService.name);

  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly tariffs: TariffsService,
    private readonly ledger: LedgerService,
    @Inject(EVENT_BUS) private readonly events: EventBus,
    private readonly repo: AccrualRepository,
  ) {}

  /**
   * Ежедневный срез хранения.
   *
   * Остаток — величина мгновенная: по нему нельзя восстановить, сколько товар
   * пролежал. Поэтому объём фиксируется на каждый день отдельно, и тариф
   * «за кубометр-сутки» получает честную базу.
   */
  async snapshotStorage(date: string): Promise<{ date: string; sellers: number }> {
    const rows = await this.repo.upsertStorageSnapshots(this.dataSource, date);
    return { date, sellers: rows.length };
  }

  /**
   * Прогон начислений за период. Идемпотентен: повторный запуск досчитает
   * пропущенное и не тронет уже посчитанное.
   */
  async accrue(periodStart: string, periodEnd: string, actor: ActorContext): Promise<AccrualResultDto> {
    const result: AccrualResultDto = {
      periodStart,
      periodEnd,
      created: 0,
      skippedExisting: 0,
      problems: 0,
      byKind: {},
    };

    // Тариф зависит от тройки (селлер, услуга, дата) и в пределах прогона не
    // меняется. Без памятки каждая строка-основание тянула бы его заново — а
    // строк за месяц тысячи.
    const tariffCache = new Map<string, ResolvedTariff | null>();

    for (const source of this.repo.sources) {
      const rows: AccrualRow[] = await this.repo.rowsForSource(
        this.dataSource,
        source,
        periodStart,
        periodEnd,
      );
      for (const row of rows) {
        const outcome = await this.applyRow(source, row, actor, tariffCache);
        result.created += outcome.created;
        result.skippedExisting += outcome.exists;
        result.problems += outcome.problems;
        if (outcome.created > 0) {
          result.byKind[source.kind] = (result.byKind[source.kind] ?? 0) + outcome.created;
        }
      }
    }

    // Собранный наложенный платёж — не услуга, а деньги селлера у перевозчика.
    // Он проводится по книге отдельно от начислений.
    result.problems += await this.postCollectedCod(periodStart, periodEnd);

    return result;
  }

  async problems(): Promise<Array<Record<string, unknown>>> {
    return this.repo.openProblems(this.dataSource);
  }

  // ------------------------------------------------------------ внутреннее

  /**
   * Одна строка-основание — по начислению на КАЖДУЮ составляющую цены.
   *
   * Составляющие независимы: если у «перевеса по кг» не нашлось ступени, это
   * не повод не выставить «за паллету». Иначе одна кривая строка тарифа гасила
   * бы услугу целиком.
   */
  private async applyRow(
    source: AccrualSource,
    row: AccrualRow,
    actor: ActorContext,
    cache: Map<string, ResolvedTariff | null>,
  ): Promise<RowOutcome> {
    const outcome: RowOutcome = { created: 0, exists: 0, problems: 0 };
    const occurredAt = new Date(row.occurred_at);
    const onDate = occurredAt.toISOString().slice(0, 10);

    const found = await this.resolveTariff(cache, row.seller_id, source.kind, onDate);
    if (!found) {
      await this.recordProblem(row, source.kind, row.source_key, 'Тариф не заведён для этой услуги.');
      outcome.problems += 1;
      return outcome;
    }

    for (const component of found.components) {
      const result = await this.applyComponent(
        source,
        row,
        occurredAt,
        component,
        found.currency,
        actor,
      );
      if (result === 'created') outcome.created += 1;
      else if (result === 'exists') outcome.exists += 1;
      else if (result === 'problem') outcome.problems += 1;
      // 'skipped' не считается нигде: доплаты за этот объём просто нет.
    }

    return outcome;
  }

  private async applyComponent(
    source: AccrualSource,
    row: AccrualRow,
    occurredAt: Date,
    component: TariffComponentRules,
    currency: string,
    actor: ActorContext,
  ): Promise<'created' | 'exists' | 'problem' | 'skipped'> {
    const sourceKey = componentSourceKey(row.source_key, component.component);

    const existing: Array<{ id: string }> = await this.repo.chargeIdBySourceKey(
      this.dataSource,
      sourceKey,
    );
    if (existing.length > 0) return 'exists';

    const unit = component.unit;
    const column = UNIT_COLUMN[unit];
    const measured = column === null ? 1 : Number(row[column] ?? 0);
    // Округление — по ИТОГУ строки, а не по каждой позиции внутри неё.
    const quantity = ROUND_UP_UNITS.has(unit) ? Math.ceil(measured) : measured;
    if (!Number.isFinite(quantity) || quantity <= 0) {
      await this.recordProblem(
        row,
        source.kind,
        sourceKey,
        missingQuantityReason(
          source.kind,
          component.component,
          unit,
          column === null ? null : row[column],
        ),
      );
      return 'problem';
    }

    /**
     * Ступени отсортированы по убыванию `min_qty`, поэтому первая подошедшая —
     * нужная. Не подошла НИ ОДНА — значит объём не дотянул до минимальной
     * ступени составляющей, и это НЕ сбой конфигурации: `min_qty` — способ
     * выразить «свыше» («доплата за вес свыше 5 кг» = WEIGHT/PER_KG/min_qty 5
     * рядом с BASE/PER_ORDER/min_qty 0). Доплаты за такой объём просто нет:
     * начисление не создаётся, остальные составляющие считаются как обычно.
     *
     * Проблема — это когда у услуги вообще нет действующих правил (проверено
     * выше, в `applyRow`): там деньги теряются молча, и сказать об этом надо.
     * Раньше оба случая шли одной дорогой, и КАЖДАЯ коробка легче порога
     * забивала `billing_problems` мусором, в котором тонули настоящие проблемы.
     */
    const rule = component.steps.find((step) => Number(step.minQty) <= quantity) ?? null;
    if (!rule) return 'skipped';

    if (unit === 'PERCENT_OF_COD') {
      // Проверка валюты — fail-closed. «Валюты нет, посчитаем в валюте тарифа»
      // это догадка о чужих деньгах: у дочернего заказа сплита валюта пустая
      // ровно потому, что COD принадлежит родителю.
      if (!row.cod_currency) {
        await this.recordProblem(
          row,
          source.kind,
          sourceKey,
          `Составляющая ${component.component}: у собранного платежа не указана валюта ` +
            '(ни в отправлении, ни в заказе) — процент считать не от чего.',
        );
        return 'problem';
      }
      if (row.cod_currency !== currency) {
        // Считать процент от суммы в другой валюте — молча получить неверный счёт.
        await this.recordProblem(
          row,
          source.kind,
          sourceKey,
          `Валюта платежа ${row.cod_currency} не совпадает с валютой тарифа ${currency}.`,
        );
        return 'problem';
      }
    }

    // Оба множителя — в целых долях своего разряда, произведение — в BigInt.
    // Промежуточного double нет нигде: он и терял копейку на 4.1 кг × 0.05.
    const quantityText = quantity.toFixed(QTY_SCALE);
    const quantityScaled = toScaled(quantityText, QTY_SCALE);
    const priceScaled = toScaled(rule.price, PRICE_SCALE);
    const amountScaled =
      unit === 'FLAT'
        ? divideHalfUp(priceScaled, PRICE_DIVISOR)
        : unit === 'PERCENT_OF_COD'
          ? divideHalfUp(quantityScaled * priceScaled, AMOUNT_DIVISOR * 100n)
          : divideHalfUp(quantityScaled * priceScaled, AMOUNT_DIVISOR);
    /**
     * Дальше всё решает ОКРУГЛЁННАЯ сумма.
     *
     * 0.004 паллето-суток по тарифу «1 за паллето-сутки» дают 0.004: условие
     * «сумма больше нуля» истинно, а в книгу уходит «0.00», и отложенный
     * триггер `ledger_entries_amount_positive` валит на COMMIT ВЕСЬ прогон —
     * причём каждый раз об одну и ту же строку, так что перезапуск не
     * помогает. Сравниваем то же число, что и пишем: после округления в ноль
     * проводки просто нет, как и задумано.
     */
    const amountText = fromScaled(amountScaled, AMOUNT_SCALE);

    try {
      await this.dataSource.transaction(async (em) => {
        const inserted: Array<{ id: string }> = await this.repo.insertCharge(em, {
          sellerId: row.seller_id,
          kind: source.kind,
          unit,
          quantity: quantityText,
          unitPrice: fromScaled(priceScaled, PRICE_SCALE),
          amount: amountText,
          currency,
          occurredAt: occurredAt.toISOString(),
          orderId: row.order_id,
          shipmentId: row.shipment_id,
          sourceKey,
          tariffRuleId: rule.id,
        });
        const chargeId = inserted[0].id;

        // Услуга оказана: селлер должен нам, у нас выручка.
        if (amountScaled > 0n) {
          const transactionId = await this.ledger.post(em, {
            occurredAt,
            description: `${source.title}: ${sourceKey}`,
            sellerId: row.seller_id,
            referenceType: 'CHARGE',
            referenceId: chargeId,
            currency,
            legs: [
              { accountCode: 'AR_SELLER', side: 'DEBIT', amount: amountText },
              { accountCode: 'INCOME_FF', side: 'CREDIT', amount: amountText },
            ],
          });
          await this.repo.linkChargeToTransaction(em, chargeId, transactionId);
        }
      });
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_charges_source') return 'exists';
      throw error;
    }

    await this.events.publish(
      createEvent(
        FF_EVENTS.BILLING_CHARGE_CREATED,
        {
          chargeId: sourceKey,
          sellerId: row.seller_id,
          kind: source.kind,
          amount: amountText,
          currency,
        },
        { actorUserId: actor.user.id, correlationId: actor.correlationId },
      ),
    );

    return 'created';
  }

  private async resolveTariff(
    cache: Map<string, ResolvedTariff | null>,
    sellerId: string,
    kind: ChargeKind,
    onDate: string,
  ): Promise<ResolvedTariff | null> {
    const key = `${sellerId}|${kind}|${onDate}`;
    const cached = cache.get(key);
    if (cached !== undefined) return cached;
    const found = await this.tariffs.rulesFor(sellerId, kind, onDate);
    cache.set(key, found);
    return found;
  }

  /**
   * Собранный курьером наложенный платёж: деньги покупателя, принадлежащие
   * селлеру и временно находящиеся у перевозчика. Услугой это не является,
   * поэтому проводится напрямую по книге.
   */
  private async postCollectedCod(periodStart: string, periodEnd: string): Promise<number> {
    const rows = await this.repo.collectedCod(this.dataSource, periodStart, periodEnd);

    let problems = 0;
    for (const row of rows) {
      // Валюты нет — не проводим. Проводка с валютой NULL разбивается о CHECK
      // `ledger_entries_currency_shape` и роняет ВЕСЬ прогон, а не одну строку;
      // подставить «какую-нибудь» валюту чужим деньгам тем более нельзя.
      if (!row.currency) {
        problems += 1;
        await this.insertProblem(
          row.seller_id,
          'COD_FEE',
          `cod_collected:${row.id}`,
          `Отправление ${row.shipment_no}: платёж собран, но валюта не указана ` +
            'ни в отправлении, ни в заказе — провести по книге нельзя.',
          new Date(row.collected_at).toISOString(),
        );
        continue;
      }
      const currency = row.currency;
      await this.dataSource.transaction(async (em) => {
        await this.ledger.post(em, {
          occurredAt: new Date(row.collected_at),
          description: `Наложенный платёж собран, отправление ${row.shipment_no}`,
          sellerId: row.seller_id,
          referenceType: 'SHIPMENT_COD',
          referenceId: row.id,
          currency,
          legs: [
            { accountCode: 'AR_CARRIER', side: 'DEBIT', amount: row.amount },
            { accountCode: 'AP_SELLER', side: 'CREDIT', amount: row.amount },
          ],
        });
      });
    }
    return problems;
  }

  private async recordProblem(
    row: AccrualRow,
    kind: ChargeKind,
    sourceKey: string,
    reason: string,
  ): Promise<void> {
    await this.insertProblem(
      row.seller_id,
      kind,
      sourceKey,
      reason,
      new Date(row.occurred_at).toISOString(),
    );
  }

  /** Та же запись проблемы, но без строки-основания: у проводки COD её нет. */
  private async insertProblem(
    sellerId: string,
    kind: ChargeKind,
    sourceKey: string,
    reason: string,
    occurredAt: string,
  ): Promise<void> {
    this.logger.warn(`Начисление ${sourceKey} (${kind}) отложено: ${reason}`);
    await this.repo.insertProblem(
      this.dataSource,
      sellerId,
      kind,
      sourceKey,
      reason,
      occurredAt,
    );
  }
}

/**
 * Причина, по которой составляющую не посчитали. Она попадает оператору в
 * список проблем, поэтому обязана называть и составляющую, и то, чего не
 * хватило: «нет объёма» без имени составляющей в комбинированном тарифе
 * не отвечает ни на один вопрос.
 */
function missingQuantityReason(
  kind: ChargeKind,
  component: string,
  unit: TariffUnit,
  raw: string | null,
): string {
  if (raw === null && unit === 'PER_KG' && kind === 'INBOUND') {
    // Вес приёмки считается из `skus.weight_g`, а не вводится кладовщиком:
    // причина обязана вести к товару без нормы, а не к «нет объёма».
    return `Составляющая ${component}: не у всех принятых товаров задан вес — считать килограммы не из чего.`;
  }
  if (raw === null && (unit === 'PER_BOX' || unit === 'PER_BOX_DAY')) {
    return `Составляющая ${component}: не у всех товаров задана норма «единиц в коробке» — считать коробки не из чего.`;
  }
  if (raw === null && (unit === 'PER_PALLET' || unit === 'PER_PALLET_DAY')) {
    return `Составляющая ${component}: не у всех товаров задана норма «единиц на паллете» — считать паллеты не из чего.`;
  }
  return `Составляющая ${component}: нет объёма для единицы ${unit} — начислять не с чего.`;
}
