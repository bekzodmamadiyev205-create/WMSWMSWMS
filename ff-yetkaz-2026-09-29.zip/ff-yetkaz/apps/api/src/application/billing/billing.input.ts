import type { ChargeKind, TariffUnit } from '@ff/shared';

/**
 * Формы входных данных биллинга. В `@ff/shared` описано, что биллинг ОТДАЁТ
 * (`TariffPlanDto`, `TariffRuleDto`), но не то, что он принимает, — эти формы
 * объявлены здесь, рядом с сервисом.
 *
 * Прикладному слою нужна ФОРМА запроса, а не класс с декораторами
 * class-validator: декораторы существуют ради разбора HTTP и к бизнес-операции
 * отношения не имеют.
 *
 * Деньги и количества — СТРОКИ. Не потому, что так пришло из HTTP, а потому,
 * что float теряет копейки: `number` здесь недопустим ни на входе, ни в БД.
 */

export interface CreateTariffPlanInput {
  code: string;
  name: string;
  currency: string;
  isDefault?: boolean;
  isActive?: boolean;
}

/**
 * Правка плана. Кода здесь нет намеренно: на него ссылаются в переписке и в
 * отчётах, нужен другой код — заводится другой план.
 */
export interface UpdateTariffPlanInput {
  name?: string;
  currency?: string;
  isDefault?: boolean;
  isActive?: boolean;
}

export interface CreateTariffRuleInput {
  kind: ChargeKind;
  unit: TariffUnit;
  /** Не задана — `BASE`, то есть поведение до комбинированных тарифов. */
  component?: string;
  price: string;
  minQty?: string;
  effectiveFrom?: string;
  effectiveTo?: string;
}

/**
 * Правка правила. `kind`, `unit` и `component` не меняются: на правило уже
 * могут ссылаться начисления, и подмена того, ЗА ЧТО была взята цена,
 * переписала бы историю. Вывести правило из обращения — это `effectiveTo`.
 */
export interface UpdateTariffRuleInput {
  price?: string;
  minQty?: string;
  effectiveFrom?: string;
  /** `null` снимает дату окончания — правило снова бессрочное. */
  effectiveTo?: string | null;
}

/** Нормы упаковки товара: из них считаются коробки и паллеты для тарифов. */
export interface PackingNormsInput {
  /** `null` снимает норму: у товара её нет, и коробки по нему не считаются. */
  unitsPerBox?: number | null;
  unitsPerPallet?: number | null;
}
