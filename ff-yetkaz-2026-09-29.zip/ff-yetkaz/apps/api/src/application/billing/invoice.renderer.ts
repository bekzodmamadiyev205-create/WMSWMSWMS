import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import type { InvoiceDto } from '@ff/shared';
import { fontPath } from '../../infrastructure/runtime/fonts';

const MM = 72 / 25.4;
const PAGE_MARGIN = 18 * MM;
const FONT_REGULAR = 'body';
const FONT_BOLD = 'bodyBold';

const money = (value: string, currency: string): string =>
  `${Number(value).toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;

/**
 * Счёт в PDF. Как и на этикетке, шрифт вшивается: стандартные шрифты PDF не
 * содержат кириллицы, а счёт с искажённым названием юрлица бесполезен.
 */
export function renderInvoicePdf(invoice: InvoiceDto): Promise<Buffer> {
  const doc = new PDFDocument({ size: 'A4', margin: PAGE_MARGIN });
  doc.registerFont(FONT_REGULAR, fontPath('DejaVuSans.ttf'));
  doc.registerFont(FONT_BOLD, fontPath('DejaVuSans-Bold.ttf'));

  const chunks: Buffer[] = [];
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });

  const width = doc.page.width - PAGE_MARGIN * 2;

  doc.font(FONT_BOLD).fontSize(18).text('YETKAZ EXPRESS', { continued: false });
  doc.font(FONT_REGULAR).fontSize(9).fillColor('#555555').text('Фулфилмент — отчёт за период');
  doc.fillColor('#000000').moveDown(1);

  doc.font(FONT_BOLD).fontSize(14).text(`Счёт ${invoice.number}`);
  doc.font(FONT_REGULAR).fontSize(10);
  doc.text(`Селлер: ${invoice.sellerName}`);
  doc.text(`Период: ${invoice.periodStart} — ${invoice.periodEnd}`);
  doc.text(`Статус: ${invoice.status}`);
  doc.moveDown(0.8);

  // --- таблица услуг ---------------------------------------------------------
  const columns = [
    { title: 'Услуга', width: width * 0.4 },
    { title: 'Кол-во', width: width * 0.15 },
    { title: 'Цена', width: width * 0.2 },
    { title: 'Сумма', width: width * 0.25 },
  ];

  const drawRow = (cells: string[], bold = false): void => {
    const top = doc.y;
    let x = PAGE_MARGIN;
    doc.font(bold ? FONT_BOLD : FONT_REGULAR).fontSize(9);
    cells.forEach((cell, index) => {
      doc.text(cell, x, top, {
        width: columns[index].width - 4,
        align: index === 0 ? 'left' : 'right',
      });
      x += columns[index].width;
    });
    doc.y = top + 14;
  };

  drawRow(columns.map((column) => column.title), true);
  doc
    .moveTo(PAGE_MARGIN, doc.y - 3)
    .lineTo(PAGE_MARGIN + width, doc.y - 3)
    .lineWidth(0.7)
    .stroke('#000000');

  if (invoice.lines.length === 0) {
    doc.font(FONT_REGULAR).fontSize(9).fillColor('#555555').text('За период начислений нет.');
    doc.fillColor('#000000');
  }
  for (const line of invoice.lines) {
    drawRow([
      line.description,
      Number(line.quantity).toLocaleString('ru-RU'),
      Number(line.unitPrice).toLocaleString('ru-RU'),
      money(line.amount, invoice.currency),
    ]);
  }

  doc.moveDown(0.6);
  doc
    .moveTo(PAGE_MARGIN, doc.y)
    .lineTo(PAGE_MARGIN + width, doc.y)
    .lineWidth(0.7)
    .stroke('#000000');
  doc.moveDown(0.4);

  const totalRow = (label: string, value: string, bold = false): void => {
    const top = doc.y;
    doc.font(bold ? FONT_BOLD : FONT_REGULAR).fontSize(10);
    doc.text(label, PAGE_MARGIN, top, { width: width * 0.65 });
    doc.text(value, PAGE_MARGIN + width * 0.65, top, { width: width * 0.35, align: 'right' });
    doc.y = top + 16;
  };

  totalRow('Услуги фулфилмента', money(invoice.servicesTotal, invoice.currency));
  totalRow('Наложенный платёж собран', money(invoice.codCollectedTotal, invoice.currency));
  totalRow('К перечислению селлеру', money(invoice.payoutTotal, invoice.currency), true);

  doc
    .font(FONT_REGULAR)
    .fontSize(7)
    .fillColor('#555555')
    .text(
      'Сумма к перечислению — собранный наложенный платёж за вычетом услуг фулфилмента. ' +
        'Отрицательное значение означает задолженность селлера.',
      PAGE_MARGIN,
      doc.y + 8,
      { width },
    );

  doc.end();
  return done;
}

/** Тот же счёт в Excel: бухгалтерия работает с цифрами, а не с картинкой. */
export async function renderInvoiceXlsx(invoice: InvoiceDto): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Yetkaz Express FF';
  const sheet = workbook.addWorksheet(`Счёт ${invoice.number}`);

  sheet.columns = [
    { header: 'Услуга', key: 'description', width: 42 },
    { header: 'Кол-во', key: 'quantity', width: 14 },
    { header: 'Единица', key: 'unit', width: 16 },
    { header: 'Цена', key: 'unitPrice', width: 14 },
    { header: 'Сумма', key: 'amount', width: 16 },
  ];
  sheet.getRow(1).font = { bold: true };

  sheet.addRow([`Счёт ${invoice.number}`]).font = { bold: true, size: 14 };
  sheet.addRow([`Селлер: ${invoice.sellerName}`]);
  sheet.addRow([`Период: ${invoice.periodStart} — ${invoice.periodEnd}`]);
  sheet.addRow([]);

  for (const line of invoice.lines) {
    sheet.addRow({
      description: line.description,
      // Числами, а не строками: иначе в Excel по ним нельзя ни сложить, ни
      // построить сводную — ради чего выгрузку и просят.
      quantity: Number(line.quantity),
      unit: line.unit,
      unitPrice: Number(line.unitPrice),
      amount: Number(line.amount),
    });
  }

  sheet.addRow([]);
  const totals: Array<[string, number, boolean]> = [
    ['Услуги фулфилмента', Number(invoice.servicesTotal), false],
    ['Наложенный платёж собран', Number(invoice.codCollectedTotal), false],
    ['К перечислению селлеру', Number(invoice.payoutTotal), true],
  ];
  for (const [label, value, bold] of totals) {
    const row = sheet.addRow({ description: label, amount: value });
    if (bold) row.font = { bold: true };
  }

  sheet.getColumn('unitPrice').numFmt = '#,##0.0000';
  sheet.getColumn('amount').numFmt = `#,##0.00 "${invoice.currency}"`;

  return Buffer.from(await workbook.xlsx.writeBuffer());
}
