import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  BillingProblemEntity,
  ChargeEntity,
  InvoiceEntity,
  InvoiceLineEntity,
  LedgerAccountEntity,
  LedgerEntryEntity,
  LedgerTransactionEntity,
  SellerEntity,
  SkuEntity,
  StorageSnapshotEntity,
  TariffPlanEntity,
  TariffRuleEntity,
} from '../../infrastructure/database/entities';
import { AccrualRepository } from '../../infrastructure/database/repositories/accrual.repository';
import { InvoicesRepository } from '../../infrastructure/database/repositories/invoices.repository';
import { LedgerRepository } from '../../infrastructure/database/repositories/ledger.repository';
import { TariffsRepository } from '../../infrastructure/database/repositories/tariffs.repository';
import { AccrualService } from './accrual.service';
import { BillingController } from '../../presentation/http/billing.controller';
import { InvoicesService } from './invoices.service';
import { LedgerService } from './ledger.service';
import { StorageScheduler } from '../../presentation/schedulers/storage.scheduler';
import { TariffsService } from './tariffs.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      TariffPlanEntity,
      TariffRuleEntity,
      LedgerAccountEntity,
      LedgerTransactionEntity,
      LedgerEntryEntity,
      ChargeEntity,
      BillingProblemEntity,
      StorageSnapshotEntity,
      InvoiceEntity,
      InvoiceLineEntity,
      SellerEntity,
      // Нормы упаковки правятся отсюда: они существуют ради тарифов
      // PER_BOX/PER_PALLET, а не ради каталога.
      SkuEntity,
    ]),
  ],
  controllers: [BillingController],
  providers: [
    TariffsService,
    LedgerService,
    AccrualService,
    InvoicesService,
    StorageScheduler,
    // Весь сырой SQL биллинга живёт в репозиториях; соединение они получают
    // параметром, поэтому запрос идёт ровно в ту транзакцию, что и у вызывающего.
    TariffsRepository,
    LedgerRepository,
    AccrualRepository,
    InvoicesRepository,
  ],
  exports: [AccrualService, InvoicesService],
})
export class BillingModule {}
