import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, QueryFailedError } from 'typeorm';
import {
  ALLOWED_UNITS,
  DEFAULT_TARIFF_COMPONENT,
  type ChargeKind,
  type TariffPlanDto,
  type TariffRuleDto,
  type TariffUnit,
} from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import {
  isForeignKeyViolation,
  uniqueViolationConstraint,
} from '../../infrastructure/database/unique-violation';
import type { ActorContext } from '../../domain/types/actor';
import { SellerEntity, SkuEntity, TariffPlanEntity, TariffRuleEntity } from '../../infrastructure/database/entities';
import {
  TariffsRepository,
  type EffectiveTariffRuleRow,
} from '../../infrastructure/database/repositories/tariffs.repository';
import type {
  CreateTariffPlanInput,
  CreateTariffRuleInput,
  PackingNormsInput,
  UpdateTariffPlanInput,
  UpdateTariffRuleInput,
} from './billing.input';

/**
 * Составляющая цены, подобранная под начисление.
 *
 * Единица здесь ровно одна — это держит триггер `trg_tariff_rules_single_unit`
 * в БД. Ступени (`min_qty`) остаются: они задаются в пределах одной единицы.
 */
export interface TariffComponentRules {
  component: string;
  unit: TariffUnit;
  /** Ступени объёма, от большей `min_qty` к меньшей: первая подошедшая и берётся. */
  steps: TariffRuleEntity[];
}

export interface ResolvedTariff {
  components: TariffComponentRules[];
  currency: string;
}

/** Нормы упаковки товара — то, из чего считаются коробки и паллеты. */
export interface PackingNormsResult {
  skuId: string;
  unitsPerBox: number | null;
  unitsPerPallet: number | null;
}

/**
 * На запись ещё кто-то ссылается — удалять нельзя.
 *
 * Общий `isForeignKeyViolation` проверяет только 23503, а ЯВНЫЙ
 * `ON DELETE RESTRICT` PostgreSQL отбивает кодом 23001 (`restrict_violation`):
 * это разные RI-триггеры, 23503 остаётся за `NO ACTION`. Проверено вживую на
 * `charges_tariff_rule_id_fkey` — без второго кода удаление применённого
 * правила отдавало 500 вместо понятного 409.
 */
function isReferencedElsewhere(error: unknown): boolean {
  if (isForeignKeyViolation(error)) return true;
  if (!(error instanceof QueryFailedError)) return false;
  const driverError = error.driverError as { code?: string } | undefined;
  return driverError?.code === '23001';
}

@Injectable()
export class TariffsService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
    private readonly repo: TariffsRepository,
  ) {}

  async listPlans(): Promise<TariffPlanDto[]> {
    const plans = await this.dataSource
      .getRepository(TariffPlanEntity)
      .find({ order: { code: 'ASC' } });
    // Порядок правил — как их читает человек: услуга, составляющая цены,
    // ступень объёма. Иначе комбинированный тариф в форме выглядит россыпью.
    // `kind` — enum БД, поэтому сортируется по порядку ОБЪЯВЛЕНИЯ, а не по
    // алфавиту: приёмка → хранение → сборка → упаковка → доставка, то есть по
    // ходу процесса. Это удачнее алфавита, менять не нужно.
    const rules = await this.dataSource
      .getRepository(TariffRuleEntity)
      .find({ order: { kind: 'ASC', component: 'ASC', minQty: 'ASC' } });

    return plans.map((plan) => ({
      id: plan.id,
      code: plan.code,
      name: plan.name,
      currency: plan.currency,
      isDefault: plan.isDefault,
      isActive: plan.isActive,
      rules: rules.filter((rule) => rule.planId === plan.id).map((rule) => this.toRuleDto(rule)),
    }));
  }

  async createPlan(dto: CreateTariffPlanInput, actor: ActorContext): Promise<TariffPlanDto> {
    const repo = this.dataSource.getRepository(TariffPlanEntity);
    const existing = await repo.findOne({ where: { code: dto.code.trim().toUpperCase() } });
    if (existing) throw new ConflictException(`Тарифный план «${dto.code}» уже существует.`);

    const plan = await this.dataSource.transaction(async (em) => {
      if (dto.isDefault) {
        // План по умолчанию ровно один — снимаем флаг с прежнего, иначе
        // уникальный частичный индекс не даст вставить второй.
        await this.repo.clearDefaultPlan(em);
      }
      const plans = em.getRepository(TariffPlanEntity);
      return plans.save(
        plans.create({
          code: dto.code.trim().toUpperCase(),
          name: dto.name.trim(),
          currency: dto.currency.trim().toUpperCase(),
          isDefault: dto.isDefault ?? false,
          // По умолчанию ВКЛЮЧЁН. Раньше здесь стояло false, и заведённый из
          // интерфейса план не подхватывался никогда: `rulesFor` требует
          // `is_active`, а включить план было нечем — все начисления по нему
          // молча уезжали в billing_problems.
          isActive: dto.isActive ?? true,
        }),
      );
    });

    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'TariffPlan',
      entityId: plan.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: null,
      after: { code: plan.code, currency: plan.currency, isActive: plan.isActive },
    });

    return this.planById(plan.id);
  }

  async updatePlan(
    planId: string,
    dto: UpdateTariffPlanInput,
    actor: ActorContext,
  ): Promise<TariffPlanDto> {
    const repo = this.dataSource.getRepository(TariffPlanEntity);
    const plan = await repo.findOne({ where: { id: planId } });
    if (!plan) throw new NotFoundException('Тарифный план не найден.');

    const before = {
      name: plan.name,
      currency: plan.currency,
      isDefault: plan.isDefault,
      isActive: plan.isActive,
    };

    const currency = dto.currency?.trim().toUpperCase();
    if (currency && currency !== plan.currency) {
      /**
       * Валюта плана — не косметика. Начисления хранят валюту на момент расчёта,
       * поэтому смена валюты у работавшего плана даёт период, где часть услуг
       * посчитана в одной валюте, часть в другой, и счёт за такой период
       * собрать нельзя вообще. Пока по плану ничего не начислено — менять можно.
       */
      const used: Array<{ count: string }> = await this.repo.countChargesByPlan(
        this.dataSource,
        planId,
      );
      if (used[0].count !== '0') {
        throw new ConflictException(
          'По плану уже есть начисления — валюту менять нельзя: счёт за период перестанет сводиться. ' +
            'Заведите новый план в нужной валюте и переназначьте селлеров.',
        );
      }
    }

    await this.dataSource.transaction(async (em) => {
      if (dto.isDefault === true) {
        await this.repo.clearDefaultPlanExcept(em, planId);
      }
      const plans = em.getRepository(TariffPlanEntity);
      if (dto.name !== undefined) plan.name = dto.name.trim();
      if (currency) plan.currency = currency;
      if (dto.isDefault !== undefined) plan.isDefault = dto.isDefault;
      if (dto.isActive !== undefined) plan.isActive = dto.isActive;
      await plans.save(plan);
    });

    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'TariffPlan',
      entityId: planId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before,
      after: {
        name: plan.name,
        currency: plan.currency,
        isDefault: plan.isDefault,
        isActive: plan.isActive,
      },
    });

    return this.planById(planId);
  }

  async addRule(
    planId: string,
    dto: CreateTariffRuleInput,
    actor: ActorContext,
  ): Promise<TariffRuleDto> {
    const plan = await this.dataSource
      .getRepository(TariffPlanEntity)
      .findOne({ where: { id: planId } });
    if (!plan) throw new NotFoundException('Тарифный план не найден.');

    // Единица измерения должна иметь смысл для вида услуги: «хранение за
    // заказ» — не тариф, а ошибка ввода.
    if (!ALLOWED_UNITS[dto.kind].includes(dto.unit)) {
      throw new BadRequestException(
        `Для услуги ${dto.kind} допустимы единицы: ${ALLOWED_UNITS[dto.kind].join(', ')}.`,
      );
    }

    const component = dto.component?.trim().toUpperCase() || DEFAULT_TARIFF_COMPONENT;
    const effectiveFrom = dto.effectiveFrom ?? new Date().toISOString().slice(0, 10);
    const effectiveTo = dto.effectiveTo ?? null;
    this.assertPeriod(effectiveFrom, effectiveTo);

    /**
     * «Одна единица на составляющую» проверяет БД, а не этот код.
     *
     * Здесь раньше стоял SELECT, и он был гонкой: два одновременных POST с
     * разными единицами оба его проходили, оба вставлялись, а начисление потом
     * брало первое попавшееся правило — то есть цена зависела от порядка
     * строк в выдаче. Теперь конфликт отбивает триггер, а нам остаётся
     * перевести 23505 в понятный ответ.
     */
    const rules = this.dataSource.getRepository(TariffRuleEntity);
    let rule: TariffRuleEntity;
    try {
      rule = await rules.save(
        rules.create({
          planId,
          kind: dto.kind,
          unit: dto.unit,
          component,
          price: dto.price,
          minQty: dto.minQty ?? '0',
          effectiveFrom,
          effectiveTo,
        }),
      );
    } catch (error) {
      throw this.translateRuleConflict(error, dto.kind, component);
    }

    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'TariffRule',
      entityId: rule.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: null,
      after: { kind: rule.kind, unit: rule.unit, component: rule.component, price: rule.price },
    });

    return this.toRuleDto(rule);
  }

  async updateRule(
    ruleId: string,
    dto: UpdateTariffRuleInput,
    actor: ActorContext,
  ): Promise<TariffRuleDto> {
    const rules = this.dataSource.getRepository(TariffRuleEntity);
    const rule = await rules.findOne({ where: { id: ruleId } });
    if (!rule) throw new NotFoundException('Правило тарифа не найдено.');

    const before = {
      price: rule.price,
      minQty: rule.minQty,
      effectiveFrom: this.asDate(rule.effectiveFrom),
      effectiveTo: rule.effectiveTo,
    };

    if (dto.price !== undefined) rule.price = dto.price;
    if (dto.minQty !== undefined) rule.minQty = dto.minQty;
    if (dto.effectiveFrom !== undefined) rule.effectiveFrom = dto.effectiveFrom;
    if (dto.effectiveTo !== undefined) rule.effectiveTo = dto.effectiveTo;
    this.assertPeriod(this.asDate(rule.effectiveFrom), rule.effectiveTo);

    try {
      await rules.save(rule);
    } catch (error) {
      throw this.translateRuleConflict(error, rule.kind, rule.component);
    }

    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'TariffRule',
      entityId: ruleId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before,
      after: {
        price: rule.price,
        minQty: rule.minQty,
        effectiveFrom: this.asDate(rule.effectiveFrom),
        effectiveTo: rule.effectiveTo,
      },
    });

    return this.toRuleDto(rule);
  }

  async deleteRule(ruleId: string, actor: ActorContext): Promise<void> {
    const rules = this.dataSource.getRepository(TariffRuleEntity);
    const rule = await rules.findOne({ where: { id: ruleId } });
    if (!rule) throw new NotFoundException('Правило тарифа не найдено.');

    try {
      await rules.delete({ id: ruleId });
    } catch (error) {
      // На правило ссылается начисление (FK RESTRICT). Удалить его — значит
      // оставить в счёте сумму, про которую больше не сказать, по какой цене
      // она посчитана. Вывод из обращения — это дата окончания.
      if (isReferencedElsewhere(error)) {
        throw new ConflictException(
          'Правило уже применено в начислениях — закройте его датой окончания.',
        );
      }
      throw error;
    }

    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'TariffRule',
      entityId: ruleId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: { kind: rule.kind, unit: rule.unit, component: rule.component, price: rule.price },
      after: null,
    });
  }

  async assignPlan(sellerId: string, planId: string | null, actor: ActorContext): Promise<void> {
    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    if (planId) {
      const plan = await this.dataSource
        .getRepository(TariffPlanEntity)
        .findOne({ where: { id: planId } });
      if (!plan) throw new NotFoundException('Тарифный план не найден.');
    }

    await this.repo.assignPlanToSeller(this.dataSource, sellerId, planId);
    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'Seller',
      entityId: sellerId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: null,
      after: { tariffPlanId: planId },
    });
  }

  /**
   * Нормы упаковки товара.
   *
   * Ручка живёт в биллинге, потому что норма существует ради цены: склад
   * считает штуки, а коробки и паллеты — производная, нужная только тарифам
   * `PER_BOX`/`PER_PALLET`. Пишется прямо в `skus` — каталог ведёт другой
   * модуль, и лезть в его сервис ради двух чисел значит связать их намертво.
   */
  async setPackingNorms(
    skuId: string,
    dto: PackingNormsInput,
    actor: ActorContext,
  ): Promise<PackingNormsResult> {
    if (dto.unitsPerBox === undefined && dto.unitsPerPallet === undefined) {
      throw new BadRequestException('Не передано ни одной нормы упаковки.');
    }

    const repo = this.dataSource.getRepository(SkuEntity);
    const sku = await repo.findOne({ where: { id: skuId } });
    if (!sku) throw new NotFoundException('Товар не найден.');

    const before = { unitsPerBox: sku.unitsPerBox, unitsPerPallet: sku.unitsPerPallet };
    const unitsPerBox = dto.unitsPerBox === undefined ? sku.unitsPerBox : dto.unitsPerBox;
    const unitsPerPallet =
      dto.unitsPerPallet === undefined ? sku.unitsPerPallet : dto.unitsPerPallet;

    // Паллета вмещает меньше коробки — так не бывает, а в счёте это дало бы
    // паллет больше, чем коробок, и объяснить сумму стало бы нечем.
    if (unitsPerBox !== null && unitsPerPallet !== null && unitsPerPallet < unitsPerBox) {
      throw new BadRequestException(
        `Норма на паллету (${unitsPerPallet}) меньше нормы на коробку (${unitsPerBox}).`,
      );
    }

    await repo.update({ id: skuId }, { unitsPerBox, unitsPerPallet });

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Sku',
      entityId: skuId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before,
      after: { unitsPerBox, unitsPerPallet },
    });

    return { skuId, unitsPerBox, unitsPerPallet };
  }

  /**
   * Действующие на дату правила для услуги, СГРУППИРОВАННЫЕ по составляющим цены.
   *
   * Берётся план селлера, иначе план по умолчанию. Каждая составляющая
   * тарифицируется отдельно и попадает в счёт своей строкой: «паллета» и
   * «перевес по кг» — разные деньги за одну и ту же услугу, и складывать их
   * в одну цену значит потерять, из чего сумма сложилась.
   *
   * Ступень (`min_qty`) выбирает вызывающий: чтобы понять, с каким объёмом
   * сравнивать, надо сперва узнать единицу измерения — а она задана правилом.
   *
   * `null` означает «тарифа нет». Цену выдумывать нельзя: начисление уйдёт
   * в `billing_problems`, а не посчитается по нулю.
   */
  async rulesFor(sellerId: string, kind: ChargeKind, onDate: string): Promise<ResolvedTariff | null> {
    const rows: EffectiveTariffRuleRow[] = await this.repo.effectiveRules(
      this.dataSource,
      sellerId,
      kind,
      onDate,
    );
    if (rows.length === 0) return null;

    const byComponent = new Map<string, TariffComponentRules>();
    for (const row of rows) {
      const rule = new TariffRuleEntity();
      Object.assign(rule, {
        id: row.id,
        planId: row.plan_id,
        kind: row.kind,
        unit: row.unit,
        component: row.component,
        price: row.price,
        minQty: row.min_qty,
        effectiveFrom: row.effective_from,
        effectiveTo: row.effective_to,
      });

      const existing = byComponent.get(row.component);
      if (!existing) {
        byComponent.set(row.component, { component: row.component, unit: row.unit, steps: [rule] });
        continue;
      }
      // Единицу задаёт первое правило составляющей; остальные единицы внутри
      // неё существовать не могут (триггер), но данные, заведённые до миграции,
      // никто не перепроверял — лишнее просто отбрасываем, а не тарифицируем
      // «чем попало».
      if (rule.unit === existing.unit) existing.steps.push(rule);
    }

    return { components: [...byComponent.values()], currency: rows[0].currency };
  }

  // ------------------------------------------------------------ внутреннее

  private async planById(planId: string): Promise<TariffPlanDto> {
    const plan = (await this.listPlans()).find((item) => item.id === planId);
    if (!plan) throw new NotFoundException('Тарифный план не найден.');
    return plan;
  }

  private assertPeriod(effectiveFrom: string, effectiveTo: string | null): void {
    if (effectiveTo && effectiveTo < effectiveFrom) {
      throw new BadRequestException(
        `Дата окончания ${effectiveTo} раньше даты начала ${effectiveFrom}.`,
      );
    }
  }

  /**
   * 23505 от правил тарифа приходит из двух мест, и путать их нельзя: индекс —
   * это дубль ступени, триггер — вторая единица у той же составляющей.
   */
  private translateRuleConflict(error: unknown, kind: ChargeKind, component: string): unknown {
    const constraint = uniqueViolationConstraint(error);
    if (constraint === null) return error;
    if (constraint === 'uq_tariff_rules_step') {
      return new ConflictException(
        `Такая ступень тарифа (${kind}/${component}) с этой датой начала уже заведена.`,
      );
    }
    return new ConflictException(
      `В плане уже есть действующее правило ${kind} (составляющая ${component}) с другой единицей. ` +
        'Закройте его датой окончания перед добавлением другой единицы.',
    );
  }

  private asDate(value: string | Date): string {
    return typeof value === 'string' ? value : new Date(value).toISOString().slice(0, 10);
  }

  private toRuleDto(rule: TariffRuleEntity): TariffRuleDto {
    return {
      id: rule.id,
      planId: rule.planId,
      kind: rule.kind,
      unit: rule.unit,
      component: rule.component,
      price: rule.price,
      minQty: rule.minQty,
      effectiveFrom: this.asDate(rule.effectiveFrom),
      effectiveTo: rule.effectiveTo,
    };
  }
}
