import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import type {
  CodReconciliationDto,
  CodReconciliationRowDto,
  InvoiceDto,
  InvoiceLineDto,
} from '@ff/shared';
import { isSellerVisible, resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { InvoiceEntity, SellerEntity } from '../../infrastructure/database/entities';
import {
  InvoicesRepository,
  type PeriodInvoiceRow,
  type UncapturedChargeRow,
} from '../../infrastructure/database/repositories/invoices.repository';

/** Описание услуги в счёте: человеку нужен русский текст, а не код enum'а. */
const KIND_TITLE: Record<string, string> = {
  INBOUND: 'Приёмка товара',
  STORAGE: 'Хранение',
  PICKING: 'Сборка заказов',
  PACKING: 'Упаковка',
  DELIVERY: 'Передача в доставку',
  COD_FEE: 'Комиссия за наложенный платёж',
  SURCHARGE: 'Дополнительные услуги',
};

/**
 * Без надстрочных знаков: «м³» не кодируется в cp1251, а базы у клиентов
 * встречаются разные. Печатный счёт от этого только понятнее.
 */
const UNIT_TITLE: Record<string, string> = {
  PER_ORDER: 'заказ',
  PER_UNIT: 'единица',
  PER_KG: 'кг',
  PER_M3_DAY: 'куб. м в сутки',
  PERCENT_OF_COD: '% от платежа',
  FLAT: 'услуга',
  // Тарная тарификация. Без этих строк новая единица печаталась бы в счёте
  // кодом enum'а: `?? row.unit` ниже не падает, а молча выводит PER_PALLET.
  PER_BOX: 'коробка',
  PER_PALLET: 'паллета',
  PER_BOX_DAY: 'коробко-сутки',
  PER_PALLET_DAY: 'паллето-сутки',
};

@Injectable()
export class InvoicesService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly repo: InvoicesRepository,
  ) {}

  /**
   * Собирает счёт за период из уже посчитанных начислений.
   *
   * Счёт ничего не вычисляет заново: он агрегирует `charges`, которые уже
   * проведены по книге. Иначе сумма в счёте и сумма в бухгалтерии разъезжаются,
   * и разбираться, какая из них правильная, приходится вручную.
   */
  async build(
    sellerId: string,
    periodStart: string,
    periodEnd: string,
    actor: ActorContext,
  ): Promise<InvoiceDto> {
    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    this.assertVisible(sellerId, actor);

    const existing: PeriodInvoiceRow[] = await this.repo.findPeriodInvoice(
      this.dataSource,
      sellerId,
      periodStart,
      periodEnd,
    );
    if (existing.length > 0) {
      return this.rebuild(existing[0], sellerId, periodStart, periodEnd, actor);
    }

    await this.assertNoOverlap(sellerId, periodStart, periodEnd);

    const invoiceId = await this.dataSource.transaction(async (em) => {
      // 'XXX' — код ISO 4217 «валюта не определена»: настоящая проставляется
      // в compose, когда известно, из чего счёт собран.
      const inserted: Array<{ id: string }> = await this.repo.insertInvoice(
        em,
        sellerId,
        periodStart,
        periodEnd,
      );
      const id = inserted[0].id;
      await this.captureAndCompose(em, id, sellerId, periodStart, periodEnd);
      return id;
    });

    return this.get(invoiceId, actor);
  }

  /**
   * Повторный `build` за уже собранный период.
   *
   * Финансист разбирает `billing_problems`, заводит недостающий тариф и
   * перезапускает начисления за прошлый период — ровно как предписано. Новые
   * начисления получают `invoice_id = NULL`, а период уже закрыт счётом: пока
   * повторная сборка просто отдавала существующий счёт, эти деньги не попадали
   * НИ В ОДИН счёт никогда — второй за тот же период не создать (`uq_invoices_period`).
   *
   * Поэтому черновик пересобирается (состав черновика ещё никому не обещан), а
   * выставленный счёт трогать нельзя — про незахваченные начисления он обязан
   * СКАЗАТЬ, а не молча их проглотить.
   */
  private async rebuild(
    invoice: { id: string; number: string; status: string },
    sellerId: string,
    periodStart: string,
    periodEnd: string,
    actor: ActorContext,
  ): Promise<InvoiceDto> {
    if (invoice.status === 'DRAFT') {
      await this.dataSource.transaction(async (em) => {
        await this.captureAndCompose(em, invoice.id, sellerId, periodStart, periodEnd);
      });
      return this.get(invoice.id, actor);
    }

    const pending = await this.uncapturedCharges(sellerId, periodStart, periodEnd);
    if (pending.length > 0) {
      const listed = pending
        .map((row) => `${row.kind} — ${row.count} шт. на ${row.amount} ${row.currency}`)
        .join('; ');
      throw new ConflictException(
        `Счёт ${invoice.number} за этот период уже в статусе ${invoice.status}, а начисления ` +
          `за тот же период не захвачены ни одним счётом: ${listed}. Состав выставленного счёта ` +
          'менять нельзя: отмените его и соберите заново либо включите эти начисления в следующий период.',
      );
    }
    return this.get(invoice.id, actor);
  }

  /**
   * Захват оснований за счётом и пересчёт строк по захваченному.
   *
   * Порядок здесь — не вкусовщина, а защита от гонки. Сначала основания
   * ЗАХВАТЫВАЮТСЯ (начисления — `charges.invoice_id`, собранный платёж —
   * `shipments.payout_invoice_id`), и только потом по захваченным считаются
   * строки и итог. Если сперва посчитать, а пометить потом, параллельный прогон
   * начислений успеет добавить строку в тот же период: она получит `invoice_id`
   * (то есть будет считаться выставленной), но в сумму счёта не попадёт —
   * деньги пропадут молча.
   */
  private async captureAndCompose(
    em: EntityManager,
    invoiceId: string,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<void> {
    /**
     * Отменённый счёт держать основания не может.
     *
     * Отмена освобождает период (`assertNoOverlap` и поиск существующего счёта
     * отменённые не видят), а захват на строке об этом не знает: без снятия
     * начисления и платежи навсегда остались бы за мёртвым счётом, и
     * собранный заново период вышел бы пустым. Захват с отменённого счёта
     * снимаем ровно в том периоде, который сейчас собираем.
     */
    await this.repo.releaseChargesFromCancelled(em, sellerId, periodStart, periodEnd);
    await this.repo.releaseShipmentsFromCancelled(em, sellerId, periodStart, periodEnd);

    await this.repo.captureCharges(em, invoiceId, sellerId, periodStart, periodEnd);

    // Собранный платёж захватывается ровно так же и в том же порядке: до его
    // подсчёта, а не после. Период сам по себе принадлежности не доказывает —
    // именно поэтому две пересекающиеся сборки складывали одни и те же деньги
    // в «к перечислению» дважды.
    await this.repo.captureCollectedShipments(em, invoiceId, sellerId, periodStart, periodEnd);

    // Строки пересобираются целиком: при пересборке черновика дозахваченное
    // начисление попадает в ту же группу (услуга, единица, цена), и правкой
    // одной строки тут не обойтись.
    await this.repo.deleteLines(em, invoiceId);

    // Группировка по (услуга, единица, цена) — та же, что была. С
    // комбинированными тарифами она сама даёт по строке на составляющую:
    // «паллета» и «перевес по кг» отличаются единицей, и оператор видит в
    // счёте именно то, из чего сумма сложилась.
    const grouped = await this.repo.groupCapturedCharges(em, invoiceId);

    const currencies = new Set(grouped.map((row) => row.currency));
    if (currencies.size > 1) {
      // Складывать разные валюты в один счёт — гарантированный мусор в итоге.
      throw new ConflictException(
        `За период начисления в разных валютах: ${[...currencies].join(', ')}. Разведите тарифы.`,
      );
    }

    // Считаем по ЗАХВАЧЕННЫМ отправлениям, а не по периоду: захват уже
    // произошёл выше, и только он отвечает на вопрос «чьи это деньги».
    const codRows = await this.repo.capturedCodTotals(em, invoiceId);
    const codCurrency = codRows[0].currency;
    const codTotal = Number(codRows[0].total);

    // Валюта счёта не придумывается: она берётся из начислений, из собранного
    // платежа или из тарифного плана селлера. Если взять её неоткуда —
    // выставлять нечего, и лучше сказать об этом прямо.
    const currency = [...currencies][0] ?? codCurrency ?? (await this.planCurrency(em, sellerId));
    if (!currency) {
      throw new ConflictException(
        'За период нет ни начислений, ни платежей, а тарифный план селлеру не назначен — ' +
          'валюту счёта определить не из чего.',
      );
    }
    if (codTotal > 0 && codCurrency && codCurrency !== currency) {
      throw new ConflictException(
        `Платежи собраны в ${codCurrency}, а услуги посчитаны в ${currency}: счёт свести нельзя.`,
      );
    }

    for (const row of grouped) {
      await this.repo.insertLine(
        em,
        invoiceId,
        row.kind,
        `${KIND_TITLE[row.kind] ?? row.kind} (${UNIT_TITLE[row.unit] ?? row.unit})`,
        row.quantity,
        row.unit,
        row.unit_price,
        row.amount,
      );
    }

    /**
     * Итоги складывает БД в `numeric`, а не JS в double.
     *
     * Слагаемые берутся из тех же захваченных строк, что и выше, поэтому
     * промежуточное число в памяти тут не нужно вовсе — а деньги через float
     * в этом проекте недопустимы даже там, где сумма пока помещается точно.
     * «К перечислению» — собранный за селлера платёж минус наши услуги.
     */
    await this.repo.applyTotals(em, invoiceId, currency);
  }

  /** Начисления периода, не попавшие ни в один счёт. */
  private async uncapturedCharges(
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<UncapturedChargeRow[]> {
    return this.repo.uncapturedCharges(this.dataSource, sellerId, periodStart, periodEnd);
  }

  /**
   * Пересечение периодов запрещено.
   *
   * `uq_invoices_period` покрывает только ТОЧНУЮ тройку (селлер, начало,
   * конец), поэтому счёт 01.08–15.08 спокойно создаётся поверх счёта
   * 01.08–31.08.
   *
   * Двойного счёта денег это уже не даёт: и начисления (`charges.invoice_id`),
   * и собранный платёж (`shipments.payout_invoice_id`) захватываются строкой,
   * так что второй счёт получил бы нули. Проверку оставляем именно поэтому —
   * пустой счёт поверх чужого периода не ошибка расчёта, а мусор в реестре, и
   * сказать о нём номером мешающего счёта полезнее, чем выдать «0.00».
   */
  private async assertNoOverlap(
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<void> {
    const rows = await this.repo.overlappingInvoices(
      this.dataSource,
      sellerId,
      periodStart,
      periodEnd,
    );
    if (rows.length === 0) return;

    throw new ConflictException(
      `Период пересекается со счётом ${rows[0].number} (${rows[0].period_start} — ` +
        `${rows[0].period_end}). Собранный наложенный платёж попал бы в оба счёта дважды: ` +
        'выберите непересекающийся период или отмените мешающий счёт.',
    );
  }

  /** Валюта тарифного плана селлера (или плана по умолчанию). */
  private async planCurrency(em: EntityManager, sellerId: string): Promise<string | null> {
    const rows: Array<{ currency: string }> = await this.repo.planCurrency(em, sellerId);
    return rows[0]?.currency ?? null;
  }

  async issue(invoiceId: string, actor: ActorContext): Promise<InvoiceDto> {
    const invoice = await this.load(invoiceId);
    this.assertVisible(invoice.sellerId, actor);
    if (invoice.status !== 'DRAFT') {
      throw new ConflictException(`Счёт уже в статусе ${invoice.status}.`);
    }
    await this.repo.markIssued(this.dataSource, invoiceId);
    return this.get(invoiceId, actor);
  }

  async list(actor: ActorContext, sellerId?: string): Promise<InvoiceDto[]> {
    const scope = resolveSellerScope(actor.user);
    const target = scope ?? sellerId;

    const rows = await this.dataSource
      .getRepository(InvoiceEntity)
      .find({
        where: target ? { sellerId: target } : {},
        order: { periodStart: 'DESC' },
        take: 100,
      });
    return Promise.all(rows.map((row) => this.get(row.id, actor)));
  }

  async get(invoiceId: string, actor: ActorContext): Promise<InvoiceDto> {
    const invoice = await this.load(invoiceId);
    this.assertVisible(invoice.sellerId, actor);

    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: invoice.sellerId } });

    const lines: Array<Record<string, unknown>> = await this.repo.lines(
      this.dataSource,
      invoiceId,
    );

    return {
      id: invoice.id,
      number: invoice.number,
      sellerId: invoice.sellerId,
      sellerName: seller?.legalName ?? '—',
      periodStart: this.asDate(invoice.periodStart),
      periodEnd: this.asDate(invoice.periodEnd),
      currency: invoice.currency,
      servicesTotal: invoice.servicesTotal,
      codCollectedTotal: invoice.codCollectedTotal,
      payoutTotal: invoice.payoutTotal,
      status: invoice.status,
      issuedAt: invoice.issuedAt ? invoice.issuedAt.toISOString() : null,
      lines: lines.map(
        (line): InvoiceLineDto => ({
          id: line.id as string,
          kind: line.kind as InvoiceLineDto['kind'],
          description: line.description as string,
          quantity: line.quantity as string,
          unit: line.unit as InvoiceLineDto['unit'],
          unitPrice: line.unit_price as string,
          amount: line.amount as string,
        }),
      ),
    };
  }

  /**
   * Сверка наложенного платежа: что обещали собрать против того, что собрали.
   * Считает SQL — расхождение должно быть видно на всём массиве, а не на
   * выборке, дотянутой в память.
   */
  async reconcileCod(
    periodStart: string,
    periodEnd: string,
    actor: ActorContext,
  ): Promise<CodReconciliationDto> {
    const scope = resolveSellerScope(actor.user);

    const rows: Array<Record<string, unknown>> = await this.repo.codReconciliation(
      this.dataSource,
      periodStart,
      periodEnd,
      scope,
    );

    let totalExpected = 0;
    let totalCollected = 0;
    const result: CodReconciliationRowDto[] = rows.map((row) => {
      const expected = Number(row.expected);
      const collected = row.collected === null ? null : Number(row.collected);
      totalExpected += expected;
      totalCollected += collected ?? 0;

      let status: CodReconciliationRowDto['status'] = 'MATCHED';
      if (collected === null) status = 'MISSING';
      else if (collected < expected) status = 'SHORT';
      else if (collected > expected) status = 'OVER';

      return {
        shipmentId: row.id as string,
        shipmentNo: row.shipment_no as string,
        orderExternalId: row.external_id as string,
        sellerId: row.seller_id as string,
        expected: expected.toFixed(2),
        collected: collected === null ? null : collected.toFixed(2),
        difference: row.difference as string,
        currency: row.currency as string,
        deliveredAt: row.delivered_at ? new Date(row.delivered_at as string).toISOString() : null,
        status,
      };
    });

    return {
      periodStart,
      periodEnd,
      totalExpected: totalExpected.toFixed(2),
      totalCollected: totalCollected.toFixed(2),
      rows: result,
    };
  }

  // ------------------------------------------------------------ внутреннее

  private async load(invoiceId: string): Promise<InvoiceEntity> {
    const invoice = await this.dataSource
      .getRepository(InvoiceEntity)
      .findOne({ where: { id: invoiceId } });
    if (!invoice) throw new NotFoundException('Счёт не найден.');
    return invoice;
  }

  private assertVisible(sellerId: string, actor: ActorContext): void {
    const scope = resolveSellerScope(actor.user);
    if (!isSellerVisible(scope, sellerId)) throw new NotFoundException('Счёт не найден.');
  }

  private asDate(value: string | Date): string {
    return typeof value === 'string' ? value : value.toISOString().slice(0, 10);
  }
}
