import { Module } from '@nestjs/common';
import { HealthRepository } from '../../infrastructure/database/repositories/health.repository';
import { HealthController } from '../../presentation/http/health.controller';
import { HealthService } from './health.service';

@Module({
  controllers: [HealthController],
  providers: [HealthService, HealthRepository],
})
export class HealthModule {}
