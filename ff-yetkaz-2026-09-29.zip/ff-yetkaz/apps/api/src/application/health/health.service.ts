import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { HealthRepository } from '../../infrastructure/database/repositories/health.repository';

/**
 * Проверка живости сервиса. В базу ходит репозиторий, а не контроллер:
 * контроллер разбирает запрос и отдаёт ответ, за SQL отвечает слой хранения.
 */
@Injectable()
export class HealthService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly health: HealthRepository,
  ) {}

  async check(): Promise<{ status: 'ok'; db: 'up'; time: string }> {
    try {
      await this.health.ping(this.dataSource);
    } catch (error) {
      throw new ServiceUnavailableException(`База данных недоступна: ${String(error)}`);
    }
    return { status: 'ok', db: 'up', time: new Date().toISOString() };
  }
}
