import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import type { DepartmentDto } from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import type { ActorContext } from '../../domain/types/actor';
import { DepartmentEntity } from '../../infrastructure/database/entities';
import {
  IdentityRepository,
  type DepartmentRow,
} from '../../infrastructure/database/repositories/identity.repository';

/**
 * Отделы оператора. Доступно только ADMIN (гвард на контроллере).
 *
 * Удаления нет намеренно: на отдел ссылаются учётки сотрудников, а «в каком
 * подразделении он был» должно отвечаться и потом. Расформирование — это
 * is_active = false: в назначениях отдел больше не предлагается, история цела.
 */
@Injectable()
export class DepartmentsService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
    private readonly identity: IdentityRepository,
  ) {}

  async list(): Promise<DepartmentDto[]> {
    // Число сотрудников считаем в БД одним проходом — иначе N+1 на каждый отдел.
    const rows = await this.identity.listDepartmentsWithMemberCount(this.dataSource);
    return rows.map(rowToDto);
  }

  async create(
    input: { code: string; name: string; description?: string },
    actor: ActorContext,
  ): Promise<DepartmentDto> {
    const code = input.code.trim().toUpperCase();
    const name = input.name.trim();
    const description = input.description?.trim() || null;

    const repo = this.dataSource.getRepository(DepartmentEntity);
    let created: DepartmentEntity;
    try {
      created = await repo.save(repo.create({ code, name, description, isActive: true }));
    } catch (error) {
      if (uniqueViolationConstraint(error)) {
        throw new ConflictException(`Отдел с кодом ${code} уже существует.`);
      }
      throw error;
    }

    await this.audit.record({
      action: 'CREATE',
      entityType: 'Department',
      entityId: created.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: { code, name, description },
    });

    return this.one(created.id);
  }

  async update(
    id: string,
    input: { name?: string; description?: string; isActive?: boolean },
    actor: ActorContext,
  ): Promise<DepartmentDto> {
    const repo = this.dataSource.getRepository(DepartmentEntity);
    const department = await repo.findOne({ where: { id } });
    if (!department) throw new NotFoundException('Отдел не найден.');

    const before = { name: department.name, description: department.description, isActive: department.isActive };
    if (input.name !== undefined) department.name = input.name.trim();
    if (input.description !== undefined) department.description = input.description.trim() || null;
    if (input.isActive !== undefined) department.isActive = input.isActive;
    await repo.save(department);

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Department',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before,
      after: { name: department.name, description: department.description, isActive: department.isActive },
    });

    return this.one(id);
  }

  // ------------------------------------------------------------- внутреннее

  private async one(id: string): Promise<DepartmentDto> {
    const rows = await this.identity.findDepartmentWithMemberCount(this.dataSource, id);
    if (!rows[0]) throw new NotFoundException('Отдел не найден.');
    return rowToDto(rows[0]);
  }
}

function rowToDto(row: DepartmentRow): DepartmentDto {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    description: row.description ?? null,
    isActive: row.is_active,
    memberCount: Number(row.member_count ?? 0),
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : String(row.created_at),
  };
}
