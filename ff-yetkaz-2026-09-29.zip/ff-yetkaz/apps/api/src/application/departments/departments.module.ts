import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DepartmentEntity } from '../../infrastructure/database/entities';
import { IdentityRepository } from '../../infrastructure/database/repositories/identity.repository';
import { DepartmentsController } from '../../presentation/http/departments.controller';
import { DepartmentsService } from './departments.service';

@Module({
  imports: [TypeOrmModule.forFeature([DepartmentEntity])],
  controllers: [DepartmentsController],
  providers: [DepartmentsService, IdentityRepository],
})
export class DepartmentsModule {}
