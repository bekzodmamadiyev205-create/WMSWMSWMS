import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import {
  ORDER_CATEGORY_COLORS,
  type CreateOrderCategoryPayload,
  type OrderCategoryDto,
} from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import {
  isForeignKeyViolation,
  uniqueViolationConstraint,
} from '../../infrastructure/database/unique-violation';
import {
  OrderCategoriesRepository,
  type OrderCategoryRow,
} from '../../infrastructure/database/repositories/order-categories.repository';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { OrderCategoryEntity } from '../../infrastructure/database/entities';
import type {
  ListOrderCategoriesQueryInput,
  UpdateOrderCategoryInput,
} from './order-categories.input';

/**
 * Справочник категорий заказа.
 *
 * Читать может любой авторизованный: категорию выбирают при оформлении заказа,
 * и роль, которой не дали прав на справочники, всё равно обязана видеть список —
 * иначе форма заказа отдаёт 403 на собственном выпадающем списке.
 *
 * Править может только ADMIN (гварды стоят на ручках контроллера).
 */
@Injectable()
export class OrderCategoriesService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
    private readonly categories: OrderCategoriesRepository,
  ) {}

  async list(
    query: ListOrderCategoriesQueryInput,
    actor: ActorContext,
  ): Promise<OrderCategoryDto[]> {
    const scope = resolveSellerScope(actor.user);

    const rows = await this.categories.findAll(this.dataSource, {
      scope,
      onlyActive: query.includeInactive !== 'true',
    });
    return rows.map(rowToDto);
  }

  async create(input: CreateOrderCategoryPayload, actor: ActorContext): Promise<OrderCategoryDto> {
    const code = input.code.trim().toUpperCase();
    const name = input.name.trim();
    const description = input.description?.trim() || null;
    const color = input.color ? normaliseColor(input.color) : await this.nextFreeColor();
    const sortOrder = input.sortOrder ?? DEFAULT_SORT_ORDER;

    const repo = this.dataSource.getRepository(OrderCategoryEntity);
    let created: OrderCategoryEntity;
    try {
      created = await repo.save(
        repo.create({ code, name, description, color, sortOrder, isActive: true }),
      );
    } catch (error) {
      if (uniqueViolationConstraint(error) !== null) {
        throw new ConflictException(`Категория с кодом ${code} уже существует.`);
      }
      throw error;
    }

    await this.audit.record({
      action: 'CREATE',
      entityType: 'OrderCategory',
      entityId: created.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: { code, name, description, color, sortOrder, isActive: true },
    });

    return this.one(created.id, actor);
  }

  async update(
    id: string,
    input: UpdateOrderCategoryInput,
    actor: ActorContext,
  ): Promise<OrderCategoryDto> {
    if (input.code !== undefined) {
      throw new BadRequestException(
        'Код категории изменить нельзя: по нему связаны выгрузки и отчёты за прошлые ' +
          'периоды. Заведите новую категорию, а эту отключите.',
      );
    }

    const repo = this.dataSource.getRepository(OrderCategoryEntity);
    const category = await repo.findOne({ where: { id } });
    if (!category) throw new NotFoundException('Категория не найдена.');

    const before = snapshot(category);
    if (input.name !== undefined) category.name = input.name.trim();
    if (input.description !== undefined) category.description = input.description?.trim() || null;
    if (input.color !== undefined) category.color = input.color ? normaliseColor(input.color) : null;
    if (input.sortOrder !== undefined) category.sortOrder = input.sortOrder;
    if (input.isActive !== undefined) category.isActive = input.isActive;
    await repo.save(category);

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'OrderCategory',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before,
      after: snapshot(category),
    });

    return this.one(id, actor);
  }

  /**
   * Жёсткое удаление — только у категории, на которую никто не ссылается.
   *
   * Одной ловли 23503 тут НЕ хватает: `orders.category_id` объявлен
   * ON DELETE SET NULL, поэтому удаление используемой категории не упало бы,
   * а тихо обнулило разрез у всех её заказов. Настоящий барьер — подсчёт.
   * Нарушение внешнего ключа всё равно перехватываем: на категорию могут
   * сослаться будущие таблицы со строгим RESTRICT.
   */
  async remove(id: string, actor: ActorContext): Promise<{ deleted: boolean }> {
    const before = await this.dataSource.transaction(async (manager) => {
      // FOR UPDATE на строке справочника конфликтует с FOR KEY SHARE, который
      // PostgreSQL берёт на родительской строке при проверке внешнего ключа.
      // Значит, пока идёт удаление, ни один заказ не может встать на эту
      // категорию: иначе ссылка успела бы появиться между подсчётом и DELETE.
      const locked = await this.categories.lockById(manager, id);
      const row = locked[0];
      if (!row) throw new NotFoundException('Категория не найдена.');

      await assertUnused(this.categories, manager, id);

      try {
        await this.categories.deleteById(manager, id);
      } catch (error) {
        if (isForeignKeyViolation(error)) throw new ConflictException(IN_USE_MESSAGE);
        throw error;
      }
      return row;
    });

    // Аудит пишется после коммита и отдельным соединением: журнал не должен
    // становиться причиной отката уже состоявшегося удаления.
    await this.audit.record({
      action: 'DELETE',
      entityType: 'OrderCategory',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: {
        code: before.code,
        name: before.name,
        description: before.description,
        color: before.color,
        sortOrder: before.sort_order,
        isActive: before.is_active,
      },
    });

    return { deleted: true };
  }

  // ------------------------------------------------------------- внутреннее

  private async one(id: string, actor: ActorContext): Promise<OrderCategoryDto> {
    const scope = resolveSellerScope(actor.user);

    const rows = await this.categories.findById(this.dataSource, { scope, id });
    const row = rows[0];
    if (!row) throw new NotFoundException('Категория не найдена.');
    return rowToDto(row);
  }

  /**
   * Цвет новой категории выбирается сам: оператор заводит направление бизнеса,
   * а не подбирает палитру. Берём первый неиспользованный оттенок, чтобы две
   * соседние категории не оказались одного цвета в списке.
   */
  private async nextFreeColor(): Promise<string> {
    const rows = await this.categories.findUsedColors(this.dataSource);
    const used = new Set(rows.map((row) => row.color));
    const free = ORDER_CATEGORY_COLORS.find((candidate) => !used.has(candidate));
    // Палитра кончилась — идём по кругу: категория без цвета хуже, чем повтор.
    return free ?? ORDER_CATEGORY_COLORS[used.size % ORDER_CATEGORY_COLORS.length];
  }
}

const DEFAULT_SORT_ORDER = 100;

const IN_USE_MESSAGE = 'Категория используется в заказах — отключите её вместо удаления.';

async function assertUnused(
  categories: OrderCategoriesRepository,
  manager: EntityManager,
  id: string,
): Promise<void> {
  const rows = await categories.countOrders(manager, id);
  if (Number(rows[0]?.orders_count ?? 0) > 0) throw new ConflictException(IN_USE_MESSAGE);
}

/** Цвет храним в нижнем регистре: иначе #6366F1 и #6366f1 считались бы разными. */
function normaliseColor(raw: string): string {
  return raw.trim().toLowerCase();
}

function snapshot(category: OrderCategoryEntity): Record<string, unknown> {
  return {
    name: category.name,
    description: category.description,
    color: category.color,
    sortOrder: category.sortOrder,
    isActive: category.isActive,
  };
}

function rowToDto(row: OrderCategoryRow): OrderCategoryDto {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    description: row.description ?? null,
    color: row.color ?? null,
    sortOrder: Number(row.sort_order ?? DEFAULT_SORT_ORDER),
    isActive: row.is_active,
    ordersCount: Number(row.orders_count ?? 0),
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function toIso(value: Date | string): string {
  return value instanceof Date ? value.toISOString() : String(value);
}
