import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderCategoryEntity } from '../../infrastructure/database/entities';
import { OrderCategoriesRepository } from '../../infrastructure/database/repositories/order-categories.repository';
import { OrderCategoriesController } from '../../presentation/http/order-categories.controller';
import { OrderCategoriesService } from './order-categories.service';

@Module({
  imports: [TypeOrmModule.forFeature([OrderCategoryEntity])],
  controllers: [OrderCategoriesController],
  providers: [OrderCategoriesService, OrderCategoriesRepository],
  // Экспортируется для модуля заказов: проверять категорию при создании заказа
  // надо тем же кодом, а не вторым запросом в ту же таблицу.
  exports: [OrderCategoriesService],
})
export class OrderCategoriesModule {}
