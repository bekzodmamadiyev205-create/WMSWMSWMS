import type { UpdateOrderCategoryPayload } from '@ff/shared';

/**
 * Формы входных данных справочника категорий, которых нет в `@ff/shared`.
 *
 * Прикладному слою нужна ФОРМА запроса, а не класс с декораторами
 * class-validator: декораторы существуют ради разбора HTTP. Создание категории
 * описано контрактом `CreateOrderCategoryPayload` и берётся из пакета; здесь —
 * только то, что живёт исключительно на входе API.
 */

/**
 * Правка категории.
 *
 * Отличается от контракта пакета одним полем: `code` в запросе ПРИНИМАЕТСЯ,
 * хотя менять его нельзя. Поле доходит до сервиса именно затем, чтобы тот дал
 * внятный отказ, — иначе `forbidNonWhitelisted` ответил бы безличным
 * «property code should not exist».
 */
export interface UpdateOrderCategoryInput extends UpdateOrderCategoryPayload {
  code?: string;
}

/** Параметры выдачи списка категорий. */
export interface ListOrderCategoriesQueryInput {
  /**
   * Строка, а не boolean: в query всё приходит текстом, а глобальный
   * ValidationPipe включён без `enableImplicitConversion`.
   */
  includeInactive?: 'true' | 'false';
}
