import type { InventoryUnitStatus } from '@ff/shared';

/**
 * Формы входных данных складских операций.
 *
 * Живут рядом с сервисом, а не в presentation: прикладному слою нужна ФОРМА
 * данных, а декораторы class-validator существуют ради разбора HTTP-запроса.
 * Классы DTO в presentation объявляют `implements` этих интерфейсов — так
 * расхождение формы поймает сборка, а не боевой запрос.
 *
 * Витрины остатков здесь нет: её запрос `StockTableQuery` — часть публичного
 * контракта с фронтом и потому живёт в @ff/shared.
 */

export interface StockInInput {
  skuId: string;
  warehouseId: string;
  binId: string;
  quantity: number;
  /** Обязателен для SKU с партионным учётом. */
  lotCode?: string;
  /** Обязателен для SKU с учётом срока годности. */
  expiryDate?: string;
  /** Куда кладём: обычно AVAILABLE, при браке — DAMAGED или QUARANTINE. */
  status?: InventoryUnitStatus;
  comment?: string;
}

export interface MoveStockInput {
  skuId: string;
  warehouseId: string;
  fromBinId: string;
  fromStatus: InventoryUnitStatus;
  toBinId: string;
  toStatus: InventoryUnitStatus;
  lotId?: string;
  quantity: number;
  comment?: string;
}

export interface AdjustStockInput {
  skuId: string;
  warehouseId: string;
  binId: string;
  lotId?: string;
  status?: InventoryUnitStatus;
  /** Со знаком: +5 — нашли лишнее, −3 — недостача. Ноль бессмысленен. */
  delta: number;
  /** Причина обязательна: корректировка без объяснения обесценивает журнал. */
  comment: string;
}

export interface ReserveInput {
  ownerType: string;
  ownerId: string;
  skuId: string;
  warehouseId: string;
  quantity: number;
}

export interface ReleaseInput {
  ownerType: string;
  ownerId: string;
  reason?: string;
}

export interface StockQueryInput {
  skuId?: string;
  warehouseId?: string;
  /** Для оператора: чей товар смотрим. У селлера область берётся из токена. */
  sellerId?: string;
}

export interface MovementsQueryInput {
  skuId?: string;
  warehouseId?: string;
  limit?: number;
}
