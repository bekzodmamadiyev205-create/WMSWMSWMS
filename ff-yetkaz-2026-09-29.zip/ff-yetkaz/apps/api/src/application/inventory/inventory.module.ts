import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  BinLocationEntity,
  LotEntity,
  ReservationEntity,
  SkuEntity,
  StockEntity,
  StockMovementEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { InventoryRepository } from '../../infrastructure/database/repositories/inventory.repository';
import { StockTableRepository } from '../../infrastructure/database/repositories/stock-table.repository';
import { InventoryController } from '../../presentation/http/inventory.controller';
import { InventoryService } from './inventory.service';
import { StockTableService } from './stock-table.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      LotEntity,
      StockEntity,
      StockMovementEntity,
      ReservationEntity,
      SkuEntity,
      WarehouseEntity,
      BinLocationEntity,
    ]),
  ],
  controllers: [InventoryController],
  providers: [InventoryService, StockTableService, InventoryRepository, StockTableRepository],
  exports: [InventoryService],
})
export class InventoryModule {}
