import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import type { Response } from 'express';
import { DataSource } from 'typeorm';
import {
  STOCK_SORT_FIELDS,
  type InventoryUnitStatus,
  type PageDto,
  type StockBinRowDto,
  type StockSortField,
  type StockTableQuery,
  type StockTableRowDto,
  type StockTableTotalsDto,
} from '@ff/shared';
import { XlsxService } from '../../infrastructure/export/xlsx.service';
import { pageEnvelope, resolvePage, resolveSort } from '../../infrastructure/database/query/page';
import {
  StockTableRepository,
  type StockRow,
} from '../../infrastructure/database/repositories/stock-table.repository';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';

/**
 * Витрина остатков: строка = SKU × склад × статус.
 *
 * Отдельный сервис, а не метод в `InventoryService`: там живёт единственная
 * точка записи остатка (`applyMovement`) с FEFO/FIFO-резервом и защитой от
 * гонки. Чтение никогда не должно становиться поводом трогать этот код.
 *
 * ГЛАВНАЯ ЛОВУШКА, ради которой всё это написано — ДАТА ПОСТУПЛЕНИЯ.
 * В таблице `stock` даты поступления НЕТ ни в каком виде:
 *  - `stock.created_at` — момент, когда строка среза появилась впервые. Строки
 *    переиспользуются через `ON CONFLICT` и не удаляются никогда, поэтому срез,
 *    заведённый в марте, в августе содержит августовский товар, а `created_at`
 *    у него по-прежнему мартовский;
 *  - `stock.updated_at` двигает триггер при ЛЮБОМ изменении количества, включая
 *    расход — то есть отгрузка «омолаживает» остаток.
 * Ни то ни другое не является датой прихода. Правда лежит в журнале:
 * `stock_movements.occurred_at` того движения, которое ПОЛОЖИЛО товар в ячейку —
 * `RECEIPT` (приёмка в зону приёмки), `PUTAWAY` (раскладка в ячейку хранения)
 * или `RETURN` (приёмка возврата — это тоже поступление на склад).
 * Статус в этот ключ НЕ входит: резерв, брак, сборка и упаковка меняют статус
 * товара, уже лежащего на складе, и поступлением не являются.
 */
@Injectable()
export class StockTableService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly xlsx: XlsxService,
    private readonly stockTableRepository: StockTableRepository,
  ) {}

  // ------------------------------------------------------------------ таблица

  async table(query: StockTableQuery, actor: ActorContext): Promise<PageDto<StockTableRowDto>> {
    return this.page(query, this.scopeOf(query, actor));
  }

  /** Итоги считаются по ВСЕМУ фильтру, а не по видимой странице. */
  async totals(query: StockTableQuery, actor: ActorContext): Promise<StockTableTotalsDto> {
    const sellerId = this.scopeOf(query, actor);

    const rows: Array<{
      row_count: string;
      units: string;
      available: string;
      reserved: string;
      damaged: string;
      sku_count: string;
    }> = await this.stockTableRepository.countTotals(this.dataSource, query, sellerId);

    const row = rows[0];
    return {
      rows: Number(row?.row_count ?? 0),
      units: Number(row?.units ?? 0),
      available: Number(row?.available ?? 0),
      reserved: Number(row?.reserved ?? 0),
      damaged: Number(row?.damaged ?? 0),
      skus: Number(row?.sku_count ?? 0),
    };
  }

  // ----------------------------------------------------------------- выгрузка

  async export(
    query: StockTableQuery,
    actor: ActorContext,
    response: Response,
  ): Promise<void> {
    const sellerId = this.scopeOf(query, actor);
    const stamp = new Date().toISOString().slice(0, 10);

    await this.xlsx.stream<StockTableRowDto>(response, {
      filename: `Остатки-${stamp}.xlsx`,
      sheetName: 'Остатки',
      title: 'Остатки на складе',
      notes: this.describeFilters(query, sellerId),
      columns: [
        { header: 'SKU', key: 'skuCode', width: 20, value: (row) => row.skuCode },
        { header: 'Товар', key: 'skuName', width: 38, value: (row) => row.skuName },
        { header: 'Селлер', key: 'sellerName', width: 26, value: (row) => row.sellerName },
        { header: 'Склад', key: 'warehouseCode', width: 14, value: (row) => row.warehouseCode },
        { header: 'Статус', key: 'status', width: 14, value: (row) => row.status },
        { header: 'Количество', key: 'quantity', width: 12, value: (row) => row.quantity },
        { header: 'Доступно', key: 'available', width: 12, value: (row) => row.available },
        { header: 'Зарезервировано', key: 'reserved', width: 16, value: (row) => row.reserved },
        { header: 'Брак', key: 'damaged', width: 10, value: (row) => row.damaged },
        {
          header: 'Первое поступление',
          key: 'firstReceivedAt',
          width: 20,
          numFmt: 'dd.mm.yyyy hh:mm',
          value: (row) => (row.firstReceivedAt ? new Date(row.firstReceivedAt) : null),
        },
        {
          header: 'Последнее поступление',
          key: 'lastReceivedAt',
          width: 22,
          numFmt: 'dd.mm.yyyy hh:mm',
          value: (row) => (row.lastReceivedAt ? new Date(row.lastReceivedAt) : null),
        },
        { header: 'Ячейки', key: 'bins', width: 40, value: (row) => binsToText(row.bins) },
      ],
      rows: this.streamBatches(query, sellerId),
    });
  }

  /**
   * Страницы по 500 строк. Выгрузка обязана отвечать ТЕМ ЖЕ фильтрам, что и
   * список — поэтому она и идёт через тот же `page()`, а не через отдельный
   * запрос, который со временем разъехался бы со списком.
   */
  private async *streamBatches(
    query: StockTableQuery,
    sellerId: string | undefined,
  ): AsyncIterable<StockTableRowDto[]> {
    const batch = 500;
    for (let page = 1; ; page += 1) {
      const chunk = await this.page({ ...query, page, pageSize: batch }, sellerId);
      if (chunk.rows.length === 0) return;
      yield chunk.rows;
      // Останов и по признаку неполной страницы, и по общему числу: остаток
      // едет во время выгрузки, и полагаться на что-то одно значит либо
      // оборвать отчёт, либо крутить бесконечный цикл.
      if (chunk.rows.length < batch || page * batch >= chunk.total) return;
    }
  }

  // --------------------------------------------------------------- внутреннее

  /**
   * Область селлера из токена сильнее параметра запроса: подставленный чужой
   * `sellerId` не должен показать чужой остаток.
   */
  private scopeOf(query: StockTableQuery, actor: ActorContext): string | undefined {
    const scope = resolveSellerScope(actor.user);
    return scope ?? query.sellerId;
  }

  private async page(
    query: StockTableQuery,
    sellerId: string | undefined,
  ): Promise<PageDto<StockTableRowDto>> {
    const pageParams = resolvePage(query);
    // Умолчание по возрастанию артикула: витрину читают глазами, и обратный
    // алфавит по умолчанию — это просто неудобно.
    const sort = resolveSort<StockSortField>(
      STOCK_SORT_FIELDS,
      'skuCode',
      query.sort,
      query.direction ?? 'asc',
    );
    const rows: StockRow[] = await this.stockTableRepository.findRows(
      this.dataSource,
      query,
      sellerId,
      pageParams,
      sort,
    );

    const total = rows.length > 0 ? Number(rows[0].total_rows) : 0;
    const bins = await this.loadBins(rows, Boolean(query.includeZero));

    return pageEnvelope(
      rows.map((row) => {
        const key = `${row.sku_id}:${row.warehouse_id}:${row.status}`;
        return {
          key,
          skuId: row.sku_id,
          skuCode: row.sku_code,
          skuName: row.sku_name,
          sellerId: row.seller_id,
          sellerCode: row.seller_code,
          sellerName: row.seller_name,
          warehouseId: row.warehouse_id,
          warehouseCode: row.warehouse_code,
          status: row.status,
          quantity: Number(row.quantity),
          available: Number(row.available),
          reserved: Number(row.reserved),
          damaged: Number(row.damaged),
          firstReceivedAt: toIso(row.first_received_at),
          lastReceivedAt: toIso(row.last_received_at),
          bins: bins.get(key) ?? [],
        };
      }),
      total,
      pageParams,
    );
  }

  /**
   * Раскладка по ячейкам — ТОЛЬКО для текущей страницы, одним запросом по её
   * тройкам (SKU, склад, статус). Вопрос кладовщика звучит «где взять», поэтому
   * ответ обязан быть на экране без клика; но тянуть ячейки на весь фильтр
   * значит обесценить постраничность, ради которой всё и затевалось.
   */
  private async loadBins(
    rows: StockRow[],
    includeZero: boolean,
  ): Promise<Map<string, StockBinRowDto[]>> {
    const result = new Map<string, StockBinRowDto[]>();
    if (rows.length === 0) return result;

    const skuIds = rows.map((row) => row.sku_id);
    const warehouseIds = rows.map((row) => row.warehouse_id);
    const statuses = rows.map((row) => String(row.status));

    const binRows: Array<{
      sku_id: string;
      warehouse_id: string;
      status: InventoryUnitStatus;
      bin_id: string;
      bin_code: string;
      quantity: string;
    }> = await this.stockTableRepository.findBinsForSlices(
      this.dataSource,
      skuIds,
      warehouseIds,
      statuses,
      includeZero,
    );

    for (const bin of binRows) {
      const key = `${bin.sku_id}:${bin.warehouse_id}:${bin.status}`;
      const list = result.get(key);
      const item: StockBinRowDto = {
        binId: bin.bin_id,
        binCode: bin.bin_code,
        status: bin.status,
        quantity: Number(bin.quantity),
      };
      if (list) list.push(item);
      else result.set(key, [item]);
    }
    return result;
  }

  private describeFilters(query: StockTableQuery, sellerId: string | undefined): string[] {
    const notes = [`Выгружено: ${new Date().toLocaleString('ru-RU')}`];
    if (sellerId) notes.push(`Селлер: ${sellerId}`);
    if (query.warehouseId) notes.push(`Склад: ${query.warehouseId}`);
    if (query.status) notes.push(`Статус: ${query.status}`);
    if (query.search) notes.push(`Поиск: ${query.search}`);
    if (query.dateFrom || query.dateTo) {
      notes.push(
        `Период поступления: ${query.dateFrom ?? '—'} — ${query.dateTo ?? '—'} (включительно)`,
      );
    }
    if (query.includeZero) notes.push('Включая нулевые остатки');
    return notes;
  }
}

function toIso(value: Date | string | null): string | null {
  if (value === null || value === undefined) return null;
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function binsToText(bins: StockBinRowDto[]): string {
  return bins.map((bin) => `${bin.binCode} (${bin.quantity})`).join('; ');
}
