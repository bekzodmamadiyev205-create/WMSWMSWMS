import {
  BadRequestException,
  ConflictException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import {
  FF_EVENTS,
  inventoryUnitFsm,
  type InventoryUnitStatus,
  type MovementReason,
  type ReservationDto,
  type ReserveResultDto,
  type StockMovementDto,
  type StockSummaryDto,
} from '@ff/shared';
import { createEvent, EVENT_BUS, type EventBus } from '../../infrastructure/queues/events/event-bus';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import {
  BinLocationEntity,
  LotEntity,
  SkuEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { InventoryRepository } from '../../infrastructure/database/repositories/inventory.repository';
import type {
  AdjustStockInput,
  MoveStockInput,
  MovementsQueryInput,
  ReleaseInput,
  ReserveInput,
  StockInInput,
  StockQueryInput,
} from './inventory.input';

export interface MovementSide {
  binId: string;
  status: InventoryUnitStatus;
}

export interface MovementInput {
  skuId: string;
  warehouseId: string;
  lotId: string | null;
  from?: MovementSide;
  to?: MovementSide;
  quantity: number;
  reason: MovementReason;
  referenceType?: string | null;
  referenceId?: string | null;
  comment?: string | null;
}

const DEFAULT_MOVEMENTS_LIMIT = 100;

@Injectable()
export class InventoryService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    @Inject(EVENT_BUS) private readonly events: EventBus,
    private readonly inventoryRepository: InventoryRepository,
  ) {}

  // ------------------------------------------------------------------ приход

  async stockIn(dto: StockInInput, actor: ActorContext): Promise<StockSummaryDto> {
    const sku = await this.loadSku(dto.skuId);
    await this.loadBin(dto.binId, dto.warehouseId);

    const status = dto.status ?? 'AVAILABLE';

    await this.dataSource.transaction(async (em) => {
      const lotId = await this.resolveLot(em, sku, dto.lotCode, dto.expiryDate);
      await this.applyMovement(
        em,
        {
          skuId: dto.skuId,
          warehouseId: dto.warehouseId,
          lotId,
          to: { binId: dto.binId, status },
          quantity: dto.quantity,
          reason: 'RECEIPT',
          comment: dto.comment ?? null,
        },
        actor,
      );
    });

    return this.summaryFor(dto.skuId, dto.warehouseId);
  }

  // ------------------------------------------------------------- перемещение

  async move(dto: MoveStockInput, actor: ActorContext): Promise<StockSummaryDto> {
    await this.loadSku(dto.skuId);
    await this.loadBin(dto.fromBinId, dto.warehouseId);
    await this.loadBin(dto.toBinId, dto.warehouseId);

    await this.dataSource.transaction(async (em) => {
      await this.applyMovement(
        em,
        {
          skuId: dto.skuId,
          warehouseId: dto.warehouseId,
          lotId: dto.lotId ?? null,
          from: { binId: dto.fromBinId, status: dto.fromStatus },
          to: { binId: dto.toBinId, status: dto.toStatus },
          quantity: dto.quantity,
          reason: 'MOVE',
          comment: dto.comment ?? null,
        },
        actor,
      );
    });

    return this.summaryFor(dto.skuId, dto.warehouseId);
  }

  // --------------------------------------------------------- инвентаризация

  /** Ручная корректировка. Причина обязательна и на уровне DTO, и в CHECK таблицы. */
  async adjust(dto: AdjustStockInput, actor: ActorContext): Promise<StockSummaryDto> {
    await this.loadSku(dto.skuId);
    await this.loadBin(dto.binId, dto.warehouseId);

    const status = dto.status ?? 'AVAILABLE';
    const side: MovementSide = { binId: dto.binId, status };

    await this.dataSource.transaction(async (em) => {
      await this.applyMovement(
        em,
        {
          skuId: dto.skuId,
          warehouseId: dto.warehouseId,
          lotId: dto.lotId ?? null,
          from: dto.delta < 0 ? side : undefined,
          to: dto.delta > 0 ? side : undefined,
          quantity: Math.abs(dto.delta),
          reason: 'ADJUSTMENT',
          comment: dto.comment,
        },
        actor,
      );
    });

    return this.summaryFor(dto.skuId, dto.warehouseId);
  }

  // ------------------------------------------------------------ резервирование

  /**
   * Резерв под владельца. Конкурентная безопасность держится на `FOR UPDATE`:
   * второй запрос ждёт первого, а после его коммита PostgreSQL перепроверяет
   * условие `quantity > 0` и просто не видит уже разобранную строку. Поэтому
   * два одновременных резерва последней единицы не могут оба преуспеть.
   */
  async reserve(dto: ReserveInput, actor: ActorContext): Promise<ReserveResultDto> {
    await this.loadSku(dto.skuId);

    const lines = await this.dataSource.transaction<ReservationDto[]>(async (em) => {
      // FOR UPDATE OF s — блокируем только остатки: `lots` на nullable-стороне
      // LEFT JOIN, и PostgreSQL отказывается их блокировать.
      const candidates: Array<{ bin_id: string; lot_id: string | null; quantity: number }> =
        await this.inventoryRepository.lockAvailableSlicesForReserve(
          em,
          dto.skuId,
          dto.warehouseId,
        );

      let remaining = dto.quantity;
      const allocations: Array<{ binId: string; lotId: string | null; quantity: number }> = [];
      for (const candidate of candidates) {
        if (remaining === 0) break;
        const take = Math.min(remaining, candidate.quantity);
        allocations.push({ binId: candidate.bin_id, lotId: candidate.lot_id, quantity: take });
        remaining -= take;
      }

      if (remaining > 0) {
        const available = dto.quantity - remaining;
        throw new ConflictException(
          `Недостаточно доступного остатка: запрошено ${dto.quantity}, доступно ${available}.`,
        );
      }

      const created: ReservationDto[] = [];
      for (const allocation of allocations) {
        await this.applyMovement(
          em,
          {
            skuId: dto.skuId,
            warehouseId: dto.warehouseId,
            lotId: allocation.lotId,
            from: { binId: allocation.binId, status: 'AVAILABLE' },
            to: { binId: allocation.binId, status: 'RESERVED' },
            quantity: allocation.quantity,
            reason: 'RESERVE',
            referenceType: dto.ownerType,
            referenceId: dto.ownerId,
          },
          actor,
        );

        const rows: Array<{ id: string }> = await this.inventoryRepository.insertReservation(em, {
          ownerType: dto.ownerType,
          ownerId: dto.ownerId,
          skuId: dto.skuId,
          warehouseId: dto.warehouseId,
          binId: allocation.binId,
          lotId: allocation.lotId,
          quantity: allocation.quantity,
        });

        created.push({
          id: rows[0].id,
          ownerType: dto.ownerType,
          ownerId: dto.ownerId,
          skuId: dto.skuId,
          warehouseId: dto.warehouseId,
          binId: allocation.binId,
          lotId: allocation.lotId,
          quantity: allocation.quantity,
          status: 'ACTIVE',
        });
      }
      return created;
    });

    // Событие публикуем после коммита: на in-memory шине откат транзакции
    // уже не отменит доставленное подписчикам сообщение.
    await this.events.publish(
      createEvent(
        FF_EVENTS.INVENTORY_RESERVED,
        {
          ownerType: dto.ownerType,
          ownerId: dto.ownerId,
          skuId: dto.skuId,
          warehouseId: dto.warehouseId,
          quantity: dto.quantity,
        },
        { actorUserId: actor.user.id, correlationId: actor.correlationId },
      ),
    );

    return {
      ownerType: dto.ownerType,
      ownerId: dto.ownerId,
      skuId: dto.skuId,
      warehouseId: dto.warehouseId,
      requested: dto.quantity,
      lines,
    };
  }

  /** Снимает все активные резервы владельца, возвращая количество в те же ячейки. */
  async release(dto: ReleaseInput, actor: ActorContext): Promise<{ released: number }> {
    const released = await this.dataSource.transaction<
      Array<{ skuId: string; warehouseId: string; quantity: number }>
    >(async (em) => {
      const rows: Array<{
        id: string;
        sku_id: string;
        warehouse_id: string;
        bin_id: string;
        lot_id: string | null;
        quantity: number;
      }> = await this.inventoryRepository.lockActiveReservations(em, dto.ownerType, dto.ownerId);

      if (rows.length === 0) {
        throw new NotFoundException(
          `Активных резервов для ${dto.ownerType}/${dto.ownerId} не найдено.`,
        );
      }

      for (const row of rows) {
        await this.applyMovement(
          em,
          {
            skuId: row.sku_id,
            warehouseId: row.warehouse_id,
            lotId: row.lot_id,
            from: { binId: row.bin_id, status: 'RESERVED' },
            to: { binId: row.bin_id, status: 'AVAILABLE' },
            quantity: row.quantity,
            reason: 'RELEASE',
            referenceType: dto.ownerType,
            referenceId: dto.ownerId,
            comment: dto.reason ?? null,
          },
          actor,
        );
        await this.inventoryRepository.markReservationReleased(em, row.id);
      }

      return rows.map((row) => ({
        skuId: row.sku_id,
        warehouseId: row.warehouse_id,
        quantity: row.quantity,
      }));
    });

    for (const item of released) {
      await this.events.publish(
        createEvent(
          FF_EVENTS.INVENTORY_RELEASED,
          {
            ownerType: dto.ownerType,
            ownerId: dto.ownerId,
            skuId: item.skuId,
            warehouseId: item.warehouseId,
            quantity: item.quantity,
            reason: dto.reason ?? 'manual',
          },
          { actorUserId: actor.user.id, correlationId: actor.correlationId },
        ),
      );
    }

    return { released: released.length };
  }

  // -------------------------------------------------------------------- чтение

  async summary(query: StockQueryInput, actor: ActorContext): Promise<StockSummaryDto[]> {
    // Область селлера из токена сильнее параметра: подставленный чужой
    // sellerId не должен показать чужой остаток.
    const scope = resolveSellerScope(actor.user);
    return this.loadSummaries({
      sellerId: scope ?? query.sellerId,
      skuId: query.skuId,
      warehouseId: query.warehouseId,
    });
  }

  /**
   * Свод остатка по SKU и складу с раскладкой по ячейкам.
   *
   * Группировка идёт сразу до ячейки, а суммы по статусам складываются из тех
   * же строк. Отдельный запрос за итогами разошёлся бы с раскладкой: между
   * двумя запросами товар успевает переехать.
   */
  private async loadSummaries(filter: {
    sellerId?: string | null;
    skuId?: string;
    warehouseId?: string;
  }): Promise<StockSummaryDto[]> {
    const rows: Array<{
      sku_id: string;
      sku_code: string;
      sku_name: string;
      warehouse_id: string;
      bin_id: string;
      bin_code: string;
      status: InventoryUnitStatus;
      total: string;
    }> = await this.inventoryRepository.findStockSummaries(this.dataSource, filter);

    const byKey = new Map<string, StockSummaryDto>();
    for (const row of rows) {
      const key = `${row.sku_id}:${row.warehouse_id}`;
      let summary = byKey.get(key);
      if (!summary) {
        summary = {
          skuId: row.sku_id,
          skuCode: row.sku_code,
          skuName: row.sku_name,
          warehouseId: row.warehouse_id,
          byStatus: {},
          available: 0,
          total: 0,
          bins: [],
        };
        byKey.set(key, summary);
      }
      const quantity = Number(row.total);
      // Именно сложение, а не присваивание: один и тот же статус теперь
      // приходит несколькими строками — по строке на ячейку.
      summary.byStatus[row.status] = (summary.byStatus[row.status] ?? 0) + quantity;
      summary.total += quantity;
      if (row.status === 'AVAILABLE') summary.available += quantity;
      summary.bins.push({
        binId: row.bin_id,
        binCode: row.bin_code,
        status: row.status,
        quantity,
      });
    }
    return [...byKey.values()];
  }

  async movements(query: MovementsQueryInput, actor: ActorContext): Promise<StockMovementDto[]> {
    const scope = resolveSellerScope(actor.user);

    const rows: Array<Record<string, unknown>> = await this.inventoryRepository.findMovements(
      this.dataSource,
      {
        sellerScope: scope,
        skuId: query.skuId,
        warehouseId: query.warehouseId,
        limit: query.limit ?? DEFAULT_MOVEMENTS_LIMIT,
      },
    );

    return rows.map((row) => ({
      id: String(row.id),
      occurredAt: new Date(row.occurred_at as string).toISOString(),
      skuId: row.sku_id as string,
      warehouseId: row.warehouse_id as string,
      lotId: (row.lot_id as string | null) ?? null,
      fromBinId: (row.from_bin_id as string | null) ?? null,
      fromStatus: (row.from_status as InventoryUnitStatus | null) ?? null,
      toBinId: (row.to_bin_id as string | null) ?? null,
      toStatus: (row.to_status as InventoryUnitStatus | null) ?? null,
      quantity: Number(row.quantity),
      reason: row.reason as MovementReason,
      referenceType: (row.reference_type as string | null) ?? null,
      referenceId: (row.reference_id as string | null) ?? null,
      comment: (row.comment as string | null) ?? null,
      actorUserId: (row.actor_user_id as string | null) ?? null,
    }));
  }

  // ------------------------------------------------------------------ внутреннее

  /**
   * Единственная точка, меняющая остаток. Сначала списывает источник под
   * блокировкой, потом пополняет цель, и только затем пишет строку журнала —
   * всё в одной транзакции, поэтому журнал и остаток не могут разойтись.
   *
   * Публичный, но требует ВНЕШНЕЙ транзакции: соседние модули (например,
   * приёмка) складывают несколько движений и свои записи в одну атомарную
   * операцию, поэтому транзакцию открывает вызывающий.
   */
  async applyMovement(
    em: EntityManager,
    input: MovementInput,
    actor: ActorContext,
  ): Promise<void> {
    if (!input.from && !input.to) {
      throw new BadRequestException('Движение должно иметь источник или цель.');
    }
    if (input.from && input.to && input.from.status !== input.to.status) {
      // Недопустимый переход статуса бросит InvalidTransitionError → 409.
      inventoryUnitFsm.assert(input.from.status, input.to.status);
    }

    if (input.from) {
      const current: Array<{ id: string; quantity: number }> =
        await this.inventoryRepository.lockStockSlice(em, {
          skuId: input.skuId,
          warehouseId: input.warehouseId,
          binId: input.from.binId,
          lotId: input.lotId,
          status: input.from.status,
        });

      const have = current[0]?.quantity ?? 0;
      if (have < input.quantity) {
        throw new ConflictException(
          `Недостаточно остатка в статусе ${input.from.status}: нужно ${input.quantity}, есть ${have}.`,
        );
      }
      await this.inventoryRepository.decreaseStockQuantity(em, current[0].id, input.quantity);
    }

    if (input.to) {
      await this.inventoryRepository.upsertStockQuantity(em, {
        skuId: input.skuId,
        warehouseId: input.warehouseId,
        binId: input.to.binId,
        lotId: input.lotId,
        status: input.to.status,
        quantity: input.quantity,
      });
    }

    await this.inventoryRepository.insertStockMovement(em, {
      skuId: input.skuId,
      warehouseId: input.warehouseId,
      lotId: input.lotId,
      fromBinId: input.from?.binId ?? null,
      fromStatus: input.from?.status ?? null,
      toBinId: input.to?.binId ?? null,
      toStatus: input.to?.status ?? null,
      quantity: input.quantity,
      reason: input.reason,
      referenceType: input.referenceType ?? null,
      referenceId: input.referenceId ?? null,
      comment: input.comment ?? null,
      actorUserId: actor.user.id,
      correlationId: actor.correlationId,
    });
  }

  /** Находит или заводит партию по правилам SKU. Требует внешней транзакции. */
  async resolveLot(
    em: EntityManager,
    sku: SkuEntity,
    lotCode: string | undefined,
    expiryDate: string | undefined,
  ): Promise<string | null> {
    const code = lotCode?.trim();

    if (!sku.isLotTracked) {
      if (code) {
        throw new BadRequestException(
          `У SKU «${sku.skuCode}» партионный учёт выключен — партию указывать нельзя.`,
        );
      }
      return null;
    }
    if (!code) {
      throw new BadRequestException(`SKU «${sku.skuCode}» с партионным учётом требует lotCode.`);
    }
    if (sku.isExpiryTracked && !expiryDate) {
      throw new BadRequestException(
        `SKU «${sku.skuCode}» с учётом срока годности требует expiryDate.`,
      );
    }

    const lots = em.getRepository(LotEntity);
    const existing = await lots
      .createQueryBuilder('lot')
      .where('lot.skuId = :skuId', { skuId: sku.id })
      .andWhere('lower(lot.lotCode) = :code', { code: code.toLowerCase() })
      .getOne();
    if (existing) return existing.id;

    const created = await lots.save(
      lots.create({
        skuId: sku.id,
        lotCode: code,
        expiryDate: expiryDate ?? null,
        receivedAt: new Date(),
      }),
    );
    return created.id;
  }

  private async loadSku(skuId: string): Promise<SkuEntity> {
    const sku = await this.dataSource.getRepository(SkuEntity).findOne({ where: { id: skuId } });
    if (!sku) throw new NotFoundException('SKU не найден.');
    if (!sku.isActive) throw new ConflictException(`SKU «${sku.skuCode}» деактивирован.`);
    return sku;
  }

  private async loadBin(binId: string, warehouseId: string): Promise<BinLocationEntity> {
    const bin = await this.dataSource
      .getRepository(BinLocationEntity)
      .findOne({ where: { id: binId } });
    if (!bin) throw new NotFoundException('Ячейка не найдена.');
    if (bin.warehouseId !== warehouseId) {
      throw new BadRequestException(`Ячейка «${bin.code}» принадлежит другому складу.`);
    }
    if (!bin.isActive) throw new ConflictException(`Ячейка «${bin.code}» деактивирована.`);

    const warehouse = await this.dataSource
      .getRepository(WarehouseEntity)
      .findOne({ where: { id: warehouseId } });
    if (!warehouse) throw new NotFoundException('Склад не найден.');
    return bin;
  }

  private async summaryFor(skuId: string, warehouseId: string): Promise<StockSummaryDto> {
    const [summary] = await this.loadSummaries({ skuId, warehouseId });
    if (summary) return summary;

    // Остатка не осталось вовсе (всё уехало или списано). Ответ на движение
    // обязан сохранить форму, поэтому отдаём нули, а не пустоту.
    const sku = await this.dataSource.getRepository(SkuEntity).findOne({ where: { id: skuId } });
    return {
      skuId,
      skuCode: sku?.skuCode ?? '',
      skuName: sku?.name ?? '',
      warehouseId,
      byStatus: {},
      available: 0,
      total: 0,
      bins: [],
    };
  }
}
