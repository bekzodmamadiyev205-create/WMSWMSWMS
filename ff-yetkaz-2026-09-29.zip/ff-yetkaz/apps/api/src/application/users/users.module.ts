import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from '../auth/auth.module';
import { SellerEntity, UserEntity, UserRoleEntity } from '../../infrastructure/database/entities';
import { IdentityRepository } from '../../infrastructure/database/repositories/identity.repository';
import { UsersController } from '../../presentation/http/users.controller';
import { UsersService } from './users.service';

@Module({
  imports: [
    // PasswordService живёт в AuthModule — хэш обязан считаться одинаково
    // и на логине, и при выдаче доступа.
    AuthModule,
    TypeOrmModule.forFeature([UserEntity, UserRoleEntity, SellerEntity]),
  ],
  controllers: [UsersController],
  providers: [UsersService, IdentityRepository],
})
export class UsersModule {}
