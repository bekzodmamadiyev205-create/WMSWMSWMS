import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import { passwordProblem, SELLER_ROLE, type Role, type UserSummaryDto } from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import type { ActorContext } from '../../domain/types/actor';
import { DepartmentEntity, SellerEntity, UserEntity, UserRoleEntity } from '../../infrastructure/database/entities';
import { PasswordService } from '../../infrastructure/auth/password.service';
import { IdentityRepository } from '../../infrastructure/database/repositories/identity.repository';

/**
 * Управление пользователями. Доступно только ADMIN (гвард на контроллере).
 *
 * Удаления нет намеренно: на пользователя ссылается аудит и журнал движений,
 * а «кто принимал эту поставку» должно отвечаться и через год. Увольнение —
 * это isActive = false: вход закрыт, история цела.
 */
@Injectable()
export class UsersService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly passwords: PasswordService,
    private readonly audit: AuditService,
    private readonly identity: IdentityRepository,
  ) {}

  async list(): Promise<UserSummaryDto[]> {
    const users = await this.dataSource.getRepository(UserEntity).find({
      relations: { userRoles: true, department: true },
      order: { createdAt: 'ASC' },
    });
    return users.map((user) => this.toDto(user));
  }

  async create(
    input: {
      email: string;
      fullName: string;
      password: string;
      roles: Role[];
      sellerId?: string;
      departmentId?: string | null;
    },
    actor: ActorContext,
  ): Promise<UserSummaryDto> {
    const email = input.email.trim().toLowerCase();
    const roles = [...new Set(input.roles)];
    await this.assertSellerConsistent(roles, input.sellerId ?? null);
    await this.assertDepartmentAssignable(roles, input.departmentId ?? null);

    // Политика пароля — на сервере, а не только в DTO по длине: тривиальный,
    // но длинный пароль («123456789012») класс-валидатор пропустит.
    const problem = passwordProblem(input.password);
    if (problem) throw new BadRequestException(problem);

    const passwordHash = await this.passwords.hash(input.password);

    let created: UserEntity;
    try {
      created = await this.dataSource.transaction(async (em) => {
        const users = em.getRepository(UserEntity);
        const user = await users.save(
          users.create({
            email,
            passwordHash,
            fullName: input.fullName.trim(),
            isActive: true,
            sellerId: input.sellerId ?? null,
            departmentId: input.departmentId ?? null,
          }),
        );
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
        return user;
      });
    } catch (error) {
      if (uniqueViolationConstraint(error)) {
        throw new ConflictException(`Пользователь с email ${email} уже существует.`);
      }
      throw error;
    }

    await this.audit.record({
      action: 'CREATE',
      entityType: 'User',
      entityId: created.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: { email, roles, sellerId: input.sellerId ?? null, departmentId: input.departmentId ?? null },
    });

    // Перечитываем с отделом: имя подразделения приходит из связи, а не из вставки.
    return this.toDto(await this.load(created.id));
  }

  async update(
    id: string,
    input: { fullName?: string; isActive?: boolean; roles?: Role[]; departmentId?: string | null },
    actor: ActorContext,
  ): Promise<UserSummaryDto> {
    const user = await this.load(id);
    const before = this.toDto(user);

    // Последнего действующего администратора нельзя ни выключить, ни разжаловать:
    // это единственная роль, которая умеет чинить остальных.
    const losesAdmin =
      (input.isActive === false && this.rolesOf(user).includes('ADMIN')) ||
      (input.roles !== undefined &&
        this.rolesOf(user).includes('ADMIN') &&
        !input.roles.includes('ADMIN'));
    if (losesAdmin) await this.assertNotLastAdmin(user.id);

    const roles = input.roles ? [...new Set(input.roles)] : undefined;
    if (roles) await this.assertSellerConsistent(roles, user.sellerId);

    if (input.departmentId !== undefined) {
      await this.assertDepartmentAssignable(roles ?? this.rolesOf(user), input.departmentId);
    }

    await this.dataSource.transaction(async (em: EntityManager) => {
      const userRepo = em.getRepository(UserEntity);
      if (input.fullName !== undefined) user.fullName = input.fullName.trim();
      if (input.isActive !== undefined) user.isActive = input.isActive;
      await userRepo.save(user);

      // Отдел меняем отдельным апдейтом КОЛОНКИ, а не через сущность. У загруженного
      // `user` есть связь `department`, и `save()` берёт department_id из объекта
      // связи, затирая наше значение — что ломает и «снять» (null), и переназначение
      // на тот же/другой отдел. `update()` пишет FK напрямую и корректен для всех
      // переходов: null→отдел, отдел→другой, отдел→null.
      if (input.departmentId !== undefined) {
        await userRepo.update(user.id, { departmentId: input.departmentId });
      }

      if (roles) {
        await em.getRepository(UserRoleEntity).delete({ userId: user.id });
        for (const role of roles) {
          await em.getRepository(UserRoleEntity).insert({ userId: user.id, role });
        }
      }
    });

    const updated = await this.load(id);
    await this.audit.record({
      action: 'UPDATE',
      entityType: 'User',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before: { ...before },
      after: { ...this.toDto(updated) },
    });
    return this.toDto(updated);
  }

  /**
   * Смена пароля БЕЗ старого: это административный сброс для сотрудника,
   * который пароль забыл, а не смена own-пароля. Право уже проверено гвардом.
   */
  async setPassword(id: string, password: string, actor: ActorContext): Promise<void> {
    const problem = passwordProblem(password);
    if (problem) throw new BadRequestException(problem);

    const user = await this.load(id);
    user.passwordHash = await this.passwords.hash(password);
    await this.dataSource.getRepository(UserEntity).save(user);

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'User',
      entityId: id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      // В аудите только факт смены. Ни пароль, ни хэш в журнал не попадают.
      after: { passwordChanged: true },
    });
  }

  // ------------------------------------------------------------- внутреннее

  private async load(id: string): Promise<UserEntity> {
    const user = await this.dataSource.getRepository(UserEntity).findOne({
      where: { id },
      relations: { userRoles: true, department: true },
    });
    if (!user) throw new NotFoundException('Пользователь не найден.');
    return user;
  }

  private rolesOf(user: UserEntity): Role[] {
    return (user.userRoles ?? []).map((userRole) => userRole.role as Role);
  }

  /** SELLER обязан указывать на селлера, сотрудники оператора — наоборот. */
  private async assertSellerConsistent(roles: Role[], sellerId: string | null): Promise<void> {
    const isSeller = roles.includes(SELLER_ROLE);
    if (isSeller && roles.length > 1) {
      throw new BadRequestException(
        'Роль SELLER не совмещается с ролями сотрудников: у селлера изоляция по своим данным.',
      );
    }
    if (isSeller && !sellerId) {
      throw new BadRequestException('Для роли SELLER укажите селлера.');
    }
    if (!isSeller && sellerId) {
      throw new BadRequestException('Селлер указывается только для роли SELLER.');
    }
    if (sellerId) {
      const seller = await this.dataSource
        .getRepository(SellerEntity)
        .findOne({ where: { id: sellerId } });
      if (!seller) throw new NotFoundException('Селлер не найден.');
    }
  }

  /** Отдел — только для сотрудников и только действующий. Пусто/undefined — ок. */
  private async assertDepartmentAssignable(
    roles: Role[],
    departmentId: string | null | undefined,
  ): Promise<void> {
    if (!departmentId) return;
    if (roles.includes(SELLER_ROLE)) {
      throw new BadRequestException('Отдел назначается сотрудникам, а не селлеру.');
    }
    const department = await this.dataSource
      .getRepository(DepartmentEntity)
      .findOne({ where: { id: departmentId } });
    if (!department) throw new NotFoundException('Отдел не найден.');
    if (!department.isActive) {
      throw new BadRequestException('Отдел отключён — выберите действующий.');
    }
  }

  private async assertNotLastAdmin(userId: string): Promise<void> {
    const [{ others }]: Array<{ others: string }> = await this.identity.countOtherActiveAdmins(
      this.dataSource,
      userId,
    );
    if (others === '0') {
      throw new ForbiddenException(
        'Это последний действующий администратор — некому будет управлять системой.',
      );
    }
  }

  private toDto(user: UserEntity): UserSummaryDto {
    return {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      isActive: user.isActive,
      sellerId: user.sellerId,
      departmentId: user.departmentId ?? null,
      departmentName: user.department?.name ?? null,
      roles: this.rolesOf(user),
      createdAt: user.createdAt instanceof Date ? user.createdAt.toISOString() : String(user.createdAt),
    };
  }
}
