import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  IntegrationOutboxEntity,
  OrderEntity,
  ShipmentEntity,
  ShipmentStatusEventEntity,
  WebhookDeliveryEntity,
} from '../../infrastructure/database/entities';
import { OutboxRepository } from '../../infrastructure/database/repositories/outbox.repository';
import { WebhookRepository } from '../../infrastructure/database/repositories/webhook.repository';
import { InventoryModule } from '../inventory/inventory.module';
import { CarrierGateway } from '../../infrastructure/integrations';
import { CarrierWebhookService } from './carrier-webhook.service';
import { IntegrationController } from '../../presentation/http/integration.controller';
import { OutboxScheduler } from '../../presentation/schedulers/outbox.scheduler';
import { OutboxService } from '../../infrastructure/queues/outbox.service';

@Module({
  imports: [
    InventoryModule,
    TypeOrmModule.forFeature([
      IntegrationOutboxEntity,
      WebhookDeliveryEntity,
      ShipmentStatusEventEntity,
      ShipmentEntity,
      OrderEntity,
    ]),
  ],
  controllers: [IntegrationController],
  providers: [
    OutboxService,
    // Шлюз собирается там же, где очередь: она — его единственный потребитель,
    // а наружу класс не экспортируется намеренно. Доступ к внешнему API идёт
    // через application-слой, а не прямым внедрением шлюза в контроллер.
    CarrierGateway,
    CarrierWebhookService,
    OutboxScheduler,
    OutboxRepository,
    WebhookRepository,
  ],
  exports: [OutboxService],
})
export class IntegrationModule {}
