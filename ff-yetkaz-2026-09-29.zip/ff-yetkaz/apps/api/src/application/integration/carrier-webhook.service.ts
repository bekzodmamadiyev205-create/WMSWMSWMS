import {
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import {
  orderFsm,
  SETTING_KEYS,
  shipmentFsm,
  type CarrierWebhookPayload,
  type OrderStatus,
  type ShipmentStatus,
  type ShipmentStatusEventDto,
  type WebhookAckDto,
} from '@ff/shared';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import {
  WebhookRepository,
  type PackedOnHandRow,
} from '../../infrastructure/database/repositories/webhook.repository';
import { FsmService } from '../fsm/fsm.service';
import type { ActorContext } from '../../domain/types/actor';
import { CarriersService } from '../../infrastructure/config-store/carriers.service';
import { SettingsService } from '../../infrastructure/config-store/settings.service';
import { OrderEntity, ShipmentEntity } from '../../infrastructure/database/entities';
import { InventoryService } from '../inventory/inventory.service';
import { SignatureError, verifySignature } from '../../infrastructure/integrations/carrier/signature';

const OWNER_TYPE = 'ORDER';

/**
 * Что делает со статусом ЗАКАЗА тот или иной статус отправления.
 *
 * Таблицей, а не цепочкой `if`: правило «доставлено у перевозчика ⇒ доставлен
 * заказ» — предметное знание, и его должно быть видно одним взглядом.
 * Отсутствие записи означает «на заказ не влияет»: IN_TRANSIT и FAILED —
 * состояния доставки, а не заказа.
 */
const ORDER_EFFECT: Partial<
  Record<ShipmentStatus, { from: readonly OrderStatus[]; to: OrderStatus }>
> = {
  // Исходных статусов может быть несколько: склад мог отметить расход руками
  // (DISPATCHED) ДО того, как перевозчик прислал подтверждение приёмки. Не
  // принять от него HANDED_OVER в этом случае значит наказать за аккуратность —
  // заказ навсегда остался бы «выдан со склада», но не «отгружен».
  HANDED_OVER: { from: ['READY_TO_SHIP', 'DISPATCHED'], to: 'SHIPPED' },
  DELIVERED: { from: ['SHIPPED'], to: 'DELIVERED' },
  RETURNING: { from: ['SHIPPED'], to: 'RETURNED' },
};

/** Системный актор: вебхук приходит не от пользователя. */
function carrierActor(carrierCode: string, correlationId: string | null): ActorContext {
  return {
    user: {
      id: '00000000-0000-0000-0000-000000000000',
      email: `carrier:${carrierCode}`,
      roles: [],
      sellerId: null,
    },
    ip: null,
    correlationId,
  };
}

@Injectable()
export class CarrierWebhookService {
  private readonly logger = new Logger(CarrierWebhookService.name);

  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly carriers: CarriersService,
    private readonly settings: SettingsService,
    private readonly inventory: InventoryService,
    private readonly fsm: FsmService,
    private readonly webhookRepository: WebhookRepository,
  ) {}

  /**
   * Приём статуса от перевозчика.
   *
   * Порядок важен: сначала подпись (иначе мы обрабатываем чужой запрос), потом
   * запись доставки как мьютекс на уникальном индексе, и только затем переход.
   */
  async handle(input: {
    carrierCode: string;
    rawBody: Buffer;
    signature: string | undefined;
    deliveryId: string | undefined;
    correlationId: string | null;
  }): Promise<WebhookAckDto> {
    const secret = await this.carriers.secretFor(input.carrierCode);
    if (!secret) {
      throw new UnauthorizedException('Перевозчик не настроен.');
    }
    if (!input.deliveryId) {
      await this.record(input, 'REJECTED', 'Отсутствует X-FF-Delivery-Id.', null);
      throw new UnauthorizedException('Отсутствует идентификатор доставки.');
    }

    const tolerance = await this.settings.getNumber(SETTING_KEYS.WEBHOOK_TOLERANCE_SECONDS);
    try {
      verifySignature({
        secret,
        body: input.rawBody,
        header: input.signature,
        toleranceSeconds: tolerance,
      });
    } catch (error) {
      const reason = error instanceof SignatureError ? error.message : 'Ошибка проверки подписи.';
      await this.record(input, 'REJECTED', reason, null);
      // Наружу — общий отказ: подробности подсказали бы, как подбирать подпись.
      throw new UnauthorizedException('Подпись запроса не принята.');
    }

    let payload: CarrierWebhookPayload;
    try {
      payload = JSON.parse(input.rawBody.toString('utf8')) as CarrierWebhookPayload;
    } catch {
      await this.record(input, 'REJECTED', 'Тело запроса не является JSON.', null);
      throw new ConflictException('Тело запроса не является JSON.');
    }

    const shipment = await this.dataSource
      .getRepository(ShipmentEntity)
      .findOne({ where: { shipmentNo: payload.shipmentNo } });
    if (!shipment) {
      await this.record(input, 'REJECTED', `Отправление ${payload.shipmentNo} не найдено.`, null);
      throw new NotFoundException(`Отправление ${payload.shipmentNo} не найдено.`);
    }

    // Повтор уже применённого события: перевозчик обязан повторять доставку
    // при таймауте, и повтор не должен второй раз двигать статус.
    if (shipment.status === payload.status) {
      await this.record(input, 'DUPLICATE', 'Статус уже применён.', shipment.id);
      return { result: 'DUPLICATE', shipmentNo: shipment.shipmentNo, status: shipment.status };
    }

    try {
      await this.apply(shipment, payload, input);
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_webhook_delivery') {
        return { result: 'DUPLICATE', shipmentNo: shipment.shipmentNo, status: shipment.status };
      }
      const message = (error as Error).message;
      await this.record(input, 'REJECTED', message, shipment.id);
      throw error;
    }

    return { result: 'ACCEPTED', shipmentNo: shipment.shipmentNo, status: payload.status };
  }

  async history(shipmentId: string): Promise<ShipmentStatusEventDto[]> {
    const rows: Array<Record<string, unknown>> =
      await this.webhookRepository.listShipmentStatusEvents(this.dataSource, shipmentId);
    return rows.map((row) => ({
      id: String(row.id),
      shipmentId: row.shipment_id as string,
      fromStatus: (row.from_status as ShipmentStatus | null) ?? null,
      toStatus: row.to_status as ShipmentStatus,
      occurredAt: new Date(row.occurred_at as string).toISOString(),
      recordedAt: new Date(row.recorded_at as string).toISOString(),
      source: row.source as 'FF' | 'CARRIER',
      comment: (row.comment as string | null) ?? null,
    }));
  }

  // ------------------------------------------------------------ внутреннее

  /**
   * Применение статуса. Всё в одной транзакции вместе с записью доставки:
   * уникальный индекс по принятым доставкам работает мьютексом, поэтому два
   * одновременных повтора не могут применить переход дважды.
   */
  private async apply(
    shipment: ShipmentEntity,
    payload: CarrierWebhookPayload,
    input: { carrierCode: string; deliveryId?: string; correlationId: string | null },
  ): Promise<void> {
    const actor = carrierActor(input.carrierCode, input.correlationId);
    const occurredAt = new Date(payload.occurredAt);
    if (Number.isNaN(occurredAt.getTime())) {
      throw new ConflictException('Некорректное поле occurredAt.');
    }

    await this.dataSource.transaction(async (em) => {
      await this.webhookRepository.insertAcceptedDelivery(em, {
        carrierCode: input.carrierCode,
        deliveryId: input.deliveryId,
        payloadJson: JSON.stringify(payload),
        shipmentId: shipment.id,
      });

      // Таблица переходов — единственный арбитр: присланный не по порядку
      // статус получит 409, а не тихо перепишет состояние.
      await this.fsm.transition(
        shipmentFsm,
        shipment.status,
        payload.status,
        {
          entityType: 'Shipment',
          entityId: shipment.id,
          actorUserId: null,
          actorRole: `carrier:${input.carrierCode}`,
          correlationId: input.correlationId,
        },
        em,
      );

      const patch: Record<string, unknown> = { status: payload.status };
      if (payload.trackingNo) patch.trackingNo = payload.trackingNo;
      if (payload.reason) patch.failureReason = payload.reason;
      if (payload.status === 'HANDED_OVER') patch.handedOverAt = occurredAt;
      if (payload.status === 'DELIVERED') patch.deliveredAt = occurredAt;
      if (payload.pod) {
        patch.podRecipientName = payload.pod.recipientName ?? null;
        patch.podSignatureUrl = payload.pod.signatureUrl ?? null;
        patch.podPhotoUrl = payload.pod.photoUrl ?? null;
      }
      if (payload.cod) {
        patch.codCollectedAmount = payload.cod.collectedAmount;
        patch.codCollectedAt = new Date(payload.cod.collectedAt);
      }
      await em.getRepository(ShipmentEntity).update({ id: shipment.id }, patch);

      await this.webhookRepository.insertShipmentStatusEvent(em, {
        shipmentId: shipment.id,
        fromStatus: shipment.status,
        toStatus: payload.status,
        occurredAt: occurredAt.toISOString(),
        comment: payload.reason ?? null,
        rawJson: JSON.stringify(payload),
      });

      // Товар физически покидает склад именно при передаче перевозчику.
      if (payload.status === 'HANDED_OVER') {
        await this.shipOut(em, shipment, actor);
      }

      const effect = ORDER_EFFECT[payload.status];
      if (effect) {
        const order = await em.getRepository(OrderEntity).findOne({ where: { id: shipment.orderId } });
        if (order && effect.from.includes(order.status)) {
          await this.fsm.transition(
            orderFsm,
            order.status,
            effect.to,
            {
              entityType: 'Order',
              entityId: order.id,
              actorUserId: null,
              actorRole: `carrier:${input.carrierCode}`,
              correlationId: input.correlationId,
              comment: `Статус перевозчика: ${payload.status}`,
            },
            em,
          );
          // Автоматическая половина «расходного»: заказ, который склад не
          // отметил руками, получает время выдачи по факту передачи. COALESCE,
          // а не присваивание: если расход уже отмечен, время оформления
          // накладной важнее времени вебхука, и переписывать его нельзя.
          await em.getRepository(OrderEntity).update(
            { id: order.id },
            effect.to === 'SHIPPED'
              ? { status: effect.to, dispatchedAt: () => 'COALESCE(dispatched_at, now())' }
              : { status: effect.to },
          );
        } else if (order) {
          // Не бросаем: статус доставки применён, а заказ мог уйти вперёд по
          // другому пути. Расхождение важно увидеть, но не ценой отката.
          this.logger.warn(
            `Заказ ${order.id} в статусе ${order.status}: переход ${effect.from.join('|')} → ` +
              `${effect.to} пропущен.`,
          );
        }
      }
    });
  }

  /** PACKED → SHIPPED по фактическому местонахождению из журнала движений. */
  private async shipOut(
    em: EntityManager,
    shipment: ShipmentEntity,
    actor: ActorContext,
  ): Promise<void> {
    const rows: PackedOnHandRow[] = await this.webhookRepository.sumPackedOnHand(
      em,
      OWNER_TYPE,
      shipment.orderId,
    );

    for (const row of rows) {
      await this.inventory.applyMovement(
        em,
        {
          skuId: row.sku_id,
          warehouseId: row.warehouse_id,
          lotId: row.lot_id,
          from: { binId: row.bin_id, status: 'PACKED' },
          to: { binId: row.bin_id, status: 'SHIPPED' },
          quantity: Number(row.qty),
          reason: 'SHIP',
          referenceType: OWNER_TYPE,
          referenceId: shipment.orderId,
          comment: `Передано перевозчику, отправление ${shipment.shipmentNo}`,
        },
        actor,
      );
    }
  }

  /** Запись отвергнутой доставки — отдельным соединением, чтобы пережить откат. */
  private async record(
    input: { carrierCode: string; rawBody?: Buffer; deliveryId?: string },
    result: 'REJECTED' | 'DUPLICATE',
    error: string,
    shipmentId: string | null,
  ): Promise<void> {
    let payload: unknown = null;
    try {
      payload = input.rawBody ? JSON.parse(input.rawBody.toString('utf8')) : null;
    } catch {
      payload = { unparsed: input.rawBody?.toString('utf8').slice(0, 500) ?? null };
    }
    try {
      await this.webhookRepository.insertRejectedDelivery(this.dataSource, {
        carrierCode: input.carrierCode,
        deliveryId: input.deliveryId ?? 'unknown',
        payloadJson: JSON.stringify(payload),
        result,
        error: error.slice(0, 1000),
        shipmentId,
      });
    } catch (writeError) {
      this.logger.error(`Не удалось записать вебхук: ${(writeError as Error).message}`);
    }
  }
}
