import { Controller, Get, Module, Query } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import type { OpsDashboardDto, SellerDashboardDto } from '@ff/shared';
import { Actor, Roles } from '../../presentation/http/decorators';
import type { ActorContext } from '../../domain/types/actor';
import { SellerEntity } from '../../infrastructure/database/entities';
import { DashboardRepository } from '../../infrastructure/database/repositories/dashboard.repository';
import { DashboardService } from './dashboard.service';

@Controller('dashboard')
class DashboardController {
  constructor(private readonly dashboard: DashboardService) {}

  /** Операционная сводка склада: очереди, проблемы, сделанное за сегодня. */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'FINANCE')
  @Get('ops')
  ops(@Actor() actor: ActorContext): Promise<OpsDashboardDto> {
    return this.dashboard.ops(actor);
  }

  /**
   * Витрина селлера. Роль SELLER всегда видит только себя.
   *
   * Ролей раньше не было вовсе, то есть складской ТСД-логин (PICKER, PACKER,
   * RECEIVER) с любым sellerId в запросе получал финансовую сводку чужого клиента —
   * с суммами наложенного платежа, которые у тех же ролей специально скрыты
   * в заказах матрицей прав. Сборщику эта витрина не нужна ни при каких
   * обстоятельствах.
   */
  @Roles('ADMIN', 'WAREHOUSE_OPERATOR', 'FINANCE', 'SELLER')
  @Get('seller')
  seller(
    @Actor() actor: ActorContext,
    @Query('sellerId') sellerId?: string,
  ): Promise<SellerDashboardDto> {
    return this.dashboard.seller(actor, sellerId);
  }
}

@Module({
  imports: [TypeOrmModule.forFeature([SellerEntity])],
  controllers: [DashboardController],
  providers: [DashboardService, DashboardRepository],
})
export class DashboardModule {}
