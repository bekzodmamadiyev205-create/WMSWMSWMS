import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import {
  STAFF_ROLES,
  type MetricDto,
  type OpsDashboardDto,
  type SellerDashboardDto,
  type SellerShipmentRowDto,
  type SellerStockRowDto,
} from '@ff/shared';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { SellerEntity } from '../../infrastructure/database/entities';
import {
  DashboardRepository,
  PROBLEMS,
  QUEUES,
  TODAY,
  type MetricSpec,
} from '../../infrastructure/database/repositories/dashboard.repository';

@Injectable()
export class DashboardService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly repo: DashboardRepository,
  ) {}

  async ops(actor: ActorContext): Promise<OpsDashboardDto> {
    resolveSellerScope(actor.user);
    if (!actor.user.roles.some((role) => STAFF_ROLES.includes(role))) {
      throw new ForbiddenException('Сводка склада доступна только сотрудникам оператора.');
    }

    const [queues, problems, today, ordersByStatus] = await Promise.all([
      this.metrics(QUEUES),
      this.metrics(PROBLEMS),
      this.metrics(TODAY),
      this.ordersByStatus(null),
    ]);

    return { generatedAt: new Date().toISOString(), queues, problems, today, ordersByStatus };
  }

  /**
   * Витрина селлера. Селлер видит только себя — область берётся из токена, а
   * не из параметра запроса: параметру верить нельзя.
   */
  async seller(actor: ActorContext, requestedSellerId?: string): Promise<SellerDashboardDto> {
    const scope = resolveSellerScope(actor.user);
    const sellerId = scope ?? requestedSellerId;
    if (!sellerId) {
      throw new NotFoundException('Не указан селлер: оператору нужно передать sellerId.');
    }

    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');

    const [ordersByStatus, stock, recentShipments, openInvoices] = await Promise.all([
      this.ordersByStatus(sellerId),
      this.stock(sellerId),
      this.shipments(sellerId),
      this.invoices(sellerId),
    ]);

    return {
      sellerId,
      sellerName: seller.legalName,
      generatedAt: new Date().toISOString(),
      ordersByStatus,
      stock,
      recentShipments,
      openInvoices,
    };
  }

  // ------------------------------------------------------------ внутреннее

  private async metrics(specs: MetricSpec[]): Promise<MetricDto[]> {
    const rows = await this.repo.countMetrics(this.dataSource, specs);

    return specs.map((spec, index) => {
      const value = Number(rows.find((row) => Number(row.idx) === index)?.value ?? 0);
      return {
        key: spec.key,
        title: spec.title,
        value,
        attention: Boolean(spec.attentionWhenPositive) && value > 0,
      };
    });
  }

  private async ordersByStatus(sellerId: string | null): Promise<Array<{ status: string; count: number }>> {
    const rows = await this.repo.countOrdersByStatus(this.dataSource, sellerId);
    return rows.map((row) => ({ status: row.status, count: Number(row.count) }));
  }

  private async stock(sellerId: string): Promise<SellerStockRowDto[]> {
    const rows = await this.repo.loadSellerStock(this.dataSource, sellerId);

    return rows.map((row) => ({
      skuId: row.id as string,
      skuCode: row.sku_code as string,
      name: row.name as string,
      available: Number(row.available),
      reserved: Number(row.reserved),
      inProgress: Number(row.in_progress),
      quarantine: Number(row.quarantine),
      damaged: Number(row.damaged),
    }));
  }

  private async shipments(sellerId: string): Promise<SellerShipmentRowDto[]> {
    const rows = await this.repo.loadRecentShipments(this.dataSource, sellerId);

    return rows.map((row) => ({
      shipmentNo: row.shipment_no as string,
      orderExternalId: row.external_id as string,
      status: row.status as string,
      trackingNo: (row.tracking_no as string | null) ?? null,
      handedOverAt: row.handed_over_at ? new Date(row.handed_over_at as string).toISOString() : null,
      deliveredAt: row.delivered_at ? new Date(row.delivered_at as string).toISOString() : null,
      codAmount: (row.cod_amount as string | null) ?? null,
      codCollectedAmount: (row.cod_collected_amount as string | null) ?? null,
    }));
  }

  private async invoices(sellerId: string): Promise<SellerDashboardDto['openInvoices']> {
    const rows = await this.repo.loadOpenInvoices(this.dataSource, sellerId);

    return rows.map((row) => ({
      id: row.id as string,
      number: row.number as string,
      periodStart: row.period_start as string,
      periodEnd: row.period_end as string,
      currency: row.currency as string,
      servicesTotal: row.services_total as string,
      payoutTotal: row.payout_total as string,
      status: row.status as string,
    }));
  }
}
