import {
  HttpException,
  HttpStatus,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import type { AuthUser, LoginRequest, LoginResponse, Role } from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { UserEntity } from '../../infrastructure/database/entities';
import { PasswordService } from '../../infrastructure/auth/password.service';
import { IdentityRepository } from '../../infrastructure/database/repositories/identity.repository';

export interface RequestMeta {
  ip?: string | null;
  correlationId?: string | null;
}

/** Сколько неудачных попыток подряд запирают учётку и на сколько минут. */
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_WINDOW_MINUTES = 15;

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(UserEntity) private readonly users: Repository<UserEntity>,
    private readonly passwords: PasswordService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly audit: AuditService,
    private readonly identity: IdentityRepository,
  ) {}

  async login(dto: LoginRequest, meta: RequestMeta): Promise<LoginResponse> {
    const email = dto.email.trim().toLowerCase();

    // Защита от перебора. Счёт неудач держит БД (audit_events), а не память
    // процесса, — на serverless инстансы разные, память общего состояния не даёт.
    await this.assertNotLockedOut(email);

    const user = await this.findByEmailWithSecret(email);

    const passwordOk = user
      ? user.isActive && (await this.passwords.verify(user.passwordHash, dto.password))
      : await this.passwords.verifyDummy(dto.password);

    if (!user || !passwordOk) {
      await this.audit.recordSafe({
        action: 'LOGIN_FAILED',
        entityType: 'User',
        entityId: user?.id ?? null,
        after: { email, reason: !user ? 'UNKNOWN_EMAIL' : user.isActive ? 'BAD_PASSWORD' : 'INACTIVE' },
        ip: meta.ip ?? null,
        correlationId: meta.correlationId ?? null,
      });
      // Один и тот же текст на все три причины — чтобы не подсказывать,
      // существует ли учётная запись.
      throw new UnauthorizedException('Неверный email или пароль.');
    }

    const roles = this.rolesOf(user);
    const ttlHours = this.config.get<number>('JWT_TTL_HOURS') ?? 12;
    const accessToken = await this.jwt.signAsync(
      { sub: user.id, email: user.email, roles, sellerId: user.sellerId },
      { expiresIn: `${ttlHours}h` },
    );

    await this.audit.record({
      action: 'LOGIN_SUCCESS',
      entityType: 'User',
      entityId: user.id,
      actorUserId: user.id,
      actorRole: roles.join(',') || null,
      // email в успехе — чтобы счётчик неудач обнулялся: блокировка считает
      // провалы только ПОСЛЕ последнего удачного входа этой же почты.
      after: { email },
      ip: meta.ip ?? null,
      correlationId: meta.correlationId ?? null,
    });

    return {
      accessToken,
      expiresAt: new Date(Date.now() + ttlHours * 3600 * 1000).toISOString(),
      user: this.toAuthUser(user, roles),
    };
  }

  async profile(userId: string): Promise<AuthUser> {
    const user = await this.users.findOne({ where: { id: userId }, relations: { userRoles: true } });
    if (!user || !user.isActive) {
      // Токен ещё жив, а учётная запись выключена или удалена.
      throw new NotFoundException('Пользователь не найден.');
    }
    return this.toAuthUser(user, this.rolesOf(user));
  }

  /**
   * Заперта ли учётка перебором. Считаем LOGIN_FAILED этой почты за окно, но
   * только после последнего LOGIN_SUCCESS: удачный вход обнуляет счётчик, а
   * стереть append-only аудит нельзя. Ответ намеренно общий (429) — не
   * подсказываем, существует ли учётная запись.
   */
  private async assertNotLockedOut(email: string): Promise<void> {
    const rows: Array<{ fails: string }> = await this.identity.countRecentFailedLogins(
      this.users.manager,
      email,
      LOCKOUT_WINDOW_MINUTES,
    );
    if (Number(rows[0]?.fails ?? 0) >= MAX_FAILED_ATTEMPTS) {
      throw new HttpException(
        `Слишком много неудачных попыток. Повторите через ${LOCKOUT_WINDOW_MINUTES} минут.`,
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }
  }

  private findByEmailWithSecret(email: string): Promise<UserEntity | null> {
    return this.users
      .createQueryBuilder('u')
      .addSelect('u.passwordHash')
      .leftJoinAndSelect('u.userRoles', 'ur')
      .where('lower(u.email) = :email', { email })
      .getOne();
  }

  private rolesOf(user: UserEntity): Role[] {
    return (user.userRoles ?? []).map((userRole) => userRole.role);
  }

  private toAuthUser(user: UserEntity, roles: Role[]): AuthUser {
    return {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      roles,
      sellerId: user.sellerId,
    };
  }
}
