import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity } from '../../infrastructure/database/entities';
import { IdentityRepository } from '../../infrastructure/database/repositories/identity.repository';
import { AuthController } from '../../presentation/http/auth.controller';
import { AuthService } from './auth.service';
import { PasswordService } from '../../infrastructure/auth/password.service';

@Module({
  imports: [TypeOrmModule.forFeature([UserEntity])],
  controllers: [AuthController],
  providers: [AuthService, PasswordService, IdentityRepository],
  exports: [AuthService, PasswordService],
})
export class AuthModule {}
