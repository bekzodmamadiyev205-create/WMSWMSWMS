import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import type { Response } from 'express';
import {
  RETURN_SORT_FIELDS,
  orderFsm,
  returnFsm,
  type BinKind,
  type CreateReturnPayload,
  type InventoryUnitStatus,
  type MovementReason,
  type MoveReturnPayload,
  type PageDto,
  type ReturnDto,
  type ReturnItemDto,
  type ReturnListQuery,
  type ReturnReason,
  type ReturnStatus,
  type ReturnStatusEventDto,
  type StoreReturnPayload,
} from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { XlsxService, type XlsxColumn } from '../../infrastructure/export/xlsx.service';
import { FsmService, type TransitionContext } from '../fsm/fsm.service';
import {
  SqlParams,
  dateRangeConditions,
  likePattern,
  pageEnvelope,
  resolvePage,
  resolveSort,
  whereClause,
} from '../../infrastructure/database/query/page';
import { isSellerVisible, resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { findBinByKind } from '../../infrastructure/database/repositories/bin-location.repository';
import {
  ReturnsRepository,
  type ItemRow,
  type ReturnRow,
} from '../../infrastructure/database/repositories/returns.repository';
import {
  BinLocationEntity,
  OrderEntity,
  ReturnEntity,
  ReturnItemEntity,
  ReturnStatusEventEntity,
  SellerEntity,
  SkuEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { InventoryService } from '../inventory/inventory.service';
import type { CancelReturnInput } from './returns.input';

/** Все движения возврата помечаются им — по нему возврат находится в журнале. */
const REFERENCE_TYPE = 'RETURN';

/**
 * Причина прихода. В enum'е БД `movement_reason` значение 'RETURN' уже есть
 * (миграция PlatformV2Enums), а в `MOVEMENT_REASONS` пакета `@ff/shared` его
 * ещё нет — пакет правится отдельно. Приведение держим ОДНОЙ строкой, чтобы
 * снять его было ровно одним удалением, а не поиском по файлу.
 */
const RETURN_RECEIPT_REASON = 'RETURN' as MovementReason;

const EXPORT_BATCH = 200;

/** Что возврат физически удерживает прямо сейчас — по журналу движений. */
interface Holding {
  skuId: string;
  lotId: string | null;
  binId: string;
  status: InventoryUnitStatus;
  quantity: number;
}

interface Slice {
  binId: string;
  lotId: string | null;
  quantity: number;
}

/** Строка выгрузки: возврат × позиция. */
interface ExportRow {
  returnNo: string;
  createdAt: Date | null;
  status: string;
  sellerName: string;
  warehouseCode: string;
  orderCode: string;
  reason: string;
  skuCode: string;
  skuName: string;
  quantity: number | null;
  condition: string;
  restocked: number | null;
}

const EXPORT_COLUMNS: Array<XlsxColumn<ExportRow>> = [
  { header: 'Номер возврата', key: 'returnNo', width: 18, value: (row) => row.returnNo },
  {
    header: 'Дата',
    key: 'createdAt',
    width: 18,
    value: (row) => row.createdAt,
    numFmt: 'dd.mm.yyyy hh:mm',
  },
  { header: 'Статус', key: 'status', width: 14, value: (row) => row.status },
  { header: 'Селлер', key: 'sellerName', width: 28, value: (row) => row.sellerName },
  { header: 'Склад', key: 'warehouseCode', width: 14, value: (row) => row.warehouseCode },
  { header: 'Заказ', key: 'orderCode', width: 18, value: (row) => row.orderCode },
  { header: 'Причина', key: 'reason', width: 20, value: (row) => row.reason },
  { header: 'Артикул', key: 'skuCode', width: 20, value: (row) => row.skuCode },
  { header: 'Товар', key: 'skuName', width: 34, value: (row) => row.skuName },
  { header: 'Принято', key: 'quantity', width: 12, value: (row) => row.quantity },
  { header: 'Состояние', key: 'condition', width: 14, value: (row) => row.condition },
  { header: 'Возвращено в остаток', key: 'restocked', width: 22, value: (row) => row.restocked },
];

/**
 * Возвраты (RMA) — обратная логистика.
 *
 * Документ самостоятельный, а не поле заказа: возврат бывает без заказа
 * (клиент вернул мимо нас, перепутанная посылка, брак партии), а сам заказ к
 * этому моменту уже закрыт.
 *
 * Остаток модуль не трогает напрямую ни в одной строке: любое перемещение
 * идёт через `InventoryService.applyMovement` с `referenceType = 'RETURN'`,
 * поэтому на вопрос «откуда на складе эти семь штук» журнал отвечает
 * возвратом, а не догадкой.
 */
@Injectable()
export class ReturnsService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly inventory: InventoryService,
    private readonly fsm: FsmService,
    private readonly audit: AuditService,
    private readonly xlsx: XlsxService,
    private readonly returns: ReturnsRepository,
  ) {}

  // ------------------------------------------------------------------ приём

  async create(dto: CreateReturnPayload, actor: ActorContext): Promise<ReturnDto> {
    const scope = resolveSellerScope(actor.user);
    if (!isSellerVisible(scope, dto.sellerId)) {
      throw new ForbiddenException('Оформить возврат можно только своему селлеру.');
    }

    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: dto.sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    if (!seller.isActive) throw new ConflictException('Селлер деактивирован.');

    const warehouse = await this.dataSource
      .getRepository(WarehouseEntity)
      .findOne({ where: { id: dto.warehouseId } });
    if (!warehouse) throw new NotFoundException('Склад не найден.');
    if (!warehouse.isActive) throw new ConflictException('Склад деактивирован.');

    const skuIds = dto.items.map((item) => item.skuId);
    if (new Set(skuIds).size !== skuIds.length) {
      // На (return_id, sku_id) стоит уникальный индекс: две строки на один
      // артикул означали бы, что «сколько вернулось» зависит от порядка ввода.
      throw new BadRequestException(
        'В возврате повторяется один и тот же SKU — сложите количество в одну строку.',
      );
    }
    const skus = await this.dataSource
      .getRepository(SkuEntity)
      .find({ where: skuIds.map((id) => ({ id })) });
    if (skus.length !== skuIds.length) throw new NotFoundException('Часть SKU не найдена.');
    for (const sku of skus) {
      // Чужой товар на балансе этого селлера потом не отмотать: остаток
      // количественный, и «чей он был» из него уже не восстановить.
      if (sku.sellerId !== dto.sellerId) {
        throw new BadRequestException(`SKU «${sku.skuCode}» принадлежит другому селлеру.`);
      }
    }

    const order = dto.orderId
      ? await this.dataSource.getRepository(OrderEntity).findOne({ where: { id: dto.orderId } })
      : null;
    if (dto.orderId && !order) throw new NotFoundException('Заказ не найден.');
    if (order && order.sellerId !== dto.sellerId) {
      throw new ForbiddenException('Заказ принадлежит другому селлеру.');
    }

    const receivingBin = await this.requireBin(dto.warehouseId, 'RECEIVING');
    const comment = dto.comment?.trim() || null;

    const result = await this.dataSource.transaction(async (em) => {
      const returns = em.getRepository(ReturnEntity);
      const created = await returns.save(
        returns.create({
          status: 'ACCEPTED',
          sellerId: dto.sellerId,
          warehouseId: dto.warehouseId,
          orderId: dto.orderId ?? null,
          reason: dto.reason,
          comment,
          createdBy: actor.user.id,
          completedAt: null,
        }),
      );

      const items = em.getRepository(ReturnItemEntity);
      for (const line of dto.items) {
        await items.insert({
          returnId: created.id,
          skuId: line.skuId,
          quantity: line.quantity,
          condition: line.condition ?? 'GOOD',
          restockedQuantity: 0,
          binId: null,
        });

        await this.inventory.applyMovement(
          em,
          {
            skuId: line.skuId,
            warehouseId: dto.warehouseId,
            // Партия у возврата неизвестна: коробка приезжает без маркировки.
            // Приходуем без неё — придуманный номер сделал бы FEFO уверенно
            // неверным, а пустая партия хотя бы честно молчит.
            lotId: null,
            to: { binId: receivingBin.id, status: 'RECEIVED' },
            quantity: line.quantity,
            reason: RETURN_RECEIPT_REASON,
            referenceType: REFERENCE_TYPE,
            referenceId: created.id,
            comment: dto.reason,
          },
          actor,
        );
      }

      // Первую запись трека пишем сами: перехода тут нет — документ рождается
      // сразу в ACCEPTED, а журнал, начинающийся с середины, не журнал.
      await em.getRepository(ReturnStatusEventEntity).insert({
        returnId: created.id,
        fromStatus: null,
        toStatus: 'ACCEPTED',
        actorUserId: actor.user.id,
        comment,
      });

      const orderMoved =
        order && dto.markOrderReturned !== false
          ? await this.markOrderReturned(em, order, actor)
          : false;

      return { id: created.id, orderMoved };
    });

    await this.audit.record({
      action: 'CREATE',
      entityType: 'Return',
      entityId: result.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: {
        sellerId: dto.sellerId,
        warehouseId: dto.warehouseId,
        orderId: dto.orderId ?? null,
        reason: dto.reason,
        items: dto.items.length,
        units: dto.items.reduce((sum, item) => sum + item.quantity, 0),
        orderMarkedReturned: result.orderMoved,
      },
    });

    return this.get(result.id, actor);
  }

  // -------------------------------------------------------------- раскладка

  /**
   * Инспекция и раскладка принятого: годное едет в ячейку хранения, брак — в
   * ячейку брака.
   *
   * Модель остатка не разрешает RECEIVED → AVAILABLE напрямую, поэтому годное
   * проходит через INSPECTED: в журнале обязано быть видно, что товар
   * осмотрели, а не просто «стал доступен».
   */
  async store(id: string, dto: StoreReturnPayload, actor: ActorContext): Promise<ReturnDto> {
    const rma = await this.loadForWrite(id, actor);
    if (rma.status === 'COMPLETED' || rma.status === 'CANCELLED') {
      throw new ConflictException(
        `Возврат ${rma.returnNo} закрыт (${rma.status}) — раскладывать нечего.`,
      );
    }

    // Проверки самой заявки — до транзакции: они не смотрят в состояние склада,
    // и держать под блокировкой разбор заведомо кривого тела незачем.
    const seen = new Set<string>();
    for (const line of dto.lines) {
      if (seen.has(line.itemId)) {
        throw new BadRequestException('Одна и та же позиция передана в раскладке дважды.');
      }
      seen.add(line.itemId);

      if (line.goodQuantity + line.damagedQuantity <= 0) {
        throw new BadRequestException('Пустая строка раскладки: укажите годное или брак.');
      }
    }

    const needDamaged = dto.lines.some((line) => line.damagedQuantity > 0);
    const damagedBin = needDamaged
      ? await findBinByKind(this.dataSource, rma.warehouseId, 'DAMAGED', false)
      : null;

    const storageBins = await this.resolveStorageBins(dto, rma.warehouseId);

    await this.dataSource.transaction(async (em) => {
      // Дальше всё состояние читается ТОЛЬКО под блокировкой документа: снимок,
      // взятый до транзакции, к этому моменту уже мог устареть на чужую
      // раскладку — см. `lockForWrite`.
      const locked = await this.lockForWrite(em, rma.id);
      if (locked.status === 'COMPLETED' || locked.status === 'CANCELLED') {
        throw new ConflictException(
          `Возврат ${locked.returnNo} закрыт (${locked.status}) — раскладывать нечего.`,
        );
      }

      const items = await em
        .getRepository(ReturnItemEntity)
        .find({ where: { returnId: locked.id } });
      const byId = new Map(items.map((item) => [item.id, item]));

      // Где товар лежит сейчас, знает журнал, а не «ячейка приёмки» по умолчанию:
      // после /move коробка стоит в другой зоне, и слепая раскладка из приёмки
      // упёрлась бы в нехватку остатка там, где физически всё на месте.
      const holdings = await this.holdings(locked.id, em);

      for (const line of dto.lines) {
        const item = byId.get(line.itemId);
        if (!item) throw new NotFoundException('Позиция возврата не найдена.');

        const total = line.goodQuantity + line.damagedQuantity;
        const budget = item.quantity - item.restockedQuantity;
        if (total > budget) {
          throw new BadRequestException(
            `По позиции принято ${item.quantity} ед., уже возвращено в остаток ` +
              `${item.restockedQuantity} — указать можно не больше ${budget}, указано ${total}.`,
          );
        }

        const available = holdings.filter(
          (holding) => holding.skuId === item.skuId && holding.status === 'RECEIVED',
        );
        const have = available.reduce((sum, holding) => sum + holding.quantity, 0);
        if (have < total) {
          throw new ConflictException(
            `По позиции нераспределённым числится ${have} ед., указано ${total}. ` +
              'Проверьте, не разложили ли её раньше.',
          );
        }

        const storageBin = storageBins.get(line.itemId) as BinLocationEntity;
        for (const slice of takeFrom(available, line.goodQuantity)) {
          await this.inventory.applyMovement(
            em,
            {
              skuId: item.skuId,
              warehouseId: rma.warehouseId,
              lotId: slice.lotId,
              from: { binId: slice.binId, status: 'RECEIVED' },
              to: { binId: slice.binId, status: 'INSPECTED' },
              quantity: slice.quantity,
              reason: 'INSPECTION',
              referenceType: REFERENCE_TYPE,
              referenceId: rma.id,
              comment: dto.comment ?? null,
            },
            actor,
          );
          await this.inventory.applyMovement(
            em,
            {
              skuId: item.skuId,
              warehouseId: rma.warehouseId,
              lotId: slice.lotId,
              from: { binId: slice.binId, status: 'INSPECTED' },
              to: { binId: storageBin.id, status: 'AVAILABLE' },
              quantity: slice.quantity,
              reason: 'PUTAWAY',
              referenceType: REFERENCE_TYPE,
              referenceId: rma.id,
              comment: dto.comment ?? null,
            },
            actor,
          );
        }

        for (const slice of takeFrom(available, line.damagedQuantity)) {
          // Ячейки брака может не быть — тогда брак остаётся там же, где стоял,
          // но уже в статусе DAMAGED, то есть вне доступного остатка.
          await this.inventory.applyMovement(
            em,
            {
              skuId: item.skuId,
              warehouseId: rma.warehouseId,
              lotId: slice.lotId,
              from: { binId: slice.binId, status: 'RECEIVED' },
              to: { binId: damagedBin?.id ?? slice.binId, status: 'DAMAGED' },
              quantity: slice.quantity,
              reason: 'DAMAGE',
              referenceType: REFERENCE_TYPE,
              referenceId: rma.id,
              comment: dto.comment ?? null,
            },
            actor,
          );
        }

        // Прибавление в SQL, а не запись посчитанного в приложении числа:
        // абсолютное значение из прочитанного снимка затирает то, что успел
        // записать параллельный вызов. Блокировка документа этот случай уже
        // закрывает, но относительная запись не зависит от того, удержит ли её
        // кто-нибудь в будущем.
        await this.returns.addRestocked(
          em,
          item.id,
          line.goodQuantity,
          line.goodQuantity > 0 ? storageBin.id : null,
        );
      }

      // Повторная (частичная) раскладка статус не двигает: IN_STORAGE →
      // IN_STORAGE в таблице переходов нет, и правильно — состояние то же.
      // Статус берём из захваченной строки: параллельная раскладка могла уже
      // перевести документ, и по устаревшему снимку в трек ушёл бы второй
      // такой же переход ACCEPTED → IN_STORAGE.
      if (locked.status !== 'IN_STORAGE') {
        await this.fsm.transition(
          returnFsm,
          locked.status,
          'IN_STORAGE',
          this.context('Return', locked.id, actor, undefined, dto.comment ?? null),
          em,
        );
        await em.getRepository(ReturnEntity).update({ id: locked.id }, { status: 'IN_STORAGE' });
      }
    });

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Return',
      entityId: rma.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: {
        stored: dto.lines.map((line) => ({
          itemId: line.itemId,
          good: line.goodQuantity,
          damaged: line.damagedQuantity,
        })),
        comment: dto.comment ?? null,
      },
    });

    return this.get(rma.id, actor);
  }

  // ------------------------------------------------------------ перемещение

  async move(id: string, dto: MoveReturnPayload, actor: ActorContext): Promise<ReturnDto> {
    const rma = await this.loadForWrite(id, actor);

    const bin = await this.dataSource
      .getRepository(BinLocationEntity)
      .findOne({ where: { id: dto.binId } });
    if (!bin) throw new NotFoundException('Ячейка не найдена.');
    if (bin.warehouseId !== rma.warehouseId) {
      throw new BadRequestException('Ячейка принадлежит другому складу.');
    }
    if (!bin.isActive) throw new ConflictException('Ячейка деактивирована.');

    let units = 0;
    await this.dataSource.transaction(async (em) => {
      const locked = await this.lockForWrite(em, rma.id);

      // Что переезжает — считает журнал возврата: приход минус то, что уже ушло.
      // Товар, разобранный заказами, из этого расчёта сам не выпадает, поэтому
      // такое перемещение честно упрётся в нехватку остатка, а не «переедет»
      // на бумаге.
      const held = await this.holdings(locked.id, em);
      const moving = held.filter((holding) => holding.binId !== bin.id);
      units = moving.reduce((sum, holding) => sum + holding.quantity, 0);

      // Повторный переезд статус не двигает: MOVING → MOVING в таблице
      // переходов нет намеренно (см. `states/returns.ts`) — короб возят по
      // складу сколько нужно, и каждый рейс не создаёт нового состояния.
      if (locked.status !== 'MOVING') {
        await this.fsm.transition(
          returnFsm,
          locked.status,
          'MOVING',
          this.context('Return', locked.id, actor, { binId: bin.id, units }, dto.comment ?? null),
          em,
        );
        await em.getRepository(ReturnEntity).update({ id: locked.id }, { status: 'MOVING' });
      }

      for (const holding of moving) {
        await this.inventory.applyMovement(
          em,
          {
            skuId: holding.skuId,
            warehouseId: rma.warehouseId,
            lotId: holding.lotId,
            // Статус не меняется: коробка переезжает, а не осматривается.
            from: { binId: holding.binId, status: holding.status },
            to: { binId: bin.id, status: holding.status },
            quantity: holding.quantity,
            reason: 'MOVE',
            referenceType: REFERENCE_TYPE,
            referenceId: locked.id,
            comment: dto.comment ?? null,
          },
          actor,
        );
      }

      // Ячейка в позициях едет следом за товаром. Иначе карточка возврата
      // показывает место, где груза уже нет, и кладовщик идёт не туда.
      // Обновляем по ВСЕМ удерживаемым артикулам, а не только по переехавшим:
      // у стоявших в целевой ячейке `bin_id` мог остаться от прошлого рейса.
      const skuIds = [...new Set(held.map((holding) => holding.skuId))];
      if (skuIds.length > 0) {
        await this.returns.setItemsBin(em, locked.id, bin.id, skuIds);
      }
    });

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Return',
      entityId: rma.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: { movedToBinId: bin.id, units, comment: dto.comment ?? null },
    });

    return this.get(rma.id, actor);
  }

  // ------------------------------------------------------------- завершение

  async complete(id: string, actor: ActorContext): Promise<ReturnDto> {
    const rma = await this.loadForWrite(id, actor);

    const completedAt = new Date();
    await this.dataSource.transaction(async (em) => {
      const locked = await this.lockForWrite(em, rma.id);

      // Что осталось неразложенным, знает журнал, а не `restocked_quantity`:
      // у позиции, разложенной на 1 из 10, он уже не ноль, и проверка «есть ли
      // позиции с нулём» такой возврат пропускает. Девять единиц при этом
      // остаются в приёмочной ячейке вне доступного остатка — и уже без
      // документа, который бы за них отвечал.
      const pending = (await this.holdings(locked.id, em)).filter(
        (holding) => holding.status === 'RECEIVED' || holding.status === 'INSPECTED',
      );
      if (pending.length > 0) {
        const bySku = new Map<string, number>();
        for (const holding of pending) {
          bySku.set(holding.skuId, (bySku.get(holding.skuId) ?? 0) + holding.quantity);
        }
        const codes = await this.skuCodes([...bySku.keys()], em);
        const listed = [...bySku.entries()]
          .map(([skuId, quantity]) => `${codes.get(skuId) ?? skuId} — ${quantity} ед.`)
          .sort((left, right) => left.localeCompare(right, 'ru'));
        throw new ConflictException(
          `Возврат нельзя завершить: не разложено ${listed.join('; ')}. ` +
            'Сначала выполните раскладку.',
        );
      }

      await this.fsm.transition(
        returnFsm,
        locked.status,
        'COMPLETED',
        this.context('Return', locked.id, actor, { completedAt: completedAt.toISOString() }),
        em,
      );
      // `completed_at` обязателен по CHECK таблицы — ставим той же командой.
      await em
        .getRepository(ReturnEntity)
        .update({ id: locked.id }, { status: 'COMPLETED', completedAt });
    });

    return this.get(rma.id, actor);
  }

  async cancel(id: string, dto: CancelReturnInput, actor: ActorContext): Promise<ReturnDto> {
    const rma = await this.loadForWrite(id, actor);
    const reason = dto.comment.trim();

    await this.dataSource.transaction(async (em) => {
      const locked = await this.lockForWrite(em, rma.id);

      const items = await em
        .getRepository(ReturnItemEntity)
        .find({ where: { returnId: locked.id } });
      const restocked = items.reduce((sum, item) => sum + item.restockedQuantity, 0);
      if (restocked > 0) {
        // Отмена — не «ctrl+z»: разложенный товар уже смешался с общим остатком
        // и мог уехать в заказ. Снятие с полки оформляется своим документом.
        // Считать это можно только под блокировкой: по снимку, взятому до
        // параллельной раскладки, здесь виден ноль — и отмена закрыла бы
        // возврат, товар которого уже лежит на полке.
        throw new ConflictException(
          `По возврату уже возвращено в остаток ${restocked} ед. — отмена невозможна. ` +
            'Обратная раскладка оформляется отдельным документом.',
        );
      }

      // Причина живёт в самом документе, а не только в аудите: тот, кто откроет
      // возврат, должен видеть, почему он закрыт, не имея доступа к журналу.
      const comment = locked.comment ? `${locked.comment}\nОтмена: ${reason}` : `Отмена: ${reason}`;

      await this.fsm.transition(
        returnFsm,
        locked.status,
        'CANCELLED',
        this.context('Return', locked.id, actor, undefined, reason),
        em,
      );
      await em
        .getRepository(ReturnEntity)
        .update({ id: locked.id }, { status: 'CANCELLED', comment });
    });

    // Остаток отмена НЕ трогает намеренно: принятая коробка физически стоит на
    // складе. Отдать её обратно или списать — решение оператора, и оно тоже
    // обязано быть движением с причиной, а не побочным эффектом отмены.
    return this.get(rma.id, actor);
  }

  // ----------------------------------------------------------------- чтение

  async list(query: ReturnListQuery, actor: ActorContext): Promise<PageDto<ReturnDto>> {
    const page = resolvePage(query);
    const sort = resolveSort(RETURN_SORT_FIELDS, 'createdAt', query.sort, query.direction);

    const filter = this.buildFilter(query, actor);
    const totals: Array<{ total: number | string }> = await this.returns.countByFilter(
      this.dataSource,
      filter.where,
      filter.params.values,
    );
    const total = Number(totals[0]?.total ?? 0);

    const limit = filter.params.bind(page.pageSize);
    const offset = filter.params.bind(page.offset);
    const rows: ReturnRow[] = await this.returns.findPage(
      this.dataSource,
      {
        where: filter.where,
        sortField: sort.field,
        direction: sort.direction,
        limit,
        offset,
      },
      filter.params.values,
    );

    const items = await this.itemsFor(rows.map((row) => row.id));
    return pageEnvelope(
      rows.map((row) => rowToDto(row, items.get(row.id) ?? [])),
      total,
      page,
    );
  }

  async get(id: string, actor: ActorContext): Promise<ReturnDto> {
    const scope = resolveSellerScope(actor.user);
    const rows: ReturnRow[] = await this.returns.findById(this.dataSource, id);
    const row = rows[0];
    // Чужой возврат — именно 404, а не 403: иначе перебором id можно узнать,
    // какие документы существуют у соседнего селлера.
    if (!row || !isSellerVisible(scope, row.seller_id)) {
      throw new NotFoundException('Возврат не найден.');
    }

    const items = await this.itemsFor([row.id]);
    const dto = rowToDto(row, items.get(row.id) ?? []);
    dto.events = await this.events(row.id);
    return dto;
  }

  async export(query: ReturnListQuery, actor: ActorContext, response: Response): Promise<void> {
    await this.xlsx.stream(response, {
      filename: `returns-${new Date().toISOString().slice(0, 10)}.xlsx`,
      sheetName: 'Возвраты',
      title: 'Возвраты (RMA)',
      notes: [`Выгружено: ${new Date().toISOString()}`, describeFilters(query)],
      columns: EXPORT_COLUMNS,
      rows: this.exportRows(query, actor),
    });
  }

  // ------------------------------------------------------------- внутреннее

  /**
   * Выгрузка идёт страницами: один SELECT на всё — это и память инстанса, и
   * долгий запрос. Фильтр пересобирается на каждую страницу, чтобы номера
   * параметров не считались руками.
   */
  private async *exportRows(
    query: ReturnListQuery,
    actor: ActorContext,
  ): AsyncIterable<ExportRow[]> {
    for (let offset = 0; ; offset += EXPORT_BATCH) {
      const filter = this.buildFilter(query, actor);
      const limit = filter.params.bind(EXPORT_BATCH);
      const skip = filter.params.bind(offset);
      const rows: ReturnRow[] = await this.returns.findExportPage(
        this.dataSource,
        { where: filter.where, limit, offset: skip },
        filter.params.values,
      );
      if (rows.length === 0) return;

      const items = await this.itemsFor(rows.map((row) => row.id));
      const batch: ExportRow[] = [];
      for (const row of rows) {
        const list = items.get(row.id) ?? [];
        if (list.length === 0) {
          // Возврат без позиций всё равно попадает в выгрузку: это вопрос к
          // оператору, а не повод спрятать документ из сверки.
          batch.push(exportRow(row, null));
          continue;
        }
        for (const item of list) batch.push(exportRow(row, item));
      }
      yield batch;

      if (rows.length < EXPORT_BATCH) return;
    }
  }

  private buildFilter(
    query: ReturnListQuery,
    actor: ActorContext,
  ): { where: string; params: SqlParams } {
    const scope = resolveSellerScope(actor.user);
    const params = new SqlParams();
    const conditions: string[] = [];

    // Область видимости берётся из токена: селлер с подставленным чужим
    // `?sellerId=` получает свои же данные, а не чужие и не 403.
    const sellerId = scope ?? query.sellerId;
    if (sellerId) conditions.push(`r.seller_id = ${params.bind(sellerId)}`);
    if (query.warehouseId) conditions.push(`r.warehouse_id = ${params.bind(query.warehouseId)}`);
    if (query.status) conditions.push(`r.status = ${params.bind(query.status)}::return_status`);
    if (query.reason) conditions.push(`r.reason = ${params.bind(query.reason)}`);
    conditions.push(...dateRangeConditions('r.created_at', params, query.dateFrom, query.dateTo));

    const search = query.search?.trim();
    if (search) {
      const pattern = params.bind(likePattern(search));
      conditions.push(
        `(r.return_no ILIKE ${pattern}
          OR o.order_code ILIKE ${pattern}
          OR o.external_id ILIKE ${pattern}
          OR EXISTS (
            SELECT 1 FROM return_items i JOIN skus k ON k.id = i.sku_id
             WHERE i.return_id = r.id AND (k.sku_code ILIKE ${pattern} OR k.name ILIKE ${pattern})
          ))`,
      );
    }

    return { where: whereClause(conditions), params };
  }

  /** Позиции всей страницы одним запросом — иначе N+1 на каждый возврат. */
  private async itemsFor(ids: string[]): Promise<Map<string, ReturnItemDto[]>> {
    const grouped = new Map<string, ReturnItemDto[]>();
    if (ids.length === 0) return grouped;

    const rows: ItemRow[] = await this.returns.findItems(this.dataSource, ids);

    for (const row of rows) {
      const list = grouped.get(row.return_id) ?? [];
      list.push({
        id: row.id,
        skuId: row.sku_id,
        skuCode: row.sku_code,
        skuName: row.sku_name,
        quantity: Number(row.quantity),
        condition: row.condition,
        restockedQuantity: Number(row.restocked_quantity),
        binCode: row.bin_code ?? null,
      });
      grouped.set(row.return_id, list);
    }
    return grouped;
  }

  private async events(returnId: string): Promise<ReturnStatusEventDto[]> {
    const rows = await this.returns.findStatusHistory(this.dataSource, returnId);

    return rows.map((row) => ({
      // bigint приходит строкой — number его молча округлил бы на большом журнале.
      id: String(row.id),
      fromStatus: (row.from_status as ReturnStatus | null) ?? null,
      toStatus: row.to_status as ReturnStatus,
      actorUserId: row.actor_user_id ?? null,
      actorName: row.actor_name ?? null,
      comment: row.comment ?? null,
      occurredAt: toIso(row.occurred_at),
    }));
  }

  /**
   * Что возврат удерживает = приход минус расход по ЕГО движениям. Именно так,
   * а не по `stock`: остаток количественный и не знает, чьи это единицы.
   *
   * `EntityManager` обязателен, а не опционален: этот расчёт всегда решает,
   * что записать, а посчитанный вне транзакции он к моменту записи уже не
   * описывает склад.
   */
  private async holdings(returnId: string, em: EntityManager): Promise<Holding[]> {
    const rows = await this.returns.holdingsByReference(em, REFERENCE_TYPE, returnId);

    return rows.map((row) => ({
      skuId: row.sku_id,
      lotId: row.lot_id,
      binId: row.bin_id,
      status: row.status,
      quantity: Number(row.qty),
    }));
  }

  /** Ячейка хранения на строку: переданная явно либо STORAGE склада. */
  private async resolveStorageBins(
    dto: StoreReturnPayload,
    warehouseId: string,
  ): Promise<Map<string, BinLocationEntity>> {
    const resolved = new Map<string, BinLocationEntity>();
    let fallback: BinLocationEntity | null = null;

    for (const line of dto.lines) {
      if (line.goodQuantity <= 0) continue;

      if (line.binId) {
        const bin = await this.dataSource
          .getRepository(BinLocationEntity)
          .findOne({ where: { id: line.binId } });
        if (!bin) throw new NotFoundException('Ячейка хранения не найдена.');
        if (bin.warehouseId !== warehouseId) {
          throw new BadRequestException('Ячейка принадлежит другому складу.');
        }
        if (!bin.isActive) throw new ConflictException('Ячейка деактивирована.');
        resolved.set(line.itemId, bin);
        continue;
      }

      fallback = fallback ?? (await this.requireBin(warehouseId, 'STORAGE'));
      resolved.set(line.itemId, fallback);
    }
    return resolved;
  }

  /**
   * Заказ переводится в RETURNED, только если это разрешает статусная модель.
   *
   * Если не разрешает (заказ ещё не отгружали или он уже в терминальном
   * состоянии) — возврат всё равно оформляется. Товар физически стоит на доке;
   * отказать в документе значит потерять его для системы, а расхождение по
   * статусу заказа видно и правится отдельно.
   */
  private async markOrderReturned(
    em: EntityManager,
    order: OrderEntity,
    actor: ActorContext,
  ): Promise<boolean> {
    if (!orderFsm.can(order.status, 'RETURNED')) return false;

    await this.fsm.transition(
      orderFsm,
      order.status,
      'RETURNED',
      this.context('Order', order.id, actor, { source: 'return' }),
      em,
    );
    await em.getRepository(OrderEntity).update({ id: order.id }, { status: 'RETURNED' });
    return true;
  }

  private async loadForWrite(id: string, actor: ActorContext): Promise<ReturnEntity> {
    const scope = resolveSellerScope(actor.user);
    const rma = await this.dataSource.getRepository(ReturnEntity).findOne({ where: { id } });
    if (!rma || !isSellerVisible(scope, rma.sellerId)) {
      throw new NotFoundException('Возврат не найден.');
    }
    return rma;
  }

  /**
   * Захватывает документ на запись (`SELECT … FOR UPDATE`) и отдаёт его
   * АКТУАЛЬНОЕ состояние.
   *
   * Точка сериализации всего модуля — сам возврат, а не остаток. Движения
   * защищены собственным `FOR UPDATE` по строкам `stock`, поэтому две
   * одновременные раскладки проходят обе и обе правы. А вот статус,
   * `restocked_quantity` и решение «можно ли отменить» считались по снимку,
   * прочитанному ДО транзакции: вторая раскладка записывала 0 поверх уже
   * разложенных двух, и после этого отмена видела ноль и закрывала возврат,
   * товар которого уже смешался с общим остатком.
   *
   * Скоуп селлера здесь не перепроверяется: он проверен в `loadForWrite`, а
   * владелец документа не меняется.
   */
  private async lockForWrite(em: EntityManager, id: string): Promise<ReturnEntity> {
    const rma = await em
      .getRepository(ReturnEntity)
      .findOne({ where: { id }, lock: { mode: 'pessimistic_write' } });
    if (!rma) throw new NotFoundException('Возврат не найден.');
    return rma;
  }

  private async requireBin(warehouseId: string, kind: BinKind): Promise<BinLocationEntity> {
    // required = true: без нужной ячейки промежуточному состоянию негде жить,
    // а сообщение назовёт, какой именно ячейки не хватает.
    return (await findBinByKind(this.dataSource, warehouseId, kind, true)) as BinLocationEntity;
  }

  /** Артикулы по идентификаторам — чтобы отказ называл товар, а не uuid. */
  private async skuCodes(ids: string[], em: EntityManager): Promise<Map<string, string>> {
    const codes = new Map<string, string>();
    if (ids.length === 0) return codes;

    const rows = await this.returns.findSkuCodes(em, ids);
    for (const row of rows) codes.set(row.id, row.sku_code);
    return codes;
  }

  private context(
    entityType: string,
    entityId: string,
    actor: ActorContext,
    extra?: Record<string, unknown>,
    comment?: string | null,
  ): TransitionContext {
    return {
      entityType,
      entityId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      // Комментарий уходит и в аудит, и в ТРЕК. Раньше он попадал только в
      // `extra`, то есть в аудит: на карточке возврата в `return_status_history`
      // стоял NULL — единственное объяснение отсутствовало ровно там, где его
      // ищут, а журнал аудита оператору недоступен.
      extra: comment === undefined ? extra : { ...extra, comment: comment ?? null },
      comment: comment ?? null,
    };
  }
}

/**
 * Отрезает `quantity` единиц от того, что возврат удерживает, уменьшая запас.
 * Массив мутируется намеренно: годное и брак берутся из ОДНОГО запаса, и
 * второй вызов обязан видеть, сколько взял первый.
 */
function takeFrom(available: Holding[], quantity: number): Slice[] {
  const slices: Slice[] = [];
  let remaining = quantity;

  for (const holding of available) {
    if (remaining <= 0) break;
    if (holding.quantity <= 0) continue;

    const take = Math.min(remaining, holding.quantity);
    slices.push({ binId: holding.binId, lotId: holding.lotId, quantity: take });
    holding.quantity -= take;
    remaining -= take;
  }
  return slices;
}

function rowToDto(row: ReturnRow, items: ReturnItemDto[]): ReturnDto {
  return {
    id: row.id,
    returnNo: row.return_no,
    status: row.status,
    sellerId: row.seller_id,
    sellerName: row.seller_name ?? null,
    warehouseId: row.warehouse_id,
    warehouseCode: row.warehouse_code ?? null,
    orderId: row.order_id ?? null,
    orderCode: row.order_code ?? null,
    orderExternalId: row.order_external_id ?? null,
    reason: row.reason as ReturnReason,
    comment: row.comment ?? null,
    items,
    totalQuantity: Number(row.total_quantity ?? 0),
    totalRestocked: Number(row.total_restocked ?? 0),
    createdBy: row.created_by ?? null,
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
    completedAt: row.completed_at ? toIso(row.completed_at) : null,
  };
}

function exportRow(row: ReturnRow, item: ReturnItemDto | null): ExportRow {
  return {
    returnNo: row.return_no,
    createdAt: row.created_at ? new Date(row.created_at) : null,
    status: row.status,
    sellerName: row.seller_name ?? '',
    warehouseCode: row.warehouse_code ?? '',
    orderCode: row.order_code ?? row.order_external_id ?? '',
    reason: row.reason,
    skuCode: item?.skuCode ?? '',
    skuName: item?.skuName ?? '',
    quantity: item ? item.quantity : null,
    condition: item?.condition ?? '',
    restocked: item ? item.restockedQuantity : null,
  };
}

function describeFilters(query: ReturnListQuery): string {
  const parts: string[] = [];
  if (query.status) parts.push(`статус: ${query.status}`);
  if (query.reason) parts.push(`причина: ${query.reason}`);
  if (query.sellerId) parts.push(`селлер: ${query.sellerId}`);
  if (query.warehouseId) parts.push(`склад: ${query.warehouseId}`);
  if (query.dateFrom) parts.push(`с ${query.dateFrom}`);
  if (query.dateTo) parts.push(`по ${query.dateTo}`);
  if (query.search) parts.push(`поиск: ${query.search}`);
  return parts.length ? `Фильтры — ${parts.join('; ')}` : 'Фильтры не заданы';
}

function toIso(value: Date | string): string {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}
