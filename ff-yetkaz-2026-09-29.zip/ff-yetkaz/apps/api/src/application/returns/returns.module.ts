import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExportModule } from '../../infrastructure/export/export.module';
import {
  BinLocationEntity,
  OrderEntity,
  ReturnEntity,
  ReturnItemEntity,
  ReturnStatusEventEntity,
  SellerEntity,
  SkuEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { ReturnsRepository } from '../../infrastructure/database/repositories/returns.repository';
import { InventoryModule } from '../inventory/inventory.module';
import { ReturnsController } from '../../presentation/http/returns.controller';
import { ReturnsService } from './returns.service';

@Module({
  imports: [
    // Остаток модуль правит только через InventoryService — своих UPDATE'ов
    // по `stock` здесь нет ни одного.
    InventoryModule,
    // ExportModule глобальный, но импортируем явно: возвраты не должны падать
    // на DI из-за того, что кто-то поменял состав корневого модуля.
    ExportModule,
    TypeOrmModule.forFeature([
      ReturnEntity,
      ReturnItemEntity,
      ReturnStatusEventEntity,
      OrderEntity,
      SellerEntity,
      WarehouseEntity,
      SkuEntity,
      BinLocationEntity,
    ]),
  ],
  controllers: [ReturnsController],
  providers: [ReturnsService, ReturnsRepository],
  exports: [ReturnsService],
})
export class ReturnsModule {}
