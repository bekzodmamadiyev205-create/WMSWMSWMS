import { Module } from '@nestjs/common';
import { AnalyticsController } from '../../presentation/http/analytics.controller';
import { AnalyticsRepository } from '../../infrastructure/database/repositories/analytics.repository';
import { AnalyticsService } from './analytics.service';

/**
 * Модуль читает только витрины `bi_*` и агрегаты, поэтому `TypeOrmModule.
 * forFeature` ему не нужен: сущностей тут нет, весь счёт идёт сырым SQL
 * `AnalyticsRepository` поверх общего `DataSource`. `XlsxService` приходит из
 * глобального `ExportModule`.
 */
@Module({
  controllers: [AnalyticsController],
  providers: [AnalyticsService, AnalyticsRepository],
})
export class AnalyticsModule {}
