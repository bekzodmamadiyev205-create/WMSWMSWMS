import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import type { Response } from 'express';
import { DataSource, type EntityManager } from 'typeorm';
import type {
  AnalyticsGranularity,
  AnalyticsMetricDto,
  AnalyticsOverviewDto,
  AnalyticsQuery,
  AnalyticsSeriesPointDto,
  BiViewDto,
  OrderStatus,
  SellerAnalyticsDto,
  SellerAnalyticsRowDto,
} from '@ff/shared';
import { XlsxService } from '../../infrastructure/export/xlsx.service';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import {
  AnalyticsRepository,
  GRANULARITY_SQL,
  METRICS,
  type OverviewFilters,
  type ResolvedWindow,
  type SellerRow,
} from '../../infrastructure/database/repositories/analytics.repository';

/**
 * BI-слой: каждое число здесь считает PostgreSQL и отдаёт готовым — сам SQL
 * живёт в `AnalyticsRepository`, здесь остаются область видимости, период и
 * сборка ответа.
 *
 * Сквозное правило слоя — деньги остаются строкой от `::text` в SQL до JSON.
 * Как только сумма побывала в `number`, дашборд начинает расходиться со
 * счетами на копейки, и объяснить это расхождение уже невозможно.
 */

const SERIES_KEYS = ['orders', 'delivered', 'returned', 'revenue'];

/**
 * Потолок числа точек графика. Без него `?dateFrom=2000-01-01&granularity=day`
 * заставляет базу построить девять тысяч интервалов и отдать их клиенту,
 * который всё равно нарисует их в 800 пикселей.
 */
const MAX_BUCKETS = 400;

const DAY_MS = 86_400_000;

@Injectable()
export class AnalyticsService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly xlsx: XlsxService,
    private readonly repo: AnalyticsRepository,
  ) {}

  /**
   * Отчётные запросы идут в ЧАСОВОМ ПОЯСЕ СКЛАДА, а не в UTC.
   *
   * Пояс задаётся один раз на транзакцию, а не расставляется по каждому
   * `date_trunc` и сравнению дат: половина выражений в поясе склада, а
   * половина в UTC — это сдвиг на пять часов ровно в тех местах, где его
   * никто не проверит. Здесь либо всё в одном поясе, либо ничего.
   *
   * Практическая цена ошибки: Ташкент это UTC+5, поэтому в UTC «сегодня»
   * начинается в 05:00 по местному времени — вся ночная смена попадала во
   * вчерашний отчёт, а отчёт «за сегодня», открытый в 02:00, показывал
   * позавчерашние цифры.
   *
   * Поэтому запрос выполняется ТЕМ ЖЕ `manager`, которым выставлен пояс:
   * возьми репозиторий соединение сам — и `SET LOCAL` остался бы в одной
   * транзакции, а счёт ушёл бы в другую, уже по UTC.
   */
  private async reportQuery<T>(run: (manager: EntityManager) => Promise<T>): Promise<T> {
    return this.dataSource.transaction(async (manager) => {
      await this.repo.setReportTimeZone(manager, REPORT_TIME_ZONE);
      return run(manager);
    });
  }

  // ============================================================== публичное

  async overview(query: AnalyticsQuery, actor: ActorContext): Promise<AnalyticsOverviewDto> {
    return this.buildOverview(query, actor);
  }

  /**
   * Витрина селлера. Отдельная ручка, а не роль на `overview`: селлеру нужен
   * доступ, но не право спрашивать про чужие данные — область берётся из
   * токена, и подставленный `?sellerId=` для него ничего не меняет.
   */
  async sellerSummary(query: AnalyticsQuery, actor: ActorContext): Promise<AnalyticsOverviewDto> {
    return this.buildOverview(query, actor);
  }

  async sellers(query: AnalyticsQuery, actor: ActorContext): Promise<SellerAnalyticsDto> {
    const { window, rows, totals } = await this.sellerRows(query, actor);
    return {
      generatedAt: new Date().toISOString(),
      dateFrom: window.from,
      dateTo: window.to,
      rows,
      totals,
    };
  }

  async exportSellers(
    query: AnalyticsQuery,
    actor: ActorContext,
    response: Response,
  ): Promise<void> {
    const { window, rows } = await this.sellerRows(query, actor);

    await this.xlsx.stream<SellerAnalyticsRowDto>(response, {
      filename: `analytics-sellers-${window.from}_${window.to}.xlsx`,
      sheetName: 'Селлеры',
      title: 'Аналитика по селлерам',
      notes: [
        `Период: ${window.from} — ${window.to} (обе границы включительно)`,
        `Выгружено: ${new Date().toISOString()}`,
        'Остаток — текущий, на момент выгрузки: к периоду он не относится.',
      ],
      // Строки одной пачкой: селлеров у оператора десятки, а не миллионы —
      // постраничная выгрузка здесь была бы механикой ради механики. Потоковый
      // писатель книги при этом сохранён, он и есть защита от большого отчёта.
      rows: [rows],
      columns: [
        { header: 'Код', key: 'sellerCode', width: 14, value: (row) => row.sellerCode },
        { header: 'Селлер', key: 'sellerName', width: 34, value: (row) => row.sellerName },
        { header: 'Заказов', key: 'orders', width: 12, value: (row) => row.orders },
        { header: 'Единиц', key: 'units', width: 12, value: (row) => row.units },
        { header: 'Доставлено', key: 'delivered', width: 14, value: (row) => row.delivered },
        { header: 'Отменено', key: 'cancelled', width: 12, value: (row) => row.cancelled },
        { header: 'Возвратов', key: 'returned', width: 12, value: (row) => row.returned },
        {
          header: 'Доля возвратов, %',
          key: 'returnRatePct',
          width: 18,
          numFmt: '0.0',
          value: (row) => Number(row.returnRatePct),
        },
        {
          // Единственное место, где деньги перестают быть строкой. В книге
          // Excel сумма ОБЯЗАНА быть числом: текстовый столбец не суммируется
          // и по нему нельзя построить сводную — ради этого выгрузку и делают.
          header: 'Оборот',
          key: 'revenue',
          width: 16,
          numFmt: '#,##0.00',
          value: (row) => Number(row.revenue),
        },
        {
          header: 'Собрано COD',
          key: 'codCollected',
          width: 16,
          numFmt: '#,##0.00',
          value: (row) => Number(row.codCollected),
        },
        { header: 'Валюта', key: 'currency', width: 10, value: (row) => row.currency },
        {
          header: 'Средний чек',
          key: 'averageOrderValue',
          width: 16,
          numFmt: '#,##0.00',
          value: (row) => Number(row.averageOrderValue),
        },
        { header: 'Остаток, шт', key: 'stockUnits', width: 14, value: (row) => row.stockUnits },
      ],
    });
  }

  /**
   * Каталог витрин для внешнего BI. Написан руками и намеренно: аналитику
   * нужен контракт с человеческими описаниями и оговорками, а не дамп схемы,
   * из которого не видно, что чем считается и где подвох.
   */
  biViews(): { views: BiViewDto[] } {
    return { views: BI_VIEWS };
  }

  // ============================================================== внутреннее

  private async buildOverview(
    query: AnalyticsQuery,
    actor: ActorContext,
  ): Promise<AnalyticsOverviewDto> {
    const filters = this.resolveFilters(query, actor);
    const window = resolveWindow(query);
    const previous = previousWindow(window);
    const granularity = resolveGranularity(query.granularity);
    assertBucketCount(window, granularity);

    const [metrics, ordersByStatus, ordersByCategory, series] = await Promise.all([
      this.metrics(window, previous, filters),
      this.ordersByStatus(window, filters),
      this.ordersByCategory(window, filters),
      this.series(window, filters, granularity),
    ]);

    return {
      generatedAt: new Date().toISOString(),
      dateFrom: window.from,
      dateTo: window.to,
      currency: metrics.currency,
      metrics: metrics.metrics,
      ordersByStatus,
      ordersByCategory,
      series,
      seriesKeys: SERIES_KEYS,
    };
  }

  /**
   * Область видимости. Для роли SELLER скоуп из токена ПЕРЕКРЫВАЕТ параметр
   * запроса, а не наоборот: порядок `query.sellerId ?? scope` открыл бы чужие
   * данные одной строкой в адресе.
   */
  private resolveFilters(query: AnalyticsQuery, actor: ActorContext): OverviewFilters {
    const scope = resolveSellerScope(actor.user);
    return {
      sellerId: scope ?? query.sellerId ?? null,
      warehouseId: query.warehouseId ?? null,
      categoryId: query.categoryId ?? null,
    };
  }

  private async metrics(
    window: ResolvedWindow,
    previous: ResolvedWindow,
    filters: OverviewFilters,
  ): Promise<{ currency: string | null; metrics: AnalyticsMetricDto[] }> {
    const rows = await this.reportQuery((manager) =>
      this.repo.loadMetrics(manager, window, previous, filters),
    );

    const byKey = new Map(rows.map((row) => [row.key, row]));
    const currency = rows[0]?.currency ?? null;

    return {
      currency,
      metrics: METRICS.map((spec) => {
        const row = byKey.get(spec.key);
        return {
          key: spec.key,
          value: row?.value ?? '0',
          previous: row?.previous ?? null,
          changePct: row?.change_pct ?? null,
          positiveIsGood: spec.positiveIsGood,
          format: spec.format,
          currency: spec.format === 'money' ? currency : null,
        };
      }),
    };
  }

  private async ordersByStatus(
    window: ResolvedWindow,
    filters: OverviewFilters,
  ): Promise<AnalyticsOverviewDto['ordersByStatus']> {
    const rows = await this.reportQuery((manager) =>
      this.repo.loadOrdersByStatus(manager, window, filters),
    );

    return rows.map((row) => ({ status: row.status as OrderStatus, count: Number(row.count) }));
  }

  private async ordersByCategory(
    window: ResolvedWindow,
    filters: OverviewFilters,
  ): Promise<AnalyticsOverviewDto['ordersByCategory']> {
    const rows = await this.reportQuery((manager) =>
      this.repo.loadOrdersByCategory(manager, window, filters),
    );

    return rows.map((row) => ({
      categoryId: row.category_id,
      name: row.name,
      color: row.color,
      count: Number(row.count),
    }));
  }

  /**
   * Временной ряд. Хребет строится `generate_series`, агрегаты навешиваются на
   * него слева: интервал без данных обязан присутствовать нулём. График,
   * пропускающий пустые дни, рисует прямую линию через простой склада — то
   * есть прячет ровно то, ради чего на него и смотрят.
   */
  private async series(
    window: ResolvedWindow,
    filters: OverviewFilters,
    granularity: AnalyticsGranularity,
  ): Promise<AnalyticsSeriesPointDto[]> {
    // Промежуток для валюты ряда берётся такой же, как у плиток (прошлое окно
    // плюс текущее), иначе подпись под графиком может разойтись с подписью
    // над ним.
    const rows = await this.reportQuery((manager) =>
      this.repo.loadSeries(manager, window, previousWindow(window), filters, granularity),
    );

    return rows.map((row) => ({
      bucket: row.bucket,
      values: {
        orders: row.orders,
        delivered: row.delivered,
        returned: row.returned,
        revenue: row.revenue,
      },
    }));
  }

  /**
   * Строки по селлерам плюс итог. Итог считается в SQL из тех же строк, а не
   * складывается на клиенте: два независимых способа получить одно число
   * гарантированно разойдутся, и спорить будут с тем, что на экране.
   */
  private async sellerRows(
    query: AnalyticsQuery,
    actor: ActorContext,
  ): Promise<{
    window: ResolvedWindow;
    rows: SellerAnalyticsRowDto[];
    totals: SellerAnalyticsDto['totals'];
  }> {
    const filters = this.resolveFilters(query, actor);
    const window = resolveWindow(query);

    const rows = await this.reportQuery((manager) =>
      this.repo.loadSellerRows(manager, window, filters),
    );

    const dataRows = rows.filter((row) => row.kind === 'row').map(toSellerRow);
    const totalRow = rows.find((row) => row.kind === 'total');

    return { window, rows: dataRows, totals: toTotals(totalRow) };
  }
}

function toSellerRow(row: SellerRow): SellerAnalyticsRowDto {
  return {
    sellerId: row.seller_id ?? '',
    sellerCode: row.seller_code ?? '',
    sellerName: row.seller_name ?? '',
    orders: Number(row.orders),
    delivered: Number(row.delivered),
    cancelled: Number(row.cancelled),
    returned: Number(row.returned),
    returnRatePct: row.return_rate_pct,
    units: Number(row.units),
    revenue: row.revenue,
    codCollected: row.cod_collected,
    currency: row.currency,
    averageOrderValue: row.average_order_value,
    stockUnits: Number(row.stock_units),
  };
}

/** Пустая база — тоже ответ: итог из нулей, а не отсутствующее поле. */
function toTotals(row: SellerRow | undefined): SellerAnalyticsDto['totals'] {
  const mapped: SellerAnalyticsRowDto | null = row ? toSellerRow(row) : null;
  return {
    orders: mapped?.orders ?? 0,
    delivered: mapped?.delivered ?? 0,
    cancelled: mapped?.cancelled ?? 0,
    returned: mapped?.returned ?? 0,
    returnRatePct: mapped?.returnRatePct ?? '0.0',
    units: mapped?.units ?? 0,
    revenue: mapped?.revenue ?? '0.00',
    codCollected: mapped?.codCollected ?? '0.00',
    currency: mapped?.currency ?? null,
    averageOrderValue: mapped?.averageOrderValue ?? '0.00',
    stockUnits: mapped?.stockUnits ?? 0,
  };
}

// ==================================================================== период

/**
 * Часовой пояс отчётности. Один оператор — один пояс; вынесен в переменную
 * окружения, чтобы не переписывать код при переезде склада.
 */
export const REPORT_TIME_ZONE = process.env.FF_REPORT_TIMEZONE ?? 'Asia/Tashkent';

// Неверный пояс должен убить старт, а не тихо сдвинуть все отчёты: тот же
// приём, что и с таймзоной склада при её вводе.
try {
  new Intl.DateTimeFormat('en-CA', { timeZone: REPORT_TIME_ZONE });
} catch {
  throw new Error(`FF_REPORT_TIMEZONE: неизвестный часовой пояс ${REPORT_TIME_ZONE}`);
}

/** Сегодня ПО МЕСТУ, а не по UTC. `en-CA` даёт ровно YYYY-MM-DD. */
function todayIso(): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: REPORT_TIME_ZONE }).format(new Date());
}

function shiftIso(iso: string, days: number): string {
  return new Date(Date.parse(`${iso}T00:00:00Z`) + days * DAY_MS).toISOString().slice(0, 10);
}

function daysInclusive(window: ResolvedWindow): number {
  const from = Date.parse(`${window.from}T00:00:00Z`);
  const to = Date.parse(`${window.to}T00:00:00Z`);
  return Math.round((to - from) / DAY_MS) + 1;
}

/** По умолчанию — последние 30 дней ВКЛЮЧАЯ сегодня. */
/**
 * Форма даты проверяется регуляркой в DTO, но `2026-13-01` ей удовлетворяет —
 * и разбивается уже о Postgres, отдавая 500 вместо внятного отказа.
 */
function assertCalendarDate(value: string, field: string): void {
  const [year, month, day] = value.split('-').map(Number);
  const parsed = new Date(Date.UTC(year, month - 1, day));
  if (
    parsed.getUTCFullYear() !== year ||
    parsed.getUTCMonth() !== month - 1 ||
    parsed.getUTCDate() !== day
  ) {
    throw new BadRequestException(`${field}: такой даты не существует — ${value}.`);
  }
}

function resolveWindow(query: AnalyticsQuery): ResolvedWindow {
  if (query.dateFrom) assertCalendarDate(query.dateFrom, 'dateFrom');
  if (query.dateTo) assertCalendarDate(query.dateTo, 'dateTo');
  const to = query.dateTo ?? todayIso();
  const from = query.dateFrom ?? shiftIso(to, -29);
  if (from > to) {
    throw new BadRequestException('Начало периода позже его конца.');
  }
  return { from, to };
}

/**
 * Предыдущее окно ТОЙ ЖЕ длины, вплотную к текущему. Сравнивать неделю с
 * месяцем бессмысленно, а сравнение с «прошлым календарным месяцем» врало бы
 * в феврале и в первых числах.
 */
function previousWindow(window: ResolvedWindow): ResolvedWindow {
  const length = daysInclusive(window);
  const to = shiftIso(window.from, -1);
  return { from: shiftIso(to, -(length - 1)), to };
}

function resolveGranularity(value: AnalyticsGranularity | undefined): AnalyticsGranularity {
  return value && value in GRANULARITY_SQL ? value : 'day';
}

function assertBucketCount(window: ResolvedWindow, granularity: AnalyticsGranularity): void {
  const days = daysInclusive(window);
  const perBucket = granularity === 'day' ? 1 : granularity === 'week' ? 7 : 28;
  if (Math.ceil(days / perBucket) > MAX_BUCKETS) {
    throw new BadRequestException(
      'Слишком длинный период для выбранной детализации. Выберите более крупный шаг (week или month) либо сузьте период.',
    );
  }
}

// =================================================================== витрины

/**
 * Каталог витрин BI. Держится в соответствии с миграцией `PlatformV2` вручную:
 * аналитику, подключающему Metabase, нужен контракт с оговорками («контейнер
 * сплита тут есть, отфильтруйте его сами»), а не список колонок, который он и
 * так увидит в схеме.
 */
const BI_VIEWS: BiViewDto[] = [
  {
    name: 'bi_orders',
    title: 'Заказы',
    description:
      'Плоская таблица заказов: селлер, склад, категория, отправление и число единиц уже соединены. ' +
      'ВНИМАНИЕ: заказы-контейнеры разделённых заказов тоже здесь (is_split = true) — исполняют их ' +
      'дочерние заказы, поэтому в любом подсчёте фильтруйте is_split = false, иначе заказ посчитается дважды.',
    columns: [
      { name: 'order_id', type: 'uuid', description: 'Идентификатор заказа' },
      {
        name: 'order_code',
        type: 'text',
        description: 'Наш код заказа (FF-YES0000001), он же штрихкод',
      },
      { name: 'external_id', type: 'text', description: 'Номер заказа у клиента, придуман не нами' },
      { name: 'channel', type: 'text', description: 'Канал поступления заказа' },
      { name: 'status', type: 'text', description: 'Текущий статус заказа' },
      { name: 'seller_id', type: 'uuid', description: 'Селлер — владелец товара' },
      { name: 'seller_code', type: 'text', description: 'Код селлера' },
      { name: 'seller_name', type: 'text', description: 'Юридическое наименование селлера' },
      {
        name: 'warehouse_id',
        type: 'uuid',
        description: 'Склад исполнения; у контейнера сплита пуст',
      },
      { name: 'warehouse_code', type: 'text', description: 'Код склада' },
      { name: 'category_id', type: 'uuid', description: 'Категория заказа; NULL — без категории' },
      { name: 'category_code', type: 'text', description: 'Код категории' },
      { name: 'category_name', type: 'text', description: 'Название категории' },
      {
        name: 'region',
        type: 'text',
        description: 'Регион доставки, свободный текст вида «Область, Район»',
      },
      { name: 'is_split', type: 'boolean', description: 'Заказ-контейнер разделённого заказа' },
      { name: 'has_shortage', type: 'boolean', description: 'Резерв закрыт не полностью' },
      { name: 'cod_amount', type: 'numeric(14,2)', description: 'Заявленный наложенный платёж' },
      { name: 'currency', type: 'text', description: 'Валюта наложенного платежа' },
      { name: 'weight_kg', type: 'numeric(10,3)', description: 'Заявленный вес отправления, кг' },
      { name: 'created_at', type: 'timestamptz', description: 'Момент создания заказа' },
      {
        name: 'dispatched_at',
        type: 'timestamptz',
        description: 'Момент выдачи со склада («расходный»)',
      },
      { name: 'handed_over_at', type: 'timestamptz', description: 'Момент передачи перевозчику' },
      {
        name: 'delivered_at',
        type: 'timestamptz',
        description: 'Момент доставки по данным перевозчика',
      },
      {
        name: 'cod_collected_amount',
        type: 'numeric(14,2)',
        description: 'Фактически собранный курьером платёж',
      },
      { name: 'tracking_no', type: 'text', description: 'Трек-номер перевозчика' },
      { name: 'units', type: 'int', description: 'Сумма количеств по позициям заказа' },
      { name: 'lines_count', type: 'int', description: 'Число позиций в заказе' },
    ],
  },
  {
    name: 'bi_order_status_history',
    title: 'Трек статусов заказа',
    description:
      'Журнал переходов заказа по статусам, только на добавление. Колонка seconds_in_previous_status ' +
      'посчитана оконной функцией — по ней строится воронка и время на каждом шаге без самостоятельных ' +
      'self-join. У самой первой записи заказа она пуста.',
    columns: [
      { name: 'id', type: 'bigint', description: 'Идентификатор записи журнала' },
      { name: 'order_id', type: 'uuid', description: 'Заказ' },
      { name: 'order_code', type: 'text', description: 'Наш код заказа' },
      { name: 'seller_id', type: 'uuid', description: 'Селлер заказа' },
      {
        name: 'from_status',
        type: 'text',
        description: 'Статус до перехода; NULL у первой записи',
      },
      { name: 'to_status', type: 'text', description: 'Статус после перехода' },
      { name: 'source', type: 'text', description: 'Кто инициировал: роль, system, backfill' },
      { name: 'occurred_at', type: 'timestamptz', description: 'Момент перехода' },
      {
        name: 'seconds_in_previous_status',
        type: 'bigint',
        description: 'Сколько секунд заказ провёл в предыдущем статусе',
      },
    ],
  },
  {
    name: 'bi_stock',
    title: 'Остатки',
    description:
      'Остаток на МОМЕНТ ЗАПРОСА, с раскладкой до ячейки и партии. Это срез, а не история: по нему ' +
      'нельзя посчитать, сколько товар пролежал — для хранения есть storage_snapshots. Нулевые строки ' +
      'отфильтрованы (quantity > 0).',
    columns: [
      { name: 'sku_id', type: 'uuid', description: 'Товар' },
      { name: 'sku_code', type: 'text', description: 'Артикул' },
      { name: 'sku_name', type: 'text', description: 'Наименование товара' },
      { name: 'seller_id', type: 'uuid', description: 'Селлер — владелец товара' },
      { name: 'seller_code', type: 'text', description: 'Код селлера' },
      { name: 'seller_name', type: 'text', description: 'Юридическое наименование селлера' },
      { name: 'warehouse_id', type: 'uuid', description: 'Склад' },
      { name: 'warehouse_code', type: 'text', description: 'Код склада' },
      { name: 'bin_code', type: 'text', description: 'Код ячейки хранения' },
      {
        name: 'bin_kind',
        type: 'text',
        description: 'Назначение ячейки: STORAGE, RECEIVING, PACKING, SHIPPING, DAMAGED',
      },
      { name: 'lot_id', type: 'uuid', description: 'Партия; NULL у товара без партионного учёта' },
      { name: 'lot_code', type: 'text', description: 'Код партии' },
      { name: 'expiry_date', type: 'date', description: 'Срок годности партии' },
      {
        name: 'status',
        type: 'text',
        description: 'Статус единиц: AVAILABLE, RESERVED, QUARANTINE, DAMAGED и т. д.',
      },
      { name: 'quantity', type: 'int', description: 'Количество единиц в строке' },
      { name: 'weight_g', type: 'int', description: 'Вес единицы товара, граммы' },
      {
        name: 'volume_mm3',
        type: 'bigint',
        description: 'Объём единицы товара в кубических миллиметрах, считает БД',
      },
      { name: 'units_per_box', type: 'int', description: 'Единиц в коробке' },
      { name: 'units_per_pallet', type: 'int', description: 'Единиц на паллете' },
      {
        name: 'updated_at',
        type: 'timestamptz',
        description: 'Когда строка остатка менялась последний раз',
      },
    ],
  },
  {
    name: 'bi_returns',
    title: 'Возвраты',
    description:
      'Возвраты с посчитанными итогами по позициям. total_restocked — сколько вернулось в доступный ' +
      'остаток, damaged_quantity — сколько принято как брак; с total_quantity они не совпадают ' +
      'намеренно, раскладка бывает частичной.',
    columns: [
      { name: 'return_id', type: 'uuid', description: 'Идентификатор возврата' },
      { name: 'return_no', type: 'text', description: 'Номер возврата (RMA000000001)' },
      { name: 'status', type: 'text', description: 'Статус возврата' },
      { name: 'seller_id', type: 'uuid', description: 'Селлер' },
      { name: 'seller_code', type: 'text', description: 'Код селлера' },
      { name: 'seller_name', type: 'text', description: 'Юридическое наименование селлера' },
      { name: 'warehouse_id', type: 'uuid', description: 'Склад приёма возврата' },
      { name: 'warehouse_code', type: 'text', description: 'Код склада' },
      { name: 'order_id', type: 'uuid', description: 'Заказ; возврат без заказа допустим' },
      { name: 'order_code', type: 'text', description: 'Наш код заказа' },
      { name: 'reason', type: 'text', description: 'Причина возврата' },
      { name: 'created_at', type: 'timestamptz', description: 'Момент приёма возврата' },
      { name: 'completed_at', type: 'timestamptz', description: 'Момент завершения обработки' },
      { name: 'total_quantity', type: 'int', description: 'Всего принято единиц' },
      { name: 'total_restocked', type: 'int', description: 'Из них возвращено в остаток' },
      { name: 'damaged_quantity', type: 'int', description: 'Из них принято как брак' },
    ],
  },
  {
    name: 'bi_seller_daily',
    title: 'Селлер по дням',
    description:
      'Витрина фактов «селлер × день»: заказы, возвраты, начисления и срезы хранения сведены в одну ' +
      'строку на день. Дней без событий здесь НЕТ намеренно — календарь добавляет своим измерением дат ' +
      'сам BI-инструмент. Заказы-контейнеры сплита уже исключены.',
    columns: [
      { name: 'seller_id', type: 'uuid', description: 'Селлер' },
      { name: 'seller_code', type: 'text', description: 'Код селлера' },
      { name: 'seller_name', type: 'text', description: 'Юридическое наименование селлера' },
      { name: 'day', type: 'date', description: 'День события' },
      { name: 'orders', type: 'int', description: 'Заказов создано за день' },
      { name: 'units', type: 'int', description: 'Единиц в этих заказах' },
      { name: 'delivered', type: 'int', description: 'Из них сейчас в статусе DELIVERED' },
      { name: 'cancelled', type: 'int', description: 'Из них сейчас в статусе CANCELLED' },
      { name: 'returns_count', type: 'int', description: 'Возвратов принято за день' },
      { name: 'returned_units', type: 'int', description: 'Единиц в этих возвратах' },
      {
        name: 'revenue',
        type: 'numeric(14,2)',
        description:
          'Начисления FF за день. ВНИМАНИЕ: суммируется без разбивки по валюте — если селлер работает ' +
          'в нескольких, разделяйте сами по таблице charges',
      },
      { name: 'stock_units', type: 'int', description: 'Единиц на хранении по срезу этого дня' },
      {
        name: 'stock_pallets',
        type: 'numeric(14,3)',
        description: 'Паллет на хранении по срезу дня',
      },
    ],
  },
];
