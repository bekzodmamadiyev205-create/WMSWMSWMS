import {
  BadRequestException,
  ConflictException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import type { Response } from 'express';
import {
  FF_EVENTS,
  ORDER_SORT_FIELDS,
  ORDER_STATUSES,
  orderFsm,
  type OrderDto,
  type OrderIntakeResultDto,
  type OrderLineDto,
  type OrderListQuery,
  type OrderListTotalsDto,
  type OrderShortageDto,
  type OrderSortField,
  type OrderStatus,
  type OrderStatusEventDto,
  type OrderTrackDto,
  type PageDto,
  type UpdateOrderPayload,
} from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import { uniqueViolationConstraint } from '../../infrastructure/database/unique-violation';
import { createEvent, EVENT_BUS, type EventBus } from '../../infrastructure/queues/events/event-bus';
import { XlsxService, type XlsxColumn } from '../../infrastructure/export/xlsx.service';
import { FieldAclService } from '../field-acl/field-acl.service';
import { submittedFields } from '../field-acl/submitted-fields';
import { FsmService } from '../fsm/fsm.service';
import { StatusHistoryService } from '../fsm/status-history.service';
import {
  dateRangeConditions,
  likePattern,
  pageEnvelope,
  resolvePage,
  resolveSort,
  SqlParams,
  whereClause,
} from '../../infrastructure/database/query/page';
import { isSellerVisible, resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import {
  OrderCategoryEntity,
  OrderEntity,
  OrderLineEntity,
  SellerEntity,
  SkuEntity,
} from '../../infrastructure/database/entities';
import {
  EFFECTIVE_STATUS,
  OrdersRepository,
  type OrderExportRow,
  type OrderRow,
} from '../../infrastructure/database/repositories/orders.repository';
import { InventoryService } from '../inventory/inventory.service';
import type { CancelOrderInput, CreateOrderInput } from './orders.input';
import { PutBackService } from './put-back.service';

const OWNER_TYPE = 'ORDER';

/** Заказ закрыт: его жизненный цикл дальше не двигается. */
const TERMINAL_STATUSES: readonly OrderStatus[] = ['DELIVERED', 'RETURNED', 'CANCELLED'];

/**
 * С этого момента карточка доставки в FF уже НЕ управляет доставкой.
 *
 * DISPATCHED — коробка выдана со склада по расходной накладной: на ней наклеена
 * этикетка с прежним получателем и адресом. SHIPPED — перевозчик подтвердил
 * приёмку, и у него в системе тоже прежние данные. Переписать их в FF значит
 * получить два разных адреса на один заказ, причём расхождение всплывёт только
 * на недоставке, когда чинить уже нечем.
 *
 * Терминальные статусы входят сюда же — доставка состоялась или отменена.
 * Категория при этом правится ВСЕГДА: переклассификация закрытого заказа нужна
 * отчётности и на физику отгрузки не влияет.
 */
const DELIVERY_LOCKED_STATUSES: readonly OrderStatus[] = [
  'DISPATCHED',
  'SHIPPED',
  ...TERMINAL_STATUSES,
];

/** Отказ обязан назвать ПРИЧИНУ: статус сам по себе оператору ничего не объясняет. */
function deliveryLockedMessage(orderCode: string, status: OrderStatus): string {
  if (status === 'DISPATCHED' || status === 'SHIPPED') {
    return (
      `Заказ ${orderCode} уже покинул склад (${status}): на коробке напечатана этикетка ` +
      `с прежним адресом, и у перевозчика записан прежний получатель — правка в FF их ` +
      `не изменит, а только разойдётся с фактом. Изменить можно только категорию.`
    );
  }
  return (
    `Заказ ${orderCode} закрыт (${status}): доставка уже состоялась или отменена, ` +
    `менять получателя и адрес задним числом не на что. Изменить можно только категорию.`
  );
}

/**
 * Колонки сортировки. Белый список из `@ff/shared` даёт ИМЕНА полей DTO, а этот
 * словарь — колонки схемы: подставлять пришедшую строку в текст SQL нельзя даже
 * после проверки по списку.
 */
const SORT_COLUMNS: Record<OrderSortField, string> = {
  createdAt: 'o.created_at',
  orderCode: 'o.order_code',
  externalId: 'o.external_id',
  // Сортируем по тому же статусу, который видно в списке, иначе строки
  // расставлены по одному значению, а показаны с другим.
  status: `(${EFFECTIVE_STATUS})`,
  recipientName: 'o.recipient_name',
  codAmount: 'o.cod_amount',
  weightKg: 'o.weight_kg',
  dispatchedAt: 'o.dispatched_at',
};

/** Страница выгрузки: компромисс между памятью и числом запросов. */
const EXPORT_BATCH = 500;

/**
 * Сколько номеров части перебрать, наткнувшись на занятый суффикс. Занят он
 * бывает только от гонки двух резервов одного заказа, поэтому запас невелик.
 */
const CHILD_SUFFIX_ATTEMPTS = 20;

/**
 * Колонка выгрузки, привязанная к ИМЕНИ ПОЛЯ `OrderDto`.
 *
 * Матрица прав оперирует именами полей, а не заголовками листа: сопоставлять
 * их по русскому заголовку значит потерять запрет при первом же переименовании
 * колонки — причём потерять молча, в файле, который никто не перечитывает.
 */
interface OrderExportColumn extends XlsxColumn<OrderExportRow> {
  field: keyof OrderDto;
}

const ORDER_EXPORT_COLUMNS: OrderExportColumn[] = [
  { header: 'Код FF', key: 'orderCode', field: 'orderCode', width: 16, value: (row) => row.order_code },
  {
    header: 'Номер клиента',
    key: 'externalId',
    field: 'externalId',
    width: 20,
    value: (row) => row.external_id,
  },
  { header: 'Канал', key: 'channel', field: 'channel', width: 14, value: (row) => row.channel },
  {
    header: 'Категория',
    key: 'category',
    field: 'categoryName',
    width: 16,
    value: (row) => row.category_name,
  },
  { header: 'Статус', key: 'status', field: 'status', width: 15, value: (row) => row.status },
  // Закрыт идентификатор селлера — закрыто и его название: скрыть одно, оставив
  // другое, значит не скрыть селлера.
  { header: 'Селлер', key: 'seller', field: 'sellerId', width: 24, value: (row) => row.seller_name },
  {
    header: 'Склад',
    key: 'warehouse',
    field: 'warehouseId',
    width: 12,
    value: (row) => row.warehouse_code,
  },
  {
    header: 'Получатель',
    key: 'recipient',
    field: 'recipientName',
    width: 24,
    value: (row) => row.recipient_name,
  },
  {
    header: 'Телефон',
    key: 'phone',
    field: 'recipientPhone',
    width: 16,
    value: (row) => row.recipient_phone,
  },
  { header: 'Регион', key: 'region', field: 'region', width: 20, value: (row) => row.region },
  { header: 'Адрес', key: 'address', field: 'address', width: 40, value: (row) => row.address },
  // Числа — числами, даты — датами: по текстовой колонке оператор не построит
  // сводную, а ради сводной выгрузку и просили.
  {
    header: 'Позиции, шт',
    key: 'units',
    field: 'lines',
    width: 12,
    numFmt: '0',
    value: (row) => row.units,
  },
  {
    header: 'Вес, кг',
    key: 'weight',
    field: 'weightKg',
    width: 12,
    numFmt: '0.000',
    value: (row) => toNumber(row.weight_kg),
  },
  {
    header: 'COD',
    key: 'cod',
    field: 'codAmount',
    width: 14,
    numFmt: '#,##0.00',
    value: (row) => toNumber(row.cod_amount),
  },
  { header: 'Валюта', key: 'currency', field: 'currency', width: 10, value: (row) => row.currency },
  {
    header: 'Создан',
    key: 'createdAt',
    field: 'createdAt',
    width: 18,
    numFmt: 'dd.mm.yyyy hh:mm',
    value: (row) => toDate(row.created_at),
  },
  {
    header: 'Выдан со склада',
    key: 'dispatchedAt',
    field: 'dispatchedAt',
    width: 18,
    numFmt: 'dd.mm.yyyy hh:mm',
    value: (row) => toDate(row.dispatched_at),
  },
];

interface RequestedLine {
  skuId: string;
  quantity: number;
}

interface WarehouseGroup {
  warehouseId: string;
  lines: RequestedLine[];
}

interface Allocation {
  groups: WarehouseGroup[];
  uncovered: OrderShortageDto[];
}

/**
 * Итог попытки резерва.
 *
 * Сорвавшийся резерв (гонка за последними единицами) обязан ОСТАВИТЬ заказ в
 * очереди нехватки, поэтому пометка пишется в той же транзакции и коммитится,
 * а сама ошибка отдаётся вызывающему уже после коммита. Бросить её изнутри
 * значит откатить пометку вместе с ней — заказ выпал бы и из резерва, и из
 * очереди нехватки.
 */
interface ReserveOutcome {
  shortages: OrderShortageDto[];
  failure: unknown;
}

@Injectable()
export class OrdersService {
  private readonly logger = new Logger(OrdersService.name);

  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly inventory: InventoryService,
    private readonly fsm: FsmService,
    private readonly history: StatusHistoryService,
    private readonly putBack: PutBackService,
    private readonly audit: AuditService,
    private readonly xlsx: XlsxService,
    private readonly acl: FieldAclService,
    private readonly repo: OrdersRepository,
    @Inject(EVENT_BUS) private readonly events: EventBus,
  ) {}

  // ----------------------------------------------------------- приём заказа

  async intake(dto: CreateOrderInput, actor: ActorContext): Promise<OrderIntakeResultDto> {
    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: dto.sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    if (!seller.isActive) throw new ConflictException('Селлер деактивирован.');

    // Сравнение через «пусто», а не через `=== undefined`: JSON умеет прислать
    // `"currency": null`, и пара «сумма есть, валюта null» проскакивала проверку,
    // а падала уже на CHECK orders_cod_needs_currency — то есть 500 вместо
    // внятного отказа.
    if (isBlank(dto.codAmount) !== isBlank(dto.currency)) {
      throw new BadRequestException('codAmount и currency указываются вместе.');
    }

    if (dto.categoryId) await this.requireCategory(dto.categoryId);

    const skuIds = dto.lines.map((line) => line.skuId);
    if (new Set(skuIds).size !== skuIds.length) {
      throw new BadRequestException('В заказе повторяется один и тот же SKU.');
    }
    const skus = await this.dataSource
      .getRepository(SkuEntity)
      .find({ where: skuIds.map((id) => ({ id })) });
    if (skus.length !== skuIds.length) throw new NotFoundException('Часть SKU не найдена.');
    for (const sku of skus) {
      if (sku.sellerId !== dto.sellerId) {
        throw new BadRequestException(`SKU «${sku.skuCode}» принадлежит другому селлеру.`);
      }
      if (!sku.isActive) throw new ConflictException(`SKU «${sku.skuCode}» деактивирован.`);
    }

    // Естественный ключ канала: повторная выгрузка не создаёт второй заказ,
    // даже если Idempotency-Key уже протух.
    const existing = await this.findByChannelKey(dto.sellerId, dto.channel, dto.externalId);
    if (existing) {
      return { order: await this.buildOrderDto(existing.id), duplicate: true, shortages: [] };
    }

    let orderId: string;
    try {
      orderId = await this.dataSource.transaction(async (em) => {
        const orders = em.getRepository(OrderEntity);
        const order = await orders.save(
          orders.create({
            sellerId: dto.sellerId,
            channel: dto.channel.trim(),
            externalId: dto.externalId.trim(),
            status: 'NEW',
            warehouseId: null,
            parentOrderId: null,
            isSplit: false,
            hasShortage: false,
            recipientName: dto.recipientName.trim(),
            recipientPhone: dto.recipientPhone.trim(),
            address: dto.address.trim(),
            region: dto.region?.trim() ?? null,
            codAmount: dto.codAmount ?? null,
            currency: dto.currency?.trim().toUpperCase() ?? null,
            weightKg: dto.weightKg ?? null,
            categoryId: dto.categoryId ?? null,
            createdBy: actor.user.id,
          }),
        );
        for (const line of dto.lines) {
          await em
            .getRepository(OrderLineEntity)
            .insert({ orderId: order.id, skuId: line.skuId, quantity: line.quantity });
        }
        // Точка отсчёта трека — сам факт появления заказа. Перехода NULL → NEW
        // в машине нет, поэтому FsmService его не запишет; миграция такую строку
        // старым заказам проставила, и без неё трек старых и новых заказов
        // начинался бы по-разному.
        await this.history.record(
          orderFsm,
          order.id,
          null,
          'NEW',
          {
            actorUserId: actor.user.id,
            actorRole: actor.user.roles.join(','),
            comment: 'Заказ принят в систему',
          },
          em,
        );
        return order.id;
      });
    } catch (error) {
      if (uniqueViolationConstraint(error) === 'uq_orders_channel_external') {
        // Гонка двух одновременных выгрузок одного заказа.
        const raced = await this.findByChannelKey(dto.sellerId, dto.channel, dto.externalId);
        if (raced) {
          return { order: await this.buildOrderDto(raced.id), duplicate: true, shortages: [] };
        }
      }
      throw error;
    }

    await this.events.publish(
      createEvent(
        FF_EVENTS.ORDER_CREATED,
        { orderId, sellerId: dto.sellerId, externalId: dto.externalId },
        { actorUserId: actor.user.id, correlationId: actor.correlationId },
      ),
    );

    await this.transition(orderId, 'NEW', 'VALIDATED', actor);
    await this.events.publish(
      createEvent(
        FF_EVENTS.ORDER_VALIDATED,
        { orderId, sellerId: dto.sellerId },
        { actorUserId: actor.user.id, correlationId: actor.correlationId },
      ),
    );

    const shortages = await this.reserveOrder(orderId, actor);
    return { order: await this.buildOrderDto(orderId), duplicate: false, shortages };
  }

  /** Повторная попытка резерва после прихода товара. */
  async reserve(orderId: string, actor: ActorContext): Promise<OrderIntakeResultDto> {
    const shortages = await this.reserveOrder(orderId, actor);
    return { order: await this.buildOrderDto(orderId), duplicate: false, shortages };
  }

  /**
   * Единственный вход в резерв — и приём, и кнопка «повторить резерв».
   *
   * Строка заказа захватывается на всё время раскладки: без захвата два
   * одновременных `POST /orders/:id/reserve` (двойной клик) оба видят
   * VALIDATED и оба резервируют — `FOR UPDATE` внутри Inventory сериализует
   * движения, но зарезервировать дважды не мешает.
   */
  private async reserveOrder(orderId: string, actor: ActorContext): Promise<OrderShortageDto[]> {
    const outcome = await this.dataSource.transaction(async (em) => {
      const order = await this.lockOrder(em, orderId);
      if (order.status !== 'VALIDATED') {
        throw new ConflictException(
          `Резервировать можно заказ в статусе VALIDATED, текущий: ${order.status}.`,
        );
      }
      return this.allocateAndReserve(em, order, actor);
    });

    // Отказ резерва отдаём ПОСЛЕ коммита — см. `ReserveOutcome`.
    if (outcome.failure !== null) throw outcome.failure;
    return outcome.shortages;
  }

  // ------------------------------------------------ «расходный» (DISPATCHED)

  /**
   * Выдача коробки со склада: выписана расходная накладная, товар уехал.
   *
   * Отдельный шаг перед SHIPPED, потому что SHIPPED подтверждает ПЕРЕВОЗЧИК
   * вебхуком, а расход фиксирует склад. Статус и время выдачи меняются в одной
   * транзакции с переходом: «выдан, но без времени выдачи» — это дыра в отчёте
   * по расходу, а не мелочь оформления.
   */
  async dispatch(orderId: string, actor: ActorContext): Promise<OrderDto> {
    await this.dataSource.transaction(async (em) => {
      // Блокировка строки ДО проверки статуса: иначе два одновременных «выдать»
      // оба видят READY_TO_SHIP и оба идут дальше.
      const order = await em.getRepository(OrderEntity).findOne({
        where: { id: orderId },
        lock: { mode: 'pessimistic_write' },
      });
      if (!order) throw new NotFoundException('Заказ не найден.');
      if (order.isSplit) {
        throw new BadRequestException(
          'Разделённый заказ со склада не выдаётся: расход оформляется на его дочерние заказы.',
        );
      }

      await this.fsm.transition(
        orderFsm,
        order.status,
        'DISPATCHED',
        {
          entityType: 'Order',
          entityId: orderId,
          actorUserId: actor.user.id,
          actorRole: actor.user.roles.join(','),
          correlationId: actor.correlationId,
          source: 'warehouse',
          comment: 'Выдано со склада по расходной накладной',
        },
        em,
      );
      await em
        .getRepository(OrderEntity)
        .update({ id: orderId }, { status: 'DISPATCHED', dispatchedAt: () => 'now()' });
    });

    return this.buildOrderDto(orderId);
  }

  // ---------------------------------------------------------------- правка

  /**
   * Правка карточки заказа.
   *
   * Заказ, покинувший склад (выдан, передан перевозчику) или закрытый совсем,
   * правке доставочных полей НЕ подлежит — только категории: переклассифицировать
   * заказ для отчёта законно, а менять адрес у уехавшей коробки — нет.
   */
  async update(orderId: string, dto: UpdateOrderPayload, actor: ActorContext): Promise<OrderDto> {
    const order = await this.loadOrder(orderId);

    // Матрица прав на колонки закрывает не только показ, но и запись. Интерцептор
    // режет ОТВЕТ, а PATCH идёт мимо него — без этой проверки закрытое на
    // изменение поле спокойно писалось прямым запросом.
    await this.acl.assertEditable('order', submittedFields(dto), actor.user.roles);

    const touchesDelivery =
      dto.region !== undefined ||
      dto.recipientName !== undefined ||
      dto.recipientPhone !== undefined ||
      dto.address !== undefined ||
      dto.weightKg !== undefined;

    if (touchesDelivery && DELIVERY_LOCKED_STATUSES.includes(order.status)) {
      throw new ConflictException(deliveryLockedMessage(order.orderCode, order.status));
    }
    // У разделённого заказа собственный статус так и остаётся RESERVED (см.
    // EFFECTIVE_STATUS), уезжают части — поэтому проверка выше на него не
    // срабатывает. Пока хоть одна часть в работе, правка осмысленна; когда все
    // уехали, контейнер показал бы оператору новый адрес, а поехал бы старый.
    if (touchesDelivery && order.isSplit) {
      const parts = await this.dataSource
        .getRepository(OrderEntity)
        .find({ where: { parentOrderId: orderId } });
      const editable = parts.filter((part) => !DELIVERY_LOCKED_STATUSES.includes(part.status));
      if (parts.length > 0 && editable.length === 0) {
        throw new ConflictException(
          `Заказ ${order.orderCode} разделён между складами, и все его части уже покинули ` +
            `склад или закрыты: этикетки напечатаны с прежним адресом. ` +
            `Изменить можно только категорию.`,
        );
      }
    }
    if (dto.categoryId) await this.requireCategory(dto.categoryId);

    const patch: Partial<OrderEntity> = {};
    if (dto.categoryId !== undefined) patch.categoryId = dto.categoryId ?? null;
    if (dto.region !== undefined) patch.region = dto.region?.trim() || null;
    // `?.trim()` вместо `.trim()` — вторая линия обороны: `null` в обязательном
    // поле отбивает DTO (400), но падать TypeError'ом от чужой правки DTO эта
    // ветка не должна. Значение `undefined` в patch не попадает.
    const recipientName = dto.recipientName?.trim();
    if (recipientName !== undefined) patch.recipientName = recipientName;
    const recipientPhone = dto.recipientPhone?.trim();
    if (recipientPhone !== undefined) patch.recipientPhone = recipientPhone;
    const address = dto.address?.trim();
    if (address !== undefined) patch.address = address;
    if (dto.weightKg !== undefined) patch.weightKg = dto.weightKg ?? null;

    const fields = Object.keys(patch) as Array<keyof OrderEntity>;
    if (fields.length === 0) return this.buildOrderDto(orderId);

    const before: Record<string, unknown> = {};
    for (const field of fields) before[field] = order[field];

    await this.dataSource.transaction(async (em) => {
      await em.getRepository(OrderEntity).update({ id: orderId }, patch);

      // Части разделённого заказа — копии карточки доставки родителя, и уезжают
      // именно они. Не размножить правку значит отправить курьера по старому
      // адресу, притом что оператор видит на экране новый.
      if (order.isSplit) {
        const children = await em
          .getRepository(OrderEntity)
          .find({ where: { parentOrderId: orderId } });
        for (const child of children) {
          // Часть, которая уже уехала, пропускаем: её этикетка напечатана, и
          // переписать ей адрес — значит завести в базе данные, не совпадающие
          // ни с коробкой, ни с перевозчиком. Категория ниже доезжает до неё
          // в любом случае — она на отгрузку не влияет.
          const childPatch: Partial<OrderEntity> = DELIVERY_LOCKED_STATUSES.includes(child.status)
            ? {}
            : { ...patch };
          // Вес у части свой, фактический на упаковке — родительский не навязываем.
          delete childPatch.weightKg;
          if (dto.categoryId !== undefined) childPatch.categoryId = dto.categoryId ?? null;
          if (Object.keys(childPatch).length > 0) {
            await em.getRepository(OrderEntity).update({ id: child.id }, childPatch);
          }
        }
      }
    });

    const updated = await this.loadOrder(orderId);
    const after: Record<string, unknown> = {};
    for (const field of fields) after[field] = updated[field];

    await this.audit.record({
      action: 'UPDATE',
      entityType: 'Order',
      entityId: orderId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      before,
      after,
    });

    return this.buildOrderDto(orderId);
  }

  // ---------------------------------------------------------------- отмена

  /**
   * Отмена снимает резерв и возвращает товар в доступные остатки.
   * Дочерние заказы отменяются вместе с родительским.
   *
   * Отмена после сборки — не косметика: собранное и упакованное лежит в зонах
   * упаковки и отгрузки вне доступного остатка, и без явного возврата оно
   * зависло бы там навсегда. Проверка выполнимости идёт до первого перехода,
   * чтобы половина заказов не оказалась отменённой при отказе на второй части.
   */
  async cancel(orderId: string, dto: CancelOrderInput, actor: ActorContext): Promise<OrderDto> {
    const order = await this.loadOrder(orderId);

    const children = await this.dataSource
      .getRepository(OrderEntity)
      .find({ where: { parentOrderId: order.id } });

    const targets = [...children.filter((child) => child.status !== 'CANCELLED'), order];
    for (const target of targets) {
      this.assertNotDispatched(target);
      await this.putBack.assertCancellable(target.id);
    }

    for (const target of targets) {
      await this.cancelSingle(target, dto.reason ?? null, actor);
    }

    return this.buildOrderDto(orderId);
  }

  /**
   * Выданный со склада заказ отменить нельзя — ровно по той же причине, что и
   * переданный перевозчику: товара в здании уже нет. Таблица переходов
   * DISPATCHED → CANCELLED разрешает (заказ можно аннулировать документом), но
   * делается это через возврат, а не кнопкой «отменить».
   */
  private assertNotDispatched(order: OrderEntity): void {
    if (order.status === 'DISPATCHED') {
      throw new ConflictException(
        `Заказ ${order.orderCode} уже выдан со склада: отмена возможна только через возврат.`,
      );
    }
  }

  /**
   * Отмена одного заказа.
   *
   * Статус читается ПОД захватом строки и пишется условным апдейтом. Проверки
   * выше идут по данным, прочитанным без блокировки, и между ними и этим
   * моментом заказ успевает уехать: оператор A жмёт «выдать», оператор B —
   * «отменить», и без захвата B затирает DISPATCHED статусом CANCELLED, а
   * заодно возвращает на полку товар, которого в здании уже нет.
   */
  private async cancelSingle(
    order: OrderEntity,
    reason: string | null,
    actor: ActorContext,
  ): Promise<void> {
    const explanation = reason ?? 'Заказ отменён';

    const warehouseId = await this.dataSource.transaction(async (em) => {
      const locked = await this.lockOrder(em, order.id);
      this.assertNotDispatched(locked);
      await this.applyTransition(em, locked.id, locked.status, 'CANCELLED', actor, explanation);
      return locked.warehouseId;
    });

    await this.releaseQuietly(order.id, explanation, actor);
    await this.putBack.putBack(order.id, warehouseId, explanation, actor);
  }

  /** Снятие резерва там, где его может и не быть (заказ отменён до резерва). */
  private async releaseQuietly(
    orderId: string,
    reason: string,
    actor: ActorContext,
  ): Promise<void> {
    try {
      await this.inventory.release({ ownerType: OWNER_TYPE, ownerId: orderId, reason }, actor);
    } catch (error) {
      if (error instanceof NotFoundException) return;
      throw error;
    }
  }

  // --------------------------------------------------------------- чтение

  /**
   * Список заказов: фильтры, поиск, период, сортировка и страница — всё на
   * сервере. Раньше отдавались первые N строк, а поиск и период считал клиент:
   * такой список перестаёт быть правдой ровно на N+1 заказе.
   */
  async list(query: OrderListQuery, actor: ActorContext): Promise<PageDto<OrderDto>> {
    const scope = resolveSellerScope(actor.user);
    const { conditions, params } = this.filterConditions(query, scope);
    const where = whereClause(conditions);

    // Значения фильтра фиксируем ДО добавления LIMIT/OFFSET: у счётчика этих
    // плейсхолдеров нет, а лишний параметр для pg — ошибка, а не мелочь.
    const filterValues = [...params.values];
    const countRows = await this.repo.countMatching(this.dataSource, where, filterValues);

    const page = resolvePage(query);
    const limit = params.bind(page.pageSize);
    const offset = params.bind(page.offset);
    const rows = await this.repo.findPage(
      this.dataSource,
      where,
      this.orderByClause(query),
      limit,
      offset,
      params.values,
    );

    return pageEnvelope(await this.assemble(rows), Number(countRows[0]?.total ?? 0), page);
  }

  /**
   * Итоги по текущему фильтру. Один GROUP BY на сервере, а не подсчёт клиентом
   * по видимой странице: счётчик колонки канбана, меняющийся от листания, врёт.
   */
  async totals(query: OrderListQuery, actor: ActorContext): Promise<OrderListTotalsDto> {
    const scope = resolveSellerScope(actor.user);
    const { conditions, params } = this.filterConditions(query, scope);
    // Группируем по тому же статусу, который отдаёт список: иначе счётчик
    // колонки канбана и её содержимое считаются по разным правилам, и
    // разделённый заказ попадает в одну колонку, а числится в другой.
    const rows = await this.repo.countByEffectiveStatus(
      this.dataSource,
      whereClause(conditions),
      params.values,
    );

    const counts = new Map(rows.map((row) => [row.status, Number(row.count)]));
    // Нулевые колонки отдаём явно: иначе клиенту пришлось бы знать полный
    // список статусов, чтобы нарисовать пустую колонку канбана.
    const byStatus = ORDER_STATUSES.map((status) => ({ status, count: counts.get(status) ?? 0 }));
    return { total: byStatus.reduce((sum, item) => sum + item.count, 0), byStatus };
  }

  /**
   * Выгрузка списка в Excel — с ТЕМИ ЖЕ фильтрами, что и список. Выгрузка,
   * отдающая не то, что видно на экране, бесполезна: сверять её будут именно
   * с экраном.
   */
  async export(query: OrderListQuery, actor: ActorContext, response: Response): Promise<void> {
    const scope = resolveSellerScope(actor.user);
    const today = new Date().toISOString().slice(0, 10);

    // Матрица прав на колонки применяется и к файлу. `FieldAclInterceptor`
    // фильтрует только объекты ответа, а книга пишется прямо в `Response`
    // потоком — к пост-фазе интерцептора байты уже у клиента. Без этого
    // сборщик выгружал бы суммы COD, которых не видит на экране.
    const hidden = await this.acl.hiddenFields('order', actor.user.roles);
    const columns = ORDER_EXPORT_COLUMNS.filter((column) => !hidden.has(column.field));

    await this.xlsx.stream<OrderExportRow>(response, {
      filename: `Заказы-${today}.xlsx`,
      sheetName: 'Заказы',
      title: 'Заказы Yetkaz Express',
      notes: [`Фильтр: ${this.describeFilter(query)}`, `Сформировано: ${today}`],
      rows: this.exportBatches(query, scope),
      columns,
    });
  }

  async get(orderId: string, actor: ActorContext): Promise<OrderDto> {
    const scope = resolveSellerScope(actor.user);
    const rows = await this.selectOrders('o.id = $1', [orderId]);
    if (!rows[0] || !isSellerVisible(scope, rows[0].seller_id)) {
      throw new NotFoundException('Заказ не найден.');
    }
    const [dto] = await this.assemble(rows);
    return dto;
  }

  /**
   * Трек статусов заказа — журнал `order_status_history`, а не выборка из
   * аудита. Порядок по возрастанию времени: это лента, её читают сверху вниз.
   */
  async track(orderId: string, actor: ActorContext): Promise<OrderTrackDto> {
    await this.assertVisible(orderId, actor);

    const rows = await this.repo.findStatusHistory(this.dataSource, orderId);

    const events: OrderStatusEventDto[] = rows.map((row) => ({
      id: String(row.id),
      orderId,
      // Журнал хранит статусы текстом намеренно (переживает правку enum'а),
      // поэтому здесь единственное место, где тип возвращается обратно.
      fromStatus: (row.from_status as OrderStatus | null) ?? null,
      toStatus: row.to_status as OrderStatus,
      source: row.source,
      actorUserId: row.actor_user_id,
      actorName: row.actor_name,
      comment: row.comment,
      occurredAt: toIso(row.occurred_at),
    }));

    return { orderId, events };
  }

  /**
   * Открыть заказ по отсканированному коду. Принимаем ЛЮБОЙ из идентификаторов на
   * этикетке/экране: наш `order_code` (FF-YES…), номер клиента `external_id` или
   * номер отправления `shipment_no`. FF-код и номер отправления уникальны глобально;
   * при совпадении по номеру клиента (он уникален лишь в паре селлер+канал) берём
   * самый свежий.
   */
  async getByCode(code: string, actor: ActorContext): Promise<OrderDto> {
    // Тип и наличие параметра гарантирует `OrderByCodeQueryDto`; сюда доходит
    // только код из одних пробелов — это кривой ввод, то есть 400, а не «не найдено».
    const value = code.trim();
    if (!value) throw new BadRequestException('Код не указан.');

    const scope = resolveSellerScope(actor.user);
    const values: unknown[] = [value];
    let where =
      `(lower(o.order_code) = lower($1) OR lower(o.external_id) = lower($1) OR ` +
      `o.id IN (SELECT s.order_id FROM shipments s WHERE lower(s.shipment_no) = lower($1)))`;
    if (scope !== null) {
      values.push(scope);
      where += ` AND o.seller_id = $2`;
    }

    const rows = await this.selectOrders(where, values, 'ORDER BY o.created_at DESC LIMIT 1');
    if (!rows[0]) throw new NotFoundException(`Заказ по коду «${value}» не найден.`);
    const [dto] = await this.assemble(rows);
    return dto;
  }

  // --------------------------------------------------------- распределение

  /**
   * Раскладывает заказ по складам и резервирует.
   *
   * Стратегия — минимум отправлений (решение PM): жадно берём склад, который
   * закрывает больше всего позиций, остальное уходит в дочерние заказы.
   * Позиция целиком уезжает на один склад: дробить её между складами смысла нет —
   * отправлений от этого не станет меньше.
   */
  private async allocateAndReserve(
    em: EntityManager,
    order: OrderEntity,
    actor: ActorContext,
  ): Promise<ReserveOutcome> {
    const orderId = order.id;
    const orders = em.getRepository(OrderEntity);
    const outstanding = await this.outstandingLines(em, order);

    // Всё, что было в заказе, уже исполняют живые части: резервировать нечего,
    // а контейнер считается обеспеченным.
    if (outstanding.length === 0) {
      await orders.update({ id: orderId }, { hasShortage: false });
      await this.applyTransition(em, orderId, 'VALIDATED', 'RESERVED', actor);
      return { shortages: [], failure: null };
    }

    const allocation = await this.allocate(em, outstanding);

    if (allocation.groups.length === 0) {
      // Совсем нечего резервировать — заказ ждёт поставки (решение PM).
      await orders.update({ id: orderId }, { hasShortage: true });
      return { shortages: allocation.uncovered, failure: null };
    }

    // Заказ, ещё не разделённый и покрытый одним складом, исполняет себя сам.
    // Уже разделённый остаётся контейнером: резерв на него поверх живых частей
    // означал бы отгрузку одного и того же товара дважды.
    if (!order.isSplit && allocation.groups.length === 1 && allocation.uncovered.length === 0) {
      const group = allocation.groups[0];
      try {
        // Склад и снятая отметка нехватки пишутся ТОЛЬКО после удачного резерва:
        // при гонке за последними единицами `reserveGroup` бросает 409, и заказ
        // с проставленным складом и `has_shortage = false` выпадал из очереди
        // нехватки, оставаясь без резерва.
        await this.reserveGroup(orderId, group, actor);
      } catch (error) {
        await orders.update({ id: orderId }, { hasShortage: true, warehouseId: null });
        return { shortages: [], failure: error };
      }
      await orders.update(
        { id: orderId },
        { warehouseId: group.warehouseId, hasShortage: false },
      );
      await this.applyTransition(em, orderId, 'VALIDATED', 'RESERVED', actor);
      return { shortages: [], failure: null };
    }

    // Разделение: заказ-контейнер сохраняет все позиции канала, исполняют дети.
    await orders.update(
      { id: orderId },
      { isSplit: true, hasShortage: allocation.uncovered.length > 0, warehouseId: null },
    );

    let sequence = await this.maxChildSequence(em, order);
    for (const group of allocation.groups) {
      const child = await this.createChild(order, group, sequence + 1);
      sequence = child.sequence;
      await this.transition(child.id, 'NEW', 'VALIDATED', actor);
      try {
        await this.reserveGroup(child.id, group, actor);
      } catch (error) {
        // Часть создана, но не обеспечена: контейнер обязан остаться в очереди
        // нехватки, иначе оператор больше никогда не нажмёт «повторить резерв».
        await orders.update({ id: orderId }, { hasShortage: true });
        return { shortages: allocation.uncovered, failure: error };
      }
      await this.transition(child.id, 'VALIDATED', 'RESERVED', actor);
    }

    if (allocation.uncovered.length === 0) {
      // Все части обеспечены — контейнер тоже считается зарезервированным.
      await this.applyTransition(em, orderId, 'VALIDATED', 'RESERVED', actor);
    }
    return { shortages: allocation.uncovered, failure: null };
  }

  /**
   * Что ещё НЕ обеспечено: позиции контейнера минус позиции живых частей.
   *
   * Контейнер по решению PM хранит ВСЕ позиции канала, а исполняют их дети.
   * Считать по позициям контейнера при повторном резерве значит зарезервировать
   * то же самое второй раз — поверх живого резерва ребёнка, то есть отгрузить
   * товар дважды. Отменённые части не вычитаем: их резерв уже снят, и товар
   * снова нужно обеспечить.
   */
  private async outstandingLines(em: EntityManager, order: OrderEntity): Promise<RequestedLine[]> {
    const lines = await em.getRepository(OrderLineEntity).find({ where: { orderId: order.id } });
    const rows = await this.repo.sumChildLineQuantities(em, order.id);
    const covered = new Map(rows.map((row) => [row.sku_id, Number(row.quantity)]));

    const outstanding: RequestedLine[] = [];
    for (const line of lines) {
      const rest = line.quantity - (covered.get(line.skuId) ?? 0);
      if (rest > 0) outstanding.push({ skuId: line.skuId, quantity: rest });
    }
    return outstanding;
  }

  /**
   * Номер, от которого нумеруются НОВЫЕ части.
   *
   * Считается по уже существующим частям, ВКЛЮЧАЯ отменённые: суффикс входит в
   * естественный ключ канала, а отмена строку не удаляет. Начав снова с «#2»,
   * повторный резерв упирался в `uq_orders_channel_external` — и заказ нельзя
   * было зарезервировать уже никогда. Контейнер занимает «#1» по смыслу
   * нумерации, поэтому это и есть минимум.
   */
  private async maxChildSequence(em: EntityManager, parent: OrderEntity): Promise<number> {
    const children = await em
      .getRepository(OrderEntity)
      .find({ where: { parentOrderId: parent.id } });
    const prefix = `${parent.externalId}#`;

    let max = 1;
    for (const child of children) {
      if (!child.externalId.startsWith(prefix)) continue;
      const suffix = Number(child.externalId.slice(prefix.length));
      if (Number.isInteger(suffix) && suffix > max) max = suffix;
    }
    return max;
  }

  private async allocate(em: EntityManager, requested: RequestedLine[]): Promise<Allocation> {
    const skuIds = requested.map((line) => line.skuId);
    const rows = await this.repo.findAvailabilityBySku(em, skuIds);

    const stock = new Map<string, Map<string, number>>();
    for (const row of rows) {
      const perWarehouse = stock.get(row.warehouse_id) ?? new Map<string, number>();
      perWarehouse.set(row.sku_id, Number(row.available));
      stock.set(row.warehouse_id, perWarehouse);
    }

    const groups: WarehouseGroup[] = [];
    let remaining = [...requested];
    const usedWarehouses = new Set<string>();

    while (remaining.length > 0) {
      let best: { warehouseId: string; lines: RequestedLine[] } | null = null;

      for (const [warehouseId, perSku] of stock) {
        if (usedWarehouses.has(warehouseId)) continue;
        const covered = remaining.filter((line) => (perSku.get(line.skuId) ?? 0) >= line.quantity);
        if (covered.length === 0) continue;
        // Детерминированный выбор: больше позиций, при равенстве — меньший id.
        if (
          !best ||
          covered.length > best.lines.length ||
          (covered.length === best.lines.length && warehouseId < best.warehouseId)
        ) {
          best = { warehouseId, lines: covered };
        }
      }

      if (!best) break;
      groups.push({ warehouseId: best.warehouseId, lines: best.lines });
      usedWarehouses.add(best.warehouseId);
      const takenSkus = new Set(best.lines.map((line) => line.skuId));
      remaining = remaining.filter((line) => !takenSkus.has(line.skuId));
    }

    const uncovered: OrderShortageDto[] = remaining.map((line) => {
      let bestAvailable = 0;
      for (const perSku of stock.values()) {
        bestAvailable = Math.max(bestAvailable, perSku.get(line.skuId) ?? 0);
      }
      return { skuId: line.skuId, requested: line.quantity, available: bestAvailable };
    });

    return { groups, uncovered };
  }

  /**
   * Создание части со свободным суффиксом.
   *
   * Занятый номер разбирается тем же способом, что и в `intake`: нарушение
   * `uq_orders_channel_external` — это конфликт естественного ключа канала, а не
   * сбой, и уходить наружу пятисоткой он не должен. Пробуем следующий номер:
   * занять его могла только параллельная попытка резерва того же заказа.
   */
  private async createChild(
    parent: OrderEntity,
    group: WarehouseGroup,
    sequence: number,
  ): Promise<{ id: string; sequence: number }> {
    for (let attempt = 0; attempt < CHILD_SUFFIX_ATTEMPTS; attempt += 1) {
      const candidate = sequence + attempt;
      try {
        return { id: await this.insertChild(parent, group, candidate), sequence: candidate };
      } catch (error) {
        if (uniqueViolationConstraint(error) !== 'uq_orders_channel_external') throw error;
      }
    }
    throw new ConflictException(
      `Не удалось подобрать свободный номер части для заказа ${parent.orderCode}: ` +
        'повторите резерв.',
    );
  }

  private async insertChild(
    parent: OrderEntity,
    group: WarehouseGroup,
    sequence: number,
  ): Promise<string> {
    return this.dataSource.transaction(async (em) => {
      const orders = em.getRepository(OrderEntity);
      const child = await orders.save(
        orders.create({
          sellerId: parent.sellerId,
          channel: parent.channel,
          // Суффикс держит естественный ключ уникальным и делает часть узнаваемой.
          externalId: `${parent.externalId}#${sequence}`,
          status: 'NEW',
          warehouseId: group.warehouseId,
          parentOrderId: parent.id,
          isSplit: false,
          hasShortage: false,
          recipientName: parent.recipientName,
          recipientPhone: parent.recipientPhone,
          address: parent.address,
          region: parent.region,
          // Категория — разрез отчёта, и он наследуется: уезжают именно части,
          // и без наследования половина отгрузок оказалась бы «без категории».
          categoryId: parent.categoryId,
          // Наложенный платёж остаётся на родителе: делить его между частями —
          // отдельное решение по биллингу, а не механика склада.
          codAmount: null,
          currency: null,
          // Вес — заявленный атрибут родителя; у части — свой фактический на упаковке.
          weightKg: null,
          createdBy: parent.createdBy,
        }),
      );
      for (const line of group.lines) {
        await em
          .getRepository(OrderLineEntity)
          .insert({ orderId: child.id, skuId: line.skuId, quantity: line.quantity });
      }
      await this.history.record(
        orderFsm,
        child.id,
        null,
        'NEW',
        {
          actorUserId: parent.createdBy,
          source: 'split',
          comment: `Часть разделённого заказа ${parent.orderCode}`,
        },
        em,
      );
      return child.id;
    });
  }

  /**
   * Резерв по позициям группы. Резерв каждой позиции — своя транзакция в
   * Inventory, поэтому при гонке на середине компенсируем уже взятое:
   * заказ не должен остаться с половиной резерва.
   */
  private async reserveGroup(
    orderId: string,
    group: WarehouseGroup,
    actor: ActorContext,
  ): Promise<void> {
    try {
      for (const line of group.lines) {
        await this.inventory.reserve(
          {
            ownerType: OWNER_TYPE,
            ownerId: orderId,
            skuId: line.skuId,
            warehouseId: group.warehouseId,
            quantity: line.quantity,
          },
          actor,
        );
      }
    } catch (error) {
      this.logger.warn(`Резерв заказа ${orderId} не удался, откатываю частичный резерв.`);
      await this.releaseQuietly(orderId, 'Откат частичного резерва', actor);
      throw error;
    }
  }

  // ------------------------------------------------------- фильтр и выборка

  /**
   * Условия фильтра — общие для списка, итогов и выгрузки. Одна функция, а не
   * три похожих: разъехавшийся фильтр обнаруживают не тестом, а спором о том,
   * чей отчёт правильный.
   */
  private filterConditions(
    query: OrderListQuery,
    scope: string | null,
  ): { conditions: string[]; params: SqlParams } {
    const params = new SqlParams();
    const conditions: string[] = [];

    // Скоуп селлера бьёт параметр запроса: подставленный чужой sellerId должен
    // отдавать свои же данные, а не чужие.
    if (scope !== null) conditions.push(`o.seller_id = ${params.bind(scope)}`);
    else if (query.sellerId) conditions.push(`o.seller_id = ${params.bind(query.sellerId)}`);

    if (!query.includeSplitChildren) conditions.push('o.parent_order_id IS NULL');

    // Фильтр — по тому же статусу, который видно в списке и в итогах. Иначе
    // клик по колонке канбана открывал бы не то, что в ней посчитано.
    const statuses = this.parseStatuses(query);
    if (statuses.length === 1) {
      conditions.push(`(${EFFECTIVE_STATUS}) = ${params.bind(statuses[0])}::order_status`);
    } else if (statuses.length > 1) {
      conditions.push(`(${EFFECTIVE_STATUS}) = ANY(${params.bind(statuses)}::order_status[])`);
    }

    if (query.categoryId) conditions.push(`o.category_id = ${params.bind(query.categoryId)}`);
    if (query.warehouseId) conditions.push(`o.warehouse_id = ${params.bind(query.warehouseId)}`);
    if (query.channel) conditions.push(`o.channel = ${params.bind(query.channel.trim())}`);

    const search = query.search?.trim();
    if (search) {
      // Один плейсхолдер на четыре колонки: под них заведены триграммные
      // индексы, поэтому подстрока ищется индексом, а не перебором таблицы.
      const pattern = params.bind(likePattern(search));
      conditions.push(
        `(o.order_code ILIKE ${pattern} OR o.external_id ILIKE ${pattern} ` +
          `OR o.recipient_name ILIKE ${pattern} OR o.recipient_phone ILIKE ${pattern})`,
      );
    }

    conditions.push(...dateRangeConditions('o.created_at', params, query.dateFrom, query.dateTo));
    return { conditions, params };
  }

  /** `status` и `statuses` складываются: канбан шлёт список, фильтр — одно значение. */
  private parseStatuses(query: OrderListQuery): OrderStatus[] {
    const raw = [
      ...(query.status ? [query.status] : []),
      ...(query.statuses ?? '')
        .split(',')
        .map((value) => value.trim().toUpperCase())
        .filter(Boolean),
    ];

    const result: OrderStatus[] = [];
    for (const value of raw) {
      if (!(ORDER_STATUSES as readonly string[]).includes(value)) {
        throw new BadRequestException(`Неизвестный статус заказа: ${value}.`);
      }
      if (!result.includes(value as OrderStatus)) result.push(value as OrderStatus);
    }
    return result;
  }

  /**
   * Порядок строк. Добавочный ключ `o.id` обязателен: без него у страницы 2
   * нет причины не повторить страницу 1 — PostgreSQL не обязан сохранять
   * порядок строк с равными значениями сортировки.
   */
  private orderByClause(query: OrderListQuery): string {
    const { field, direction } = resolveSort(
      ORDER_SORT_FIELDS,
      'createdAt',
      query.sort,
      query.direction,
    );
    // NULLS LAST в обе стороны: пустая дата выдачи не должна возглавлять список.
    const dir = direction === 'asc' ? 'ASC' : 'DESC';
    return `ORDER BY ${SORT_COLUMNS[field]} ${dir} NULLS LAST, o.id ASC`;
  }

  /**
   * Выгрузка страницами: фильтр пересобирается на каждую, параметры — свои.
   *
   * Все пачки читаются в ОДНОЙ транзакции REPEATABLE READ. `OFFSET` считает по
   * живой таблице: заказ, созданный между пачками, сдвигает окно — строка
   * попадает в файл дважды, а соседняя не попадает вовсе. Снимок фиксирует
   * набор строк на всё время выгрузки, поэтому файл соответствует одному
   * моменту, а не размазан по нему.
   */
  private async *exportBatches(
    query: OrderListQuery,
    scope: string | null,
  ): AsyncGenerator<OrderExportRow[]> {
    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction('REPEATABLE READ');

    try {
      let offset = 0;
      for (;;) {
        const { conditions, params } = this.filterConditions(query, scope);
        const limit = params.bind(EXPORT_BATCH);
        const skip = params.bind(offset);
        const rows = await this.repo.findExportPage(
          runner,
          whereClause(conditions),
          this.orderByClause(query),
          limit,
          skip,
          params.values,
        );

        if (rows.length === 0) return;
        yield rows;
        if (rows.length < EXPORT_BATCH) return;
        offset += EXPORT_BATCH;
      }
    } finally {
      // Выгрузка только читает, поэтому закрываем откатом: он корректен и тогда,
      // когда потребитель бросил генератор на полпути (клиент отключился) —
      // соединение обязано вернуться в пул без открытой транзакции.
      if (runner.isTransactionActive) await runner.rollbackTransaction();
      await runner.release();
    }
  }

  /** Человеческое описание фильтра — уходит подписью на лист выгрузки. */
  private describeFilter(query: OrderListQuery): string {
    const parts: string[] = [];
    if (query.dateFrom || query.dateTo) {
      parts.push(`период ${query.dateFrom ?? '...'} — ${query.dateTo ?? '...'}`);
    }
    const statuses = this.parseStatuses(query);
    if (statuses.length) parts.push(`статус ${statuses.join(', ')}`);
    if (query.sellerId) parts.push('выбран селлер');
    if (query.warehouseId) parts.push('выбран склад');
    if (query.categoryId) parts.push('выбрана категория');
    if (query.channel) parts.push(`канал ${query.channel}`);
    if (query.search?.trim()) parts.push(`поиск «${query.search.trim()}»`);
    if (query.includeSplitChildren) parts.push('включая части разделённых заказов');
    return parts.length ? parts.join('; ') : 'без фильтров';
  }

  // ------------------------------------------------------------ внутреннее

  private async transition(
    orderId: string,
    from: OrderStatus,
    to: OrderStatus,
    actor: ActorContext,
    comment?: string | null,
  ): Promise<void> {
    await this.dataSource.transaction(async (em: EntityManager) => {
      await this.applyTransition(em, orderId, from, to, actor, comment);
    });
  }

  /**
   * Перевод статуса внутри УЖЕ открытой транзакции: проверка машиной, аудит,
   * трек и сама колонка — одним куском.
   *
   * Апдейт условный (`WHERE id = … AND status = …`), и число затронутых строк
   * проверяется: ноль означает, что состояние увели из-под нас, и это 409, а не
   * молчаливая перезапись. При взятой блокировке строки это уже страховка —
   * но страховка ценой одного условия, а цена ошибки здесь равна стоимости
   * уехавшего со склада товара.
   */
  private async applyTransition(
    em: EntityManager,
    orderId: string,
    from: OrderStatus,
    to: OrderStatus,
    actor: ActorContext,
    comment?: string | null,
  ): Promise<void> {
    await this.fsm.transition(
      orderFsm,
      from,
      to,
      {
        entityType: 'Order',
        entityId: orderId,
        actorUserId: actor.user.id,
        actorRole: actor.user.roles.join(','),
        correlationId: actor.correlationId,
        comment: comment ?? null,
      },
      em,
    );

    const result = await em
      .getRepository(OrderEntity)
      .update({ id: orderId, status: from }, { status: to });
    if (!result.affected) {
      throw new ConflictException(
        `Статус заказа изменился одновременно с этой операцией (ожидался ${from}). ` +
          'Обновите карточку и повторите.',
      );
    }
  }

  /**
   * Захват строки заказа на время операции.
   *
   * `FOR NO KEY UPDATE`, а не `FOR UPDATE`: под этой блокировкой создаются
   * дочерние заказы, а вставка строки с `parent_order_id` берёт на родителе
   * `FOR KEY SHARE` — с `FOR UPDATE` она ждала бы нас же, то есть операция
   * заблокировала бы сама себя. Ключевых колонок заказа мы при этом не меняем,
   * поэтому более слабой блокировки достаточно: два одновременных резерва (и
   * резерв с отменой) друг друга по-прежнему сериализуют.
   */
  private async lockOrder(em: EntityManager, orderId: string): Promise<OrderEntity> {
    const order = await em.getRepository(OrderEntity).findOne({
      where: { id: orderId },
      lock: { mode: 'for_no_key_update' },
    });
    if (!order) throw new NotFoundException('Заказ не найден.');
    return order;
  }

  private findByChannelKey(
    sellerId: string,
    channel: string,
    externalId: string,
  ): Promise<OrderEntity | null> {
    return this.dataSource
      .getRepository(OrderEntity)
      .createQueryBuilder('o')
      .where('o.sellerId = :sellerId', { sellerId })
      .andWhere('o.channel = :channel', { channel: channel.trim() })
      .andWhere('lower(o.externalId) = :externalId', { externalId: externalId.trim().toLowerCase() })
      .getOne();
  }

  private async loadOrder(orderId: string): Promise<OrderEntity> {
    const order = await this.dataSource
      .getRepository(OrderEntity)
      .findOne({ where: { id: orderId } });
    if (!order) throw new NotFoundException('Заказ не найден.');
    return order;
  }

  /** Лёгкая проверка доступа: без позиций и детей — для ручек, которым нужен только скоуп. */
  private async assertVisible(orderId: string, actor: ActorContext): Promise<OrderEntity> {
    const scope = resolveSellerScope(actor.user);
    const order = await this.dataSource
      .getRepository(OrderEntity)
      .findOne({ where: { id: orderId } });
    if (!order || !isSellerVisible(scope, order.sellerId)) {
      throw new NotFoundException('Заказ не найден.');
    }
    return order;
  }

  private async requireCategory(categoryId: string): Promise<OrderCategoryEntity> {
    const category = await this.dataSource
      .getRepository(OrderCategoryEntity)
      .findOne({ where: { id: categoryId } });
    // Отключённую категорию присвоить разрешаем: переклассификация старого
    // заказа в закрытое направление — законная операция для отчёта.
    if (!category) throw new NotFoundException('Категория заказа не найдена.');
    return category;
  }

  private async selectOrders(where: string, values: unknown[], tail = ''): Promise<OrderRow[]> {
    return this.repo.findByCondition(this.dataSource, where, values, tail);
  }

  private async buildOrderDto(orderId: string): Promise<OrderDto> {
    const rows = await this.selectOrders('o.id = $1', [orderId]);
    if (!rows[0]) throw new NotFoundException('Заказ не найден.');
    const [dto] = await this.assemble(rows);
    return dto;
  }

  /**
   * Сборка пачкой: три запроса на любой размер списка.
   * Поштучная давала 2·N+1 — на сотне заказов список превращался в две сотни
   * обращений к базе, причём ровно на том экране, который открыт весь день.
   */
  private async assemble(rows: OrderRow[]): Promise<OrderDto[]> {
    if (rows.length === 0) return [];

    const ids = rows.map((row) => row.id);
    const children = await this.selectOrders(
      'o.parent_order_id = ANY($1::uuid[])',
      [ids],
      'ORDER BY o.external_id ASC',
    );
    const lines = await this.loadLines([...ids, ...children.map((child) => child.id)]);

    const byParent = new Map<string, OrderDto[]>();
    for (const child of children) {
      const parentId = child.parent_order_id as string;
      const siblings = byParent.get(parentId) ?? [];
      siblings.push({
        ...this.mapOrder(child),
        lines: lines.get(child.id) ?? [],
        children: [],
      });
      byParent.set(parentId, siblings);
    }

    return rows.map((row) => ({
      ...this.mapOrder(row),
      lines: lines.get(row.id) ?? [],
      children: byParent.get(row.id) ?? [],
    }));
  }

  /** Позиции всех заказов одним запросом, с артикулом и названием товара. */
  private async loadLines(orderIds: string[]): Promise<Map<string, OrderLineDto[]>> {
    const rows = await this.repo.findLines(this.dataSource, orderIds);

    const byOrder = new Map<string, OrderLineDto[]>();
    for (const row of rows) {
      const list = byOrder.get(row.order_id) ?? [];
      list.push({
        id: row.id,
        skuId: row.sku_id,
        skuCode: row.sku_code,
        skuName: row.name,
        quantity: Number(row.quantity),
      });
      byOrder.set(row.order_id, list);
    }
    return byOrder;
  }

  private mapOrder(row: OrderRow): Omit<OrderDto, 'lines' | 'children'> {
    return {
      id: row.id,
      sellerId: row.seller_id,
      channel: row.channel,
      externalId: row.external_id,
      orderCode: row.order_code,
      status: row.status,
      warehouseId: row.warehouse_id,
      parentOrderId: row.parent_order_id,
      isSplit: row.is_split,
      hasShortage: row.has_shortage,
      recipientName: row.recipient_name,
      recipientPhone: row.recipient_phone,
      address: row.address,
      region: row.region,
      codAmount: row.cod_amount,
      currency: row.currency,
      weightKg: row.weight_kg,
      categoryId: row.category_id,
      // Код, название и цвет категории денормализованы В ОТВЕТ, а не в таблицу:
      // список иначе тянул бы справочник на клиент ради двух слов в строке.
      categoryCode: row.category_code,
      categoryName: row.category_name,
      categoryColor: row.category_color,
      dispatchedAt: row.dispatched_at ? toIso(row.dispatched_at) : null,
      createdAt: toIso(row.created_at),
    };
  }
}

function toIso(value: Date | string): string {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function toDate(value: Date | string | null): Date | null {
  if (value === null) return null;
  return value instanceof Date ? value : new Date(value);
}

/**
 * «Значение не задано» — и когда поля нет вовсе, и когда прислали `null`.
 * JSON умеет и то, и другое, а правило «сумма и валюта только вместе» обязано
 * считать их одинаково.
 */
function isBlank(value: string | null | undefined): boolean {
  return value === undefined || value === null;
}

/** Деньги и вес хранятся строкой (без float), но в Excel обязаны быть числом. */
function toNumber(value: string | null): number | null {
  if (value === null) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}
