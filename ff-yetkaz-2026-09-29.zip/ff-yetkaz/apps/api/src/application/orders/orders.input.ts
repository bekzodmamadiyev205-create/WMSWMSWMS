import type { OrderImportOrderDto } from '@ff/shared';

/**
 * Формы входных данных прикладного слоя заказов.
 *
 * Сервису нужна ФОРМА того, что ему передали, а не класс с декораторами
 * class-validator: декораторы существуют ради разбора HTTP-запроса, и импорт
 * DTO из presentation разворачивал зависимость вверх — прикладной слой начинал
 * знать про транспорт. Здесь объявлено ровно то, что живёт в @ff/shared:
 * контракты ОТВЕТОВ там уже есть (`OrderDto`, `OrderListQuery`,
 * `UpdateOrderPayload`), а этих входных форм не было, и добавлять их в пакет
 * ради одного потребителя — значит трогать его сборку в двух форматах.
 *
 * Классы DTO в presentation получают `implements` этих интерфейсов: расхождение
 * формы тогда ловит сборка, а не боевой запрос.
 */

/** Позиция заказа: внутренний идентификатор товара, а не артикул селлера. */
export interface CreateOrderLineInput {
  skuId: string;
  quantity: number;
}

export interface CreateOrderInput {
  sellerId: string;
  channel: string;
  externalId: string;
  recipientName: string;
  recipientPhone: string;
  address: string;
  region?: string;
  /**
   * Строкой: деньги через float недопустимы. `null` допустим не для красоты —
   * JSON умеет прислать `"currency": null`, и сервис обязан считать пару
   * «сумма есть, валюта null» тем же нарушением правила «только вместе», что и
   * «валюты нет вовсе».
   */
  codAmount?: string | null;
  currency?: string | null;
  weightKg?: string;
  categoryId?: string;
  lines: CreateOrderLineInput[];
}

export interface CancelOrderInput {
  reason?: string;
}

/**
 * Загрузка заказов файлом. Селлер и канал общие на всю пачку, поэтому в самих
 * заказах их нет — иначе одна строка файла могла бы уехать чужому селлеру.
 */
export interface ImportOrdersInput {
  sellerId: string;
  channel: string;
  orders: OrderImportOrderDto[];
}
