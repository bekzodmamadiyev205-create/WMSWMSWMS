import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExportModule } from '../../infrastructure/export/export.module';
import {
  BinLocationEntity,
  OrderCategoryEntity,
  OrderEntity,
  OrderLineEntity,
  OrderStatusEventEntity,
  PackageEntity,
  PickTaskLineEntity,
  SellerEntity,
  ShipmentEntity,
  SkuEntity,
} from '../../infrastructure/database/entities';
import { OrdersRepository } from '../../infrastructure/database/repositories/orders.repository';
import { PutBackRepository } from '../../infrastructure/database/repositories/put-back.repository';
import { InventoryModule } from '../inventory/inventory.module';
import { OrderImportService } from './order-import.service';
import { OrdersController } from '../../presentation/http/orders.controller';
import { OrdersService } from './orders.service';
import { PutBackService } from './put-back.service';

@Module({
  imports: [
    InventoryModule,
    // ExportModule глобальный, но импортируется здесь явно: так модуль заказов
    // поднимается сам по себе (в тестах и в изоляции), не завися от того,
    // подключил ли его кто-то ещё в AppModule.
    ExportModule,
    TypeOrmModule.forFeature([
      OrderEntity,
      OrderLineEntity,
      OrderCategoryEntity,
      OrderStatusEventEntity,
      SellerEntity,
      SkuEntity,
      // Возврат при отмене трогает упаковку, отправление и строки сборки, но
      // модули Packing/Picking сюда не импортируются: зависимость от них
      // замкнула бы граф — им самим нужен Orders.
      PackageEntity,
      ShipmentEntity,
      PickTaskLineEntity,
      BinLocationEntity,
    ]),
  ],
  controllers: [OrdersController],
  providers: [
    OrdersService,
    OrderImportService,
    PutBackService,
    // Сырой SQL заказов и возврата на склад. Соединение репозиторию не
    // внедряется — оно приходит параметром, поэтому провайдер без состояния.
    OrdersRepository,
    PutBackRepository,
  ],
  exports: [OrdersService],
})
export class OrdersModule {}
