import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import type {
  OrderImportOrderDto,
  OrderImportResultDto,
  OrderImportResultRowDto,
  OrderShortageDto,
} from '@ff/shared';
import { AuditService } from '../../infrastructure/logging/audit/audit.service';
import type { ActorContext } from '../../domain/types/actor';
import { SellerEntity } from '../../infrastructure/database/entities';
import { OrdersRepository } from '../../infrastructure/database/repositories/orders.repository';
import type { ImportOrdersInput } from './orders.input';
import { OrdersService } from './orders.service';

interface CatalogEntry {
  id: string;
  skuCode: string;
  isActive: boolean;
}

/** Каталог селлера: артикул в нижнем регистре → позиция. */
type Catalog = Map<string, CatalogEntry>;

interface PreparedLines {
  lines: Array<{ skuId: string; quantity: number }>;
  /** Замечания, которые не отменяют загрузку, но оператор должен их видеть. */
  notes: string[];
}

/**
 * Загрузка заказов файлом.
 *
 * Каждый заказ проходит через обычный `OrdersService.intake` — тот же путь, что
 * и у заказа из API клиента: те же проверки, те же переходы в аудите, тот же
 * авторезерв. Отдельной «облегчённой» ветки для импорта нет намеренно: она бы
 * неминуемо разъехалась с основной.
 *
 * Заказы обрабатываются по одному, каждый в своей транзакции. Одна общая
 * транзакция на файл здесь была бы хуже: ошибка в трёхсотой строке откатила бы
 * 299 уже принятых заказов, а склад к этому моменту уже видит их в работе.
 */
@Injectable()
export class OrderImportService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly orders: OrdersService,
    private readonly audit: AuditService,
    private readonly repo: OrdersRepository,
  ) {}

  async import(dto: ImportOrdersInput, actor: ActorContext): Promise<OrderImportResultDto> {
    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: dto.sellerId } });
    if (!seller) throw new NotFoundException('Селлер не найден.');
    if (!seller.isActive) {
      throw new ConflictException('Нельзя загружать заказы деактивированному селлеру.');
    }

    const catalog = await this.loadCatalog(dto.sellerId, dto.orders);
    const result: OrderImportResultDto = { created: 0, duplicates: 0, failed: 0, rows: [] };

    for (const item of dto.orders) {
      const row = await this.importOne(dto, item, catalog, actor);
      result.rows.push(row);
      if (row.outcome === 'CREATED') result.created += 1;
      else if (row.outcome === 'DUPLICATE') result.duplicates += 1;
      else result.failed += 1;
    }

    await this.audit.record({
      action: 'CREATE',
      entityType: 'OrderImport',
      entityId: dto.sellerId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      ip: actor.ip,
      after: {
        channel: dto.channel,
        created: result.created,
        duplicates: result.duplicates,
        failed: result.failed,
      },
    });

    return result;
  }

  private async importOne(
    dto: ImportOrdersInput,
    item: OrderImportOrderDto,
    catalog: Catalog,
    actor: ActorContext,
  ): Promise<OrderImportResultRowDto> {
    const base: Omit<OrderImportResultRowDto, 'outcome' | 'message'> = {
      row: item.fileLine,
      externalId: item.externalId.trim(),
      orderId: null,
      status: null,
      hasShortage: false,
    };

    let prepared: PreparedLines;
    try {
      prepared = this.prepareLines(item, catalog);
      this.assertCod(item);
    } catch (error) {
      return { ...base, outcome: 'FAILED', message: describe(error) };
    }

    try {
      const outcome = await this.orders.intake(
        {
          sellerId: dto.sellerId,
          channel: dto.channel,
          externalId: item.externalId.trim(),
          recipientName: item.recipientName,
          recipientPhone: item.recipientPhone,
          address: item.address,
          region: item.region?.trim() || undefined,
          codAmount: item.codAmount?.trim() || undefined,
          weightKg: item.weightKg?.trim() || undefined,
          currency: item.currency?.trim() || undefined,
          lines: prepared.lines,
        },
        actor,
      );

      const notes = [...prepared.notes, ...this.describeShortages(outcome.shortages, catalog)];
      return {
        ...base,
        outcome: outcome.duplicate ? 'DUPLICATE' : 'CREATED',
        orderId: outcome.order.id,
        status: outcome.order.status,
        hasShortage: outcome.order.hasShortage,
        message: notes.length > 0 ? notes.join(' ') : null,
      };
    } catch (error) {
      return { ...base, outcome: 'FAILED', message: describe(error) };
    }
  }

  /**
   * Артикулы файла → позиции каталога.
   *
   * Один и тот же товар в файле может встретиться дважды (две строки одного
   * заказа) — количества складываются: заказ с повторяющимся SKU приём
   * отклоняет, а разбираться с этим руками оператору незачем. Складывание
   * попадает в отчёт, молча оно не происходит.
   */
  private prepareLines(item: OrderImportOrderDto, catalog: Catalog): PreparedLines {
    const quantities = new Map<string, number>();
    const merged: string[] = [];
    const unknown: string[] = [];
    const inactive: string[] = [];

    for (const line of item.lines) {
      const code = line.skuCode.trim();
      const entry = catalog.get(code.toLowerCase());
      if (!entry) {
        if (!unknown.includes(code)) unknown.push(code);
        continue;
      }
      if (!entry.isActive) {
        if (!inactive.includes(entry.skuCode)) inactive.push(entry.skuCode);
        continue;
      }
      const previous = quantities.get(entry.id);
      if (previous !== undefined) merged.push(entry.skuCode);
      quantities.set(entry.id, (previous ?? 0) + line.quantity);
    }

    if (unknown.length > 0) {
      throw new Error(`Артикулы не найдены в каталоге селлера: ${unknown.join(', ')}.`);
    }
    if (inactive.length > 0) {
      throw new Error(`Артикулы деактивированы: ${inactive.join(', ')}.`);
    }

    return {
      lines: [...quantities].map(([skuId, quantity]) => ({ skuId, quantity })),
      notes:
        merged.length > 0
          ? [`Повторяющиеся позиции сложены: ${[...new Set(merged)].join(', ')}.`]
          : [],
    };
  }

  /**
   * Сумма без валюты — отказ, а не «наверное, местная».
   * Валюту в FF нигде не додумывают: неверная валюта наложенного платежа
   * всплывёт на сверке с перевозчиком, когда деньги уже собраны.
   */
  private assertCod(item: OrderImportOrderDto): void {
    const amount = item.codAmount?.trim();
    const currency = item.currency?.trim();
    if (amount && !currency) {
      throw new Error('Указана сумма наложенного платежа без валюты.');
    }
    if (!amount && currency) {
      throw new Error('Указана валюта без суммы наложенного платежа.');
    }
  }

  private describeShortages(shortages: OrderShortageDto[], catalog: Catalog): string[] {
    if (shortages.length === 0) return [];
    const byId = new Map([...catalog.values()].map((entry) => [entry.id, entry.skuCode]));
    const parts = shortages.map(
      (shortage) =>
        `${byId.get(shortage.skuId) ?? shortage.skuId} — нужно ${shortage.requested}, есть ${shortage.available}`,
    );
    return [`Не хватает остатка: ${parts.join('; ')}. Заказ ждёт поставки.`];
  }

  /** Каталог по артикулам файла одним запросом, без выкачивания всех SKU. */
  private async loadCatalog(sellerId: string, orders: OrderImportOrderDto[]): Promise<Catalog> {
    const codes = [
      ...new Set(
        orders.flatMap((order) => order.lines.map((line) => line.skuCode.trim().toLowerCase())),
      ),
    ];
    if (codes.length === 0) return new Map();

    const rows = await this.repo.findCatalogByCodes(this.dataSource, sellerId, codes);

    return new Map(
      rows.map((row) => [
        row.sku_code.toLowerCase(),
        { id: row.id, skuCode: row.sku_code, isActive: row.is_active },
      ]),
    );
  }
}

function describe(error: unknown): string {
  if (error instanceof Error) return error.message;
  return 'Неизвестная ошибка.';
}
