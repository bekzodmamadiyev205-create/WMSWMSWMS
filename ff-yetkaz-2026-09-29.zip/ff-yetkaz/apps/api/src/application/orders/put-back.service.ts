import { ConflictException, Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import { shipmentFsm, type InventoryUnitStatus } from '@ff/shared';
import { FsmService } from '../fsm/fsm.service';
import type { ActorContext } from '../../domain/types/actor';
import { findBinByKind } from '../../infrastructure/database/repositories/bin-location.repository';
import { PutBackRepository } from '../../infrastructure/database/repositories/put-back.repository';
import {
  PackageEntity,
  PickTaskLineEntity,
  ShipmentEntity,
} from '../../infrastructure/database/entities';
import { InventoryService } from '../inventory/inventory.service';

const OWNER_TYPE = 'ORDER';

/** Что заказ физически удерживает прямо сейчас — по журналу движений. */
interface Holding {
  skuId: string;
  lotId: string | null;
  binId: string;
  status: InventoryUnitStatus;
  quantity: number;
}

/** Ячейка, откуда товар когда-то взяли под этот заказ. */
interface Origin {
  skuId: string;
  lotId: string | null;
  binId: string;
  quantity: number;
}

export interface PutBackResult {
  /** Сколько единиц вернулось в доступный остаток. */
  units: number;
  packageCancelled: boolean;
  shipmentCancelled: boolean;
}

/**
 * Возврат на склад заказа, отменённого до передачи перевозчику.
 *
 * Это НЕ возврат от клиента: товар не покидал склад, коробку вскрывают и
 * раскладывают обратно. Источник правды о том, что и откуда взято, — журнал
 * движений: он единственный знает исходные ячейки, потому что `stock`
 * количественный и не помнит, чьи это единицы.
 */
@Injectable()
export class PutBackService {
  private readonly logger = new Logger(PutBackService.name);

  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly inventory: InventoryService,
    private readonly fsm: FsmService,
    private readonly repo: PutBackRepository,
  ) {}

  /**
   * Отказывает, если отправление уже уехало: вернуть на полку то, что у
   * курьера, нельзя — это уже возврат, а не отмена.
   */
  async assertCancellable(orderId: string): Promise<void> {
    const shipment = await this.dataSource
      .getRepository(ShipmentEntity)
      .findOne({ where: { orderId } });
    if (shipment && shipment.status !== 'READY' && shipment.status !== 'CANCELLED') {
      throw new ConflictException(
        `Отправление ${shipment.shipmentNo} уже передано перевозчику (${shipment.status}): ` +
          'отмена возможна только через возврат от перевозчика.',
      );
    }
  }

  async putBack(
    orderId: string,
    warehouseId: string | null,
    reason: string,
    actor: ActorContext,
  ): Promise<PutBackResult> {
    const holdings = await this.holdings(orderId);
    const origins = await this.origins(orderId);

    // Резервы снимает InventoryService.release: он же гасит строки reservations.
    const physical = holdings.filter(
      (holding) => holding.status === 'PICKED' || holding.status === 'PACKED',
    );

    const pkg = await this.dataSource
      .getRepository(PackageEntity)
      .findOne({ where: { orderId } });
    const shipment = await this.dataSource
      .getRepository(ShipmentEntity)
      .findOne({ where: { orderId } });

    if (physical.length === 0 && !pkg && !shipment) {
      return { units: 0, packageCancelled: false, shipmentCancelled: false };
    }
    if (physical.length > 0 && !warehouseId) {
      // Заказ-контейнер склада не имеет и товар не держит — его удерживают
      // дети. Если сюда всё же пришли с остатком, лучше остановиться, чем
      // сочинять склад: движение без склада уйдёт в никуда.
      throw new ConflictException(
        'У заказа нет склада, но за ним числится товар: верните его вручную и разберитесь с причиной.',
      );
    }

    const fallbackBin = warehouseId
      ? await findBinByKind(this.dataSource, warehouseId, 'STORAGE', false)
      : null;

    let units = 0;
    await this.dataSource.transaction(async (em) => {
      for (const holding of physical) {
        for (const slice of this.allocateToOrigins(holding, origins, fallbackBin?.id ?? null)) {
          await this.inventory.applyMovement(
            em,
            {
              skuId: holding.skuId,
              warehouseId: warehouseId as string,
              lotId: holding.lotId,
              from: { binId: holding.binId, status: holding.status },
              to: { binId: slice.binId, status: 'AVAILABLE' },
              quantity: slice.quantity,
              reason: 'PUT_BACK',
              referenceType: OWNER_TYPE,
              referenceId: orderId,
              comment: reason,
            },
            actor,
          );
          units += slice.quantity;
        }
      }

      if (shipment && shipment.status === 'READY') {
        await this.fsm.transition(
          shipmentFsm,
          'READY',
          'CANCELLED',
          this.context('Shipment', shipment.id, actor),
          em,
        );
        await em
          .getRepository(ShipmentEntity)
          .update({ id: shipment.id }, { status: 'CANCELLED', cancelledAt: new Date() });
      }

      if (pkg && pkg.status !== 'CANCELLED') {
        await em
          .getRepository(PackageEntity)
          .update({ id: pkg.id }, { status: 'CANCELLED', cancelledAt: new Date() });
      }

      // Незакрытые строки задания на сборку: за этим товаром идти уже незачем.
      await em
        .getRepository(PickTaskLineEntity)
        .update({ orderId, status: 'PENDING' }, { status: 'CANCELLED' });
    });

    this.logger.log(`Заказ ${orderId}: возвращено на склад ${units} ед.`);
    return {
      units,
      packageCancelled: Boolean(pkg && pkg.status !== 'CANCELLED'),
      shipmentCancelled: Boolean(shipment && shipment.status === 'READY'),
    };
  }

  // ------------------------------------------------------------ внутреннее

  /**
   * Позиция заказа = приход минус расход по его движениям. Именно так, а не по
   * `stock`: остаток количественный и не знает, чьи это единицы.
   */
  private async holdings(orderId: string): Promise<Holding[]> {
    const rows = await this.repo.findHoldings(this.dataSource, OWNER_TYPE, orderId);

    return rows.map((row) => ({
      skuId: row.sku_id,
      lotId: row.lot_id,
      binId: row.bin_id,
      status: row.status,
      quantity: Number(row.qty),
    }));
  }

  /** Ячейки, из которых товар резервировали: туда же его и возвращаем. */
  private async origins(orderId: string): Promise<Origin[]> {
    const rows = await this.repo.findOrigins(this.dataSource, OWNER_TYPE, orderId);

    return rows.map((row) => ({
      skuId: row.sku_id,
      lotId: row.lot_id,
      binId: row.bin_id,
      quantity: Number(row.qty),
    }));
  }

  /**
   * Раскладывает удерживаемое количество по исходным ячейкам, начиная с той,
   * откуда взяли больше всего. Ёмкость ячеек система не знает, поэтому остаток
   * без известного происхождения уходит в первую ячейку хранения склада.
   */
  private allocateToOrigins(
    holding: Holding,
    origins: Origin[],
    fallbackBinId: string | null,
  ): Array<{ binId: string; quantity: number }> {
    const slices: Array<{ binId: string; quantity: number }> = [];
    let remaining = holding.quantity;

    for (const origin of origins) {
      if (remaining === 0) break;
      if (origin.skuId !== holding.skuId) continue;
      if ((origin.lotId ?? null) !== (holding.lotId ?? null)) continue;
      if (origin.quantity === 0) continue;

      const take = Math.min(remaining, origin.quantity);
      slices.push({ binId: origin.binId, quantity: take });
      origin.quantity -= take;
      remaining -= take;
    }

    if (remaining > 0) {
      const binId = fallbackBinId ?? holding.binId;
      slices.push({ binId, quantity: remaining });
    }
    return slices;
  }

  private context(entityType: string, entityId: string, actor: ActorContext) {
    return {
      entityType,
      entityId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
    };
  }
}
