import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  BinLocationEntity,
  OrderEntity,
  PackageEntity,
  PackageItemEntity,
  SellerEntity,
  ShipmentEntity,
  SkuEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { PackingRepository } from '../../infrastructure/database/repositories/packing.repository';
import { IntegrationModule } from '../integration/integration.module';
import { InventoryModule } from '../inventory/inventory.module';
import { PackingController } from '../../presentation/http/packing.controller';
import { PackingService } from './packing.service';

@Module({
  imports: [
    InventoryModule,
    IntegrationModule,
    TypeOrmModule.forFeature([
      PackageEntity,
      PackageItemEntity,
      ShipmentEntity,
      OrderEntity,
      SellerEntity,
      SkuEntity,
      WarehouseEntity,
      BinLocationEntity,
    ]),
  ],
  controllers: [PackingController],
  providers: [PackingService, PackingRepository],
  exports: [PackingService],
})
export class PackingModule {}
