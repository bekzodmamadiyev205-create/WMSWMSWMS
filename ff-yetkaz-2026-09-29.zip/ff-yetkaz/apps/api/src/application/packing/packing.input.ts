/**
 * Формы входных данных зоны упаковки.
 *
 * В @ff/shared по упаковке лежат только контракты ответов (`PackageDto`,
 * `PackingQueueItemDto`, `PackCompletionDto`) — входных форм там нет. Брать их
 * из классов DTO в presentation нельзя: это зависимость вверх, а декораторы
 * class-validator на тех классах нужны разбору HTTP-запроса и к операции
 * упаковки отношения не имеют.
 *
 * Классы DTO получают `implements` этих интерфейсов — расхождение формы тогда
 * ловит сборка.
 */

export interface PackingQueueQueryInput {
  warehouseId?: string;
  limit?: number;
}

export interface CompletePackingInput {
  /** Фактический вес коробки в граммах — целым, как и вес в справочнике. */
  weightG: number;
  lengthMm?: number;
  widthMm?: number;
  heightMm?: number;
  /** Комментарий упаковщика — прежде всего объяснение расхождения по весу. */
  comment?: string;
}
