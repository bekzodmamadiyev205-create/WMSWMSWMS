import {
  ConflictException,
  ForbiddenException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import {
  FF_EVENTS,
  orderFsm,
  OUTBOX_TOPICS,
  SETTING_KEYS,
  STAFF_ROLES,
  type CarrierHandoffPayload,
  type PackCompletionDto,
  type PackageDto,
  type PackageItemDto,
  type PackageShipmentDto,
  type PackingQueueItemDto,
  type ShipmentDto,
  type ShipmentStatus,
} from '@ff/shared';
import { createEvent, EVENT_BUS, type EventBus } from '../../infrastructure/queues/events/event-bus';
import { FsmService } from '../fsm/fsm.service';
import { SettingsService } from '../../infrastructure/config-store/settings.service';
import { resolveSellerScope } from '../scope/seller-scope';
import type { ActorContext } from '../../domain/types/actor';
import { findBinByKind } from '../../infrastructure/database/repositories/bin-location.repository';
import { PackingRepository } from '../../infrastructure/database/repositories/packing.repository';
import {
  OrderEntity,
  PackageEntity,
  PackageItemEntity,
  SellerEntity,
  ShipmentEntity,
  WarehouseEntity,
} from '../../infrastructure/database/entities';
import { OutboxService } from '../../infrastructure/queues/outbox.service';
import { InventoryService } from '../inventory/inventory.service';
import type { LabelData } from '../../infrastructure/labels/label.renderer';
import type { CompletePackingInput, PackingQueueQueryInput } from './packing.input';

const OWNER_TYPE = 'ORDER';
const CARRIER = 'IPOST_GO';

/** Что реально доехало до зоны упаковки: SKU, партия, ячейка, количество. */
interface PickedLine {
  skuId: string;
  lotId: string | null;
  binId: string;
  quantity: number;
}

@Injectable()
export class PackingService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly repo: PackingRepository,
    private readonly inventory: InventoryService,
    private readonly fsm: FsmService,
    private readonly settings: SettingsService,
    private readonly outbox: OutboxService,
    @Inject(EVENT_BUS) private readonly events: EventBus,
  ) {}

  // -------------------------------------------------------------- очередь

  async queue(query: PackingQueueQueryInput, actor: ActorContext): Promise<PackingQueueItemDto[]> {
    this.assertStaff(actor);

    // Содержимое считаем по журналу движений, а не по позициям заказа:
    // при недоборе в коробку уедет не то, что просил канал.
    const rows: Array<Record<string, unknown>> = await this.repo.findPackingQueue(
      this.dataSource,
      query,
    );

    return rows.map((row) => ({
      orderId: row.id as string,
      externalId: row.external_id as string,
      channel: row.channel as string,
      sellerId: row.seller_id as string,
      warehouseId: row.warehouse_id as string,
      status: row.status as string,
      recipientName: row.recipient_name as string,
      address: row.address as string,
      hasShortage: Boolean(row.has_shortage),
      itemsCount: Number(row.items ?? 0),
      unitsCount: Number(row.units ?? 0),
      pickedAt: row.picked_at ? new Date(row.picked_at as string).toISOString() : null,
      packageId: (row.package_id as string | null) ?? null,
      packerUserId: (row.packer_user_id as string | null) ?? null,
    }));
  }

  // -------------------------------------------------------------- упаковка

  /**
   * Взять заказ в упаковку. Состав коробки фиксируется здесь и берётся из
   * журнала движений (`reason = 'PICK'`) — единственного места, где записано,
   * что физически доехало до зоны упаковки. Из позиций заказа его не вывести:
   * при недоборе они расходятся.
   */
  async start(orderId: string, actor: ActorContext): Promise<PackageDto> {
    this.assertStaff(actor);
    const order = await this.loadOrder(orderId);

    const existing = await this.dataSource
      .getRepository(PackageEntity)
      .findOne({ where: { orderId } });
    if (existing) {
      // Возобновление прерванной упаковки: коробка уже открыта.
      if (existing.status === 'OPEN') {
        this.assertCanPack(existing, actor);
        return this.buildPackageDto(existing.id);
      }
      throw new ConflictException(
        existing.status === 'CANCELLED'
          ? 'Заказ отменён — товар возвращён на склад.'
          : 'Заказ уже упакован.',
      );
    }

    if (order.status !== 'PICKED') {
      throw new ConflictException(
        `Упаковать можно собранный заказ, текущий статус: ${order.status}.`,
      );
    }
    if (!order.warehouseId) throw new ConflictException('У заказа не назначен склад.');

    const content = await this.pickedContent(orderId);
    if (content.length === 0) {
      // Заказ дошёл до PICKED, но собрать не удалось ничего (весь недобор без
      // замены). Пустую коробку отправлять нельзя — решение за оператором.
      throw new ConflictException(
        'В зоне упаковки нет ни одной единицы этого заказа: сборка не дала ничего.',
      );
    }

    const expectedWeightG = await this.expectedWeight(content);

    const packageId = await this.dataSource.transaction(async (em) => {
      const packages = em.getRepository(PackageEntity);
      const created = await packages.save(
        packages.create({
          orderId,
          warehouseId: order.warehouseId as string,
          status: 'OPEN',
          expectedWeightG,
          actualWeightG: null,
          weightMismatch: false,
          lengthMm: null,
          widthMm: null,
          heightMm: null,
          packerUserId: actor.user.id,
          comment: null,
          startedAt: new Date(),
          packedAt: null,
        }),
      );

      for (const line of content) {
        await em.getRepository(PackageItemEntity).insert({
          packageId: created.id,
          skuId: line.skuId,
          lotId: line.lotId,
          binId: line.binId,
          quantity: line.quantity,
        });
      }

      await this.fsm.transition(
        orderFsm,
        'PICKED',
        'PACKING',
        this.fsmContext('Order', orderId, actor),
        em,
      );
      await em.getRepository(OrderEntity).update({ id: orderId }, { status: 'PACKING' });

      return created.id;
    });

    return this.buildPackageDto(packageId);
  }

  /**
   * Закрыть коробку: взвешивание и перевод собранного в PACKED.
   *
   * Расхождение веса больше допуска помечается флагом, но упаковку не
   * блокирует (по ТЗ — контроль, а не запрет): физически коробка уже собрана,
   * а разбираться с расхождением — работа оператора, не упаковщика.
   */
  async complete(
    orderId: string,
    dto: CompletePackingInput,
    actor: ActorContext,
  ): Promise<PackCompletionDto> {
    this.assertStaff(actor);
    const order = await this.loadOrder(orderId);

    const pkg = await this.dataSource.getRepository(PackageEntity).findOne({ where: { orderId } });
    if (!pkg) throw new NotFoundException('Упаковка не начата.');
    this.assertCanPack(pkg, actor);
    if (pkg.status !== 'OPEN') {
      throw new ConflictException(
        pkg.status === 'CANCELLED' ? 'Заказ отменён — упаковка прекращена.' : 'Коробка уже закрыта.',
      );
    }
    if (order.status !== 'PACKING') {
      throw new ConflictException(`Заказ в статусе ${order.status}: закрывать нечего.`);
    }

    const items = await this.dataSource
      .getRepository(PackageItemEntity)
      .find({ where: { packageId: pkg.id } });

    const tolerancePct = await this.settings.getNumber(SETTING_KEYS.WEIGHT_TOLERANCE_PCT);
    const expected = pkg.expectedWeightG;
    const deviationPct =
      expected === null ? null : ((dto.weightG - expected) / expected) * 100;
    const weightMismatch = deviationPct !== null && Math.abs(deviationPct) > tolerancePct;

    // Упакованное уезжает в зону отгрузки, если она заведена; иначе остаётся
    // в зоне упаковки, но уже в статусе PACKED — вне доступного остатка.
    const shippingBin = await findBinByKind(this.dataSource, pkg.warehouseId, 'SHIPPING', false);

    await this.dataSource.transaction(async (em) => {
      for (const item of items) {
        await this.inventory.applyMovement(
          em,
          {
            skuId: item.skuId,
            warehouseId: pkg.warehouseId,
            lotId: item.lotId,
            from: { binId: item.binId, status: 'PICKED' },
            to: { binId: shippingBin?.id ?? item.binId, status: 'PACKED' },
            quantity: item.quantity,
            reason: 'PACK',
            referenceType: OWNER_TYPE,
            referenceId: orderId,
          },
          actor,
        );
      }

      await em.getRepository(PackageEntity).update(
        { id: pkg.id },
        {
          status: 'PACKED',
          actualWeightG: dto.weightG,
          weightMismatch,
          lengthMm: dto.lengthMm ?? null,
          widthMm: dto.widthMm ?? null,
          heightMm: dto.heightMm ?? null,
          comment: dto.comment ?? null,
          packedAt: new Date(),
        },
      );

      await this.fsm.transition(
        orderFsm,
        'PACKING',
        'PACKED',
        this.fsmContext('Order', orderId, actor),
        em,
      );
      await em.getRepository(OrderEntity).update({ id: orderId }, { status: 'PACKED' });
    });

    await this.events.publish(
      createEvent(
        FF_EVENTS.PACK_COMPLETED,
        {
          orderId,
          packageId: pkg.id,
          packerUserId: actor.user.id,
          weightKg: (dto.weightG / 1000).toFixed(3),
          weightMismatch,
        },
        { actorUserId: actor.user.id, correlationId: actor.correlationId },
      ),
    );

    return {
      package: await this.buildPackageDto(pkg.id),
      expectedWeightG: expected,
      actualWeightG: dto.weightG,
      deviationPct: deviationPct === null ? null : Number(deviationPct.toFixed(2)),
      tolerancePct,
      weightMismatch,
    };
  }

  // ------------------------------------------------------------ отправление

  /**
   * Оформление отправления — конец зоны ответственности FF: заказ переходит в
   * READY_TO_SHIP и ждёт передачи в iPost GO.
   *
   * Идемпотентно по смыслу, а не только по заголовку: повторный вызов (та же
   * этикетка печатается второй раз) возвращает существующее отправление и
   * ничего не переводит.
   */
  async issueShipment(packageId: string, actor: ActorContext): Promise<ShipmentDto> {
    this.assertStaff(actor);
    const pkg = await this.loadPackage(packageId);

    const existing = await this.dataSource
      .getRepository(ShipmentEntity)
      .findOne({ where: { packageId } });
    if (existing) return this.mapShipment(existing);

    if (pkg.status !== 'PACKED') {
      throw new ConflictException('Отправление оформляется по закрытой коробке.');
    }
    const order = await this.loadOrder(pkg.orderId);
    if (order.status !== 'PACKED') {
      throw new ConflictException(`Заказ в статусе ${order.status}: отправление не оформить.`);
    }

    // Данные для перевозчика собираем ДО транзакции: внутри она должна делать
    // только записи, а не ходить за справочниками.
    const handoff = await this.handoffContext(pkg, order);

    const shipment = await this.dataSource.transaction(async (em) => {
      // Номер выдаёт DEFAULT последовательности — приложение его не назначает.
      const rows: Array<Record<string, unknown>> = await this.repo.createShipment(em, [
        pkg.orderId,
        pkg.id,
        CARRIER,
        pkg.actualWeightG,
        order.codAmount,
        order.currency,
      ]);

      await this.fsm.transition(
        orderFsm,
        'PACKED',
        'READY_TO_SHIP',
        this.fsmContext('Order', pkg.orderId, actor),
        em,
      );
      await em.getRepository(OrderEntity).update({ id: pkg.orderId }, { status: 'READY_TO_SHIP' });

      const shipmentNo = rows[0].shipment_no as string;
      await this.repo.recordInitialStatusEvent(em, [
        rows[0].id as string,
        'Отправление оформлено на складе',
      ]);

      // Постановка в очередь — в ЭТОЙ же транзакции: иначе возможен разрыв,
      // когда отправление создано, а перевозчик о нём не узнал (или наоборот).
      await this.outbox.enqueue(em, {
        carrierCode: CARRIER,
        topic: OUTBOX_TOPICS.SHIPMENT_READY,
        entityType: 'Shipment',
        entityId: rows[0].id as string,
        payload: { ...handoff, shipmentNo },
        correlationId: actor.correlationId,
      });

      return rows[0];
    });

    const dto: ShipmentDto = {
      id: shipment.id as string,
      orderId: shipment.order_id as string,
      packageId: shipment.package_id as string,
      shipmentNo: shipment.shipment_no as string,
      status: shipment.status as ShipmentStatus,
      carrier: shipment.carrier as string,
      trackingNo: (shipment.tracking_no as string | null) ?? null,
      weightG: Number(shipment.weight_g),
      codAmount: (shipment.cod_amount as string | null) ?? null,
      currency: (shipment.currency as string | null) ?? null,
      handedOverAt: null,
      createdAt: new Date(shipment.created_at as string).toISOString(),
    };

    await this.events.publish(
      createEvent(
        FF_EVENTS.SHIPMENT_READY,
        {
          shipmentId: dto.id,
          orderId: dto.orderId,
          trackingNo: dto.trackingNo,
          codAmount: dto.codAmount,
        },
        { actorUserId: actor.user.id, correlationId: actor.correlationId },
      ),
    );

    return dto;
  }

  /** Данные этикетки. Рендер — отдельная чистая функция, БД не знает о PDF. */
  async labelData(packageId: string, actor: ActorContext): Promise<LabelData> {
    this.assertStaff(actor);
    const pkg = await this.loadPackage(packageId);

    const shipment = await this.dataSource
      .getRepository(ShipmentEntity)
      .findOne({ where: { packageId } });
    if (!shipment) {
      throw new ConflictException('Отправление не оформлено — печатать нечего.');
    }

    const order = await this.loadOrder(pkg.orderId);
    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: order.sellerId } });
    const warehouse = await this.dataSource
      .getRepository(WarehouseEntity)
      .findOne({ where: { id: pkg.warehouseId } });

    const rows: Array<{ sku_code: string; name: string; quantity: number }> =
      await this.repo.findLabelItems(this.dataSource, packageId);

    return {
      shipmentNo: shipment.shipmentNo,
      orderCode: order.orderCode,
      trackingNo: shipment.trackingNo,
      carrier: shipment.carrier,
      orderExternalId: order.externalId,
      channel: order.channel,
      sellerName: seller?.legalName ?? '—',
      warehouseCode: warehouse?.code ?? '—',
      recipientName: order.recipientName,
      recipientPhone: order.recipientPhone,
      address: order.address,
      region: order.region,
      weightG: shipment.weightG,
      lengthMm: pkg.lengthMm,
      widthMm: pkg.widthMm,
      heightMm: pkg.heightMm,
      codAmount: shipment.codAmount,
      currency: shipment.currency,
      items: rows.map((row) => ({
        skuCode: row.sku_code,
        name: row.name,
        quantity: Number(row.quantity),
      })),
      printedAt: new Date(),
    };
  }

  // ---------------------------------------------------------------- чтение

  async getPackage(packageId: string, actor: ActorContext): Promise<PackageDto> {
    this.assertStaff(actor);
    await this.loadPackage(packageId);
    return this.buildPackageDto(packageId);
  }

  async getShipmentByPackage(
    packageId: string,
    actor: ActorContext,
  ): Promise<PackageShipmentDto> {
    this.assertStaff(actor);
    const shipment = await this.dataSource
      .getRepository(ShipmentEntity)
      .findOne({ where: { packageId } });
    // Конверт, а не голый null: Nest отдаёт null пустым телом, а пустое тело
    // клиенту не разобрать как JSON.
    return { shipment: shipment ? this.mapShipment(shipment) : null };
  }

  // ------------------------------------------------------------ внутреннее

  /** Всё, что перевозчику нужно знать об отправлении, кроме его номера. */
  private async handoffContext(
    pkg: PackageEntity,
    order: OrderEntity,
  ): Promise<Omit<CarrierHandoffPayload, 'shipmentNo'>> {
    const seller = await this.dataSource
      .getRepository(SellerEntity)
      .findOne({ where: { id: order.sellerId } });
    const warehouse = await this.dataSource
      .getRepository(WarehouseEntity)
      .findOne({ where: { id: pkg.warehouseId } });

    const rows: Array<{ sku_code: string; name: string; quantity: number }> =
      await this.repo.findHandoffItems(this.dataSource, pkg.id);

    return {
      orderExternalId: order.externalId,
      sellerCode: seller?.code ?? '—',
      warehouseCode: warehouse?.code ?? '—',
      recipientName: order.recipientName,
      recipientPhone: order.recipientPhone,
      address: order.address,
      region: order.region,
      weightG: pkg.actualWeightG as number,
      lengthMm: pkg.lengthMm,
      widthMm: pkg.widthMm,
      heightMm: pkg.heightMm,
      codAmount: order.codAmount,
      currency: order.currency,
      items: rows.map((row) => ({
        skuCode: row.sku_code,
        name: row.name,
        quantity: Number(row.quantity),
      })),
    };
  }

  private async pickedContent(orderId: string): Promise<PickedLine[]> {
    const rows: Array<{
      sku_id: string;
      lot_id: string | null;
      bin_id: string;
      quantity: number;
    }> = await this.repo.findPickedContent(this.dataSource, [OWNER_TYPE, orderId]);

    return rows.map((row) => ({
      skuId: row.sku_id,
      lotId: row.lot_id,
      binId: row.bin_id,
      quantity: Number(row.quantity),
    }));
  }

  /**
   * Расчётный вес — сумма весов из справочника. null, если хотя бы у одного
   * SKU вес не заполнен: тогда сравнивать не с чем, и лучше честно не
   * проверять, чем проверять по заниженной сумме.
   */
  private async expectedWeight(content: PickedLine[]): Promise<number | null> {
    const skuIds = [...new Set(content.map((line) => line.skuId))];
    const rows: Array<{ id: string; weight_g: number | null }> = await this.repo.findSkuWeights(
      this.dataSource,
      skuIds,
    );
    const weights = new Map(rows.map((row) => [row.id, row.weight_g]));

    let total = 0;
    for (const line of content) {
      const weight = weights.get(line.skuId);
      if (weight === null || weight === undefined) return null;
      total += weight * line.quantity;
    }
    return total;
  }

  private assertStaff(actor: ActorContext): void {
    // Упаковка — внутренняя операция склада, селлеру не показываем.
    resolveSellerScope(actor.user);
    if (!actor.user.roles.some((role) => STAFF_ROLES.includes(role))) {
      throw new ForbiddenException('Упаковка доступна только сотрудникам склада.');
    }
  }

  private assertCanPack(pkg: PackageEntity, actor: ActorContext): void {
    const isPrivileged = actor.user.roles.some(
      (role) => role === 'ADMIN' || role === 'WAREHOUSE_OPERATOR',
    );
    if (isPrivileged) return;
    if (pkg.packerUserId !== actor.user.id) {
      throw new ForbiddenException('Эту коробку упаковывает другой сотрудник.');
    }
  }

  private fsmContext(entityType: string, entityId: string, actor: ActorContext) {
    return {
      entityType,
      entityId,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
    };
  }

  private async loadOrder(orderId: string): Promise<OrderEntity> {
    const order = await this.dataSource
      .getRepository(OrderEntity)
      .findOne({ where: { id: orderId } });
    if (!order) throw new NotFoundException('Заказ не найден.');
    return order;
  }

  private async loadPackage(packageId: string): Promise<PackageEntity> {
    const pkg = await this.dataSource
      .getRepository(PackageEntity)
      .findOne({ where: { id: packageId } });
    if (!pkg) throw new NotFoundException('Упаковка не найдена.');
    return pkg;
  }

  private mapShipment(shipment: ShipmentEntity): ShipmentDto {
    return {
      id: shipment.id,
      orderId: shipment.orderId,
      packageId: shipment.packageId,
      shipmentNo: shipment.shipmentNo,
      status: shipment.status,
      carrier: shipment.carrier,
      trackingNo: shipment.trackingNo,
      weightG: Number(shipment.weightG),
      codAmount: shipment.codAmount,
      currency: shipment.currency,
      handedOverAt: shipment.handedOverAt ? shipment.handedOverAt.toISOString() : null,
      createdAt: shipment.createdAt.toISOString(),
    };
  }

  private async buildPackageDto(packageId: string): Promise<PackageDto> {
    const pkg = await this.loadPackage(packageId);

    const rows: Array<{
      id: string;
      sku_id: string;
      sku_code: string;
      sku_name: string;
      lot_id: string | null;
      quantity: number;
      weight_g: number | null;
    }> = await this.repo.findPackageItems(this.dataSource, packageId);

    const items: PackageItemDto[] = rows.map((row) => ({
      id: row.id,
      skuId: row.sku_id,
      skuCode: row.sku_code,
      skuName: row.sku_name,
      lotId: row.lot_id,
      quantity: Number(row.quantity),
      unitWeightG: row.weight_g === null ? null : Number(row.weight_g),
    }));

    return {
      id: pkg.id,
      orderId: pkg.orderId,
      warehouseId: pkg.warehouseId,
      status: pkg.status,
      expectedWeightG: pkg.expectedWeightG === null ? null : Number(pkg.expectedWeightG),
      actualWeightG: pkg.actualWeightG === null ? null : Number(pkg.actualWeightG),
      weightMismatch: pkg.weightMismatch,
      weightTolerancePct: await this.settings.getNumber(SETTING_KEYS.WEIGHT_TOLERANCE_PCT),
      lengthMm: pkg.lengthMm,
      widthMm: pkg.widthMm,
      heightMm: pkg.heightMm,
      packerUserId: pkg.packerUserId,
      comment: pkg.comment,
      startedAt: pkg.startedAt.toISOString(),
      packedAt: pkg.packedAt ? pkg.packedAt.toISOString() : null,
      items,
    };
  }
}
