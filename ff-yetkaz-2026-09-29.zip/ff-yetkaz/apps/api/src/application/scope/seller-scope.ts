import { ForbiddenException } from '@nestjs/common';
import { STAFF_ROLES, type AuthPrincipal } from '@ff/shared';

/**
 * Область видимости данных селлера.
 *
 * Возвращает `null` для сотрудников оператора (видят всё) и `seller_id` для
 * роли SELLER. Пользователь без ролей не получает доступ вообще: пустой скоуп
 * молча означал бы «видит всё», а это худший из возможных вариантов по умолчанию.
 */
export function resolveSellerScope(user: AuthPrincipal | undefined): string | null {
  if (!user) throw new ForbiddenException('Требуется авторизация.');

  if (user.roles.some((role) => STAFF_ROLES.includes(role))) return null;

  if (user.roles.includes('SELLER')) {
    if (!user.sellerId) {
      throw new ForbiddenException('У учётной записи селлера не задан seller_id.');
    }
    return user.sellerId;
  }

  throw new ForbiddenException('У учётной записи нет ролей, дающих доступ к данным.');
}

/** true, если запись селлера доступна этому пользователю. */
export function isSellerVisible(scope: string | null, sellerId: string): boolean {
  return scope === null || scope === sellerId;
}
