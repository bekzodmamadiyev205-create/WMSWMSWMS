import { Controller, Get, Module, UseGuards } from '@nestjs/common';
import type { AccrualResultDto, OutboxDispatchResultDto } from '@ff/shared';
import { AccrualService } from '../billing/accrual.service';
import { BillingModule } from '../billing/billing.module';
import { Actor, Public } from '../../presentation/http/decorators';
import type { ActorContext } from '../../domain/types/actor';
import { IntegrationModule } from '../integration/integration.module';
import { OutboxService } from '../../infrastructure/queues/outbox.service';
import { CronGuard } from '../../presentation/http/guards/cron.guard';

/**
 * Точки входа для планировщика.
 *
 * **GET, а не POST** — не по идеологии, а по требованию платформы: Vercel Cron
 * умеет ходить только GET-запросом. Обе операции идемпотентны (захват очереди
 * идёт под блокировкой, срез — через upsert), поэтому повторный вызов безопасен
 * и требование REST о безопасности GET здесь не нарушается по существу.
 *
 * `@Public` снимает проверку JWT — вместо неё `CronGuard` сверяет общий секрет.
 */
@Controller('cron')
@UseGuards(CronGuard)
class CronController {
  constructor(
    private readonly outbox: OutboxService,
    private readonly accrual: AccrualService,
  ) {}

  @Public()
  @Get('outbox-dispatch')
  dispatch(): Promise<OutboxDispatchResultDto> {
    return this.outbox.dispatch();
  }

  @Public()
  @Get('storage-snapshot')
  snapshot(): Promise<{ date: string; sellers: number }> {
    return this.accrual.snapshotStorage(new Date().toISOString().slice(0, 10));
  }

  /**
   * Ночной прогон начислений за прошедшие сутки. Идемпотентен по
   * `charges.source_key`: пропущенная ночь досчитается следующей.
   */
  @Public()
  @Get('accrue-yesterday')
  accrue(@Actor() actor: ActorContext): Promise<AccrualResultDto> {
    const to = new Date();
    to.setUTCHours(0, 0, 0, 0);
    const from = new Date(to.getTime() - 2 * 24 * 60 * 60 * 1000);
    // Окно с запасом в двое суток: если ночь пропущена, следующий прогон
    // подберёт её сам, а лишнего не начислит.
    return this.accrual.accrue(from.toISOString(), new Date().toISOString(), actor);
  }
}

@Module({
  imports: [IntegrationModule, BillingModule],
  controllers: [CronController],
  providers: [CronGuard],
})
export class CronModule {}
