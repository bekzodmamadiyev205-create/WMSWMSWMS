import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppSettingEntity, CarrierEntity } from '../../infrastructure/database/entities';
import { CarriersService } from '../../infrastructure/config-store/carriers.service';
import { ConfigStoreController } from '../../presentation/http/config-store.controller';
import { SettingsService } from '../../infrastructure/config-store/settings.service';

/**
 * Глобальный: настройки нужны почти каждому модулю, а импортировать один и тот
 * же модуль в десяти местах — шум без пользы.
 */
@Global()
@Module({
  imports: [TypeOrmModule.forFeature([AppSettingEntity, CarrierEntity])],
  controllers: [ConfigStoreController],
  providers: [SettingsService, CarriersService],
  exports: [SettingsService, CarriersService],
})
export class ConfigStoreModule {}
