import 'reflect-metadata';
import { Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { API_PREFIX, configureApp } from './bootstrap';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);
  const config = app.get(ConfigService);

  configureApp(app, config);

  const port = config.get<number>('PORT') ?? 3001;
  await app.listen(port);
  new Logger('Bootstrap').log(`FF api слушает http://localhost:${port}/${API_PREFIX}`);
}

void bootstrap();
