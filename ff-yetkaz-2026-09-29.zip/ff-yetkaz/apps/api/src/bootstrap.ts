import { ValidationPipe, type INestApplication } from '@nestjs/common';
import type { ConfigService } from '@nestjs/config';
import { json } from 'express';
import { AllExceptionsFilter } from './presentation/http/filters/all-exceptions.filter';
import type { FfRequest } from './presentation/http/types/request';

export const API_PREFIX = 'api/v1';

/**
 * Единая настройка приложения для прод-запуска и для тестов.
 * Вынесена отдельно, чтобы e2e поднимал ровно тот же контур (префикс, валидация,
 * конверт ошибок), а не свою упрощённую копию, которая со временем разъедется.
 */
export function configureApp(app: INestApplication, config: ConfigService): void {
  // Свой json-парсер ставится ДО инициализации Nest, поэтому отрабатывает первым
  // и успевает сохранить сырое тело. Штатный парсер Nest увидит уже разобранный
  // запрос и не станет читать поток повторно. Без сырых байтов не проверить
  // подпись входящего вебхука: пересборка JSON их не восстанавливает.
  app.use(
    json({
      limit: '1mb',
      verify: (request, _response, buffer) => {
        (request as FfRequest).rawBody = Buffer.from(buffer);
      },
    }),
  );

  app.setGlobalPrefix(API_PREFIX);
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );
  app.useGlobalFilters(new AllExceptionsFilter());
  app.enableCors({
    origin: config.get<string[]>('CORS_ORIGINS') ?? [],
    credentials: true,
  });
}
