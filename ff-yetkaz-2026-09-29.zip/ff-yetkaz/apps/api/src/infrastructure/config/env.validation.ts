import { randomBytes } from 'node:crypto';
import { Logger } from '@nestjs/common';

export type NodeEnv = 'development' | 'test' | 'production';

export interface FfEnv extends Record<string, unknown> {
  NODE_ENV: NodeEnv;
  PORT: number;
  DATABASE_URL: string;
  JWT_SECRET: string;
  JWT_TTL_HOURS: number;
  CORS_ORIGINS: string[];
  IDEMPOTENCY_TTL_HOURS: number;
}

function requireString(raw: Record<string, unknown>, key: string): string {
  const value = raw[key];
  if (typeof value !== 'string' || value.trim() === '') {
    throw new Error(`Переменная окружения ${key} обязательна.`);
  }
  return value.trim();
}

function optionalNumber(raw: Record<string, unknown>, key: string, fallback: number): number {
  const value = raw[key];
  if (value === undefined || value === '') return fallback;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error(`Переменная окружения ${key} должна быть положительным числом, получено: ${String(value)}`);
  }
  return parsed;
}

/**
 * Валидация окружения при старте. В production — fail-closed: без JWT_SECRET
 * приложение не поднимается. В dev/test без секрета генерируется эфемерный
 * ключ на процесс (токены инвалидируются при рестарте) с громким предупреждением.
 *
 * ВАЖНО: возвращаются и необъявленные здесь переменные. `ConfigModule` кладёт в
 * `process.env` ровно то, что вернул валидатор, — отбросив «лишнее», мы сделали
 * бы невидимыми секреты перевозчиков (`FF_*_SECRET`), которые по построению
 * не могут быть перечислены заранее: их набор задаётся строками таблицы
 * `carriers`, а не кодом.
 */
export function validateEnv(raw: Record<string, unknown>): FfEnv {
  const nodeEnv = (raw.NODE_ENV as NodeEnv | undefined) ?? 'development';
  if (!['development', 'test', 'production'].includes(nodeEnv)) {
    throw new Error(`NODE_ENV должен быть development | test | production, получено: ${nodeEnv}`);
  }

  let jwtSecret = typeof raw.JWT_SECRET === 'string' ? raw.JWT_SECRET.trim() : '';
  if (nodeEnv === 'production') {
    if (jwtSecret.length < 32) {
      throw new Error('JWT_SECRET обязателен в production и должен быть не короче 32 символов (fail-closed).');
    }
  } else if (jwtSecret === '') {
    jwtSecret = `dev-ephemeral-${randomBytes(32).toString('hex')}`;
    new Logger('EnvValidation').warn(
      'JWT_SECRET не задан — использую эфемерный dev-секрет; выданные токены умрут при рестарте.',
    );
  }

  const corsRaw = typeof raw.CORS_ORIGINS === 'string' ? raw.CORS_ORIGINS : 'http://localhost:5173';

  return {
    ...raw,
    NODE_ENV: nodeEnv,
    PORT: optionalNumber(raw, 'PORT', 3001),
    DATABASE_URL: requireString(raw, 'DATABASE_URL'),
    JWT_SECRET: jwtSecret,
    JWT_TTL_HOURS: optionalNumber(raw, 'JWT_TTL_HOURS', 12),
    CORS_ORIGINS: corsRaw
      .split(',')
      .map((o) => o.trim())
      .filter(Boolean),
    IDEMPOTENCY_TTL_HOURS: optionalNumber(raw, 'IDEMPOTENCY_TTL_HOURS', 24),
  };
}
