import { Injectable } from '@nestjs/common';
import type { Response } from 'express';
import ExcelJS from 'exceljs';

/**
 * Выгрузка в Excel — потоком, а не буфером.
 *
 * Существующая выгрузка счёта собирает книгу целиком в памяти
 * (`workbook.xlsx.writeBuffer()`). Для счёта это нормально: там десятки строк.
 * Для выгрузки остатков или заказов за квартал — нет: инстанс на 1 ГБ ляжет
 * на первом же селлере с большим каталогом, причём ляжет не в разработке.
 * `WorkbookWriter` пишет прямо в ответ и не держит книгу целиком.
 *
 * Обратная сторона: `Content-Length` заранее неизвестен, поэтому его не
 * ставим — браузер покажет загрузку без процентов. Это дешевле, чем падение.
 */

export interface XlsxColumn<T> {
  header: string;
  key: string;
  width?: number;
  /** Числа отдаём числами, а не строками: иначе по выгрузке нельзя построить
   *  сводную — Excel считает такой столбец текстом. */
  value: (row: T) => string | number | Date | null;
  numFmt?: string;
}

export interface XlsxExportOptions<T> {
  filename: string;
  sheetName: string;
  columns: Array<XlsxColumn<T>>;
  /** Источник строк. Асинхронный итератор — чтобы выгрузка шла страницами и
   *  не материализовала весь набор в памяти. */
  rows: AsyncIterable<T[]> | Iterable<T[]>;
  title?: string;
  /** Строки-подписи над шапкой: период, фильтры, кто и когда выгрузил. */
  notes?: string[];
}

const MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

@Injectable()
export class XlsxService {
  async stream<T>(response: Response, options: XlsxExportOptions<T>): Promise<void> {
    // Имя файла в двух видах: ASCII-запасное для старых клиентов и UTF-8 по
    // RFC 5987 — иначе кириллица в имени превращается в мусор.
    const safeName = options.filename.replace(/[^\w.-]+/g, '_');
    response.setHeader('Content-Type', MIME);
    response.setHeader(
      'Content-Disposition',
      `attachment; filename="${safeName}"; filename*=UTF-8''${encodeURIComponent(options.filename)}`,
    );
    // Прокси, кеширующий выгрузку с фильтрами, отдаст чужой отчёт следующему.
    response.setHeader('Cache-Control', 'no-store');

    const workbook = new ExcelJS.stream.xlsx.WorkbookWriter({
      stream: response,
      useStyles: true,
      useSharedStrings: false,
    });
    workbook.creator = 'Yetkaz Express FF';
    workbook.created = new Date();

    // 31 символ — жёсткий предел Excel на имя листа; более длинное имя книга
    // не открывает вовсе.
    const leading: string[][] = [];
    if (options.title) leading.push([options.title]);
    for (const note of options.notes ?? []) leading.push([note]);
    if (leading.length) leading.push([]);
    const headerRowNumber = leading.length + 1;

    // Закрепление шапки задаётся ПРИ СОЗДАНИИ листа: у потокового
    // WorksheetWriter свойство `views` доступно только на чтение, и присвоение
    // ему роняет выгрузку уже после отправки заголовков ответа — то есть
    // обрывом соединения без внятной ошибки.
    const sheet = workbook.addWorksheet(options.sheetName.slice(0, 31), {
      views: [{ state: 'frozen', ySplit: headerRowNumber }],
    });

    // Ширины и форматы — ДО первой строки: блок <cols> уходит в файл вместе
    // с первой же записью, после этого менять его поздно. `header` здесь не
    // указываем намеренно — иначе exceljs сам напишет шапку в первую строку,
    // а над ней должны стоять заголовок отчёта и параметры фильтра.
    sheet.columns = options.columns.map((column) => ({
      key: column.key,
      width: column.width ?? 18,
      style: column.numFmt ? { numFmt: column.numFmt } : {},
    }));

    for (const row of leading) {
      const added = sheet.addRow(row);
      if (row.length) {
        added.font =
          row[0] === options.title
            ? { bold: true, size: 14 }
            : { color: { argb: 'FF666666' }, size: 10 };
      }
      added.commit();
    }

    const headerRow = sheet.addRow(options.columns.map((column) => column.header));
    headerRow.font = { bold: true };
    headerRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFEEF0F7' },
    };
    headerRow.commit();

    let count = 0;
    for await (const chunk of asAsync(options.rows)) {
      for (const item of chunk) {
        sheet.addRow(options.columns.map((column) => column.value(item))).commit();
        count += 1;
      }
    }

    const totals = sheet.addRow([`Всего строк: ${count}`]);
    totals.font = { bold: true };
    totals.commit();

    sheet.commit();
    await workbook.commit();
  }
}

async function* asAsync<T>(source: AsyncIterable<T> | Iterable<T>): AsyncIterable<T> {
  if (Symbol.asyncIterator in Object(source)) {
    yield* source as AsyncIterable<T>;
    return;
  }
  for (const item of source as Iterable<T>) yield item;
}
