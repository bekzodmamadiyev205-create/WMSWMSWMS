import { Global, Module } from '@nestjs/common';
import { XlsxService } from './xlsx.service';

/**
 * Выгрузка нужна почти каждому списку, а состояния у неё нет — поэтому модуль
 * глобальный: иначе каждый доменный модуль импортировал бы его ради одного
 * провайдера, и половина забыла бы.
 */
@Global()
@Module({
  providers: [XlsxService],
  exports: [XlsxService],
})
export class ExportModule {}
