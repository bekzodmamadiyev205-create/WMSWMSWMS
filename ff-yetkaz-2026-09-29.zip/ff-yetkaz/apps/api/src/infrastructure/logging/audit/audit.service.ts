import { Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import type { AuditAction } from '@ff/shared';
import { AuditEventEntity } from '../../database/entities';

export interface AuditInput {
  action: AuditAction;
  entityType: string;
  entityId?: string | null;
  actorUserId?: string | null;
  actorRole?: string | null;
  before?: Record<string, unknown> | null;
  after?: Record<string, unknown> | null;
  correlationId?: string | null;
  ip?: string | null;
}

@Injectable()
export class AuditService {
  private readonly logger = new Logger(AuditService.name);

  constructor(@InjectDataSource() private readonly dataSource: DataSource) {}

  /**
   * Пишет запись аудита.
   *
   * Без `manager` запись идёт по отдельному соединению из пула, то есть переживает
   * откат вызывающей транзакции. Это осознанно: попытка недопустимого перехода или
   * отказ авторизации должны остаться в журнале именно тогда, когда бизнес-операция
   * не состоялась. Если запись обязана быть атомарной с бизнес-данными —
   * передавайте `manager` вызывающей транзакции явно.
   */
  async record(input: AuditInput, manager?: EntityManager): Promise<void> {
    const em = manager ?? this.dataSource.manager;
    const repo = em.getRepository(AuditEventEntity);
    // create + save, а не insert: типы insert() в TypeORM не описывают jsonb-колонки.
    await repo.save(
      repo.create({
        action: input.action,
        entityType: input.entityType,
        entityId: input.entityId ?? null,
        actorUserId: input.actorUserId ?? null,
        actorRole: input.actorRole ?? null,
        before: input.before ?? null,
        after: input.after ?? null,
        correlationId: input.correlationId ?? null,
        ip: input.ip ?? null,
      }),
    );
  }

  /**
   * Вариант для путей, где падение аудита не должно ронять сам запрос
   * (например, запись отказа авторизации). Ошибка логируется, но не пробрасывается.
   */
  async recordSafe(input: AuditInput, manager?: EntityManager): Promise<void> {
    try {
      await this.record(input, manager);
    } catch (error) {
      this.logger.error(
        `Не удалось записать аудит ${input.action}/${input.entityType}: ${String(error)}`,
      );
    }
  }
}
