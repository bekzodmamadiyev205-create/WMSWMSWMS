import { Injectable } from '@nestjs/common';
import { CarriersService } from '../../config-store/carriers.service';
import { signPayload } from './signature';

/** Отправление, которое передаётся перевозчику. */
export interface CarrierHandoffMessage {
  /** Код перевозчика в справочнике `carriers`. */
  carrierCode: string;
  topic: string;
  entityId: string;
  payload: unknown;
  correlationId: string | null;
}

/**
 * Единственная точка выхода наружу по HTTP во всём бэкенде.
 *
 * Слой интеграций отвечает за протокол: адрес, заголовки, подпись, таймаут и
 * разбор неуспешного ответа. Что именно передаётся и как обрабатывать отказ —
 * не его дело: доставку заказывает очередь, повторы считает очередь.
 */
@Injectable()
export class CarrierGateway {
  constructor(private readonly carriers: CarriersService) {}

  /**
   * Передача отправления перевозчику. Успех — молчание; любой отказ — исключение,
   * по которому вызывающий решает, повторять ли попытку.
   *
   * Перевозчик разрешается ЗДЕСЬ, а не в очереди, хотя раньше это делал
   * `OutboxService`. Всё, что возвращает `resolve()`, — реквизиты HTTP-вызова:
   * базовый адрес, путь передачи, таймаут и секрет подписи. Разреши очередь
   * перевозчика сама — ей пришлось бы принимать и передавать сюда секрет и
   * адрес, то есть она осталась бы осведомлена о протоколе, ради ухода от
   * которого перенос и делался. Очередь знает только код перевозчика.
   */
  async handOver(message: CarrierHandoffMessage): Promise<void> {
    const { entity, secret } = await this.carriers.resolve(message.carrierCode);

    const body = Buffer.from(JSON.stringify(message.payload), 'utf8');
    const timestamp = Math.floor(Date.now() / 1000);
    const url = `${entity.baseUrl.replace(/\/+$/, '')}${entity.handoffPath}`;

    // AbortController, а не только опция таймаута fetch: зависший сосед не
    // должен держать воркер до бесконечности.
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), entity.timeoutMs);
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-FF-Signature': signPayload(secret, body, timestamp),
          'X-FF-Topic': message.topic,
          'X-FF-Delivery-Id': `${message.topic}:${message.entityId}`,
          ...(message.correlationId ? { 'X-Request-Id': message.correlationId } : {}),
        },
        body,
        signal: controller.signal,
      });

      if (!response.ok) {
        const text = (await response.text().catch(() => '')).slice(0, 300);
        // Текст дословный: по нему очередь отличает отказ перевозчика от
        // собственной аварии, и он же уходит в `integration_outbox.last_error`.
        throw new Error(`Перевозчик ответил ${response.status}: ${text}`);
      }
    } finally {
      clearTimeout(timer);
    }
  }
}
