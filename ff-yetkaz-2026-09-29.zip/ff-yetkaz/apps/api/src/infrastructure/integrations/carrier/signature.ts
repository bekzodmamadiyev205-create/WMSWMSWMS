import { createHmac, timingSafeEqual } from 'node:crypto';

export const SIGNATURE_HEADER = 'x-ff-signature';
export const DELIVERY_HEADER = 'x-ff-delivery-id';

const SCHEME_VERSION = 'v1';

export class SignatureError extends Error {}

/**
 * Подпись тела запроса: `t=<unix>,v1=<hmac-sha256(t + '.' + body)>`.
 *
 * Метка времени входит В ПОДПИСЬ, а не идёт рядом: иначе перехваченный запрос
 * можно было бы бесконечно повторять, подменив время. Тело подписывается
 * побайтно — пересобранный из объекта JSON даёт другие байты.
 */
export function signPayload(secret: string, body: Buffer, timestampSeconds: number): string {
  const digest = createHmac('sha256', secret)
    .update(`${timestampSeconds}.`)
    .update(body)
    .digest('hex');
  return `t=${timestampSeconds},${SCHEME_VERSION}=${digest}`;
}

export interface VerifyOptions {
  secret: string;
  body: Buffer;
  header: string | undefined;
  /** Допустимый возраст подписи, сек. */
  toleranceSeconds: number;
  /** Подставляется в тестах; в проде — текущее время. */
  nowSeconds?: number;
}

/**
 * Проверка подписи входящего вебхука. Бросает `SignatureError` с внятной
 * причиной — она уходит в `webhook_deliveries.error`, но НЕ наружу: клиенту
 * отдаётся общий 401, чтобы подбор подписи не получал подсказок.
 */
export function verifySignature(options: VerifyOptions): void {
  const { secret, body, header, toleranceSeconds } = options;
  const now = options.nowSeconds ?? Math.floor(Date.now() / 1000);

  if (!header) throw new SignatureError('Заголовок подписи отсутствует.');

  const parts = new Map<string, string>();
  for (const chunk of header.split(',')) {
    const index = chunk.indexOf('=');
    if (index > 0) parts.set(chunk.slice(0, index).trim(), chunk.slice(index + 1).trim());
  }

  const timestamp = Number(parts.get('t'));
  const provided = parts.get(SCHEME_VERSION);
  if (!Number.isFinite(timestamp) || !provided) {
    throw new SignatureError('Подпись не разобрана: ожидается t=<unix>,v1=<hex>.');
  }

  const age = Math.abs(now - timestamp);
  if (age > toleranceSeconds) {
    throw new SignatureError(`Подпись просрочена: возраст ${age} с при допуске ${toleranceSeconds} с.`);
  }

  const expected = createHmac('sha256', secret)
    .update(`${timestamp}.`)
    .update(body)
    .digest('hex');

  const providedBuffer = Buffer.from(provided, 'hex');
  const expectedBuffer = Buffer.from(expected, 'hex');
  // Сравнение постоянного времени: побайтовое сравнение по длине утечки
  // позволяет подбирать подпись символ за символом.
  if (
    providedBuffer.length !== expectedBuffer.length ||
    !timingSafeEqual(providedBuffer, expectedBuffer)
  ) {
    throw new SignatureError('Подпись не совпала.');
  }
}
