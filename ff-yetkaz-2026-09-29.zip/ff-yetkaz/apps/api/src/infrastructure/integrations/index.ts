/**
 * Точка входа слоя интеграций: всё общение с внешними системами доступно
 * только отсюда. Прямых вызовов внешних API из контроллеров, сервисов и
 * домена быть не должно — иначе протокол расползается по слоям и первую же
 * смену заголовка приходится искать по всему дереву.
 */
export { CarrierGateway } from './carrier/carrier.gateway';
export type { CarrierHandoffMessage } from './carrier/carrier.gateway';
export {
  DELIVERY_HEADER,
  SIGNATURE_HEADER,
  SignatureError,
  signPayload,
  verifySignature,
} from './carrier/signature';
export type { VerifyOptions } from './carrier/signature';
