import PDFDocument from 'pdfkit';
import { fontPath } from '../runtime/fonts';
import { code128Bars } from '../../domain/labels/code128';

/** Данные этикетки — plain-объект: рендер не ходит в БД и тестируется отдельно. */
export interface LabelData {
  shipmentNo: string;
  /** Наш код заказа FF-YES… — печатается отдельным штрихкодом для склада. */
  orderCode: string;
  /** Трек перевозчика, если отправление уже передано: он и уходит на штрихкод. */
  trackingNo: string | null;
  carrier: string;
  orderExternalId: string;
  channel: string;
  sellerName: string;
  warehouseCode: string;
  recipientName: string;
  recipientPhone: string;
  address: string;
  region: string | null;
  weightG: number;
  lengthMm: number | null;
  widthMm: number | null;
  heightMm: number | null;
  codAmount: string | null;
  currency: string | null;
  items: Array<{ skuCode: string; name: string; quantity: number }>;
  printedAt: Date;
}

/** Термоэтикетка 100×150 мм. */
const MM = 72 / 25.4;
const WIDTH = 100 * MM;
const HEIGHT = 150 * MM;
const PAD = 5 * MM;
const INNER = WIDTH - PAD * 2;

const BARCODE_HEIGHT = 18 * MM;
/** Ниже 0.25 мм на модуль термопринтер печатает нечитаемо. */
const MIN_MODULE_MM = 0.25;

const FONT_REGULAR = 'body';
const FONT_BOLD = 'bodyBold';

/**
 * Этикетка собирается на встроенном шрифте? Нет: стандартные шрифты PDF
 * не содержат кириллицы, а имя получателя коверкать нельзя. Поэтому в
 * документ вшивается DejaVu Sans.
 */
export function renderLabel(data: LabelData): Promise<Buffer> {
  const doc = new PDFDocument({ size: [WIDTH, HEIGHT], margin: 0 });
  doc.registerFont(FONT_REGULAR, fontPath('DejaVuSans.ttf'));
  doc.registerFont(FONT_BOLD, fontPath('DejaVuSans-Bold.ttf'));

  const chunks: Buffer[] = [];
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });

  let y = PAD;

  // --- шапка -------------------------------------------------------------
  doc.rect(0, 0, WIDTH, 12 * MM).fill('#000000');
  doc
    .fillColor('#ffffff')
    .font(FONT_BOLD)
    .fontSize(13)
    .text('YETKAZ EXPRESS', PAD, 3.2 * MM, { width: INNER });
  doc
    .font(FONT_REGULAR)
    .fontSize(7)
    .text(`Фулфилмент · ${data.carrier}`, PAD, 8 * MM, { width: INNER });
  doc.fillColor('#000000');
  y = 15 * MM;

  // --- штрихкод ----------------------------------------------------------
  // На штрихкод идёт трек перевозчика, если он уже выдан: сканеры курьера
  // работают с ним. Пока трека нет — внутренний номер отправления.
  const barcodeValue = data.trackingNo ?? data.shipmentNo;
  const { bars, modules } = code128Bars(barcodeValue);
  const moduleWidth = INNER / modules;
  if (moduleWidth < MIN_MODULE_MM * MM) {
    throw new Error(`Штрихкод «${barcodeValue}» не помещается на этикетку 100 мм.`);
  }
  for (const bar of bars) {
    doc.rect(PAD + bar.offset * moduleWidth, y, bar.width * moduleWidth, BARCODE_HEIGHT).fill('#000000');
  }
  y += BARCODE_HEIGHT + 1.5 * MM;
  doc
    .font(FONT_BOLD)
    .fontSize(12)
    .text(barcodeValue, PAD, y, { width: INNER, align: 'center', characterSpacing: 1 });
  y += 6 * MM;
  if (data.trackingNo) {
    doc
      .font(FONT_REGULAR)
      .fontSize(7)
      .text(`Отправление FF: ${data.shipmentNo}`, PAD, y, { width: INNER, align: 'center' });
    y += 4 * MM;
  }

  // --- наш код заказа (FF-YES) отдельным штрихкодом ----------------------
  // Основной штрихкод выше — для курьера (трек/отправление). Этот — для склада:
  // им открывают/находят заказ по нашему коду.
  {
    const codeBars = code128Bars(data.orderCode);
    const codeModule = INNER / codeBars.modules;
    const codeHeight = 9 * MM;
    for (const bar of codeBars.bars) {
      doc.rect(PAD + bar.offset * codeModule, y, bar.width * codeModule, codeHeight).fill('#000000');
    }
    y += codeHeight + 1 * MM;
    doc
      .font(FONT_BOLD)
      .fontSize(9)
      .text(`Код заказа: ${data.orderCode}`, PAD, y, {
        width: INNER,
        align: 'center',
        characterSpacing: 1,
      });
    y += 5 * MM;
  }

  // --- получатель --------------------------------------------------------
  y = rule(doc, y);
  doc.font(FONT_REGULAR).fontSize(7).fillColor('#555555').text('КОМУ', PAD, y);
  doc.fillColor('#000000');
  y += 3.6 * MM;
  doc.font(FONT_BOLD).fontSize(12).text(data.recipientName, PAD, y, { width: INNER });
  y = doc.y + 0.5 * MM;
  doc.font(FONT_BOLD).fontSize(11).text(data.recipientPhone, PAD, y, { width: INNER });
  y = doc.y + 0.8 * MM;
  const address = data.region ? `${data.region}, ${data.address}` : data.address;
  doc.font(FONT_REGULAR).fontSize(10).text(address, PAD, y, { width: INNER });
  y = doc.y + 1.5 * MM;

  // --- отправитель и заказ ----------------------------------------------
  y = rule(doc, y);
  doc.font(FONT_REGULAR).fontSize(8);
  y = row(doc, y, 'Отправитель', data.sellerName);
  y = row(doc, y, 'Заказ', `${data.channel} · ${data.orderExternalId}`);
  y = row(doc, y, 'Склад', data.warehouseCode);

  const dims =
    data.lengthMm && data.widthMm && data.heightMm
      ? `${data.lengthMm}×${data.widthMm}×${data.heightMm} мм`
      : '—';
  y = row(doc, y, 'Вес / габариты', `${(data.weightG / 1000).toFixed(3)} кг · ${dims}`);

  // --- наложенный платёж -------------------------------------------------
  if (data.codAmount && data.currency) {
    y += 1 * MM;
    const boxHeight = 12 * MM;
    doc.rect(PAD, y, INNER, boxHeight).lineWidth(1.2).stroke('#000000');
    doc
      .font(FONT_REGULAR)
      .fontSize(7)
      .text('НАЛОЖЕННЫЙ ПЛАТЁЖ — получить с клиента', PAD + 2 * MM, y + 1.6 * MM, {
        width: INNER - 4 * MM,
      });
    doc
      .font(FONT_BOLD)
      .fontSize(14)
      .text(`${data.codAmount} ${data.currency}`, PAD + 2 * MM, y + 5.2 * MM, {
        width: INNER - 4 * MM,
      });
    y += boxHeight + 1.5 * MM;
  }

  // --- состав ------------------------------------------------------------
  y = rule(doc, y);
  doc.font(FONT_REGULAR).fontSize(7).fillColor('#555555').text('ВЛОЖЕНИЕ', PAD, y);
  doc.fillColor('#000000');
  y += 3.6 * MM;
  doc.fontSize(8);
  for (const item of data.items) {
    if (y > HEIGHT - 12 * MM) {
      // Длинный состав не выдавливает подвал: остаток виден в системе.
      doc.text('…', PAD, y);
      y += 3.4 * MM;
      break;
    }
    doc.text(`${item.skuCode} · ${item.name}`, PAD, y, { width: INNER - 14 * MM, ellipsis: true, lineBreak: false });
    doc.font(FONT_BOLD).text(`× ${item.quantity}`, WIDTH - PAD - 14 * MM, y, {
      width: 14 * MM,
      align: 'right',
    });
    doc.font(FONT_REGULAR);
    y += 3.8 * MM;
  }

  // --- подвал ------------------------------------------------------------
  doc
    .font(FONT_REGULAR)
    .fontSize(6.5)
    .fillColor('#555555')
    .text(`Напечатано ${formatMoment(data.printedAt)}`, PAD, HEIGHT - 6 * MM, {
      width: INNER,
      align: 'right',
    });

  doc.end();
  return done;
}

function rule(doc: PDFKit.PDFDocument, y: number): number {
  doc
    .moveTo(PAD, y)
    .lineTo(WIDTH - PAD, y)
    .lineWidth(0.6)
    .stroke('#000000');
  return y + 2 * MM;
}

function row(doc: PDFKit.PDFDocument, y: number, label: string, value: string): number {
  doc.fillColor('#555555').text(label, PAD, y, { width: 28 * MM });
  doc.fillColor('#000000').text(value, PAD + 28 * MM, y, { width: INNER - 28 * MM });
  return Math.max(doc.y, y + 3.8 * MM);
}

/** Локальное время печати без зависимостей от локали окружения. */
function formatMoment(value: Date): string {
  const pad = (part: number) => String(part).padStart(2, '0');
  return (
    `${pad(value.getDate())}.${pad(value.getMonth() + 1)}.${value.getFullYear()} ` +
    `${pad(value.getHours())}:${pad(value.getMinutes())}`
  );
}
