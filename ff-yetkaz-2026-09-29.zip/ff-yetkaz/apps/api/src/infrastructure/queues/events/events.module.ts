import { Global, Module } from '@nestjs/common';
import { EventBus, EVENT_BUS } from './event-bus';
import { InMemoryEventBus } from './in-memory-event-bus';

@Global()
@Module({
  providers: [{ provide: EVENT_BUS, useClass: InMemoryEventBus }],
  exports: [EVENT_BUS],
})
export class EventsModule {}

export type { EventBus };
