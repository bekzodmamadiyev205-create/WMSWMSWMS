import { Injectable, Logger } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type { FfDomainEvent, FfEventName } from '@ff/shared';
import type { EventBus, EventHandler } from './event-bus';

/**
 * MVP-реализация шины поверх NestJS EventEmitter: доставка в том же процессе,
 * без персистентности и без ретраев. Обработчики ждутся (`emitAsync`), поэтому
 * ошибка подписчика видна публикующей стороне.
 *
 * Ограничение, важное для этапа биллинга: событие живёт только в памяти —
 * падение процесса между коммитом и доставкой теряет его. Гарантия
 * «ровно один раз» появится вместе с transactional outbox при переезде на BullMQ.
 */
@Injectable()
export class InMemoryEventBus implements EventBus {
  private readonly logger = new Logger(InMemoryEventBus.name);

  constructor(private readonly emitter: EventEmitter2) {}

  async publish<K extends FfEventName>(event: FfDomainEvent<K>): Promise<void> {
    this.logger.debug(`→ ${event.name} (correlationId=${event.correlationId ?? '—'})`);
    await this.emitter.emitAsync(event.name, event);
  }

  subscribe<K extends FfEventName>(name: K, handler: EventHandler<K>): void {
    this.emitter.on(name, handler as (payload: unknown) => void);
  }
}
