import { randomUUID } from 'node:crypto';
import type { FfDomainEvent, FfEventName, FfEventPayloads } from '@ff/shared';

export const EVENT_BUS = Symbol('FF_EVENT_BUS');

export type EventHandler<K extends FfEventName> = (event: FfDomainEvent<K>) => void | Promise<void>;

/**
 * Порт шины событий. Модули зависят только от этого интерфейса, поэтому замена
 * in-memory реализации на BullMQ/Redis не потребует правок в самих модулях.
 */
export interface EventBus {
  publish<K extends FfEventName>(event: FfDomainEvent<K>): Promise<void>;
  subscribe<K extends FfEventName>(name: K, handler: EventHandler<K>): void;
}

export interface EventContext {
  actorUserId?: string | null;
  correlationId?: string | null;
}

/** Собирает конверт события: имя + payload + кто и когда. */
export function createEvent<K extends FfEventName>(
  name: K,
  payload: FfEventPayloads[K],
  context: EventContext = {},
): FfDomainEvent<K> {
  return {
    name,
    payload,
    occurredAt: new Date().toISOString(),
    actorUserId: context.actorUserId ?? null,
    correlationId: context.correlationId ?? randomUUID(),
  };
}
