import { Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, type EntityManager } from 'typeorm';
import {
  SETTING_KEYS,
  type OutboxDispatchResultDto,
  type OutboxMessageDto,
  type OutboxStatus,
} from '@ff/shared';
import { SettingsService } from '../config-store/settings.service';
import { IntegrationOutboxEntity } from '../database/entities';
import {
  OutboxRepository,
  type ClaimedRow,
} from '../database/repositories/outbox.repository';
import { CarrierGateway } from '../integrations';

/**
 * Transactional outbox: единственный способ что-либо отправить наружу.
 *
 * Сообщение кладётся в очередь В ТОЙ ЖЕ транзакции, что и бизнес-факт, поэтому
 * «отправление создано, а перевозчик не узнал» невозможно по построению.
 * Доставку разбирает отдельный проход — с блокировкой строк, бэкоффом и
 * ограничением числа попыток.
 */
@Injectable()
export class OutboxService {
  private readonly logger = new Logger(OutboxService.name);

  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly carrier: CarrierGateway,
    private readonly settings: SettingsService,
    private readonly outboxRepository: OutboxRepository,
  ) {}

  /**
   * Постановка в очередь. Требует ВНЕШНЕЙ транзакции — в этом весь смысл:
   * сообщение и бизнес-факт коммитятся вместе или не коммитятся вовсе.
   *
   * Повторная постановка того же (topic, entityId) молча ничего не делает:
   * уникальный индекс защищает от дублей у перевозчика.
   */
  async enqueue(
    em: EntityManager,
    message: {
      carrierCode: string;
      topic: string;
      entityType: string;
      entityId: string;
      payload: unknown;
      correlationId?: string | null;
    },
  ): Promise<void> {
    await this.outboxRepository.enqueueMessage(em, {
      carrierCode: message.carrierCode,
      topic: message.topic,
      entityType: message.entityType,
      entityId: message.entityId,
      payloadJson: JSON.stringify(message.payload),
      correlationId: message.correlationId ?? null,
    });
  }

  /**
   * Один проход диспетчера.
   *
   * Строки захватываются `FOR UPDATE SKIP LOCKED`: два параллельных
   * диспетчера разберут разные сообщения, а не подерутся за одно.
   */
  async dispatch(): Promise<OutboxDispatchResultDto> {
    const [batchSize, maxAttempts, backoffBase] = await Promise.all([
      this.settings.getNumber(SETTING_KEYS.OUTBOX_BATCH_SIZE),
      this.settings.getNumber(SETTING_KEYS.OUTBOX_MAX_ATTEMPTS),
      this.settings.getNumber(SETTING_KEYS.OUTBOX_BACKOFF_BASE_SECONDS),
    ]);

    // Захват идёт ВНЕ транзакции, короткой самостоятельной командой: держать
    // блокировки на время внешних HTTP-вызовов нельзя.
    const claimed: ClaimedRow[] = await this.outboxRepository.claimBatch(
      this.dataSource,
      batchSize,
    );

    const result: OutboxDispatchResultDto = {
      claimed: claimed.length,
      delivered: 0,
      retried: 0,
      failed: 0,
    };

    for (const row of claimed) {
      try {
        await this.deliver(row);
        await this.outboxRepository.markDelivered(this.dataSource, row.id);
        result.delivered += 1;
      } catch (error) {
        const message = (error as Error).message.slice(0, 1000);
        const attempts = Number(row.attempts);
        const exhausted = attempts >= maxAttempts;
        // Экспоненциальный бэкофф: 15с, 30с, 60с… Перегружать соседа
        // повторами в момент его аварии — верный способ её продлить.
        const delaySeconds = Math.min(backoffBase * 2 ** Math.max(attempts - 1, 0), 3600);
        // Момент следующей попытки считаем в приложении и передаём готовым
        // значением: арифметика интервалов в SQL с нетипизированным параметром
        // слишком легко даёт «interval out of range» на пустом месте.
        const nextAttemptAt = new Date(Date.now() + delaySeconds * 1000);

        await this.outboxRepository.markAttemptFailed(this.dataSource, {
          id: row.id,
          status: exhausted ? 'FAILED' : 'PENDING',
          error: message,
          nextAttemptAt: nextAttemptAt.toISOString(),
        });

        if (exhausted) {
          result.failed += 1;
          this.logger.error(
            `Сообщение ${row.topic}/${row.entity_id} исчерпало попытки (${attempts}): ${message}`,
          );
        } else {
          result.retried += 1;
          this.logger.warn(
            `Сообщение ${row.topic}/${row.entity_id}: попытка ${attempts} не удалась, повтор через ${delaySeconds} с`,
          );
        }
      }
    }

    return result;
  }

  async list(status?: OutboxStatus): Promise<OutboxMessageDto[]> {
    const repo = this.dataSource.getRepository(IntegrationOutboxEntity);
    const rows = await repo.find({
      where: status ? { status } : {},
      order: { id: 'DESC' },
      take: 100,
    });
    return rows.map((row) => ({
      id: String(row.id),
      carrierCode: row.carrierCode,
      topic: row.topic,
      entityType: row.entityType,
      entityId: row.entityId,
      status: row.status,
      attempts: row.attempts,
      nextAttemptAt: row.nextAttemptAt.toISOString(),
      lastError: row.lastError,
      deliveredAt: row.deliveredAt ? row.deliveredAt.toISOString() : null,
      createdAt: row.createdAt.toISOString(),
    }));
  }

  /** Ручной повтор сообщения, застрявшего в FAILED. */
  async retry(id: string): Promise<OutboxMessageDto | null> {
    await this.outboxRepository.requeueFailed(this.dataSource, id);
    const rows = await this.list();
    return rows.find((row) => row.id === String(id)) ?? null;
  }

  // ------------------------------------------------------------ внутреннее

  /**
   * Очередь не знает, КАК уходит сообщение: адрес, подпись, заголовки и таймаут
   * живут в слое интеграций. Здесь остаётся только то, за что отвечает очередь, —
   * захват, повторы, бэкофф и аренда, — поэтому смена протокола перевозчика не
   * заставляет трогать логику повторов, и наоборот.
   */
  private async deliver(row: ClaimedRow): Promise<void> {
    await this.carrier.handOver({
      carrierCode: row.carrier_code,
      topic: row.topic,
      entityId: row.entity_id,
      payload: row.payload,
      correlationId: row.correlation_id,
    });
  }
}
