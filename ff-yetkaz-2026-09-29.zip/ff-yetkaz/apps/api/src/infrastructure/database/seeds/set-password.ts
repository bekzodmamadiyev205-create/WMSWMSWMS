import 'reflect-metadata';
import { passwordProblem } from '@ff/shared';
import dataSource from '../data-source';
import { UserEntity } from '../entities';
import { PasswordService } from '../../auth/password.service';

/**
 * Смена пароля существующего пользователя.
 *
 * Управления пользователями в MVP нет по решению PM, но пароль сменить нужно
 * уметь всегда — иначе единственный путь лежит через ручной UPDATE в базе, где
 * легко записать пароль открытым текстом вместо хэша и молча сломать вход.
 *
 * Хэш считает тот же `PasswordService`, что и логин: свои параметры argon2
 * здесь разъехались бы с проверкой при первом же изменении настроек.
 *
 * Пароль приходит переменной окружения, а не аргументом командной строки:
 * аргументы видны в списке процессов и оседают в истории команд.
 */
async function main(): Promise<void> {
  const email = (process.env.FF_USER_EMAIL ?? '').trim().toLowerCase();
  const password = process.env.FF_USER_PASSWORD ?? '';

  if (!email) throw new Error('Задайте FF_USER_EMAIL — чей пароль менять.');
  const problem = passwordProblem(password);
  if (problem) {
    throw new Error(`${problem} Учётная запись открывает данные клиентов.`);
  }

  await dataSource.initialize();
  try {
    const users = dataSource.getRepository(UserEntity);
    const user = await users
      .createQueryBuilder('u')
      .where('lower(u.email) = :email', { email })
      .getOne();
    if (!user) throw new Error(`Пользователь ${email} не найден.`);

    user.passwordHash = await new PasswordService().hash(password);
    await users.save(user);
    console.log(`Пароль обновлён: ${email}. Старый больше не работает.`);
  } finally {
    await dataSource.destroy();
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
