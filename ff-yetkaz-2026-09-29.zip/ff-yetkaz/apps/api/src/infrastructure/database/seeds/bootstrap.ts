import 'reflect-metadata';
import { randomBytes } from 'node:crypto';
import { hash } from '@node-rs/argon2';
import { passwordProblem } from '@ff/shared';
import dataSource from '../data-source';
import { UserEntity, UserRoleEntity } from '../entities';

/**
 * Создаёт стартового ADMIN. Идемпотентен: повторный запуск ничего не меняет.
 * Пароль берётся из SEED_ADMIN_PASSWORD, иначе генерируется и печатается один раз.
 */
async function main(): Promise<void> {
  await dataSource.initialize();
  try {
    const email = (process.env.SEED_ADMIN_EMAIL ?? 'admin@yetkaz.local').trim().toLowerCase();
    let password = process.env.SEED_ADMIN_PASSWORD?.trim();
    const generated = !password;
    if (!password) password = randomBytes(12).toString('base64url');

    // Тот же барьер, что и в интерфейсе: слабый стартовый пароль администратора —
    // это как раз то, из-за чего в проде оказался «1234».
    const problem = passwordProblem(password);
    if (problem) {
      console.error(`SEED_ADMIN_PASSWORD отклонён: ${problem}`);
      process.exit(1);
    }

    const existing = await dataSource
      .getRepository(UserEntity)
      .createQueryBuilder('u')
      .where('lower(u.email) = :email', { email })
      .getOne();

    if (existing) {
      console.log(`Пользователь ${email} уже существует (id=${existing.id}) — сид пропущен.`);
      return;
    }

    const passwordHash = await hash(password, { memoryCost: 19_456, timeCost: 2, parallelism: 1 });

    await dataSource.transaction(async (em) => {
      const users = em.getRepository(UserEntity);
      const user = await users.save(
        users.create({
          email,
          passwordHash,
          fullName: 'Администратор',
          isActive: true,
          sellerId: null,
        }),
      );
      await em.getRepository(UserRoleEntity).insert({ userId: user.id, role: 'ADMIN' });
    });

    console.log(`Создан ADMIN: ${email}`);
    if (generated) {
      console.log(`Пароль (показывается один раз, сохраните): ${password}`);
    }
  } finally {
    await dataSource.destroy();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
