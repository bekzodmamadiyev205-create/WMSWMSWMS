import { DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, type PageDto, type SortDirection } from '@ff/shared';

/**
 * Постраничные списки и безопасная сборка SQL-фильтров.
 *
 * До этого списки отдавали `take(limit)` без общего числа строк, а поиск и
 * период считались на клиенте поверх первой сотни записей — то есть врали, как
 * только данных стало больше сотни. Здесь один способ листать на весь проект.
 */

export interface PageParams {
  page: number;
  pageSize: number;
  offset: number;
}

export function resolvePage(query: { page?: number; pageSize?: number }): PageParams {
  const page = Math.max(1, Math.trunc(Number(query.page) || 1));
  const requested = Math.trunc(Number(query.pageSize) || DEFAULT_PAGE_SIZE);
  // Потолок обязателен: без него `?pageSize=1000000` кладёт и базу, и браузер.
  const pageSize = Math.min(MAX_PAGE_SIZE, Math.max(1, requested));
  return { page, pageSize, offset: (page - 1) * pageSize };
}

export function pageEnvelope<T>(rows: T[], total: number, params: PageParams): PageDto<T> {
  return { rows, total, page: params.page, pageSize: params.pageSize };
}

/**
 * Сортировка ТОЛЬКО по белому списку. Поле сортировки приходит из запроса и
 * попадает в текст SQL — подставлять его как есть значит открыть инъекцию,
 * а «просто экранировать» имя колонки нечем.
 */
export function resolveSort<T extends string>(
  allowed: readonly T[],
  fallback: T,
  sort?: string,
  direction?: string,
): { field: T; direction: SortDirection } {
  const field = allowed.includes(sort as T) ? (sort as T) : fallback;
  return { field, direction: direction === 'asc' ? 'asc' : 'desc' };
}

/**
 * Накопитель значений для параметризованного SQL. Каждый `bind` возвращает
 * `$N` — номера не считаются руками, а значит не разъезжаются при правке
 * условий (классический источник «ошибка синтаксиса рядом с $7»).
 */
export class SqlParams {
  readonly values: unknown[] = [];

  bind(value: unknown): string {
    this.values.push(value);
    return `$${this.values.length}`;
  }
}

export function whereClause(conditions: string[]): string {
  return conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
}

export function andClause(conditions: string[]): string {
  return conditions.length ? `AND ${conditions.join(' AND ')}` : '';
}

/**
 * Условия периода. Правая граница ВКЛЮЧИТЕЛЬНАЯ: «по 20 августа» в отчёте
 * обязано содержать двадцатое целиком, поэтому сравнение идёт с началом
 * следующего дня, а не с полуночью двадцатого — иначе всё, что сделано днём,
 * молча выпадает из отчёта.
 */
export function dateRangeConditions(
  column: string,
  params: SqlParams,
  from?: string | null,
  to?: string | null,
): string[] {
  const conditions: string[] = [];
  if (from) conditions.push(`${column} >= ${params.bind(from)}::date`);
  if (to) conditions.push(`${column} < (${params.bind(to)}::date + interval '1 day')`);
  return conditions;
}

/** Экранирование для `ILIKE '%…%'`: подчёркивание и процент — тоже шаблон. */
export function likePattern(raw: string): string {
  return `%${raw.trim().replace(/[\\%_]/g, (ch) => `\\${ch}`)}%`;
}
