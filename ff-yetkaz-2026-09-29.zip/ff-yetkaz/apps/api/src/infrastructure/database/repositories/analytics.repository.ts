import { Injectable } from '@nestjs/common';
import type { AnalyticsGranularity, AnalyticsMetricDto } from '@ff/shared';
import { SqlParams, dateRangeConditions, whereClause } from '../query/page';
import type { SqlRunner } from '../sql-runner';

/**
 * BI-слой: каждое число здесь считает PostgreSQL и отдаёт готовым.
 *
 * Правило не стилистическое. Витрина, собранная в приложении из выгруженных
 * строк, умирает вместе с ростом склада, а по дороге ещё и начинает врать:
 * посчитать «сколько всего» по первой странице невозможно, но график при этом
 * продолжает рисоваться, и заметить подмену нечем.
 *
 * Второе сквозное правило — деньги остаются строкой от `::text` в SQL до JSON.
 * Как только сумма побывала в `number`, дашборд начинает расходиться со
 * счетами на копейки, и объяснить это расхождение уже невозможно.
 */

/** Календарный период, обе границы включительно. */
export interface ResolvedWindow {
  from: string;
  to: string;
}

export interface OverviewFilters {
  sellerId: string | null;
  warehouseId: string | null;
  categoryId: string | null;
}

/**
 * Уже подставленные в SQL фрагменты фильтров: `$3`, `s.id` или null.
 * Значение биндится ОДИН раз и переиспользуется во всех подзапросах — номер
 * `$N` позиционный, поэтому повторное появление в тексте безопасно.
 */
interface BoundFilters {
  seller: string | null;
  warehouse: string | null;
  category: string | null;
}

/**
 * Описание плитки. `column` — имя колонки в строке фактов, константа кода,
 * а не пользовательский ввод: только поэтому её можно подставлять в текст SQL.
 * Всё, что приходит из запроса (период, селлер, склад), идёт параметрами.
 */
export interface MetricSpec {
  key: string;
  column: string;
  positiveIsGood: boolean;
  format: AnalyticsMetricDto['format'];
}

export const METRICS: MetricSpec[] = [
  { key: 'orders', column: 'orders', positiveIsGood: true, format: 'count' },
  { key: 'units', column: 'units', positiveIsGood: true, format: 'count' },
  { key: 'delivered', column: 'delivered', positiveIsGood: true, format: 'count' },
  { key: 'cancelled', column: 'cancelled', positiveIsGood: false, format: 'count' },
  { key: 'returned', column: 'returned', positiveIsGood: false, format: 'count' },
  { key: 'returnRatePct', column: 'return_rate_pct', positiveIsGood: false, format: 'percent' },
  { key: 'revenue', column: 'revenue', positiveIsGood: true, format: 'money' },
  { key: 'codCollected', column: 'cod_collected', positiveIsGood: true, format: 'money' },
  // Часам формат 'weight' не подходит, а своего у DTO нет: клиент форматирует
  // по ключу метрики, а не по типу.
  { key: 'avgFulfilmentHours', column: 'fulfilment_hours', positiveIsGood: false, format: 'count' },
  { key: 'dispatchedCount', column: 'dispatched_count', positiveIsGood: true, format: 'count' },
];

/** Заказ, покинувший склад: знаменатель доли возвратов. */
const SHIPPED_OUT_STATUSES = `('DISPATCHED', 'SHIPPED', 'DELIVERED', 'RETURNED')`;

export const GRANULARITY_SQL: Record<AnalyticsGranularity, { trunc: string; step: string }> = {
  day: { trunc: 'day', step: '1 day' },
  week: { trunc: 'week', step: '1 week' },
  month: { trunc: 'month', step: '1 month' },
};

// ================================================================ строки SQL

export interface MetricRow {
  key: string;
  value: string;
  previous: string | null;
  change_pct: string | null;
  currency: string | null;
}

export interface StatusCountRow {
  status: string;
  count: string;
}

export interface CategoryRow {
  category_id: string | null;
  name: string;
  color: string | null;
  count: string;
}

export interface SeriesRow {
  bucket: string;
  orders: string;
  delivered: string;
  returned: string;
  revenue: string;
}

export interface SellerRow {
  kind: 'row' | 'total';
  seller_id: string | null;
  seller_code: string | null;
  seller_name: string | null;
  orders: string;
  units: string;
  delivered: string;
  cancelled: string;
  returned: string;
  return_rate_pct: string;
  revenue: string;
  cod_collected: string;
  currency: string | null;
  average_order_value: string;
  stock_units: string;
}

/**
 * Сырой SQL аналитики. Соединение не внедряется: его передаёт вызывающий.
 *
 * Здесь это критично сильнее обычного. Отчётные запросы идут В ЧАСОВОМ ПОЯСЕ
 * СКЛАДА, а пояс задан один раз на транзакцию (`SET LOCAL TIME ZONE`) — значит
 * методы обязаны выполняться ТЕМ ЖЕ `EntityManager`, которым пояс выставлен.
 * Возьми репозиторий соединение сам — половина выражений считалась бы в поясе
 * склада, а половина в UTC, и это сдвиг на пять часов ровно там, где его никто
 * не проверит.
 */
@Injectable()
export class AnalyticsRepository {
  /**
   * Пояс отчётности на текущую транзакцию.
   *
   * Литерал, а не параметр: SET не принимает подстановки. Значение —
   * константа приложения, из запроса сюда ничего не попадает.
   *
   * Практическая цена ошибки: Ташкент это UTC+5, поэтому в UTC «сегодня»
   * начинается в 05:00 по местному времени — вся ночная смена попадала во
   * вчерашний отчёт, а отчёт «за сегодня», открытый в 02:00, показывал
   * позавчерашние цифры.
   */
  async setReportTimeZone(runner: SqlRunner, timeZone: string): Promise<void> {
    await runner.query(`SET LOCAL TIME ZONE '${timeZone}'`);
  }

  async loadMetrics(
    runner: SqlRunner,
    window: ResolvedWindow,
    previous: ResolvedWindow,
    filters: OverviewFilters,
  ): Promise<MetricRow[]> {
    const params = new SqlParams();
    const bound = this.bindFilters(filters, params, null);

    // Валюта отчёта определяется сразу по ОБОИМ окнам. Считать её только по
    // текущему нельзя: месяц без начислений обнулил бы и прошлый период, и
    // сравнение «стало / было» превратилось бы в сравнение с нулём.
    const currencySpan: ResolvedWindow = { from: previous.from, to: window.to };
    const currencyCte = this.reportCurrencySql(currencySpan, bound, params);
    const currencySql = '(SELECT currency FROM rc)';

    const cur = this.factsSql(window, bound, params, currencySql);
    const prev = this.factsSql(previous, bound, params, currencySql);

    const union = METRICS.map(
      (spec, index) => `
        SELECT ${index} AS idx,
               '${spec.key}' AS key,
               cur.${spec.column}::text AS value,
               prev.${spec.column}::text AS previous,
               CASE WHEN prev.${spec.column} IS NULL OR prev.${spec.column} = 0 THEN NULL
                    ELSE round(
                      (cur.${spec.column} - prev.${spec.column}) * 100.0 / prev.${spec.column}, 1
                    )::text
               END AS change_pct,
               ${currencySql} AS currency
          FROM cur, prev`,
    ).join(' UNION ALL ');

    const rows: MetricRow[] = await runner.query(
      `WITH rc AS (${currencyCte}), cur AS (${cur}), prev AS (${prev})
       ${union}
       ORDER BY idx`,
      params.values,
    );
    return rows;
  }

  async loadOrdersByStatus(
    runner: SqlRunner,
    window: ResolvedWindow,
    filters: OverviewFilters,
  ): Promise<StatusCountRow[]> {
    const params = new SqlParams();
    const bound = this.bindFilters(filters, params, null);
    const conds = this.orderConds('o', window, bound, params, 'created_at');

    const rows: StatusCountRow[] = await runner.query(
      `SELECT o.status, count(*)::text AS count
         FROM bi_orders o ${whereClause(conds)}
        GROUP BY o.status
        ORDER BY o.status`,
      params.values,
    );
    return rows;
  }

  async loadOrdersByCategory(
    runner: SqlRunner,
    window: ResolvedWindow,
    filters: OverviewFilters,
  ): Promise<CategoryRow[]> {
    const params = new SqlParams();
    const bound = this.bindFilters(filters, params, null);
    const conds = this.orderConds('o', window, bound, params, 'created_at');

    // LEFT JOIN, а не INNER: заказы без категории обязаны быть видны отдельной
    // строкой. Иначе сумма по разрезу тихо не сходится с общим числом заказов,
    // и разбираться с этим приходится глазами.
    const rows: CategoryRow[] = await runner.query(
      `SELECT o.category_id,
              COALESCE(cat.name, 'Без категории') AS name,
              cat.color,
              count(*)::text AS count
         FROM bi_orders o
         LEFT JOIN order_categories cat ON cat.id = o.category_id
        ${whereClause(conds)}
        GROUP BY o.category_id, cat.name, cat.color, cat.sort_order
        ORDER BY count(*) DESC, cat.sort_order NULLS LAST`,
      params.values,
    );
    return rows;
  }

  /**
   * Временной ряд. Хребет строится `generate_series`, агрегаты навешиваются на
   * него слева: интервал без данных обязан присутствовать нулём. График,
   * пропускающий пустые дни, рисует прямую линию через простой склада — то
   * есть прячет ровно то, ради чего на него и смотрят.
   */
  async loadSeries(
    runner: SqlRunner,
    window: ResolvedWindow,
    previous: ResolvedWindow,
    filters: OverviewFilters,
    granularity: AnalyticsGranularity,
  ): Promise<SeriesRow[]> {
    const params = new SqlParams();
    const bound = this.bindFilters(filters, params, null);
    const shape = GRANULARITY_SQL[granularity];
    const trunc = params.bind(shape.trunc);
    const step = params.bind(shape.step);
    const from = params.bind(window.from);
    const to = params.bind(window.to);

    const orderConds = whereClause(this.orderConds('o', window, bound, params, 'created_at'));
    const returnConds = whereClause(this.returnConds('r', window, bound, params));
    // Валюту в ряду фиксируем ТУ ЖЕ, что и в плитке оборота. Без этого график
    // складывал 5 000 000 UZS и 300 USD в одно число, пока плитка рядом честно
    // показывала только преобладающую валюту — две цифры об одном и том же
    // периоде, не сходящиеся между собой. Сложение валют в этом проекте
    // запрещено везде, где считаются деньги, и график не исключение.
    // Промежуток берётся такой же, как у плиток (прошлое окно + текущее),
    // иначе подпись под графиком может разойтись с подписью над ним.
    const currencySpan: ResolvedWindow = { from: previous.from, to: window.to };
    const currencyCte = this.reportCurrencySql(currencySpan, bound, params);
    const currencySql = '(SELECT currency FROM rc)';
    const chargeConds = whereClause(this.chargeConds('c', window, bound, params, currencySql));

    const rows: SeriesRow[] = await runner.query(
      `WITH rc AS (${currencyCte}),
       spine AS (
         SELECT gs AS bucket
           FROM generate_series(
                  date_trunc(${trunc}::text, ${from}::timestamptz),
                  date_trunc(${trunc}::text, ${to}::timestamptz),
                  ${step}::interval) gs
       ),
       o AS (
         SELECT date_trunc(${trunc}::text, o.created_at) AS bucket,
                count(*) AS orders,
                count(*) FILTER (WHERE o.status = 'DELIVERED') AS delivered
           FROM bi_orders o ${orderConds}
          GROUP BY 1
       ),
       r AS (
         SELECT date_trunc(${trunc}::text, r.created_at) AS bucket, count(*) AS returned
           FROM bi_returns r ${returnConds}
          GROUP BY 1
       ),
       c AS (
         SELECT date_trunc(${trunc}::text, c.occurred_at) AS bucket, SUM(c.amount) AS revenue
           FROM charges c ${chargeConds}
          GROUP BY 1
       )
       SELECT to_char(spine.bucket, 'YYYY-MM-DD') AS bucket,
              COALESCE(o.orders, 0)::text AS orders,
              COALESCE(o.delivered, 0)::text AS delivered,
              COALESCE(r.returned, 0)::text AS returned,
              COALESCE(c.revenue, 0)::text AS revenue
         FROM spine
         LEFT JOIN o ON o.bucket = spine.bucket
         LEFT JOIN r ON r.bucket = spine.bucket
         LEFT JOIN c ON c.bucket = spine.bucket
        ORDER BY spine.bucket`,
      params.values,
    );
    return rows;
  }

  /**
   * Строки по селлерам плюс итог. Итог считается в SQL из тех же строк, а не
   * складывается на клиенте: два независимых способа получить одно число
   * гарантированно разойдутся, и спорить будут с тем, что на экране.
   */
  async loadSellerRows(
    runner: SqlRunner,
    window: ResolvedWindow,
    filters: OverviewFilters,
  ): Promise<SellerRow[]> {
    const params = new SqlParams();
    // Селлер здесь не фильтр, а колонка группировки: условия строятся
    // относительно `s.id`, а сам фильтр (если задан) висит снаружи.
    const bound = this.bindFilters(filters, params, 's.id');
    const sellerFilter = filters.sellerId ? [`s.id = ${params.bind(filters.sellerId)}`] : [];

    const currencyLateral = this.sellerCurrencySql(window, bound, params);
    const orderConds = whereClause(this.orderConds('bo', window, bound, params, 'created_at'));
    const returnConds = whereClause(this.returnConds('r', window, bound, params));
    const chargeConds = whereClause(this.chargeConds('c', window, bound, params, 'cur.currency'));
    const codConds = whereClause(this.codConds('sh', 'so', window, bound, params, 'cur.currency'));
    const stockConds = ['bs.seller_id = s.id'];
    if (bound.warehouse) stockConds.push(`bs.warehouse_id = ${bound.warehouse}`);

    // Селлер без единого движения и без остатка — шум в отчёте, а не нулевая
    // строка: в списке он занимает место наравне с работающими.
    const activity = `(COALESCE(o.orders, 0) > 0 OR COALESCE(ret.returned, 0) > 0
                       OR COALESCE(rev.revenue, 0) <> 0 OR COALESCE(cod.collected, 0) <> 0
                       OR COALESCE(stk.stock_units, 0) > 0)`;
    // `IS NOT DISTINCT FROM`, а не `=`: у селлера без единой денежной операции
    // валюта NULL, и обычное сравнение выбросило бы такую строку из итога
    // вместе с её остатком и заказами.
    const inDomCurrency = `WHERE a.currency IS NOT DISTINCT FROM a.dom_currency`;

    const rows: SellerRow[] = await runner.query(
      `WITH r AS (
         SELECT s.id AS seller_id, s.code AS seller_code, s.legal_name AS seller_name,
                cur.currency AS currency,
                COALESCE(o.orders, 0) AS orders,
                COALESCE(o.units, 0) AS units,
                COALESCE(o.delivered, 0) AS delivered,
                COALESCE(o.cancelled, 0) AS cancelled,
                COALESCE(o.shipped_out, 0) AS shipped_out,
                COALESCE(o.cod_sum, 0) AS cod_sum,
                COALESCE(o.cod_orders, 0) AS cod_orders,
                COALESCE(ret.returned, 0) AS returned,
                COALESCE(rev.revenue, 0) AS revenue,
                COALESCE(cod.collected, 0) AS cod_collected,
                COALESCE(stk.stock_units, 0) AS stock_units
           FROM sellers s
           LEFT JOIN LATERAL (${currencyLateral}) cur ON true
           LEFT JOIN LATERAL (
             SELECT count(*) AS orders,
                    COALESCE(SUM(bo.units), 0)::bigint AS units,
                    count(*) FILTER (WHERE bo.status = 'DELIVERED') AS delivered,
                    count(*) FILTER (WHERE bo.status = 'CANCELLED') AS cancelled,
                    count(*) FILTER (WHERE bo.status IN ${SHIPPED_OUT_STATUSES}) AS shipped_out,
                    COALESCE(SUM(bo.cod_amount) FILTER (
                      WHERE cur.currency IS NULL OR bo.currency = cur.currency), 0) AS cod_sum,
                    count(*) FILTER (
                      WHERE bo.cod_amount IS NOT NULL
                        AND (cur.currency IS NULL OR bo.currency = cur.currency)) AS cod_orders
               FROM bi_orders bo ${orderConds}
           ) o ON true
           LEFT JOIN LATERAL (
             SELECT count(*) AS returned FROM bi_returns r ${returnConds}
           ) ret ON true
           LEFT JOIN LATERAL (
             SELECT COALESCE(SUM(c.amount), 0) AS revenue FROM charges c ${chargeConds}
           ) rev ON true
           LEFT JOIN LATERAL (
             SELECT COALESCE(SUM(sh.cod_collected_amount), 0) AS collected
               FROM shipments sh
               JOIN orders so ON so.id = sh.order_id ${codConds}
           ) cod ON true
           LEFT JOIN LATERAL (
             -- Остаток МГНОВЕННЫЙ: это то, что лежит на складе сейчас, период
             -- к нему не применяется. Иначе колонка врала бы дважды — и как
             -- остаток, и как «за период».
             SELECT COALESCE(SUM(bs.quantity), 0)::bigint AS stock_units
               FROM bi_stock bs ${whereClause(stockConds)}
           ) stk ON true
          ${whereClause([...sellerFilter, activity])}
       ),
       dom AS (
         SELECT currency FROM r WHERE currency IS NOT NULL
          GROUP BY currency ORDER BY SUM(revenue) DESC LIMIT 1
       ),
       a AS (
         -- Преобладающая валюта подставляется КОЛОНКОЙ, а не подзапросом внутрь
         -- FILTER: так итог считается обычным сравнением колонок и не зависит
         -- от того, разрешён ли подзапрос в фильтре агрегата.
         SELECT r.*, (SELECT currency FROM dom) AS dom_currency FROM r
       )
       SELECT 'row' AS kind,
              a.seller_id::text AS seller_id,
              a.seller_code,
              a.seller_name,
              a.orders::text AS orders,
              a.units::text AS units,
              a.delivered::text AS delivered,
              a.cancelled::text AS cancelled,
              a.returned::text AS returned,
              COALESCE(round(a.returned * 100.0 / NULLIF(a.shipped_out, 0), 1), 0)::text
                AS return_rate_pct,
              a.revenue::numeric(14, 2)::text AS revenue,
              a.cod_collected::numeric(14, 2)::text AS cod_collected,
              a.currency,
              COALESCE(round(a.cod_sum / NULLIF(a.cod_orders, 0), 2), 0)::text
                AS average_order_value,
              a.stock_units::text AS stock_units,
              a.revenue AS sort_key
         FROM a
       UNION ALL
       SELECT 'total',
              NULL::text, NULL::text, NULL::text,
              COALESCE(SUM(a.orders), 0)::text,
              COALESCE(SUM(a.units), 0)::text,
              COALESCE(SUM(a.delivered), 0)::text,
              COALESCE(SUM(a.cancelled), 0)::text,
              COALESCE(SUM(a.returned), 0)::text,
              COALESCE(round(SUM(a.returned) * 100.0 / NULLIF(SUM(a.shipped_out), 0), 1), 0)::text,
              -- В денежный итог попадают только строки в преобладающей валюте:
              -- сложить сумы с долларами и подписать результат одной валютой —
              -- это и есть тот способ, которым отчёт расходится со счетами.
              COALESCE(SUM(a.revenue) FILTER (${inDomCurrency}), 0)::numeric(14, 2)::text,
              COALESCE(SUM(a.cod_collected) FILTER (${inDomCurrency}), 0)::numeric(14, 2)::text,
              MAX(a.dom_currency),
              COALESCE(round(
                SUM(a.cod_sum) FILTER (${inDomCurrency})
                / NULLIF(SUM(a.cod_orders) FILTER (${inDomCurrency}), 0), 2), 0)::text,
              COALESCE(SUM(a.stock_units), 0)::text,
              (-1)::numeric
         FROM a
        ORDER BY kind ASC, sort_key DESC`,
      params.values,
    );
    return rows;
  }

  // ============================================================== фрагменты

  /**
   * Одна строка со всеми числами периода. Каждый источник читается ровно один
   * раз, а не по разу на плитку: десять раундтрипов ради десяти чисел — та
   * самая мелочь, из которой складывается медленный дашборд.
   */
  private factsSql(
    window: ResolvedWindow,
    bound: BoundFilters,
    params: SqlParams,
    currencySql: string,
  ): string {
    const orders = whereClause(this.orderConds('o', window, bound, params, 'created_at'));
    const returns = whereClause(this.returnConds('r', window, bound, params));
    const charges = whereClause(this.chargeConds('c', window, bound, params, currencySql));
    const cod = whereClause(this.codConds('sh', 'so', window, bound, params, currencySql));
    const fulfilment = this.fulfilmentSql(window, bound, params);
    const dispatched = whereClause(this.orderConds('o', window, bound, params, 'dispatched_at'));

    return `
      SELECT ord.orders,
             ord.units,
             ord.delivered,
             ord.cancelled,
             ret.returned,
             -- Ноль отгрузок — это ноль процентов возвратов, а не деление на
             -- ноль: пустой период обязан рисоваться, а не падать.
             CASE WHEN ord.shipped_out = 0 THEN 0
                  ELSE round(ret.returned * 100.0 / ord.shipped_out, 1)
             END AS return_rate_pct,
             chg.revenue,
             cod.cod_collected,
             ffh.fulfilment_hours,
             disp.dispatched_count
        FROM (SELECT count(*) AS orders,
                     COALESCE(SUM(o.units), 0)::bigint AS units,
                     count(*) FILTER (WHERE o.status = 'DELIVERED') AS delivered,
                     count(*) FILTER (WHERE o.status = 'CANCELLED') AS cancelled,
                     count(*) FILTER (WHERE o.status IN ${SHIPPED_OUT_STATUSES}) AS shipped_out
                FROM bi_orders o ${orders}) ord,
             (SELECT count(*) AS returned FROM bi_returns r ${returns}) ret,
             (SELECT COALESCE(SUM(c.amount), 0)::numeric(14, 2) AS revenue
                FROM charges c ${charges}) chg,
             (SELECT COALESCE(SUM(sh.cod_collected_amount), 0)::numeric(14, 2) AS cod_collected
                FROM shipments sh
                JOIN orders so ON so.id = sh.order_id ${cod}) cod,
             (SELECT round(
                       COALESCE(percentile_cont(0.5) WITHIN GROUP (ORDER BY t.hours), 0)::numeric, 1
                     ) AS fulfilment_hours
                FROM (${fulfilment}) t) ffh,
             (SELECT count(*) AS dispatched_count FROM bi_orders o ${dispatched}) disp`;
  }

  /**
   * Время от появления заказа до готовности к отгрузке.
   *
   * Берётся МЕДИАНА, а не среднее арифметическое: один заказ, зависший на
   * месяц из-за нехватки товара, сдвигает среднее так, что плитка перестаёт
   * что-либо означать. Период применяется к моменту READY_TO_SHIP — метрика
   * отвечает «сколько занимала подготовка у заказов, закрытых за период».
   * По дате создания последние дни всегда выглядели бы быстрее, чем есть:
   * заказы, ещё не доехавшие до отгрузки, в расчёт просто не попадают.
   */
  private fulfilmentSql(window: ResolvedWindow, bound: BoundFilters, params: SqlParams): string {
    const conds = ['fo.is_split = false'];
    if (bound.seller) conds.push(`fo.seller_id = ${bound.seller}`);
    if (bound.warehouse) conds.push(`fo.warehouse_id = ${bound.warehouse}`);
    if (bound.category) conds.push(`fo.category_id = ${bound.category}`);

    const readyAt = `MIN(h.occurred_at) FILTER (WHERE h.to_status = 'READY_TO_SHIP')`;
    const newAt = `MIN(h.occurred_at) FILTER (WHERE h.to_status = 'NEW')`;
    const having = dateRangeConditions(readyAt, params, window.from, window.to);

    return `
      SELECT (EXTRACT(EPOCH FROM (${readyAt} - ${newAt})) / 3600.0)::float8 AS hours
        FROM bi_order_status_history h
        JOIN orders fo ON fo.id = h.order_id
       ${whereClause(conds)}
       GROUP BY h.order_id
      HAVING ${newAt} IS NOT NULL AND ${having.join(' AND ')}`;
  }

  /**
   * Валюта отчёта. Начисления важнее собранного наложенного платежа: оборот
   * FF — это счета, а COD только проходит через нас. Если валют несколько,
   * берётся преобладающая и клиент видит её в поле `currency` — сложить сумы
   * с долларами и назвать результат оборотом нельзя.
   */
  private reportCurrencySql(
    window: ResolvedWindow,
    bound: BoundFilters,
    params: SqlParams,
  ): string {
    const charges = whereClause(this.chargeConds('c', window, bound, params, null));
    const cod = whereClause(this.codConds('sh', 'so', window, bound, params, null));

    return `
      SELECT x.currency
        FROM (SELECT c.currency AS currency, SUM(c.amount) AS weight, 1 AS pri
                FROM charges c ${charges}
               GROUP BY c.currency
              UNION ALL
              SELECT so.currency, SUM(sh.cod_collected_amount), 2
                FROM shipments sh
                JOIN orders so ON so.id = sh.order_id ${cod}
               GROUP BY so.currency) x
       WHERE x.currency IS NOT NULL
       ORDER BY x.pri ASC, x.weight DESC NULLS LAST
       LIMIT 1`;
  }

  /**
   * Валюта конкретного селлера: начисления → собранный COD → заявленный COD.
   * Порядок не случаен: первое — деньги FF, второе — подтверждённый факт,
   * третье — только намерение. Определив её ОДИН раз, оба денежных числа
   * строки считаем в ней же, и подпись `currency` перестаёт быть враньём.
   */
  private sellerCurrencySql(
    window: ResolvedWindow,
    bound: BoundFilters,
    params: SqlParams,
  ): string {
    const charges = whereClause(this.chargeConds('c', window, bound, params, null));
    const cod = whereClause(this.codConds('sh', 'so', window, bound, params, null));
    const declared = whereClause([
      ...this.orderConds('bo', window, bound, params, 'created_at'),
      'bo.cod_amount IS NOT NULL',
    ]);

    return `
      SELECT x.currency
        FROM (SELECT c.currency AS currency, SUM(c.amount) AS weight, 1 AS pri
                FROM charges c ${charges}
               GROUP BY c.currency
              UNION ALL
              SELECT so.currency, SUM(sh.cod_collected_amount), 2
                FROM shipments sh
                JOIN orders so ON so.id = sh.order_id ${cod}
               GROUP BY so.currency
              UNION ALL
              SELECT bo.currency, SUM(bo.cod_amount), 3
                FROM bi_orders bo ${declared}
               GROUP BY bo.currency) x
       WHERE x.currency IS NOT NULL
       ORDER BY x.pri ASC, x.weight DESC NULLS LAST
       LIMIT 1`;
  }

  // -------------------------------------------------------- условия фильтров

  private bindFilters(
    filters: OverviewFilters,
    params: SqlParams,
    sellerSql: string | null,
  ): BoundFilters {
    return {
      seller: sellerSql ?? (filters.sellerId ? params.bind(filters.sellerId) : null),
      warehouse: filters.warehouseId ? params.bind(filters.warehouseId) : null,
      category: filters.categoryId ? params.bind(filters.categoryId) : null,
    };
  }

  /**
   * Заказ-контейнер разделённого заказа исключён ВСЕГДА (`is_split = false`):
   * он не исполняется сам, его исполняют дочерние заказы, и без этого условия
   * один заказ попадает в отчёт дважды.
   */
  private orderConds(
    alias: string,
    window: ResolvedWindow,
    bound: BoundFilters,
    params: SqlParams,
    dateColumn: 'created_at' | 'dispatched_at',
  ): string[] {
    const conds = [`${alias}.is_split = false`];
    conds.push(...dateRangeConditions(`${alias}.${dateColumn}`, params, window.from, window.to));
    if (bound.seller) conds.push(`${alias}.seller_id = ${bound.seller}`);
    if (bound.warehouse) conds.push(`${alias}.warehouse_id = ${bound.warehouse}`);
    if (bound.category) conds.push(`${alias}.category_id = ${bound.category}`);
    return conds;
  }

  private returnConds(
    alias: string,
    window: ResolvedWindow,
    bound: BoundFilters,
    params: SqlParams,
  ): string[] {
    const conds = [`${alias}.status <> 'CANCELLED'`];
    conds.push(...dateRangeConditions(`${alias}.created_at`, params, window.from, window.to));
    if (bound.seller) conds.push(`${alias}.seller_id = ${bound.seller}`);
    if (bound.warehouse) conds.push(`${alias}.warehouse_id = ${bound.warehouse}`);
    // Своей категории у возврата нет — она берётся у заказа, по которому товар
    // вернулся. Возврат без заказа в такой срез не попадает, и это честнее,
    // чем приписать его категории наугад.
    if (bound.category) {
      conds.push(
        `EXISTS (SELECT 1 FROM orders ro
                  WHERE ro.id = ${alias}.order_id AND ro.category_id = ${bound.category})`,
      );
    }
    return conds;
  }

  /**
   * Начисления. Склад и категория у начисления не хранятся — они берутся у
   * заказа, к которому оно привязано. Поэтому при таком фильтре хранение и
   * прочие безадресные услуги из оборота выпадают: приписать их складу нечем,
   * а приписать наугад значит получить цифру, не сходящуюся ни с одним счётом.
   */
  private chargeConds(
    alias: string,
    window: ResolvedWindow,
    bound: BoundFilters,
    params: SqlParams,
    currencySql: string | null,
  ): string[] {
    const conds: string[] = [];
    conds.push(...dateRangeConditions(`${alias}.occurred_at`, params, window.from, window.to));
    if (bound.seller) conds.push(`${alias}.seller_id = ${bound.seller}`);
    if (bound.warehouse) {
      conds.push(
        `EXISTS (SELECT 1 FROM orders co
                  WHERE co.id = ${alias}.order_id AND co.warehouse_id = ${bound.warehouse})`,
      );
    }
    if (bound.category) {
      conds.push(
        `EXISTS (SELECT 1 FROM orders co
                  WHERE co.id = ${alias}.order_id AND co.category_id = ${bound.category})`,
      );
    }
    if (currencySql) {
      conds.push(`(${currencySql} IS NULL OR ${alias}.currency = ${currencySql})`);
    }
    return conds;
  }

  /**
   * Собранный наложенный платёж. Период считается по МОМЕНТУ СБОРА
   * (`cod_collected_at`), а не по дате заказа: это денежное событие со своим
   * временем, и в отчёте за август должно стоять собранное в августе.
   * У отправлений нет `seller_id` — он берётся у заказа.
   */
  private codConds(
    shipmentAlias: string,
    orderAlias: string,
    window: ResolvedWindow,
    bound: BoundFilters,
    params: SqlParams,
    currencySql: string | null,
  ): string[] {
    const conds = [
      `${shipmentAlias}.cod_collected_amount IS NOT NULL`,
      `${orderAlias}.is_split = false`,
    ];
    conds.push(
      ...dateRangeConditions(`${shipmentAlias}.cod_collected_at`, params, window.from, window.to),
    );
    if (bound.seller) conds.push(`${orderAlias}.seller_id = ${bound.seller}`);
    if (bound.warehouse) conds.push(`${orderAlias}.warehouse_id = ${bound.warehouse}`);
    if (bound.category) conds.push(`${orderAlias}.category_id = ${bound.category}`);
    if (currencySql) {
      conds.push(`(${currencySql} IS NULL OR ${orderAlias}.currency = ${currencySql})`);
    }
    return conds;
  }
}
