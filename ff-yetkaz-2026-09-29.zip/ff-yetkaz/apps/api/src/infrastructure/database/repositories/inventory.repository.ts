import { Injectable } from '@nestjs/common';
import type { InventoryUnitStatus, MovementReason } from '@ff/shared';
import type { SqlRunner } from '../sql-runner';

/** Строка-кандидат на резерв: ячейка, партия и сколько в ней лежит. */
export interface AvailableStockSliceRow {
  bin_id: string;
  lot_id: string | null;
  quantity: number;
}

/** Активный резерв владельца — всё, что нужно, чтобы вернуть товар на место. */
export interface ActiveReservationRow {
  id: string;
  sku_id: string;
  warehouse_id: string;
  bin_id: string;
  lot_id: string | null;
  quantity: number;
}

/** Захваченная строка остатка: её идентификатор и текущее количество. */
export interface LockedStockSliceRow {
  id: string;
  quantity: number;
}

/** Свод остатка с раскладкой до ячейки — одна строка на срез. */
export interface StockSummaryRow {
  sku_id: string;
  sku_code: string;
  sku_name: string;
  warehouse_id: string;
  bin_id: string;
  bin_code: string;
  status: InventoryUnitStatus;
  total: string;
}

export interface StockSummaryFilter {
  sellerId?: string | null;
  skuId?: string;
  warehouseId?: string;
}

export interface MovementsFilter {
  /** Область селлера из токена; `null` — ограничения нет (оператор). */
  sellerScope: string | null;
  skuId?: string;
  warehouseId?: string;
  limit: number;
}

export interface ReservationInsert {
  ownerType: string;
  ownerId: string;
  skuId: string;
  warehouseId: string;
  binId: string;
  lotId: string | null;
  quantity: number;
}

export interface StockSliceKey {
  skuId: string;
  warehouseId: string;
  binId: string;
  lotId: string | null;
  status: InventoryUnitStatus;
}

export interface StockUpsert {
  skuId: string;
  warehouseId: string;
  binId: string;
  lotId: string | null;
  status: InventoryUnitStatus;
  quantity: number;
}

export interface StockMovementInsert {
  skuId: string;
  warehouseId: string;
  lotId: string | null;
  fromBinId: string | null;
  fromStatus: InventoryUnitStatus | null;
  toBinId: string | null;
  toStatus: InventoryUnitStatus | null;
  quantity: number;
  reason: MovementReason;
  referenceType: string | null;
  referenceId: string | null;
  comment: string | null;
  actorUserId: string;
  correlationId: string | null;
}

/**
 * Весь сырой SQL остатков. Соединение приходит первым аргументом (`runner`) и
 * значения по умолчанию не имеет: половина этих запросов обязана выполняться
 * внутри транзакции вызывающего (блокировки под резерв, списание, журнал), и
 * взятое репозиторием соединение увело бы их мимо неё.
 */
@Injectable()
export class InventoryRepository {
  // ------------------------------------------------------------ резервирование

  /**
   * Кандидаты на резерв в порядке FEFO (по сроку годности партии), при его
   * отсутствии — FIFO (по дате появления среза).
   *
   * `FOR UPDATE OF s` — блокируем ТОЛЬКО остатки: `lots` стоит на nullable-стороне
   * LEFT JOIN, и PostgreSQL отказывается их блокировать. Блокировка и есть защита
   * от двойного резерва последней единицы: второй запрос ждёт первого, а после
   * его коммита перепроверка `quantity > 0` уже не находит разобранную строку.
   * Поэтому запрос обязан идти в транзакции вызывающего.
   */
  async lockAvailableSlicesForReserve(
    runner: SqlRunner,
    skuId: string,
    warehouseId: string,
  ): Promise<AvailableStockSliceRow[]> {
    return runner.query(
      `SELECT s.bin_id, s.lot_id, s.quantity
             FROM stock s
             LEFT JOIN lots l ON l.id = s.lot_id
            WHERE s.sku_id = $1 AND s.warehouse_id = $2
              AND s.status = 'AVAILABLE' AND s.quantity > 0
            ORDER BY l.expiry_date ASC NULLS LAST, s.created_at ASC
              FOR UPDATE OF s`,
      [skuId, warehouseId],
    );
  }

  /** Заводит строку резерва и возвращает её идентификатор. */
  async insertReservation(
    runner: SqlRunner,
    input: ReservationInsert,
  ): Promise<Array<{ id: string }>> {
    return runner.query(
      `INSERT INTO reservations
             (owner_type, owner_id, sku_id, warehouse_id, bin_id, lot_id, quantity, status)
           VALUES ($1, $2, $3, $4, $5, $6, $7, 'ACTIVE')
           RETURNING id`,
      [
        input.ownerType,
        input.ownerId,
        input.skuId,
        input.warehouseId,
        input.binId,
        input.lotId,
        input.quantity,
      ],
    );
  }

  /**
   * Все активные резервы владельца под блокировкой: снятие резерва и его
   * повторное снятие конкурентом не должны оба вернуть товар в `AVAILABLE`.
   */
  async lockActiveReservations(
    runner: SqlRunner,
    ownerType: string,
    ownerId: string,
  ): Promise<ActiveReservationRow[]> {
    return runner.query(
      `SELECT id, sku_id, warehouse_id, bin_id, lot_id, quantity
           FROM reservations
          WHERE owner_type = $1 AND owner_id = $2 AND status = 'ACTIVE'
            FOR UPDATE`,
      [ownerType, ownerId],
    );
  }

  async markReservationReleased(runner: SqlRunner, reservationId: string): Promise<void> {
    await runner.query(
      `UPDATE reservations SET status = 'RELEASED', released_at = now() WHERE id = $1`,
      [reservationId],
    );
  }

  // ------------------------------------------------------------------ движение

  /**
   * Захват строки остатка перед списанием.
   *
   * `lot_id IS NOT DISTINCT FROM $4` вместо `=`: у непартионного товара партия
   * NULL, а `NULL = NULL` в SQL не истина, а неизвестность — обычное сравнение
   * молча не нашло бы ни одной такой строки. `FOR UPDATE` держит срез до конца
   * транзакции вызывающего, поэтому проверка «хватает ли» и само списание не
   * могут разъехаться с конкурентом.
   */
  async lockStockSlice(runner: SqlRunner, key: StockSliceKey): Promise<LockedStockSliceRow[]> {
    return runner.query(
      `SELECT id, quantity FROM stock
          WHERE sku_id = $1 AND warehouse_id = $2 AND bin_id = $3
            AND lot_id IS NOT DISTINCT FROM $4 AND status = $5
            FOR UPDATE`,
      [key.skuId, key.warehouseId, key.binId, key.lotId, key.status],
    );
  }

  async decreaseStockQuantity(
    runner: SqlRunner,
    stockId: string,
    quantity: number,
  ): Promise<void> {
    await runner.query(`UPDATE stock SET quantity = quantity - $2 WHERE id = $1`, [
      stockId,
      quantity,
    ]);
  }

  /**
   * Пополнение среза. `ON CONFLICT` по естественному ключу — потому что строка
   * остатка переиспользуется: срез заводится один раз и живёт вечно. Уникальный
   * индекс объявлен как `NULLS NOT DISTINCT`, иначе непартионный товар (партия
   * NULL) плодил бы по строке на каждое поступление.
   */
  async upsertStockQuantity(runner: SqlRunner, input: StockUpsert): Promise<void> {
    await runner.query(
      `INSERT INTO stock (sku_id, warehouse_id, bin_id, lot_id, status, quantity)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (sku_id, warehouse_id, bin_id, lot_id, status)
         DO UPDATE SET quantity = stock.quantity + EXCLUDED.quantity`,
      [input.skuId, input.warehouseId, input.binId, input.lotId, input.status, input.quantity],
    );
  }

  /** Строка append-only журнала: без неё изменение остатка не имеет объяснения. */
  async insertStockMovement(runner: SqlRunner, input: StockMovementInsert): Promise<void> {
    await runner.query(
      `INSERT INTO stock_movements
         (sku_id, warehouse_id, lot_id, from_bin_id, from_status, to_bin_id, to_status,
          quantity, reason, reference_type, reference_id, comment, actor_user_id, correlation_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`,
      [
        input.skuId,
        input.warehouseId,
        input.lotId,
        input.fromBinId,
        input.fromStatus,
        input.toBinId,
        input.toStatus,
        input.quantity,
        input.reason,
        input.referenceType,
        input.referenceId,
        input.comment,
        input.actorUserId,
        input.correlationId,
      ],
    );
  }

  // -------------------------------------------------------------------- чтение

  /**
   * Свод остатка с группировкой СРАЗУ до ячейки: суммы по статусам складываются
   * из тех же строк, что и раскладка. Отдельный запрос за итогами разошёлся бы
   * с раскладкой — между двумя запросами товар успевает переехать.
   */
  async findStockSummaries(
    runner: SqlRunner,
    filter: StockSummaryFilter,
  ): Promise<StockSummaryRow[]> {
    const conditions: string[] = ['s.quantity > 0'];
    const params: unknown[] = [];
    if (filter.sellerId) {
      params.push(filter.sellerId);
      conditions.push(`sku.seller_id = $${params.length}`);
    }
    if (filter.skuId) {
      params.push(filter.skuId);
      conditions.push(`s.sku_id = $${params.length}`);
    }
    if (filter.warehouseId) {
      params.push(filter.warehouseId);
      conditions.push(`s.warehouse_id = $${params.length}`);
    }

    return runner.query(
      `SELECT s.sku_id, sku.sku_code, sku.name AS sku_name, s.warehouse_id,
              s.bin_id, b.code AS bin_code, s.status, SUM(s.quantity)::text AS total
         FROM stock s
         JOIN skus sku ON sku.id = s.sku_id
         JOIN bin_locations b ON b.id = s.bin_id
        WHERE ${conditions.join(' AND ')}
        GROUP BY s.sku_id, sku.sku_code, sku.name, s.warehouse_id, s.bin_id, b.code, s.status
        ORDER BY sku.sku_code ASC, b.code ASC, s.status ASC`,
      params,
    );
  }

  /**
   * Журнал движений. Соединение со `skus` нужно не для полей, а для области
   * селлера: право видеть движение определяет владелец товара.
   */
  async findMovements(
    runner: SqlRunner,
    filter: MovementsFilter,
  ): Promise<Array<Record<string, unknown>>> {
    const conditions: string[] = ['TRUE'];
    const params: unknown[] = [];
    if (filter.sellerScope !== null) {
      params.push(filter.sellerScope);
      conditions.push(`sku.seller_id = $${params.length}`);
    }
    if (filter.skuId) {
      params.push(filter.skuId);
      conditions.push(`m.sku_id = $${params.length}`);
    }
    if (filter.warehouseId) {
      params.push(filter.warehouseId);
      conditions.push(`m.warehouse_id = $${params.length}`);
    }
    params.push(filter.limit);

    return runner.query(
      `SELECT m.* FROM stock_movements m
         JOIN skus sku ON sku.id = m.sku_id
        WHERE ${conditions.join(' AND ')}
        ORDER BY m.occurred_at DESC, m.id DESC
        LIMIT $${params.length}`,
      params,
    );
  }
}
