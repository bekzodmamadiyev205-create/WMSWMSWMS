import { Injectable } from '@nestjs/common';
import type { ChargeKind, TariffUnit } from '@ff/shared';
import type { SqlRunner } from '../sql-runner';

/**
 * Строка-основание для начисления. Все возможные меры объёма приходят сразу:
 * какая из них нужна, решает единица измерения тарифа, а она известна только
 * после подбора правила.
 *
 * Колонку, которой в источнике нет, писать НЕЛЬЗЯ: `row[column]` тогда
 * `undefined`, объём получается нулевым, и строка молча уезжает в
 * `billing_problems` вместо того, чтобы посчитаться. Поэтому каждый источник
 * перечисляет ВСЕ поля, ставя NULL там, где мера неприменима.
 */
export interface AccrualRow {
  seller_id: string;
  occurred_at: string;
  source_key: string;
  order_id: string | null;
  shipment_id: string | null;
  qty_units: string | null;
  qty_orders: string | null;
  qty_kg: string | null;
  qty_m3day: string | null;
  /** Коробки и паллеты — считаемые: штуки / норму из `skus`, а не факт склада. */
  qty_boxes: string | null;
  qty_pallets: string | null;
  /** Тара × сутки хранения: берётся из среза, а не пересчитывается. */
  qty_boxday: string | null;
  qty_palletday: string | null;
  qty_cod: string | null;
  cod_currency: string | null;
}

export interface AccrualSource {
  kind: ChargeKind;
  title: string;
  /**
   * $1 — начало периода, $2 — конец (не включая).
   *
   * Текст запроса — принадлежность репозитория: прикладной слой берёт источники
   * готовым списком и возвращает их сюда же, в `rowsForSource`.
   */
  sql: string;
}

/** Собранный курьером платёж, который надо провести по книге. */
export interface CollectedCodRow {
  id: string;
  seller_id: string;
  amount: string;
  currency: string | null;
  collected_at: string;
  shipment_no: string;
}

/** Значения одной строки `charges` — ровно то, что вставляется. */
export interface ChargeInsert {
  sellerId: string;
  kind: ChargeKind;
  unit: TariffUnit;
  quantity: string;
  unitPrice: string;
  amount: string;
  currency: string;
  occurredAt: string;
  orderId: string | null;
  shipmentId: string | null;
  sourceKey: string;
  tariffRuleId: string;
}

/**
 * Коробки и паллеты по позициям группы.
 *
 * Делится СУММА, а не каждая позиция по отдельности: округление на каждой
 * строке накопило бы в счёте лишнюю тару из воздуха. И если норма задана не у
 * всех товаров группы — весь показатель NULL, а не «сколько получилось»:
 * `SUM` молча пропускает NULL-слагаемые, и занижение объёма выглядело бы как
 * нормально посчитанный счёт. Пусть лучше начисление уйдёт в
 * `billing_problems` с честной причиной.
 */
const boxTerms = (qtyExpr: string, skuAlias: string, rowFilter?: string): string => {
  /**
   * `rowFilter` режет и проверку норм, и сумму — ОБЕ обязательно.
   *
   * Позиция, которой набрали ноль, денег не стоит, но в `bool_and` она
   * участвовала наравне с остальными: товар без нормы, за который не берут
   * ничего, накладывал вето на тару всего заказа, и коробки не считались вовсе.
   * Фильтровать только `SUM` тоже нельзя — вето осталось бы на месте.
   */
  const filter = rowFilter ? ` FILTER (WHERE ${rowFilter})` : '';
  return `
  (CASE WHEN bool_and(${skuAlias}.units_per_box IS NOT NULL)${filter}
        THEN SUM((${qtyExpr})::numeric / ${skuAlias}.units_per_box)${filter} END)::text AS qty_boxes,
  (CASE WHEN bool_and(${skuAlias}.units_per_pallet IS NOT NULL)${filter}
        THEN SUM((${qtyExpr})::numeric / ${skuAlias}.units_per_pallet)${filter} END)::text AS qty_pallets`;
};

/** Тот же счёт тары, но по позициям одной коробки — подзапросом. */
const PACKAGE_MEASURES = `
  SELECT SUM(i.quantity)::text AS units,
         (CASE WHEN bool_and(sk.units_per_box IS NOT NULL)
               THEN SUM(i.quantity::numeric / sk.units_per_box) END)::text AS boxes,
         (CASE WHEN bool_and(sk.units_per_pallet IS NOT NULL)
               THEN SUM(i.quantity::numeric / sk.units_per_pallet) END)::text AS pallets
    FROM package_items i
    JOIN skus sk ON sk.id = i.sku_id`;

/**
 * Источники начислений — SQL по фактам, а не подписка на события.
 *
 * Событие в памяти можно потерять между коммитом и доставкой; факт в базе —
 * нет. Прогон детерминирован и идемпотентен (`charges.source_key` уникален),
 * поэтому его можно перезапускать сколько угодно: пропущенное досчитается,
 * посчитанное не удвоится.
 */
const SOURCES: AccrualSource[] = [
  {
    kind: 'INBOUND',
    title: 'Приёмка',
    sql: `
      SELECT a.seller_id,
             r.completed_at AS occurred_at,
             'inbound:' || r.id AS source_key,
             NULL::uuid AS order_id, NULL::uuid AS shipment_id,
             SUM(rl.qty_received)::text AS qty_units,
             '1' AS qty_orders,
             -- Вес приёмки склад не вводит — он считается из нормы товара:
             -- ALLOWED_UNITS.INBOUND разрешает PER_KG, и без этой величины
             -- заведённое из формы правило «приёмка за кг» отправляло бы
             -- КАЖДУЮ приёмку в billing_problems.
             --
             -- Правило то же, что у тары: нет веса хотя бы у одного принятого
             -- товара — вся величина NULL. SUM молча пропускает NULL, и
             -- недостача выглядела бы нормально посчитанным счётом.
             (CASE WHEN bool_and(sku.weight_g IS NOT NULL)
                   THEN SUM(rl.qty_received::numeric * sku.weight_g) / 1000 END)::text AS qty_kg,
             NULL AS qty_m3day,
             ${boxTerms('rl.qty_received', 'sku')},
             NULL AS qty_boxday, NULL AS qty_palletday,
             NULL AS qty_cod, NULL AS cod_currency
        FROM receipts r
        JOIN asns a ON a.id = r.asn_id
        JOIN receipt_lines rl ON rl.receipt_id = r.id
        JOIN skus sku ON sku.id = rl.sku_id
       WHERE r.status = 'COMPLETED' AND r.completed_at >= $1 AND r.completed_at < $2
       GROUP BY a.seller_id, r.id, r.completed_at`,
  },
  {
    kind: 'PICKING',
    title: 'Сборка',
    sql: `
      SELECT o.seller_id,
             t.completed_at AS occurred_at,
             'picking:' || o.id AS source_key,
             o.id AS order_id, NULL::uuid AS shipment_id,
             SUM(l.qty_picked)::text AS qty_units,
             '1' AS qty_orders,
             NULL AS qty_kg, NULL AS qty_m3day,
             ${boxTerms('l.qty_picked', 'sku', 'l.qty_picked > 0')},
             NULL AS qty_boxday, NULL AS qty_palletday,
             NULL AS qty_cod, NULL AS cod_currency
        FROM pick_tasks t
        JOIN pick_task_lines l ON l.task_id = t.id
        JOIN orders o ON o.id = l.order_id
        JOIN skus sku ON sku.id = l.sku_id
       WHERE t.status = 'COMPLETED' AND t.completed_at >= $1 AND t.completed_at < $2
       GROUP BY o.seller_id, o.id, t.completed_at
      HAVING SUM(l.qty_picked) > 0`,
  },
  {
    kind: 'PACKING',
    title: 'Упаковка',
    sql: `
      SELECT o.seller_id,
             p.packed_at AS occurred_at,
             'packing:' || p.id AS source_key,
             o.id AS order_id, NULL::uuid AS shipment_id,
             it.units AS qty_units,
             '1' AS qty_orders,
             (p.actual_weight_g / 1000.0)::text AS qty_kg,
             NULL AS qty_m3day,
             it.boxes AS qty_boxes, it.pallets AS qty_pallets,
             NULL AS qty_boxday, NULL AS qty_palletday,
             NULL AS qty_cod, NULL AS cod_currency
        FROM packages p
        JOIN orders o ON o.id = p.order_id
        LEFT JOIN LATERAL (${PACKAGE_MEASURES} WHERE i.package_id = p.id) it ON TRUE
       WHERE p.status = 'PACKED' AND p.packed_at >= $1 AND p.packed_at < $2`,
  },
  {
    kind: 'DELIVERY',
    title: 'Передача в доставку',
    sql: `
      SELECT o.seller_id,
             s.handed_over_at AS occurred_at,
             'delivery:' || s.id AS source_key,
             o.id AS order_id, s.id AS shipment_id,
             NULL AS qty_units,
             '1' AS qty_orders,
             (s.weight_g / 1000.0)::text AS qty_kg,
             NULL AS qty_m3day,
             it.boxes AS qty_boxes, it.pallets AS qty_pallets,
             NULL AS qty_boxday, NULL AS qty_palletday,
             NULL AS qty_cod, NULL AS cod_currency
        FROM shipments s
        JOIN orders o ON o.id = s.order_id
        LEFT JOIN LATERAL (${PACKAGE_MEASURES} WHERE i.package_id = s.package_id) it ON TRUE
       WHERE s.handed_over_at IS NOT NULL AND s.handed_over_at >= $1 AND s.handed_over_at < $2`,
  },
  {
    kind: 'COD_FEE',
    title: 'Комиссия за наложенный платёж',
    sql: `
      SELECT o.seller_id,
             s.cod_collected_at AS occurred_at,
             'cod_fee:' || s.id AS source_key,
             o.id AS order_id, s.id AS shipment_id,
             NULL AS qty_units, '1' AS qty_orders, NULL AS qty_kg, NULL AS qty_m3day,
             NULL AS qty_boxes, NULL AS qty_pallets,
             NULL AS qty_boxday, NULL AS qty_palletday,
             s.cod_collected_amount::text AS qty_cod,
             -- Валюта отправления, иначе валюта заказа: у дочернего заказа
             -- сплита COD и валюта остаются на родителе, а курьер собирает
             -- деньги именно по ребёнку. Без COALESCE проводка уходила с
             -- валютой NULL и разбивалась о CHECK ledger_entries_currency_shape.
             COALESCE(s.currency, o.currency) AS cod_currency
        FROM shipments s
        JOIN orders o ON o.id = s.order_id
       WHERE s.cod_collected_amount IS NOT NULL AND s.cod_collected_amount > 0
         AND s.cod_collected_at >= $1 AND s.cod_collected_at < $2`,
  },
  {
    kind: 'STORAGE',
    title: 'Хранение',
    sql: `
      SELECT s.seller_id,
             -- Полдень по времени сервера, а не конец суток в UTC: иначе срез
             -- за 6-е число уезжает в 7-е и не попадает в счёт за период.
             (s.snapshot_date::timestamptz + interval '12 hours') AS occurred_at,
             'storage:' || s.seller_id || ':' || s.snapshot_date AS source_key,
             NULL::uuid AS order_id, NULL::uuid AS shipment_id,
             s.units::text AS qty_units, NULL AS qty_orders, NULL AS qty_kg,
             (s.volume_mm3 / 1000000000.0)::text AS qty_m3day,
             NULL AS qty_boxes, NULL AS qty_pallets,
             -- Ноль в срезе означает «норма тары есть не у всех товаров»
             -- (см. snapshotStorage), а не «тары ноль»: остаток положительный
             -- по условию среза. Превращаем его в NULL, чтобы начисление ушло
             -- в billing_problems с причиной «нет нормы тары», а не
             -- тарифицировалось заниженной цифрой.
             NULLIF(s.boxes, 0)::text AS qty_boxday,
             NULLIF(s.pallets, 0)::text AS qty_palletday,
             NULL AS qty_cod, NULL AS cod_currency
        FROM storage_snapshots s
       WHERE s.snapshot_date >= $1::date AND s.snapshot_date < $2::date
         -- Тара считается наравне с объёмом: у товара могут быть заданы нормы
         -- упаковки и не заданы габариты, и тогда фильтр только по volume_mm3
         -- молча выбрасывал бы день из счёта за паллето-сутки.
         AND (s.volume_mm3 > 0 OR s.boxes > 0 OR s.pallets > 0)`,
  },
];

/**
 * Сырой SQL начислений. Соединение не внедряется: его передаёт вызывающий —
 * `em` внутри транзакции, `this.dataSource` вне её.
 *
 * Вставка начисления и его проводка по книге обязаны идти ОДНОЙ транзакцией:
 * сходимость двойной записи проверяет отложенный триггер на COMMIT, а
 * `charges.transaction_id` без самой проводки — начисление, про которое нельзя
 * сказать, попало ли оно в бухгалтерию.
 */
@Injectable()
export class AccrualRepository {
  /** Источники начислений в порядке прогона. Текст запросов — здесь же. */
  get sources(): AccrualSource[] {
    return SOURCES;
  }

  /**
   * Ежедневный срез хранения по всем селлерам.
   *
   * `ON CONFLICT DO UPDATE` делает повтор безопасным: срез за сегодня можно
   * снимать хоть ежечасно, каждый раз уточняя цифру. Тара считается по
   * принципу «всё или ничего» (`bool_and`): норма задана не у всех товаров —
   * в срез уходит ноль, и источник STORAGE превращает его обратно в NULL.
   */
  upsertStorageSnapshots(runner: SqlRunner, date: string): Promise<Array<{ count: string }>> {
    return runner.query(
      `INSERT INTO storage_snapshots (snapshot_date, seller_id, units, volume_mm3, boxes, pallets)
       SELECT $1::date, sku.seller_id,
              SUM(st.quantity)::int,
              SUM(st.quantity * COALESCE(sku.volume_mm3, 0))::numeric,
              -- Всё или ничего: норма задана у ВСЕХ товаров селлера — считаем
              -- тару, задана хотя бы не у одного — пишем ноль.
              --
              -- Раньше здесь стоял голый SUM, а он молча пропускает NULL: у
              -- селлера с нормой на двух артикулах из десяти в срез уезжала
              -- тара по этим двум, и он платил за хранение двух. Тихая
              -- недостача в счёте — худший вид ошибки в биллинге.
              --
              -- Правильная величина тут — NULL, но колонки объявлены
              -- NOT NULL DEFAULT 0, а миграцию трогать нельзя. Поэтому признак
              -- неполноты несёт сам ноль: при положительном остатке (условие
              -- ниже) полностью заполненные нормы нулём обернуться не могут,
              -- значит ноль читается однозначно. Источник STORAGE превращает
              -- его обратно в NULL, и норма проверяется по факту — на этапе
              -- начисления, где строка честно уходит в billing_problems.
              CASE WHEN bool_and(sku.units_per_box IS NOT NULL)
                   THEN SUM(st.quantity::numeric / sku.units_per_box) ELSE 0 END,
              CASE WHEN bool_and(sku.units_per_pallet IS NOT NULL)
                   THEN SUM(st.quantity::numeric / sku.units_per_pallet) ELSE 0 END
         FROM stock st
         JOIN skus sku ON sku.id = st.sku_id
        WHERE st.quantity > 0
          AND st.status IN ('AVAILABLE', 'RESERVED', 'PICKED', 'PACKED', 'QUARANTINE')
        GROUP BY sku.seller_id
       ON CONFLICT (snapshot_date, seller_id)
       DO UPDATE SET units = EXCLUDED.units, volume_mm3 = EXCLUDED.volume_mm3,
                     boxes = EXCLUDED.boxes, pallets = EXCLUDED.pallets
       RETURNING 1 AS count`,
      [date],
    );
  }

  /** Строки-основания одного источника за период: $1 — начало, $2 — конец. */
  rowsForSource(
    runner: SqlRunner,
    source: AccrualSource,
    periodStart: string,
    periodEnd: string,
  ): Promise<AccrualRow[]> {
    return runner.query(source.sql, [periodStart, periodEnd]);
  }

  /** Неразобранные проблемы начислений: свежие сверху, с потолком выдачи. */
  openProblems(runner: SqlRunner): Promise<Array<Record<string, unknown>>> {
    return runner.query(
      `SELECT id, seller_id, kind, source_key, reason, occurred_at, resolved_at
         FROM billing_problems WHERE resolved_at IS NULL ORDER BY occurred_at DESC LIMIT 200`,
    );
  }

  /**
   * Уже посчитанное начисление по ключу идемпотентности.
   *
   * Это быстрая проверка, а не защита от гонки: настоящую держит уникальный
   * индекс `uq_charges_source`, и вставка отдельно разбирает его нарушение.
   */
  chargeIdBySourceKey(runner: SqlRunner, sourceKey: string): Promise<Array<{ id: string }>> {
    return runner.query(`SELECT id FROM charges WHERE source_key = $1`, [sourceKey]);
  }

  /**
   * Начисление. Услуга и единица приводятся к своим enum'ам явно; повтор
   * ключа отбивает `uq_charges_source`, и вызывающий читает это как «уже есть».
   */
  insertCharge(runner: SqlRunner, charge: ChargeInsert): Promise<Array<{ id: string }>> {
    return runner.query(
      `INSERT INTO charges
             (seller_id, kind, unit, quantity, unit_price, amount, currency, occurred_at,
              order_id, shipment_id, source_key, tariff_rule_id)
           VALUES ($1, $2::charge_kind, $3::tariff_unit, $4, $5, $6, $7, $8, $9, $10, $11, $12)
           RETURNING id`,
      [
        charge.sellerId,
        charge.kind,
        charge.unit,
        charge.quantity,
        charge.unitPrice,
        charge.amount,
        charge.currency,
        charge.occurredAt,
        charge.orderId,
        charge.shipmentId,
        charge.sourceKey,
        charge.tariffRuleId,
      ],
    );
  }

  /**
   * Привязка начисления к проводке. Идёт в ТОЙ ЖЕ транзакции, что и вставка
   * начисления с проводкой: ссылка на проводку, которая откатилась, — это
   * начисление без бухгалтерии.
   */
  async linkChargeToTransaction(
    runner: SqlRunner,
    chargeId: string,
    transactionId: string | null,
  ): Promise<void> {
    await runner.query(`UPDATE charges SET transaction_id = $2 WHERE id = $1`, [
      chargeId,
      transactionId,
    ]);
  }

  /**
   * Собранный курьером наложенный платёж за период.
   *
   * Валюта отправления, иначе валюта заказа — та же подстановка, что и в
   * источнике COD_FEE: у дочернего заказа сплита COD с валютой остаются на
   * родителе, а собирает курьер по ребёнку.
   */
  collectedCod(
    runner: SqlRunner,
    periodStart: string,
    periodEnd: string,
  ): Promise<CollectedCodRow[]> {
    return runner.query(
      `SELECT s.id, o.seller_id, s.cod_collected_amount::text AS amount,
              COALESCE(s.currency, o.currency) AS currency,
              s.cod_collected_at AS collected_at, s.shipment_no
         FROM shipments s
         JOIN orders o ON o.id = s.order_id
        WHERE s.cod_collected_amount IS NOT NULL AND s.cod_collected_amount > 0
          AND s.cod_collected_at >= $1 AND s.cod_collected_at < $2`,
      [periodStart, periodEnd],
    );
  }

  /**
   * Отложенное начисление с причиной.
   *
   * `DO NOTHING` по ЧАСТИЧНОМУ индексу (`WHERE resolved_at IS NULL`): пока
   * проблему не разобрали, повторный прогон не плодит её копии, а разобранная
   * запись не мешает завести новую по тому же ключу.
   */
  async insertProblem(
    runner: SqlRunner,
    sellerId: string,
    kind: ChargeKind,
    sourceKey: string,
    reason: string,
    occurredAt: string,
  ): Promise<void> {
    await runner.query(
      `INSERT INTO billing_problems (seller_id, kind, source_key, reason, occurred_at)
       VALUES ($1, $2::charge_kind, $3, $4, $5)
       ON CONFLICT (source_key) WHERE resolved_at IS NULL DO NOTHING`,
      [sellerId, kind, sourceKey, reason, occurredAt],
    );
  }
}
