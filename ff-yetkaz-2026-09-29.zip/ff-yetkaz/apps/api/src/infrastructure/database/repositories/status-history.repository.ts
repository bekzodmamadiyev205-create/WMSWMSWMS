import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/**
 * Журналы статусов: `order_status_history` и `return_status_history`.
 *
 * Только вставка — правок трека не бывает. У журнала заказа это гарантирует
 * ещё и БД: UPDATE/DELETE запрещены триггером, append-only.
 *
 * Runner здесь особенно важен: трек пишется ТЕМ ЖЕ manager, что и сам переход
 * статуса. Возьми репозиторий соединение сам — запись трека уехала бы мимо
 * транзакции перехода: она не откатилась бы вместе с ним, и в журнале остался
 * бы статус, до которого заказ так и не дошёл.
 */
@Injectable()
export class StatusHistoryRepository {
  insertOrderTransition(
    runner: SqlRunner,
    params: [
      orderId: string,
      fromStatus: string | null,
      toStatus: string,
      source: string,
      actorUserId: string | null,
      comment: string | null,
    ],
  ): Promise<unknown> {
    return runner.query(
      `INSERT INTO order_status_history
           (order_id, from_status, to_status, source, actor_user_id, comment)
         VALUES ($1, $2, $3, $4, $5, $6)`,
      params,
    );
  }

  /**
   * У возвратов колонки `source` нет: возврат двигает только человек,
   * внешних инициаторов у него не бывает.
   */
  insertReturnTransition(
    runner: SqlRunner,
    params: [
      returnId: string,
      fromStatus: string | null,
      toStatus: string,
      actorUserId: string | null,
      comment: string | null,
    ],
  ): Promise<unknown> {
    return runner.query(
      `INSERT INTO return_status_history
           (return_id, from_status, to_status, actor_user_id, comment)
         VALUES ($1, $2, $3, $4, $5)`,
      params,
    );
  }
}
