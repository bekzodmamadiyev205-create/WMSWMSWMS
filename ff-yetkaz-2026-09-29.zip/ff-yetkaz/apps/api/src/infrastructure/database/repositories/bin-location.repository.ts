import { ConflictException } from '@nestjs/common';
import type { DataSource } from 'typeorm';
import type { BinKind } from '@ff/shared';
import { BinLocationEntity } from '../entities';

/**
 * Активная ячейка склада заданного назначения. Приёмке нужна RECEIVING,
 * сборке — PACKING; обе должны быть заведены заранее, иначе промежуточному
 * состоянию («принято, но не разложено», «собрано, но не упаковано») негде жить.
 *
 * При нескольких подходящих берётся первая по коду — детерминированно.
 */
export async function findBinByKind(
  dataSource: DataSource,
  warehouseId: string,
  kind: BinKind,
  required: boolean,
): Promise<BinLocationEntity | null> {
  const bin = await dataSource
    .getRepository(BinLocationEntity)
    .createQueryBuilder('bin')
    .where('bin.warehouseId = :warehouseId', { warehouseId })
    .andWhere('bin.kind = :kind', { kind })
    .andWhere('bin.isActive = true')
    .orderBy('bin.code', 'ASC')
    .getOne();

  if (!bin && required) {
    throw new ConflictException(
      `На складе не заведена активная ячейка с назначением ${kind}. Создайте её перед началом работы.`,
    );
  }
  return bin;
}
