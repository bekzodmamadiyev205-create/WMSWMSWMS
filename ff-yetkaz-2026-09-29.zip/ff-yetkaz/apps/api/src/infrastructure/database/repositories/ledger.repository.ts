import { Injectable } from '@nestjs/common';
import type { LedgerSide } from '@ff/shared';
import type { SqlRunner } from '../sql-runner';

/** Строка оборотно-сальдовой ведомости — ровно то, что отдаёт SQL. */
export interface LedgerBalanceRow {
  code: string;
  name: string;
  currency: string;
  debit: string;
  credit: string;
}

/**
 * Сырой SQL бухгалтерской книги. Соединение не внедряется: его передаёт
 * вызывающий — `em` внутри транзакции, `this.dataSource` вне её.
 *
 * Для проводок это не формальность: сходимость дебета и кредита проверяет
 * ОТЛОЖЕННЫЙ триггер на COMMIT, поэтому заголовок проводки и все её строки
 * обязаны попасть в ОДНУ транзакцию. Возьми репозиторий соединение сам —
 * половина проводки ушла бы мимо, и триггер уронил бы её на пустом месте.
 */
@Injectable()
export class LedgerRepository {
  /**
   * Заголовок проводки; повторная попытка провести то же основание молчит.
   *
   * `ON CONFLICT`, а не try/catch: повторный прогон начислений — штатная
   * ситуация, и заваливать журнал PostgreSQL ошибками уникальности из-за
   * штатного сценария незачем. Условие `WHERE` повторяет предикат ЧАСТИЧНОГО
   * индекса по (reference_type, reference_id) — без него PostgreSQL не
   * опознаёт, какой индекс разрешает конфликт.
   *
   * Пустой результат означает «уже проведено».
   */
  insertTransactionIfNew(
    runner: SqlRunner,
    occurredAt: string,
    description: string,
    sellerId: string | null,
    referenceType: string,
    referenceId: string,
  ): Promise<Array<{ id: string }>> {
    return runner.query(
      `INSERT INTO ledger_transactions
         (occurred_at, description, seller_id, reference_type, reference_id)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (reference_type, reference_id)
         WHERE reference_type IS NOT NULL AND reference_id IS NOT NULL
         DO NOTHING
       RETURNING id`,
      [occurredAt, description, sellerId, referenceType, referenceId],
    );
  }

  /**
   * Строка проводки. Счёт ищется подзапросом по коду: коды счетов — это
   * договорённость плана счетов, а идентификаторы строк `ledger_accounts`
   * прикладному слою знать неоткуда.
   */
  async insertEntry(
    runner: SqlRunner,
    transactionId: string,
    accountCode: string,
    sellerId: string | null,
    side: LedgerSide,
    amount: string,
    currency: string,
  ): Promise<void> {
    await runner.query(
      `INSERT INTO ledger_entries (transaction_id, account_id, seller_id, side, amount, currency)
         VALUES ($1, (SELECT id FROM ledger_accounts WHERE code = $2), $3, $4::ledger_side, $5, $6)`,
      [transactionId, accountCode, sellerId, side, amount, currency],
    );
  }

  /**
   * Обороты по счетам и валютам. Фильтр по селлеру приклеивается только когда
   * он задан: номер placeholder'а считается по длине массива параметров, иначе
   * пустой фильтр оставил бы в тексте несвязанный `$1`.
   */
  accountBalances(runner: SqlRunner, sellerId?: string): Promise<LedgerBalanceRow[]> {
    const params: unknown[] = [];
    let filter = '';
    if (sellerId) {
      params.push(sellerId);
      filter = `WHERE e.seller_id = $${params.length}`;
    }

    return runner.query(
      `SELECT a.code, a.name, e.currency,
              COALESCE(SUM(CASE WHEN e.side='DEBIT'  THEN e.amount END), 0)::text AS debit,
              COALESCE(SUM(CASE WHEN e.side='CREDIT' THEN e.amount END), 0)::text AS credit
         FROM ledger_entries e
         JOIN ledger_accounts a ON a.id = e.account_id
         ${filter}
        GROUP BY a.code, a.name, e.currency
        ORDER BY a.code`,
      params,
    );
  }
}
