import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/**
 * Проба живости базы. Соединение не внедряется — его передаёт вызывающий.
 */
@Injectable()
export class HealthRepository {
  /**
   * Самый дешёвый запрос, который всё же доходит до сервера БД: он проверяет
   * не «есть ли объект пула», а что соединение действительно отвечает.
   * Ничего не читает — по таблицам ходить незачем, здоровье это не измеряет.
   */
  ping(runner: SqlRunner): Promise<unknown> {
    return runner.query('SELECT 1');
  }
}
