import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/**
 * Сырой SQL зоны сборки: резервы, из которых рождается задание, маршрут
 * сборщика и гашение резерва по мере отбора.
 *
 * Соединение приходит первым аргументом. Гашение резерва выполняется ВНУТРИ
 * транзакции отбора — вместе с движением остатка и обновлением строки задания;
 * взятое отдельным соединением, оно не откатилось бы вместе с ними, и резерв
 * оказался бы погашен под товар, который на полку так и не вернули.
 */
@Injectable()
export class PickingRepository {
  /**
   * Активные резервы заказов — заготовка строк задания. Резерв уже знает ячейку
   * и партию, поэтому маршрут сборщика выводится из него, а не считается заново.
   *
   * `owner_id = ANY($2::text[])` — владелец резерва обобщённый
   * (`owner_type`/`owner_id`), идентификатор хранится текстом: Inventory не знает
   * про модуль заказов.
   */
  async findActiveReservations(
    runner: SqlRunner,
    params: [ownerType: string, ownerIds: string[]],
  ): Promise<
    Array<{
      id: string;
      owner_id: string;
      sku_id: string;
      bin_id: string;
      lot_id: string | null;
      quantity: number;
    }>
  > {
    return runner.query(
      `SELECT id, owner_id, sku_id, bin_id, lot_id, quantity
         FROM reservations
        WHERE owner_type = $1 AND owner_id = ANY($2::text[]) AND status = 'ACTIVE'`,
      params,
    );
  }

  /**
   * Первая по маршруту незакрытая строка задания под отсканированный SKU.
   *
   * `ORDER BY b.code ASC` — это и есть порядок обхода склада (коды ячеек с
   * ведущими нулями заведены ровно ради такой сортировки), поэтому сборщик
   * закрывает ближайшую строку, а не случайную.
   */
  async findNextLineForSku(
    runner: SqlRunner,
    params: [taskId: string, skuId: string],
  ): Promise<Array<{ id: string }>> {
    return runner.query(
      `SELECT l.id
         FROM pick_task_lines l
         JOIN bin_locations b ON b.id = l.bin_id
        WHERE l.task_id = $1 AND l.sku_id = $2 AND l.status = 'PENDING'
          AND l.qty_picked < l.qty_requested
        ORDER BY b.code ASC
        LIMIT 1`,
      params,
    );
  }

  /** Снять резерв целиком: недобор — товара в ячейке нет, держать нечего. */
  async releaseReservation(runner: SqlRunner, reservationId: string): Promise<unknown> {
    return runner.query(
      `UPDATE reservations SET status = 'RELEASED', released_at = now() WHERE id = $1`,
      [reservationId],
    );
  }

  /**
   * Захватить строку резерва под `FOR UPDATE` перед списанием.
   *
   * Без блокировки два одновременных отбора по одной строке прочли бы одно и то
   * же количество и оба сочли бы себя полным гашением. Второй ждёт первого и
   * читает уже уменьшенное значение.
   */
  async lockReservation(
    runner: SqlRunner,
    reservationId: string,
  ): Promise<Array<{ quantity: number }>> {
    return runner.query(
      `SELECT quantity FROM reservations WHERE id = $1 FOR UPDATE`,
      [reservationId],
    );
  }

  /** Полный отбор строки: резерв израсходован. */
  async consumeReservation(runner: SqlRunner, reservationId: string): Promise<unknown> {
    return runner.query(`UPDATE reservations SET status = 'CONSUMED' WHERE id = $1`, [
      reservationId,
    ]);
  }

  /**
   * Частичный отбор: количество уменьшается ОТНОСИТЕЛЬНО текущего значения в БД
   * (`quantity - $2`), а не пишется абсолютным из прочитанного снимка.
   */
  async decreaseReservation(
    runner: SqlRunner,
    params: [reservationId: string, quantity: number],
  ): Promise<unknown> {
    return runner.query(`UPDATE reservations SET quantity = quantity - $2 WHERE id = $1`, params);
  }

  /**
   * Строки задания в порядке обхода: сортировка по коду ячейки и есть маршрут
   * сборщика. Артикул — второй ключ, чтобы порядок в одной ячейке был
   * определённым, а не зависел от плана запроса.
   */
  async findTaskLines(
    runner: SqlRunner,
    taskId: string,
  ): Promise<
    Array<{
      id: string;
      order_id: string;
      sku_id: string;
      sku_code: string;
      sku_name: string;
      bin_id: string;
      bin_code: string;
      lot_id: string | null;
      qty_requested: number;
      qty_picked: number;
      status: string;
    }>
  > {
    return runner.query(
      `SELECT l.id, l.order_id, l.sku_id, s.sku_code, s.name AS sku_name,
              l.bin_id, b.code AS bin_code, l.lot_id,
              l.qty_requested, l.qty_picked, l.status
         FROM pick_task_lines l
         JOIN skus s ON s.id = l.sku_id
         JOIN bin_locations b ON b.id = l.bin_id
        WHERE l.task_id = $1
        ORDER BY b.code ASC, s.sku_code ASC`,
      [taskId],
    );
  }
}
