import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/** Строка прогресса позиции заявки — ровно то, что отдаёт SQL. */
export interface AsnLineProgressRow {
  id: string;
  sku_id: string;
  sku_code: string;
  sku_name: string;
  expected_qty: number;
  received: string;
  has_barcode: boolean;
}

/**
 * Сырой SQL приёмки. Соединение не внедряется: его передаёт вызывающий —
 * `em` внутри транзакции, `this.dataSource` вне её.
 */
@Injectable()
export class InboundRepository {
  /**
   * Сколько принято по каждой позиции заявки всеми не отменёнными приёмками.
   *
   * Наличие штрихкода считаем здесь же подзапросом: прогресс заявки и так
   * читается на каждый показ карточки, отдельный запрос за тем же набором
   * строк был бы лишним раундтрипом. Приёмки подцеплены LEFT JOIN'ом с
   * отсевом отменённых — позиция без единой приёмки обязана остаться в
   * выдаче с нулём, а не исчезнуть из плана поставки.
   */
  asnLineProgress(runner: SqlRunner, asnId: string): Promise<AsnLineProgressRow[]> {
    return runner.query(
      `SELECT al.id, al.sku_id, s.sku_code, s.name AS sku_name, al.expected_qty,
              COALESCE(SUM(rl.qty_received), 0)::text AS received,
              EXISTS (SELECT 1 FROM sku_barcodes b WHERE b.sku_id = al.sku_id) AS has_barcode
         FROM asn_lines al
         JOIN skus s ON s.id = al.sku_id
         LEFT JOIN receipts r ON r.asn_id = al.asn_id AND r.status <> 'CANCELLED'
         LEFT JOIN receipt_lines rl ON rl.receipt_id = r.id AND rl.sku_id = al.sku_id
        WHERE al.asn_id = $1
        GROUP BY al.id, al.sku_id, s.sku_code, s.name, al.expected_qty
        ORDER BY s.sku_code`,
      [asnId],
    );
  }

  /**
   * Позиции документа приёмки вместе с артикулом и названием товара.
   * Порядок — по времени добавления: экран приёмщика показывает строки в том
   * порядке, в котором он их сканировал.
   */
  receiptLinesWithSku(
    runner: SqlRunner,
    receiptId: string,
  ): Promise<Array<Record<string, unknown>>> {
    return runner.query(
      `SELECT l.*, s.sku_code, s.name AS sku_name
         FROM receipt_lines l JOIN skus s ON s.id = l.sku_id
        WHERE l.receipt_id = $1
        ORDER BY l.created_at ASC`,
      [receiptId],
    );
  }
}
