import { Injectable } from '@nestjs/common';
import type { OrderStatus } from '@ff/shared';
import type { SqlRunner } from '../sql-runner';

/**
 * Статус, который ВИДИТ пользователь.
 *
 * Разделённый заказ исполняют дети: контейнер доходит до RESERVED и остаётся там
 * навсегда — перехода RESERVED → PICKING у него не случится никогда, потому что
 * собирают и упаковывают части. Канонический `orders.status` мы намеренно не
 * трогаем: чтобы записать в колонку «DELIVERED», понадобился бы переход
 * RESERVED → DELIVERED, которого в статусной машине нет, то есть либо дыра в
 * таблице переходов, либо запись мимо `FsmService`. Поэтому статус контейнера —
 * ПРЕДСТАВЛЕНИЕ: самый отстающий ребёнок. Значения `order_status` объявлены в
 * порядке жизненного цикла (DISPATCHED добавлен позиционно, `AFTER
 * 'READY_TO_SHIP'`), поэтому `min` по enum'у — это именно «самый ранний по
 * циклу»; когда все части терминальны, он же даёт терминальный статус.
 *
 * Выражение живёт в SQL, а не в TypeScript, потому что по статусу ещё и
 * фильтруют и считают итоги: посчитанное в приложении разошлось бы со
 * счётчиками канбана — и разошлось бы молча.
 *
 * Экспортируется наружу: тем же выражением вызывающий собирает условие фильтра
 * и колонку сортировки. Вторая копия разошлась бы с этой — и разошлась бы молча.
 */
export const EFFECTIVE_STATUS = `CASE
          WHEN o.is_split AND o.status = 'RESERVED'
          THEN COALESCE(
                 (SELECT min(ch.status) FROM orders ch WHERE ch.parent_order_id = o.id),
                 o.status)
          ELSE o.status
        END`;

const ORDER_COLUMNS = `o.id, o.seller_id, o.channel, o.external_id, o.order_code,
        ${EFFECTIVE_STATUS} AS status,
        o.warehouse_id, o.parent_order_id, o.is_split, o.has_shortage,
        o.recipient_name, o.recipient_phone, o.address, o.region,
        o.cod_amount, o.currency, o.weight_kg, o.category_id, o.dispatched_at, o.created_at,
        c.code AS category_code, c.name AS category_name, c.color AS category_color`;

const ORDER_FROM = `FROM orders o LEFT JOIN order_categories c ON c.id = o.category_id`;

export interface OrderRow {
  id: string;
  seller_id: string;
  channel: string;
  external_id: string;
  order_code: string;
  status: OrderStatus;
  warehouse_id: string | null;
  parent_order_id: string | null;
  is_split: boolean;
  has_shortage: boolean;
  recipient_name: string;
  recipient_phone: string;
  address: string;
  region: string | null;
  cod_amount: string | null;
  currency: string | null;
  weight_kg: string | null;
  category_id: string | null;
  category_code: string | null;
  category_name: string | null;
  category_color: string | null;
  dispatched_at: Date | string | null;
  created_at: Date | string;
}

/** Плоская строка выгрузки: без вложенности, зато с именами справочников. */
export interface OrderExportRow {
  order_code: string;
  external_id: string;
  channel: string;
  category_name: string | null;
  status: string;
  seller_name: string;
  warehouse_code: string | null;
  recipient_name: string;
  recipient_phone: string;
  region: string | null;
  address: string;
  units: number;
  weight_kg: string | null;
  cod_amount: string | null;
  currency: string | null;
  created_at: Date | string;
  dispatched_at: Date | string | null;
}

/** Счётчик списка: `count(*)::int`, но драйвер вправе отдать его строкой. */
export interface OrderCountRow {
  total: number | string;
}

export interface OrderStatusCountRow {
  status: OrderStatus;
  count: number | string;
}

export interface OrderStatusHistoryRow {
  id: string | number;
  from_status: string | null;
  to_status: string;
  source: string;
  actor_user_id: string | null;
  actor_name: string | null;
  comment: string | null;
  occurred_at: Date | string;
}

export interface OrderLineRow {
  id: string;
  order_id: string;
  sku_id: string;
  sku_code: string;
  name: string;
  quantity: number;
}

/** Сколько по каждому SKU уже исполняют живые части разделённого заказа. */
export interface CoveredQuantityRow {
  sku_id: string;
  quantity: number | string;
}

export interface WarehouseAvailabilityRow {
  warehouse_id: string;
  sku_id: string;
  available: string;
}

export interface SellerCatalogRow {
  id: string;
  sku_code: string;
  is_active: boolean;
}

/**
 * Сырой SQL заказов. Соединение не внедряется: его передаёт вызывающий —
 * `em` внутри транзакции, `this.dataSource` вне её.
 */
@Injectable()
export class OrdersRepository {
  /**
   * Число заказов под фильтром.
   *
   * Считается по одной `orders`, без join'а справочника категорий: счётчику он
   * не нужен, а условия фильтра к нему и не обращаются.
   */
  countMatching(runner: SqlRunner, where: string, values: unknown[]): Promise<OrderCountRow[]> {
    return runner.query(`SELECT count(*)::int AS total FROM orders o ${where}`, values);
  }

  /**
   * Страница списка. Условия, порядок и плейсхолдеры `LIMIT`/`OFFSET` собирает
   * вызывающий: один и тот же набор условий обслуживает список, итоги и
   * выгрузку, и разъехаться они не имеют права.
   */
  findPage(
    runner: SqlRunner,
    where: string,
    orderBy: string,
    limit: string,
    offset: string,
    values: unknown[],
  ): Promise<OrderRow[]> {
    return runner.query(
      `SELECT ${ORDER_COLUMNS} ${ORDER_FROM} ${where} ${orderBy}
        LIMIT ${limit} OFFSET ${offset}`,
      values,
    );
  }

  /**
   * Итоги по фильтру одним GROUP BY.
   *
   * Группировка идёт по ТОМУ ЖЕ статусу, который отдаёт список: иначе счётчик
   * колонки канбана и её содержимое считаются по разным правилам, и
   * разделённый заказ попадает в одну колонку, а числится в другой.
   */
  countByEffectiveStatus(
    runner: SqlRunner,
    where: string,
    values: unknown[],
  ): Promise<OrderStatusCountRow[]> {
    return runner.query(
      `SELECT (${EFFECTIVE_STATUS})::text AS status, count(*)::int AS count
         FROM orders o ${where}
        GROUP BY 1`,
      values,
    );
  }

  /**
   * Трек статусов заказа — журнал `order_status_history`, а не выборка из
   * аудита. Порядок по возрастанию времени, добавочный ключ `h.id` разводит
   * события одной метки: это лента, её читают сверху вниз.
   */
  findStatusHistory(runner: SqlRunner, orderId: string): Promise<OrderStatusHistoryRow[]> {
    return runner.query(
      `SELECT h.id, h.from_status, h.to_status, h.source, h.actor_user_id,
              u.full_name AS actor_name, h.comment, h.occurred_at
         FROM order_status_history h
         LEFT JOIN users u ON u.id = h.actor_user_id
        WHERE h.order_id = $1
        ORDER BY h.occurred_at ASC, h.id ASC`,
      [orderId],
    );
  }

  /**
   * Сколько по каждому SKU уже висит на живых частях разделённого заказа.
   *
   * Отменённые части исключены намеренно: их резерв уже снят, и товар снова
   * нужно обеспечить. Читается ПОД захватом строки контейнера, поэтому идёт тем
   * же runner'ом, что и вся транзакция резерва: взятый со стороны снимок не
   * увидел бы только что вставленных частей.
   */
  sumChildLineQuantities(runner: SqlRunner, parentOrderId: string): Promise<CoveredQuantityRow[]> {
    return runner.query(
      `SELECT ol.sku_id, SUM(ol.quantity)::int AS quantity
         FROM order_lines ol
         JOIN orders ch ON ch.id = ol.order_id
        WHERE ch.parent_order_id = $1 AND ch.status <> 'CANCELLED'
        GROUP BY ol.sku_id`,
      [parentOrderId],
    );
  }

  /**
   * Доступный остаток по складам под раскладку заказа.
   *
   * Количество отдаётся ТЕКСТОМ (`::text`): это numeric, и приведение его к
   * float на стороне драйвера — потеря точности ровно там, где считают товар.
   * Нулевые строки отсекает сам запрос: склад без товара не должен участвовать
   * в жадном выборе. Идёт внутри транзакции резерва — по снимку, в котором уже
   * видны движения, сделанные этой же операцией.
   */
  findAvailabilityBySku(runner: SqlRunner, skuIds: string[]): Promise<WarehouseAvailabilityRow[]> {
    return runner.query(
      `SELECT warehouse_id, sku_id, SUM(quantity)::text AS available
           FROM stock
          WHERE sku_id = ANY($1::uuid[]) AND status = 'AVAILABLE' AND quantity > 0
          GROUP BY warehouse_id, sku_id`,
      [skuIds],
    );
  }

  /**
   * Пачка строк выгрузки.
   *
   * Позиции считает `LEFT JOIN LATERAL`, а не join с группировкой: join
   * размножил бы строку заказа по числу позиций, и суммы в файле поехали бы.
   * Выполняется на `QueryRunner` в открытой REPEATABLE READ — все пачки обязаны
   * читать ОДИН снимок, иначе `OFFSET` по живой таблице продублирует строку.
   */
  findExportPage(
    runner: SqlRunner,
    where: string,
    orderBy: string,
    limit: string,
    offset: string,
    values: unknown[],
  ): Promise<OrderExportRow[]> {
    return runner.query(
      `SELECT o.order_code, o.external_id, o.channel, (${EFFECTIVE_STATUS})::text AS status,
                  o.recipient_name, o.recipient_phone, o.region, o.address,
                  o.cod_amount, o.currency, o.weight_kg, o.created_at, o.dispatched_at,
                  c.name AS category_name, s.legal_name AS seller_name, w.code AS warehouse_code,
                  COALESCE(li.units, 0)::int AS units
             FROM orders o
             JOIN sellers s ON s.id = o.seller_id
             LEFT JOIN order_categories c ON c.id = o.category_id
             LEFT JOIN warehouses w ON w.id = o.warehouse_id
             LEFT JOIN LATERAL (
               SELECT SUM(ol.quantity)::int AS units FROM order_lines ol WHERE ol.order_id = o.id
             ) li ON true
            ${where} ${orderBy}
            LIMIT ${limit} OFFSET ${offset}`,
      values,
    );
  }

  /**
   * Заказы по произвольному условию — общая выборка карточки, поиска по коду и
   * дочерних заказов. Хвост (`ORDER BY … LIMIT`) передаёт вызывающий: у каждого
   * из трёх случаев он свой, а набор колонок обязан оставаться одним.
   */
  findByCondition(
    runner: SqlRunner,
    where: string,
    values: unknown[],
    tail = '',
  ): Promise<OrderRow[]> {
    return runner.query(`SELECT ${ORDER_COLUMNS} ${ORDER_FROM} WHERE ${where} ${tail}`, values);
  }

  /** Позиции всех заказов одним запросом, с артикулом и названием товара. */
  findLines(runner: SqlRunner, orderIds: string[]): Promise<OrderLineRow[]> {
    return runner.query(
      `SELECT ol.id, ol.order_id, ol.sku_id, ol.quantity, s.sku_code, s.name
         FROM order_lines ol
         JOIN skus s ON s.id = ol.sku_id
        WHERE ol.order_id = ANY($1::uuid[])
        ORDER BY s.sku_code ASC`,
      [orderIds],
    );
  }

  /**
   * Каталог селлера по артикулам файла — одним запросом, без выкачивания всего
   * справочника. Сравнение по `lower(sku_code)`: регистр артикула в выгрузке
   * селлера произвольный, а товар при этом тот же самый.
   */
  findCatalogByCodes(
    runner: SqlRunner,
    sellerId: string,
    codes: string[],
  ): Promise<SellerCatalogRow[]> {
    return runner.query(
      `SELECT id, sku_code, is_active
           FROM skus
          WHERE seller_id = $1 AND lower(sku_code) = ANY($2::text[])`,
      [sellerId, codes],
    );
  }
}
