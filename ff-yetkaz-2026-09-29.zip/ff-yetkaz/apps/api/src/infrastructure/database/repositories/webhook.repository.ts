import { Injectable } from '@nestjs/common';
import type { ShipmentStatus } from '@ff/shared';
import type { SqlRunner } from '../sql-runner';

/**
 * Остаток заказа, физически лежащий в статусе PACKED, с точностью до ячейки.
 * Форма строки — ровно та, что нужна `applyMovement`.
 */
export interface PackedOnHandRow {
  sku_id: string;
  lot_id: string | null;
  bin_id: string;
  warehouse_id: string;
  qty: number;
}

/** Чем закончился разбор входящей доставки. */
export type WebhookRejectionResult = 'REJECTED' | 'DUPLICATE';

/**
 * Доступ к журналам входящих вебхуков перевозчика.
 *
 * Соединение приходит параметром, и это несущая деталь: принятая доставка
 * пишется В ТОЙ ЖЕ транзакции, что и переход статуса (уникальный индекс по
 * принятым доставкам работает мьютексом), а отвергнутая — ОТДЕЛЬНЫМ
 * соединением, чтобы пережить откат вызывающей транзакции.
 */
@Injectable()
export class WebhookRepository {
  /** Трек отправления: порядок по id, а не по времени события — перевозчик может прислать их не по порядку. */
  async listShipmentStatusEvents(
    runner: SqlRunner,
    shipmentId: string,
  ): Promise<Array<Record<string, unknown>>> {
    return runner.query(
      `SELECT id, shipment_id, from_status, to_status, occurred_at, recorded_at, source, comment
         FROM shipment_status_events WHERE shipment_id = $1 ORDER BY id ASC`,
      [shipmentId],
    );
  }

  /**
   * Запись ПРИНЯТОЙ доставки.
   *
   * Обязана идти в одной транзакции с переходом статуса: уникальный индекс по
   * принятым доставкам (`uq_webhook_delivery`) — это мьютекс, из-за которого
   * два одновременных повтора не могут применить статус дважды. Вынесенная в
   * своё соединение, эта строка перестала бы что-либо защищать.
   */
  async insertAcceptedDelivery(
    runner: SqlRunner,
    delivery: {
      carrierCode: string;
      deliveryId: string | undefined;
      payloadJson: string;
      shipmentId: string;
    },
  ): Promise<void> {
    await runner.query(
      `INSERT INTO webhook_deliveries (carrier_code, delivery_id, payload, result, shipment_id)
         VALUES ($1, $2, $3::jsonb, 'ACCEPTED', $4)`,
      [delivery.carrierCode, delivery.deliveryId, delivery.payloadJson, delivery.shipmentId],
    );
  }

  /** Событие трека отправления. Источник фиксирован (`CARRIER`) — строку пишет только приём вебхука. */
  async insertShipmentStatusEvent(
    runner: SqlRunner,
    event: {
      shipmentId: string;
      fromStatus: ShipmentStatus;
      toStatus: ShipmentStatus;
      occurredAt: string;
      comment: string | null;
      rawJson: string;
    },
  ): Promise<void> {
    await runner.query(
      `INSERT INTO shipment_status_events
           (shipment_id, from_status, to_status, occurred_at, source, comment, raw)
         VALUES ($1, $2, $3, $4, 'CARRIER', $5, $6::jsonb)`,
      [
        event.shipmentId,
        event.fromStatus,
        event.toStatus,
        event.occurredAt,
        event.comment,
        event.rawJson,
      ],
    );
  }

  /**
   * Где физически лежит упакованный товар заказа.
   *
   * Остаток количественный и не помнит, чьи это единицы, поэтому фактическое
   * местонахождение считается по append-only журналу движений: приход по
   * `to_bin_id` минус расход по `from_bin_id` для ссылки на заказ.
   * `HAVING SUM(delta) > 0` отбрасывает уже уехавшие срезы — иначе передача
   * перевозчику попыталась бы отгрузить одно и то же дважды.
   */
  async sumPackedOnHand(
    runner: SqlRunner,
    referenceType: string,
    referenceId: string,
  ): Promise<PackedOnHandRow[]> {
    return runner.query(
      `SELECT sku_id, lot_id, bin_id, warehouse_id, SUM(delta)::int AS qty
         FROM (
           SELECT sku_id, lot_id, to_bin_id AS bin_id, warehouse_id, to_status AS status, quantity AS delta
             FROM stock_movements
            WHERE reference_type = $1 AND reference_id = $2 AND to_bin_id IS NOT NULL
           UNION ALL
           SELECT sku_id, lot_id, from_bin_id, warehouse_id, from_status, -quantity
             FROM stock_movements
            WHERE reference_type = $1 AND reference_id = $2 AND from_bin_id IS NOT NULL
         ) moves
        WHERE status = 'PACKED'
        GROUP BY sku_id, lot_id, bin_id, warehouse_id
       HAVING SUM(delta) > 0`,
      [referenceType, referenceId],
    );
  }

  /**
   * Запись ОТВЕРГНУТОЙ (или дублирующей) доставки.
   *
   * Пишется отдельным соединением и вне транзакции перехода: причина отказа
   * должна остаться в журнале именно тогда, когда операция не состоялась.
   * `$4::webhook_result` — приведение обязательно, параметр приходит текстом.
   */
  async insertRejectedDelivery(
    runner: SqlRunner,
    delivery: {
      carrierCode: string;
      deliveryId: string;
      payloadJson: string;
      result: WebhookRejectionResult;
      error: string;
      shipmentId: string | null;
    },
  ): Promise<void> {
    await runner.query(
      `INSERT INTO webhook_deliveries (carrier_code, delivery_id, payload, result, error, shipment_id)
         VALUES ($1, $2, $3::jsonb, $4::webhook_result, $5, $6)`,
      [
        delivery.carrierCode,
        delivery.deliveryId,
        delivery.payloadJson,
        delivery.result,
        delivery.error,
        delivery.shipmentId,
      ],
    );
  }
}
