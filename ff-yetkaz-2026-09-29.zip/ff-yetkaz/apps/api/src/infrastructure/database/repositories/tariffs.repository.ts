import { Injectable } from '@nestjs/common';
import type { ChargeKind, TariffUnit } from '@ff/shared';
import type { SqlRunner } from '../sql-runner';

/** Действующее правило тарифа вместе с валютой плана — как отдаёт SQL. */
export interface EffectiveTariffRuleRow {
  id: string;
  plan_id: string;
  kind: ChargeKind;
  unit: TariffUnit;
  component: string;
  price: string;
  min_qty: string;
  effective_from: string;
  effective_to: string | null;
  currency: string;
}

/**
 * Сырой SQL тарифов. Соединение не внедряется: его передаёт вызывающий —
 * `em` внутри транзакции, `this.dataSource` вне её.
 */
@Injectable()
export class TariffsRepository {
  /**
   * Снимает признак «по умолчанию» со всех планов.
   *
   * План по умолчанию ровно один — уникальный ЧАСТИЧНЫЙ индекс не даст
   * вставить второй, поэтому флаг снимается с прежнего в той же транзакции,
   * что и вставка нового.
   */
  async clearDefaultPlan(runner: SqlRunner): Promise<void> {
    await runner.query(`UPDATE tariff_plans SET is_default = false WHERE is_default`);
  }

  /**
   * То же снятие флага, но при ПРАВКЕ плана: сам правимый план исключается,
   * иначе он снял бы признак сам с себя ровно перед тем, как его поставить.
   */
  async clearDefaultPlanExcept(runner: SqlRunner, planId: string): Promise<void> {
    await runner.query(`UPDATE tariff_plans SET is_default = false WHERE is_default AND id <> $1`, [
      planId,
    ]);
  }

  /**
   * Сколько начислений уже посчитано по правилам плана.
   *
   * Считает БД, а не выборка в память: ответ нужен один — «ноль или нет», и
   * тянуть ради него все начисления плана бессмысленно.
   */
  countChargesByPlan(runner: SqlRunner, planId: string): Promise<Array<{ count: string }>> {
    return runner.query(
      `SELECT count(*)::text AS count
           FROM charges c JOIN tariff_rules r ON r.id = c.tariff_rule_id
          WHERE r.plan_id = $1`,
      [planId],
    );
  }

  /** Назначение тарифного плана селлеру; `null` — снятие плана. */
  async assignPlanToSeller(
    runner: SqlRunner,
    sellerId: string,
    planId: string | null,
  ): Promise<void> {
    await runner.query(`UPDATE sellers SET tariff_plan_id = $2 WHERE id = $1`, [sellerId, planId]);
  }

  /**
   * Действующие на дату правила услуги по плану селлера, иначе по плану
   * по умолчанию — `COALESCE` из двух подзапросов выбирает план одним
   * обращением, без предварительного чтения селлера.
   *
   * Порядок выдачи несущий: `min_qty DESC` внутри составляющей означает, что
   * ПЕРВАЯ подошедшая ступень и есть нужная — вызывающий перебирает ступени
   * сверху вниз и не сортирует их заново.
   */
  effectiveRules(
    runner: SqlRunner,
    sellerId: string,
    kind: ChargeKind,
    onDate: string,
  ): Promise<EffectiveTariffRuleRow[]> {
    return runner.query(
      `SELECT r.id, r.plan_id, r.kind, r.unit, r.component, r.price, r.min_qty,
              r.effective_from, r.effective_to, p.currency
         FROM tariff_rules r
         JOIN tariff_plans p ON p.id = r.plan_id
        WHERE p.is_active
          AND p.id = COALESCE(
                (SELECT tariff_plan_id FROM sellers WHERE id = $1),
                (SELECT id FROM tariff_plans WHERE is_default)
              )
          AND r.kind = $2::charge_kind
          AND r.effective_from <= $3::date
          AND (r.effective_to IS NULL OR r.effective_to >= $3::date)
        ORDER BY r.component ASC, r.min_qty DESC, r.effective_from DESC, r.unit ASC`,
      [sellerId, kind, onDate],
    );
  }
}
