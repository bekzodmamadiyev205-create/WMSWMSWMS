import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/**
 * Описание плитки сводки. Запрос отдаёт одно число — вся арифметика в SQL:
 * тянуть тысячи строк в приложение, чтобы посчитать `length`, — верный способ
 * получить дашборд, который умирает вместе с ростом склада.
 */
export interface MetricSpec {
  key: string;
  title: string;
  sql: string;
  /** Число больше нуля означает проблему, а не просто загрузку. */
  attentionWhenPositive?: boolean;
}

export const QUEUES: MetricSpec[] = [
  {
    key: 'asn_receiving',
    title: 'Заявок в приёмке',
    sql: `SELECT count(*) FROM asns WHERE status = 'RECEIVING'`,
  },
  {
    key: 'orders_to_pick',
    title: 'Заказов ждут сборки',
    sql: `SELECT count(*) FROM orders WHERE status = 'RESERVED'`,
  },
  {
    key: 'tasks_in_progress',
    title: 'Заданий на сборке',
    sql: `SELECT count(*) FROM pick_tasks WHERE status IN ('NEW', 'ASSIGNED', 'IN_PROGRESS')`,
  },
  {
    key: 'orders_to_pack',
    title: 'Заказов ждут упаковки',
    sql: `SELECT count(*) FROM orders WHERE status IN ('PICKED', 'PACKING')`,
  },
  {
    key: 'shipments_to_handover',
    title: 'Отправлений ждут передачи',
    sql: `SELECT count(*) FROM shipments WHERE status = 'READY'`,
  },
];

export const PROBLEMS: MetricSpec[] = [
  {
    key: 'orders_shortage',
    title: 'Заказов с нехваткой',
    sql: `SELECT count(*) FROM orders WHERE has_shortage AND status NOT IN ('CANCELLED', 'DELIVERED')`,
    attentionWhenPositive: true,
  },
  {
    key: 'weight_mismatch',
    title: 'Коробок с расхождением веса',
    sql: `SELECT count(*) FROM packages WHERE weight_mismatch AND status = 'PACKED'`,
    attentionWhenPositive: true,
  },
  {
    key: 'quarantine_units',
    title: 'Единиц в карантине',
    sql: `SELECT COALESCE(SUM(quantity), 0) FROM stock WHERE status = 'QUARANTINE'`,
    attentionWhenPositive: true,
  },
  {
    key: 'outbox_failed',
    title: 'Сообщений перевозчику не доставлено',
    sql: `SELECT count(*) FROM integration_outbox WHERE status = 'FAILED'`,
    attentionWhenPositive: true,
  },
  {
    key: 'webhooks_rejected',
    title: 'Отклонённых вебхуков за сутки',
    sql: `SELECT count(*) FROM webhook_deliveries
           WHERE result = 'REJECTED' AND received_at >= now() - interval '1 day'`,
    attentionWhenPositive: true,
  },
  {
    key: 'billing_problems',
    title: 'Незакрытых проблем биллинга',
    sql: `SELECT count(*) FROM billing_problems WHERE resolved_at IS NULL`,
    attentionWhenPositive: true,
  },
  {
    // Пропущенный срез не восстановить — вчерашнего объёма в базе уже нет.
    // Поэтому дыру показываем: это недосчитанные деньги за хранение.
    key: 'storage_snapshot_gaps',
    title: 'Дней без среза хранения',
    sql: `SELECT count(*) FROM generate_series(
            GREATEST((SELECT MIN(snapshot_date) FROM storage_snapshots), current_date - 30),
            current_date - 1, interval '1 day') AS day
           WHERE EXISTS (SELECT 1 FROM storage_snapshots)
             AND NOT EXISTS (
               SELECT 1 FROM storage_snapshots s WHERE s.snapshot_date = day::date
             )`,
    attentionWhenPositive: true,
  },
  {
    key: 'cod_short',
    title: 'Недосдача наложенного платежа',
    sql: `SELECT count(*) FROM shipments
           WHERE status = 'DELIVERED' AND cod_amount IS NOT NULL
             AND COALESCE(cod_collected_amount, 0) < cod_amount`,
    attentionWhenPositive: true,
  },
];

export const TODAY: MetricSpec[] = [
  {
    key: 'received_units',
    title: 'Принято единиц',
    sql: `SELECT COALESCE(SUM(rl.qty_received), 0)
            FROM receipt_lines rl JOIN receipts r ON r.id = rl.receipt_id
           WHERE r.completed_at::date = current_date`,
  },
  {
    key: 'picked_orders',
    title: 'Собрано заказов',
    sql: `SELECT count(DISTINCT l.order_id)
            FROM pick_task_lines l JOIN pick_tasks t ON t.id = l.task_id
           WHERE t.completed_at::date = current_date`,
  },
  {
    key: 'packed_orders',
    title: 'Упаковано заказов',
    sql: `SELECT count(*) FROM packages WHERE packed_at::date = current_date`,
  },
  {
    key: 'handed_over',
    title: 'Передано перевозчику',
    sql: `SELECT count(*) FROM shipments WHERE handed_over_at::date = current_date`,
  },
  {
    key: 'delivered',
    title: 'Доставлено',
    sql: `SELECT count(*) FROM shipments WHERE delivered_at::date = current_date`,
  },
];

/** Значение одной плитки: номер описания в наборе и посчитанное число. */
export interface MetricValueRow {
  idx: number;
  value: string;
}

/** Разрез воронки: статус заказа и число заказов в нём. */
export interface OrderStatusCountRow {
  status: string;
  count: string;
}

/**
 * Сырой SQL сводки склада и витрины селлера. Соединение не внедряется: его
 * передаёт вызывающий — `em` внутри транзакции, `this.dataSource` вне её.
 */
@Injectable()
export class DashboardRepository {
  /**
   * Один запрос на все плитки: пять раундтрипов к базе ради пяти чисел —
   * ровно та мелочь, из которой складывается медленный дашборд. Номер плитки
   * едет отдельной колонкой `idx`, а не подразумевается порядком: `UNION ALL`
   * порядок строк не гарантирует, и сопоставлять их позицией нельзя.
   */
  async countMetrics(runner: SqlRunner, specs: MetricSpec[]): Promise<MetricValueRow[]> {
    const union = specs
      .map((spec, index) => `SELECT ${index} AS idx, (${spec.sql})::bigint AS value`)
      .join(' UNION ALL ');
    const rows: MetricValueRow[] = await runner.query(`${union} ORDER BY idx`);
    return rows;
  }

  /**
   * Заказ-контейнер из воронки исключён: он не исполняется сам, его
   * исполняют дети. Учитывать обоих — значит считать один заказ дважды и
   * держать «зависший» контейнер в RESERVED, пока дети давно доставлены.
   */
  async countOrdersByStatus(
    runner: SqlRunner,
    sellerId: string | null,
  ): Promise<OrderStatusCountRow[]> {
    const params: unknown[] = [];
    let filter = 'WHERE is_split = false';
    if (sellerId) {
      params.push(sellerId);
      filter = `WHERE is_split = false AND seller_id = $1`;
    }
    const rows: OrderStatusCountRow[] = await runner.query(
      `SELECT status::text, count(*)::text FROM orders ${filter} GROUP BY status ORDER BY status`,
      params,
    );
    return rows;
  }

  /**
   * Остаток селлера по статусам. Отсев `quantity > 0` стоит в УСЛОВИИ
   * СОЕДИНЕНИЯ, а не в `WHERE`: перенеси его — и `LEFT JOIN` выродится во
   * внутренний, а заведённый, но ещё не привезённый артикул молча исчезнет с
   * витрины вместо честного нуля.
   */
  async loadSellerStock(
    runner: SqlRunner,
    sellerId: string,
  ): Promise<Array<Record<string, unknown>>> {
    const rows: Array<Record<string, unknown>> = await runner.query(
      `SELECT s.id, s.sku_code, s.name,
              COALESCE(SUM(st.quantity) FILTER (WHERE st.status = 'AVAILABLE'), 0)::int AS available,
              COALESCE(SUM(st.quantity) FILTER (WHERE st.status = 'RESERVED'), 0)::int AS reserved,
              COALESCE(SUM(st.quantity) FILTER (WHERE st.status IN ('PICKED', 'PACKED')), 0)::int AS in_progress,
              COALESCE(SUM(st.quantity) FILTER (WHERE st.status = 'QUARANTINE'), 0)::int AS quarantine,
              COALESCE(SUM(st.quantity) FILTER (WHERE st.status = 'DAMAGED'), 0)::int AS damaged
         FROM skus s
         LEFT JOIN stock st ON st.sku_id = s.id AND st.quantity > 0
        WHERE s.seller_id = $1 AND s.is_active
        GROUP BY s.id, s.sku_code, s.name
        ORDER BY s.sku_code`,
      [sellerId],
    );
    return rows;
  }

  /** Хвост отправлений селлера: витрина показывает последние, а не всю историю. */
  async loadRecentShipments(
    runner: SqlRunner,
    sellerId: string,
  ): Promise<Array<Record<string, unknown>>> {
    const rows: Array<Record<string, unknown>> = await runner.query(
      `SELECT sh.shipment_no, o.external_id, sh.status::text, sh.tracking_no,
              sh.handed_over_at, sh.delivered_at,
              sh.cod_amount::text, sh.cod_collected_amount::text
         FROM shipments sh JOIN orders o ON o.id = sh.order_id
        WHERE o.seller_id = $1
        ORDER BY sh.created_at DESC
        LIMIT 50`,
      [sellerId],
    );
    return rows;
  }

  /**
   * Незакрытые счета селлера. Деньги приводятся к `::text` прямо в запросе и
   * остаются строкой до самого JSON: побывав в `number`, сумма начинает
   * расходиться со счетами на копейки, а объяснить это расхождение нечем.
   */
  async loadOpenInvoices(
    runner: SqlRunner,
    sellerId: string,
  ): Promise<Array<Record<string, unknown>>> {
    const rows: Array<Record<string, unknown>> = await runner.query(
      `SELECT id, number, period_start::text, period_end::text, currency,
              services_total::text, payout_total::text, status::text
         FROM invoices
        WHERE seller_id = $1 AND status IN ('DRAFT', 'ISSUED')
        ORDER BY period_start DESC
        LIMIT 12`,
      [sellerId],
    );
    return rows;
  }
}
