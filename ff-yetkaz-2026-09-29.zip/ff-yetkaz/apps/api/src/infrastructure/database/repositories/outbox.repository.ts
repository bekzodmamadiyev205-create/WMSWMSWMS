import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/** Строка очереди в том виде, в каком её вернул SQL. */
export interface ClaimedRow {
  id: string;
  carrier_code: string;
  topic: string;
  entity_type: string;
  entity_id: string;
  payload: unknown;
  attempts: number;
  correlation_id: string | null;
}

/** Куда переводится сообщение после неудачной попытки. */
export type OutboxRetryStatus = 'PENDING' | 'FAILED';

/**
 * Доступ к `integration_outbox` — очереди исходящих сообщений перевозчику.
 *
 * Соединение приходит параметром: постановка в очередь обязана выполняться
 * ВНУТРИ транзакции вызывающего (сообщение и бизнес-факт коммитятся вместе),
 * а разбор очереди — вне её, отдельными короткими командами.
 */
@Injectable()
export class OutboxRepository {
  /**
   * Постановка сообщения в очередь.
   *
   * `ON CONFLICT (topic, entity_id) DO NOTHING` — не удобство, а защита от
   * дублей у перевозчика: повторная постановка того же (topic, entityId)
   * обязана молча ничего не делать. Уникальный индекс решает гонку, поэтому
   * предварительного SELECT нет.
   */
  async enqueueMessage(
    runner: SqlRunner,
    message: {
      carrierCode: string;
      topic: string;
      entityType: string;
      entityId: string;
      payloadJson: string;
      correlationId: string | null;
    },
  ): Promise<void> {
    await runner.query(
      `INSERT INTO integration_outbox
         (carrier_code, topic, entity_type, entity_id, payload, correlation_id)
       VALUES ($1, $2, $3, $4, $5::jsonb, $6)
       ON CONFLICT (topic, entity_id) DO NOTHING`,
      [
        message.carrierCode,
        message.topic,
        message.entityType,
        message.entityId,
        message.payloadJson,
        message.correlationId,
      ],
    );
  }

  /**
   * Захват пачки сообщений одним проходом диспетчера.
   *
   * Захват обёрнут в CTE не для красоты: TypeORM для голого `UPDATE …
   * RETURNING` отдаёт `[rows, rowCount]`, а не сами строки. Обёртка делает
   * команду SELECT'ом, и результат становится обычным списком.
   *
   * `FOR UPDATE SKIP LOCKED` — два параллельных диспетчера разберут разные
   * сообщения, а не подерутся за одно. Аренда `locked_until` обязательна:
   * диспетчер, упавший между захватом и результатом, иначе оставил бы
   * сообщение в `IN_PROGRESS` навсегда.
   */
  async claimBatch(runner: SqlRunner, batchSize: number): Promise<ClaimedRow[]> {
    return runner.query(
      `WITH claimed AS (
         UPDATE integration_outbox o
            SET status = 'IN_PROGRESS',
                attempts = o.attempts + 1,
                locked_until = now() + interval '2 minutes'
          WHERE o.id IN (
            SELECT id FROM integration_outbox
             WHERE (status = 'PENDING' AND next_attempt_at <= now())
                -- Аренда истекла: диспетчер упал между захватом и результатом.
                -- Без этой ветки сообщение осталось бы в IN_PROGRESS навсегда.
                OR (status = 'IN_PROGRESS' AND locked_until < now())
             ORDER BY next_attempt_at ASC
             LIMIT $1
             FOR UPDATE SKIP LOCKED
          )
          RETURNING o.id, o.carrier_code, o.topic, o.entity_type, o.entity_id,
                    o.payload, o.attempts, o.correlation_id
       )
       SELECT * FROM claimed`,
      [batchSize],
    );
  }

  /** Успешная доставка: аренда и прошлая ошибка снимаются вместе со статусом. */
  async markDelivered(runner: SqlRunner, id: string): Promise<void> {
    await runner.query(
      `UPDATE integration_outbox
          SET status='DELIVERED', delivered_at=now(), locked_until=NULL, last_error=NULL
        WHERE id=$1`,
      [id],
    );
  }

  /**
   * Неудачная попытка: повтор или отказ.
   *
   * Момент следующей попытки приходит готовым значением из приложения —
   * арифметика интервалов в SQL с нетипизированным параметром слишком легко
   * даёт «interval out of range» на пустом месте. Приведение
   * `$2::outbox_status` обязательно: параметр приходит текстом.
   */
  async markAttemptFailed(
    runner: SqlRunner,
    params: {
      id: string;
      status: OutboxRetryStatus;
      error: string;
      nextAttemptAt: string;
    },
  ): Promise<void> {
    await runner.query(
      `UPDATE integration_outbox
          SET status = $2::outbox_status,
              last_error = $3,
              locked_until = NULL,
              next_attempt_at = $4
        WHERE id = $1`,
      [params.id, params.status, params.error, params.nextAttemptAt],
    );
  }

  /**
   * Ручной повтор застрявшего сообщения.
   *
   * Условие `status='FAILED'` в самом UPDATE, а не проверкой перед ним: иначе
   * ручной повтор мог бы сбросить счётчик попыток сообщению, которое прямо
   * сейчас разбирает диспетчер.
   */
  async requeueFailed(runner: SqlRunner, id: string): Promise<void> {
    await runner.query(
      `UPDATE integration_outbox
          SET status='PENDING', attempts=0, next_attempt_at=now(), last_error=NULL
        WHERE id=$1 AND status='FAILED'`,
      [id],
    );
  }
}
