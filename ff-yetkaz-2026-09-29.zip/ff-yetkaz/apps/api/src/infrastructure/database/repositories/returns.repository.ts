import { Injectable } from '@nestjs/common';
import type {
  InventoryUnitStatus,
  ReturnItemCondition,
  ReturnSortField,
  ReturnStatus,
  SortDirection,
} from '@ff/shared';
import type { SqlRunner } from '../sql-runner';

const SORT_COLUMNS: Record<ReturnSortField, string> = {
  createdAt: 'r.created_at',
  returnNo: 'r.return_no',
  status: 'r.status',
  totalQuantity: 'total_quantity',
};

const SELECT_SQL = `
  r.id, r.return_no, r.status, r.seller_id, s.legal_name AS seller_name,
  r.warehouse_id, w.code AS warehouse_code,
  r.order_id, o.order_code, o.external_id AS order_external_id,
  r.reason, r.comment, r.created_by, r.created_at, r.updated_at, r.completed_at,
  COALESCE(it.quantity, 0)::int  AS total_quantity,
  COALESCE(it.restocked, 0)::int AS total_restocked`;

// Итоги считает БД одним боковым подзапросом: тянуть позиции в приложение
// ради двух сумм — это N+1, который проявится не на демо, а на объёме.
const FROM_SQL = `
  FROM returns r
  JOIN sellers s ON s.id = r.seller_id
  JOIN warehouses w ON w.id = r.warehouse_id
  LEFT JOIN orders o ON o.id = r.order_id
  LEFT JOIN LATERAL (
    SELECT SUM(i.quantity)::int AS quantity, SUM(i.restocked_quantity)::int AS restocked
      FROM return_items i WHERE i.return_id = r.id
  ) it ON true`;

export interface ReturnRow {
  id: string;
  return_no: string;
  status: ReturnStatus;
  seller_id: string;
  seller_name: string | null;
  warehouse_id: string;
  warehouse_code: string | null;
  order_id: string | null;
  order_code: string | null;
  order_external_id: string | null;
  reason: string;
  comment: string | null;
  created_by: string | null;
  created_at: Date | string;
  updated_at: Date | string;
  completed_at: Date | string | null;
  total_quantity: number | string;
  total_restocked: number | string;
}

export interface ItemRow {
  id: string;
  return_id: string;
  sku_id: string;
  sku_code: string;
  sku_name: string;
  quantity: number | string;
  condition: ReturnItemCondition;
  restocked_quantity: number | string;
  bin_code: string | null;
}

export interface ReturnStatusEventRow {
  id: string | number;
  from_status: string | null;
  to_status: string;
  actor_user_id: string | null;
  actor_name: string | null;
  comment: string | null;
  occurred_at: Date | string;
}

export interface ReturnHoldingRow {
  sku_id: string;
  lot_id: string | null;
  bin_id: string;
  status: InventoryUnitStatus;
  qty: number | string;
}

/**
 * Доступ к хранилищу возвратов (RMA).
 *
 * Условия фильтра приходят готовым куском текста от вызывающего: их собирает
 * `buildFilter` вместе с областью видимости селлера и нумерацией параметров.
 * Алиасы (`r`, `s`, `w`, `o`, `i`) заданы здесь, в `FROM_SQL`, — правя их,
 * править и фильтр.
 */
@Injectable()
export class ReturnsRepository {
  /** Сколько всего возвратов подходит под фильтр — для конверта страницы. */
  async countByFilter(
    runner: SqlRunner,
    where: string,
    values: unknown[],
  ): Promise<Array<{ total: number | string }>> {
    return runner.query(`SELECT count(*)::int AS total ${FROM_SQL} ${where}`, values);
  }

  /**
   * Страница списка. `r.id` вторым ключом сортировки: без него страницы с
   * одинаковой датой тасуются между запросами, и запись то дублируется, то
   * пропадает.
   */
  async findPage(
    runner: SqlRunner,
    query: {
      where: string;
      sortField: ReturnSortField;
      direction: SortDirection;
      limit: string;
      offset: string;
    },
    values: unknown[],
  ): Promise<ReturnRow[]> {
    return runner.query(
      `SELECT ${SELECT_SQL} ${FROM_SQL} ${query.where}
        ORDER BY ${SORT_COLUMNS[query.sortField]} ${query.direction === 'asc' ? 'ASC' : 'DESC'}, r.id ASC
        LIMIT ${query.limit} OFFSET ${query.offset}`,
      values,
    );
  }

  /** Та же выборка для выгрузки: порядок фиксированный, страницы идут подряд. */
  async findExportPage(
    runner: SqlRunner,
    query: { where: string; limit: string; offset: string },
    values: unknown[],
  ): Promise<ReturnRow[]> {
    return runner.query(
      `SELECT ${SELECT_SQL} ${FROM_SQL} ${query.where}
          ORDER BY r.created_at DESC, r.id ASC
          LIMIT ${query.limit} OFFSET ${query.offset}`,
      values,
    );
  }

  async findById(runner: SqlRunner, id: string): Promise<ReturnRow[]> {
    return runner.query(`SELECT ${SELECT_SQL} ${FROM_SQL} WHERE r.id = $1`, [id]);
  }

  /** Позиции всей страницы одним запросом — иначе N+1 на каждый возврат. */
  async findItems(runner: SqlRunner, ids: string[]): Promise<ItemRow[]> {
    return runner.query(
      `SELECT i.id, i.return_id, i.sku_id, k.sku_code, k.name AS sku_name,
              i.quantity, i.condition, i.restocked_quantity, b.code AS bin_code
         FROM return_items i
         JOIN skus k ON k.id = i.sku_id
         LEFT JOIN bin_locations b ON b.id = i.bin_id
        WHERE i.return_id = ANY($1::uuid[])
        ORDER BY k.sku_code ASC`,
      [ids],
    );
  }

  async findStatusHistory(runner: SqlRunner, returnId: string): Promise<ReturnStatusEventRow[]> {
    return runner.query(
      `SELECT h.id, h.from_status, h.to_status, h.actor_user_id,
              u.full_name AS actor_name, h.comment, h.occurred_at
         FROM return_status_history h
         LEFT JOIN users u ON u.id = h.actor_user_id
        WHERE h.return_id = $1
        ORDER BY h.occurred_at ASC, h.id ASC`,
      [returnId],
    );
  }

  /**
   * Что документ удерживает прямо сейчас: приход минус расход по ЕГО движениям.
   *
   * Обе половины `UNION ALL` идут по одной паре `reference_type/reference_id`,
   * поэтому группировка сводит приход и расход одного среза в одну строку, а
   * `HAVING SUM(delta) > 0` выбрасывает то, что уже полностью ушло. Считать по
   * `stock` нельзя: остаток количественный и не знает, чьи это единицы.
   */
  async holdingsByReference(
    runner: SqlRunner,
    referenceType: string,
    returnId: string,
  ): Promise<ReturnHoldingRow[]> {
    return runner.query(
      `SELECT sku_id, lot_id, bin_id, status, SUM(delta)::int AS qty
         FROM (
           SELECT sku_id, lot_id, to_bin_id AS bin_id, to_status AS status, quantity AS delta
             FROM stock_movements
            WHERE reference_type = $1 AND reference_id = $2 AND to_bin_id IS NOT NULL
           UNION ALL
           SELECT sku_id, lot_id, from_bin_id, from_status, -quantity
             FROM stock_movements
            WHERE reference_type = $1 AND reference_id = $2 AND from_bin_id IS NOT NULL
         ) moves
        GROUP BY sku_id, lot_id, bin_id, status
       HAVING SUM(delta) > 0
        ORDER BY 5 DESC`,
      [referenceType, returnId],
    );
  }

  /** Артикулы по идентификаторам — чтобы отказ называл товар, а не uuid. */
  async findSkuCodes(
    runner: SqlRunner,
    ids: string[],
  ): Promise<Array<{ id: string; sku_code: string }>> {
    return runner.query(`SELECT id, sku_code FROM skus WHERE id = ANY($1::uuid[])`, [ids]);
  }

  /**
   * Прибавляет разложенное к позиции.
   *
   * Прибавление в SQL, а не запись посчитанного в приложении числа: абсолютное
   * значение из прочитанного снимка затирает то, что успел записать
   * параллельный вызов. Блокировка документа этот случай уже закрывает, но
   * относительная запись не зависит от того, удержит ли её кто-нибудь в будущем.
   * `COALESCE($3, bin_id)` оставляет прежнюю ячейку, когда годного нет.
   */
  async addRestocked(
    runner: SqlRunner,
    itemId: string,
    quantity: number,
    binId: string | null,
  ): Promise<void> {
    await runner.query(
      `UPDATE return_items
              SET restocked_quantity = restocked_quantity + $2,
                  bin_id = COALESCE($3, bin_id)
            WHERE id = $1`,
      [itemId, quantity, binId],
    );
  }

  /** Ячейка в позициях едет следом за товаром — по перечисленным артикулам. */
  async setItemsBin(
    runner: SqlRunner,
    returnId: string,
    binId: string,
    skuIds: string[],
  ): Promise<void> {
    await runner.query(
      `UPDATE return_items SET bin_id = $2 WHERE return_id = $1 AND sku_id = ANY($3::uuid[])`,
      [returnId, binId, skuIds],
    );
  }
}
