import { Injectable } from '@nestjs/common';
import type { InventoryUnitStatus } from '@ff/shared';
import type { SqlRunner } from '../sql-runner';

/** Что заказ физически удерживает прямо сейчас — по журналу движений. */
export interface HoldingRow {
  sku_id: string;
  lot_id: string | null;
  bin_id: string;
  status: InventoryUnitStatus;
  qty: number;
}

/** Ячейка, откуда товар когда-то взяли под этот заказ. */
export interface OriginRow {
  sku_id: string;
  lot_id: string | null;
  bin_id: string;
  qty: number;
}

/**
 * Сырой SQL возврата на склад. Соединение не внедряется: его передаёт
 * вызывающий — `em` внутри транзакции, `this.dataSource` вне её.
 */
@Injectable()
export class PutBackRepository {
  /**
   * Что заказ удерживает: приход минус расход по ЕГО движениям.
   *
   * Именно так, а не по `stock`: остаток количественный и не помнит, чьи это
   * единицы. Обе половины `UNION ALL` берут одну и ту же пару
   * `reference_type`/`reference_id` — приход по `to_*`, расход по `from_*` со
   * знаком минус. `HAVING SUM(delta) > 0` отбрасывает срезы, из которых товар
   * уже полностью ушёл: держать в результате нули значит потом их фильтровать
   * в приложении.
   */
  findHoldings(
    runner: SqlRunner,
    referenceType: string,
    orderId: string,
  ): Promise<HoldingRow[]> {
    return runner.query(
      `SELECT sku_id, lot_id, bin_id, status, SUM(delta)::int AS qty
         FROM (
           SELECT sku_id, lot_id, to_bin_id AS bin_id, to_status AS status, quantity AS delta
             FROM stock_movements
            WHERE reference_type = $1 AND reference_id = $2 AND to_bin_id IS NOT NULL
           UNION ALL
           SELECT sku_id, lot_id, from_bin_id, from_status, -quantity
             FROM stock_movements
            WHERE reference_type = $1 AND reference_id = $2 AND from_bin_id IS NOT NULL
         ) moves
        GROUP BY sku_id, lot_id, bin_id, status
       HAVING SUM(delta) > 0`,
      [referenceType, orderId],
    );
  }

  /**
   * Ячейки, из которых товар резервировали: туда же его и возвращаем.
   *
   * Порядок `ORDER BY 4 DESC` — по убыванию количества: раскладка начинается с
   * ячейки, откуда взяли больше всего, и остаток реже размазывается по мелочи.
   */
  findOrigins(runner: SqlRunner, referenceType: string, orderId: string): Promise<OriginRow[]> {
    return runner.query(
      `SELECT sku_id, lot_id, from_bin_id AS bin_id, SUM(quantity)::int AS qty
           FROM stock_movements
          WHERE reference_type = $1 AND reference_id = $2 AND reason = 'RESERVE'
            AND from_bin_id IS NOT NULL
          GROUP BY sku_id, lot_id, from_bin_id
          ORDER BY 4 DESC`,
      [referenceType, orderId],
    );
  }
}
