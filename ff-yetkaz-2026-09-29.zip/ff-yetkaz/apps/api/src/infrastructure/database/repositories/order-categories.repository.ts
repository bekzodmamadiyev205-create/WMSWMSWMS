import { Injectable } from '@nestjs/common';
import { SqlParams, whereClause } from '../query/page';
import type { SqlRunner } from '../sql-runner';

export interface OrderCategoryLockRow {
  id: string;
  code: string;
  name: string;
  description: string | null;
  color: string | null;
  sort_order: number;
  is_active: boolean;
}

export interface OrderCategoryRow extends OrderCategoryLockRow {
  orders_count: number | string | null;
  created_at: Date | string;
  updated_at: Date | string;
}

/**
 * Число заказов считает БД боковым подзапросом: выгружать заказы ради `length`
 * нельзя — справочник открывается на каждом оформлении заказа.
 *
 * Счётчик уважает область видимости селлера. Для него «сколько заказов в
 * категории» — это его заказы, а не суммарный оборот всех клиентов оператора.
 */
function selectCategories(scopeParam: string): string {
  return `SELECT c.id, c.code, c.name, c.description, c.color, c.sort_order, c.is_active,
                 c.created_at, c.updated_at, u.orders_count
            FROM order_categories c
            LEFT JOIN LATERAL (
              SELECT count(*)::int AS orders_count
                FROM orders o
               WHERE o.category_id = c.id
                 AND (${scopeParam}::uuid IS NULL OR o.seller_id = ${scopeParam}::uuid)
            ) u ON true`;
}

/** Доступ к хранилищу справочника категорий заказа. */
@Injectable()
export class OrderCategoriesRepository {
  async findAll(
    runner: SqlRunner,
    options: { scope: string | null; onlyActive: boolean },
  ): Promise<OrderCategoryRow[]> {
    const params = new SqlParams();
    const scopeParam = params.bind(options.scope);

    const conditions: string[] = [];
    if (options.onlyActive) conditions.push('c.is_active');

    return runner.query(
      `${selectCategories(scopeParam)}
        ${whereClause(conditions)}
        ORDER BY c.sort_order ASC, c.name ASC`,
      params.values,
    );
  }

  async findById(
    runner: SqlRunner,
    options: { scope: string | null; id: string },
  ): Promise<OrderCategoryRow[]> {
    const params = new SqlParams();
    const scopeParam = params.bind(options.scope);
    const idParam = params.bind(options.id);

    return runner.query(`${selectCategories(scopeParam)} WHERE c.id = ${idParam}`, params.values);
  }

  /** Занятые оттенки — по ним подбирается цвет новой категории. */
  async findUsedColors(runner: SqlRunner): Promise<Array<{ color: string }>> {
    return runner.query(
      `SELECT lower(color) AS color FROM order_categories WHERE color IS NOT NULL`,
    );
  }

  /**
   * Захватывает строку справочника на запись.
   *
   * FOR UPDATE на строке справочника конфликтует с FOR KEY SHARE, который
   * PostgreSQL берёт на родительской строке при проверке внешнего ключа.
   * Значит, пока идёт удаление, ни один заказ не может встать на эту
   * категорию: иначе ссылка успела бы появиться между подсчётом и DELETE.
   */
  async lockById(runner: SqlRunner, id: string): Promise<OrderCategoryLockRow[]> {
    return runner.query(
      `SELECT id, code, name, description, color, sort_order, is_active
           FROM order_categories WHERE id = $1 FOR UPDATE`,
      [id],
    );
  }

  async deleteById(runner: SqlRunner, id: string): Promise<void> {
    await runner.query(`DELETE FROM order_categories WHERE id = $1`, [id]);
  }

  /** Сколько заказов ссылается на категорию — настоящий барьер удаления. */
  async countOrders(
    runner: SqlRunner,
    id: string,
  ): Promise<Array<{ orders_count: number | string }>> {
    return runner.query(
      `SELECT count(*)::int AS orders_count FROM orders WHERE category_id = $1`,
      [id],
    );
  }
}
