import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/**
 * Сырой SQL справочника товаров. Соединение не внедряется: его передаёт
 * вызывающий — здесь это ВСЕГДА `em` загрузки каталога.
 *
 * Всё содержимое — точки сохранения одной транзакции. Точка сохранения живёт
 * ТОЛЬКО внутри своей транзакции: возьми репозиторий соединение сам, и
 * `SAVEPOINT` открылся бы в чужом соединении, а `ROLLBACK TO` в нём же не нашёл
 * бы точки — строка с ошибкой отравила бы всю загрузку вместо одной себя.
 *
 * Имя точки постоянное (`sku_import_row`), и это не небрежность: строки
 * обрабатываются строго последовательно, каждая точка снимается своим
 * `RELEASE`/`ROLLBACK TO` до начала следующей, поэтому одновременно
 * существующих одноимённых точек не бывает.
 */
@Injectable()
export class SkusRepository {
  /**
   * Открыть точку сохранения перед строкой файла: файл на тысячу позиций не
   * должен целиком отвергаться из-за одной опечатки в весе.
   */
  async openImportRowSavepoint(runner: SqlRunner): Promise<void> {
    await runner.query('SAVEPOINT sku_import_row');
  }

  /** Строка принята — точка снимается, записанное остаётся в транзакции. */
  async releaseImportRowSavepoint(runner: SqlRunner): Promise<void> {
    await runner.query('RELEASE SAVEPOINT sku_import_row');
  }

  /**
   * Строка не принята — откат ровно до её начала. Без него первая же ошибка
   * переводит транзакцию PostgreSQL в аварийное состояние, и все последующие
   * строки файла отвергаются с «current transaction is aborted».
   */
  async rollbackImportRowSavepoint(runner: SqlRunner): Promise<void> {
    await runner.query('ROLLBACK TO SAVEPOINT sku_import_row');
  }
}
