import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/**
 * Сырой SQL зоны упаковки: очередь, состав коробки, оформление отправления.
 *
 * Соединение внутрь не внедряется — оно приходит первым аргументом. Оформление
 * отправления идёт ВНУТРИ транзакции (вставка в `shipments`, событие статуса и
 * постановка в outbox обязаны откатываться вместе), чтение очереди и состава —
 * вне её. Кто чем пользуется, решает вызывающий, а не репозиторий.
 */
@Injectable()
export class PackingRepository {
  /**
   * Очередь упаковки. Содержимое считается по журналу движений
   * (`reason = 'PICK'`), а не по позициям заказа: при недоборе они расходятся,
   * и в коробку уедет не то, что просил канал.
   *
   * `LEFT JOIN LATERAL` — потому что подсчёт зависит от строки заказа; заказ без
   * единого движения обязан остаться в выдаче (отсюда же `NULLS LAST` в
   * сортировке: у него нет времени сборки).
   *
   * Фильтр по складу подставляется в текст, а не передаётся всегда: номер
   * параметра лимита зависит от того, был ли фильтр.
   */
  async findPackingQueue(
    runner: SqlRunner,
    query: { warehouseId?: string; limit?: number },
  ): Promise<Array<Record<string, unknown>>> {
    const params: unknown[] = [];
    let warehouseFilter = '';
    if (query.warehouseId) {
      params.push(query.warehouseId);
      warehouseFilter = `AND o.warehouse_id = $${params.length}`;
    }
    params.push(query.limit ?? 100);

    return runner.query(
      `SELECT o.id, o.external_id, o.channel, o.seller_id, o.warehouse_id, o.status,
              o.recipient_name, o.address, o.has_shortage,
              c.items, c.units, c.picked_at,
              p.id AS package_id, p.packer_user_id
         FROM orders o
         LEFT JOIN packages p ON p.order_id = o.id
         LEFT JOIN LATERAL (
           SELECT count(DISTINCT m.sku_id)::int AS items,
                  COALESCE(SUM(m.quantity), 0)::int AS units,
                  MAX(m.occurred_at) AS picked_at
             FROM stock_movements m
            WHERE m.reference_type = 'ORDER' AND m.reference_id = o.id::text AND m.reason = 'PICK'
         ) c ON TRUE
        WHERE o.status IN ('PICKED', 'PACKING') ${warehouseFilter}
        ORDER BY c.picked_at ASC NULLS LAST, o.created_at ASC
        LIMIT $${params.length}`,
      params,
    );
  }

  /**
   * Создать отправление по закрытой коробке.
   *
   * `RETURNING *` обязателен: номер отправления выдаёт `DEFAULT`
   * последовательности БД (`FF000000001`), приложение его не назначает — узнать
   * присвоенный номер можно только из возвращённой строки.
   */
  async createShipment(
    runner: SqlRunner,
    params: [
      orderId: string,
      packageId: string,
      carrier: string,
      weightG: number | null,
      codAmount: string | null,
      currency: string | null,
    ],
  ): Promise<Array<Record<string, unknown>>> {
    return runner.query(
      `INSERT INTO shipments (order_id, package_id, status, carrier, weight_g, cod_amount, currency)
         VALUES ($1, $2, 'READY', $3, $4, $5, $6)
         RETURNING *`,
      params,
    );
  }

  /**
   * Первое событие в истории отправления: `from_status` пуст, потому что до
   * оформления состояния не было вовсе.
   */
  async recordInitialStatusEvent(
    runner: SqlRunner,
    params: [shipmentId: string, comment: string],
  ): Promise<unknown> {
    return runner.query(
      `INSERT INTO shipment_status_events (shipment_id, from_status, to_status, occurred_at, source, comment)
         VALUES ($1, NULL, 'READY', now(), 'FF', $2)`,
      params,
    );
  }

  /** Вложение для печатной этикетки: порядок по артикулу — чтобы список не прыгал. */
  async findLabelItems(
    runner: SqlRunner,
    packageId: string,
  ): Promise<Array<{ sku_code: string; name: string; quantity: number }>> {
    return runner.query(
      `SELECT s.sku_code, s.name, i.quantity
           FROM package_items i
           JOIN skus s ON s.id = i.sku_id
          WHERE i.package_id = $1
          ORDER BY s.sku_code ASC`,
      [packageId],
    );
  }

  /** То же вложение, но для передачи перевозчику. */
  async findHandoffItems(
    runner: SqlRunner,
    packageId: string,
  ): Promise<Array<{ sku_code: string; name: string; quantity: number }>> {
    return runner.query(
      `SELECT s.sku_code, s.name, i.quantity
           FROM package_items i JOIN skus s ON s.id = i.sku_id
          WHERE i.package_id = $1 ORDER BY s.sku_code ASC`,
      [packageId],
    );
  }

  /**
   * Что физически доехало до зоны упаковки: свёртка журнала движений по
   * SKU × партия × ячейка.
   *
   * `HAVING SUM(quantity) > 0` отсекает срезы, из которых товар уже ушёл: журнал
   * append-only, приход и расход лежат отдельными строками, и нулевая сумма
   * означает «здесь ничего нет», а не «строки нет».
   */
  async findPickedContent(
    runner: SqlRunner,
    params: [referenceType: string, referenceId: string],
  ): Promise<
    Array<{
      sku_id: string;
      lot_id: string | null;
      bin_id: string;
      quantity: number;
    }>
  > {
    return runner.query(
      `SELECT sku_id, lot_id, to_bin_id AS bin_id, SUM(quantity)::int AS quantity
         FROM stock_movements
        WHERE reference_type = $1 AND reference_id = $2 AND reason = 'PICK'
        GROUP BY sku_id, lot_id, to_bin_id
       HAVING SUM(quantity) > 0`,
      params,
    );
  }

  /**
   * Веса из справочника одним запросом по массиву (`= ANY($1::uuid[])`), а не
   * по одному на SKU: состав коробки читается целиком.
   */
  async findSkuWeights(
    runner: SqlRunner,
    skuIds: string[],
  ): Promise<Array<{ id: string; weight_g: number | null }>> {
    return runner.query(
      `SELECT id, weight_g FROM skus WHERE id = ANY($1::uuid[])`,
      [skuIds],
    );
  }

  /** Состав коробки с названиями и весами — для карточки упаковки. */
  async findPackageItems(
    runner: SqlRunner,
    packageId: string,
  ): Promise<
    Array<{
      id: string;
      sku_id: string;
      sku_code: string;
      sku_name: string;
      lot_id: string | null;
      quantity: number;
      weight_g: number | null;
    }>
  > {
    return runner.query(
      `SELECT i.id, i.sku_id, s.sku_code, s.name AS sku_name, i.lot_id, i.quantity, s.weight_g
         FROM package_items i
         JOIN skus s ON s.id = i.sku_id
        WHERE i.package_id = $1
        ORDER BY s.sku_code ASC`,
      [packageId],
    );
  }
}
