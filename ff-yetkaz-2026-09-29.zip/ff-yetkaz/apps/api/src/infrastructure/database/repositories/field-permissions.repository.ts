import { Injectable } from '@nestjs/common';
import type { FieldPermissionDto } from '@ff/shared';
import { SqlParams } from '../query/page';
import type { SqlRunner } from '../sql-runner';

/**
 * Доступ к хранилищу матрицы «роль × сущность × поле».
 *
 * Таблица — СПИСОК ИСКЛЮЧЕНИЙ: строка есть только там, где что-то закрыто.
 * Отсюда две операции — снять исключение (DELETE) и записать его (UPSERT);
 * вызывающий сам решает, какая строка куда относится.
 *
 * Обе команды идут ОДНИМ запросом на весь список: построчный цикл в
 * транзакции — это столько же раундтрипов, сколько чек-боксов в матрице.
 */
@Injectable()
export class FieldPermissionsRepository {
  /**
   * Снимает перечисленные исключения.
   *
   * Роль приводится к `ff_role` явно: в кортеже сравнения PostgreSQL не выводит
   * тип enum из параметра-текста, и без приведения запрос падает на разборе.
   */
  async removeExceptions(runner: SqlRunner, permissions: FieldPermissionDto[]): Promise<void> {
    const params = new SqlParams();
    const tuples = permissions.map(
      (permission) =>
        `(${params.bind(permission.role)}::ff_role, ${params.bind(permission.entity)}, ${params.bind(permission.field)})`,
    );
    await runner.query(
      `DELETE FROM field_permissions WHERE (role, entity, field) IN (${tuples.join(', ')})`,
      params.values,
    );
  }

  /**
   * Записывает исключения.
   *
   * `ON CONFLICT (role, entity, field) DO UPDATE` — потому что PUT матрицы это
   * НАБОР УТВЕРЖДЕНИЙ, а не замена состояния целиком: присланная строка либо
   * появляется, либо переписывает существующую, а не задевает соседние.
   * `updated_at` не трогаем: его проставляет триггер trg_field_permissions_touch.
   */
  async upsertExceptions(runner: SqlRunner, permissions: FieldPermissionDto[]): Promise<void> {
    const params = new SqlParams();
    const values = permissions.map(
      (permission) =>
        `(${params.bind(permission.role)}::ff_role, ${params.bind(permission.entity)}, ` +
        `${params.bind(permission.field)}, ${params.bind(permission.canView)}, ` +
        `${params.bind(permission.canEdit)}, ${params.bind(permission.canDelete)})`,
    );
    await runner.query(
      `INSERT INTO field_permissions (role, entity, field, can_view, can_edit, can_delete)
       VALUES ${values.join(', ')}
       ON CONFLICT (role, entity, field) DO UPDATE
          SET can_view = EXCLUDED.can_view,
              can_edit = EXCLUDED.can_edit,
              can_delete = EXCLUDED.can_delete`,
      params.values,
    );
  }
}
