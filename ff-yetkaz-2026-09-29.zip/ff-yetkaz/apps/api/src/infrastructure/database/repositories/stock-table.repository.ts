import { Injectable } from '@nestjs/common';
import type {
  InventoryUnitStatus,
  SortDirection,
  StockSortField,
  StockTableQuery,
} from '@ff/shared';
import {
  dateRangeConditions,
  likePattern,
  SqlParams,
  whereClause,
  type PageParams,
} from '../query/page';
import type { SqlRunner } from '../sql-runner';

/** Строка витрины остатков в том виде, в каком её отдаёт SQL. */
export interface StockRow {
  sku_id: string;
  sku_code: string;
  sku_name: string;
  seller_id: string;
  seller_code: string;
  seller_name: string;
  warehouse_id: string;
  warehouse_code: string;
  status: InventoryUnitStatus;
  quantity: string;
  available: string;
  reserved: string;
  damaged: string;
  first_received_at: Date | string | null;
  last_received_at: Date | string | null;
  total_rows: string;
}

/** Раскладка среза по ячейкам. */
export interface StockBinAggregateRow {
  sku_id: string;
  warehouse_id: string;
  status: InventoryUnitStatus;
  bin_id: string;
  bin_code: string;
  quantity: string;
}

/** Итоги витрины: сырые строки счётчиков, приведение к числам — на стороне сервиса. */
export interface StockTableTotalsRow {
  row_count: string;
  units: string;
  available: string;
  reserved: string;
  damaged: string;
  sku_count: string;
}

export interface StockTableSort {
  field: StockSortField;
  direction: SortDirection;
}

const SORT_SQL: Record<StockSortField, string> = {
  skuCode: 'sku.sku_code',
  skuName: 'sku.name',
  sellerName: 'sel.legal_name',
  warehouseCode: 'wh.code',
  quantity: 'sl.quantity',
  receivedAt: 'sl.last_received_at',
  status: 'sl.status',
};

/**
 * Весь сырой SQL витрины остатков. Соединение приходит первым аргументом
 * (`runner`) и значения по умолчанию не имеет — как и у остальных репозиториев:
 * читающий запрос сегодня выполняется вне транзакции, но право решать это
 * принадлежит вызывающему, а не хранилищу.
 */
@Injectable()
export class StockTableRepository {
  /** Итоги считаются по ВСЕМУ фильтру, а не по видимой странице. */
  async countTotals(
    runner: SqlRunner,
    query: StockTableQuery,
    sellerId: string | undefined,
  ): Promise<StockTableTotalsRow[]> {
    const source = this.buildSource(query, sellerId);

    // Плитки «доступно / резерв / брак» — это КОНТЕКСТ, а не срез выборки, и
    // считаются они ровно по тому же набору строк, что и одноимённые колонки в
    // таблице (там их считают оконные функции ДО применения `outer`). Применить
    // к ним фильтр статуса или периода значит выдать ноль в двух плитках из
    // трёх и прямо противоречить строкам на том же экране: в таблице «резерв
    // 30», в плитке над ней — ноль. Ограничивают выборку только `row_count`,
    // `units` и число SKU — это характеристики того, что человек отфильтровал.
    const selected = source.outer.length ? `FILTER (WHERE ${source.outer.join(' AND ')})` : '';

    return runner.query(
      `${source.cte}
       SELECT (count(*) ${selected})::bigint AS row_count,
              coalesce(sum(sl.quantity) ${selected}, 0)::bigint AS units,
              coalesce(sum(sl.quantity) FILTER (WHERE sl.status = 'AVAILABLE'), 0)::bigint AS available,
              coalesce(sum(sl.quantity) FILTER (WHERE sl.status = 'RESERVED'), 0)::bigint AS reserved,
              coalesce(sum(sl.quantity) FILTER (WHERE sl.status = 'DAMAGED'), 0)::bigint AS damaged,
              (count(DISTINCT sl.sku_id) ${selected})::bigint AS sku_count
         FROM slices sl`,
      source.params.values,
    );
  }

  /**
   * Страница витрины. Общее число строк едет в `total_rows` тем же запросом:
   * отдельный `count(*)` считался бы по другому снимку данных.
   */
  async findRows(
    runner: SqlRunner,
    query: StockTableQuery,
    sellerId: string | undefined,
    pageParams: PageParams,
    sort: StockTableSort,
  ): Promise<StockRow[]> {
    const source = this.buildSource(query, sellerId);
    const limit = source.params.bind(pageParams.pageSize);
    const offset = source.params.bind(pageParams.offset);

    return runner.query(
      `${source.cte},
       scoped AS (
         SELECT sl.*,
                -- Итоги по SKU и складу СРАЗУ, тем же проходом. Отдельный
                -- запрос за ними разошёлся бы со страницей: между двумя
                -- запросами товар успевает переехать между статусами.
                coalesce(sum(sl.quantity) FILTER (WHERE sl.status = 'AVAILABLE') OVER w, 0)::bigint AS available,
                coalesce(sum(sl.quantity) FILTER (WHERE sl.status = 'RESERVED')  OVER w, 0)::bigint AS reserved,
                coalesce(sum(sl.quantity) FILTER (WHERE sl.status = 'DAMAGED')   OVER w, 0)::bigint AS damaged
           FROM slices sl
         WINDOW w AS (PARTITION BY sl.sku_id, sl.warehouse_id)
       )
       SELECT sl.sku_id, sl.warehouse_id, sl.status, sl.quantity,
              sl.available, sl.reserved, sl.damaged,
              sl.first_received_at, sl.last_received_at,
              sku.sku_code, sku.name AS sku_name,
              sel.id AS seller_id, sel.code AS seller_code, sel.legal_name AS seller_name,
              wh.code AS warehouse_code,
              count(*) OVER () AS total_rows
         FROM scoped sl
         JOIN skus sku ON sku.id = sl.sku_id
         JOIN sellers sel ON sel.id = sku.seller_id
         JOIN warehouses wh ON wh.id = sl.warehouse_id
        ${whereClause(source.outer)}
        ORDER BY ${SORT_SQL[sort.field]} ${sort.direction === 'asc' ? 'ASC' : 'DESC'} NULLS LAST,
                 sku.sku_code ASC, wh.code ASC, sl.status ASC
        LIMIT ${limit} OFFSET ${offset}`,
      source.params.values,
    );
  }

  /**
   * Раскладка по ячейкам для тройек (SKU, склад, статус) текущей страницы.
   *
   * Ключи передаются ТРЕМЯ массивами через `unnest`, а не списком кортежей:
   * число параметров не зависит от размера страницы, поэтому текст запроса
   * один и тот же и планировщик его кэширует.
   */
  async findBinsForSlices(
    runner: SqlRunner,
    skuIds: string[],
    warehouseIds: string[],
    statuses: string[],
    includeZero: boolean,
  ): Promise<StockBinAggregateRow[]> {
    return runner.query(
      `SELECT s.sku_id, s.warehouse_id, s.status, s.bin_id, b.code AS bin_code,
              sum(s.quantity)::bigint AS quantity
         FROM stock s
         JOIN bin_locations b ON b.id = s.bin_id
         -- unnest тремя массивами вместо списка кортежей: число параметров не
         -- зависит от размера страницы, а значит запрос кэшируется планировщиком.
         JOIN unnest($1::uuid[], $2::uuid[], $3::text[]) AS k(sku_id, warehouse_id, status)
           ON k.sku_id = s.sku_id
          AND k.warehouse_id = s.warehouse_id
          AND k.status = s.status::text
        ${includeZero ? '' : 'WHERE s.quantity > 0'}
        GROUP BY s.sku_id, s.warehouse_id, s.status, s.bin_id, b.code
        ORDER BY b.code ASC`,
      [skuIds, warehouseIds, statuses],
    );
  }

  /**
   * Общая часть запроса: CTE журнала прихода + свод срезов.
   *
   * Условия делятся на две группы намеренно. `slices` собирает срез по всем
   * фильтрам, КРОМЕ статуса и периода: они возвращаются отдельно (`outer`) и
   * применяются снаружи — иначе «доступно / зарезервировано / брак» считались
   * бы по одному оставшемуся статусу и всегда показывали бы ноль в двух
   * значениях из трёх. Список отдаёт их как WHERE после оконных функций,
   * итоги — как FILTER на тех агрегатах, которые действительно описывают
   * выборку, а не контекст.
   */
  private buildSource(
    query: StockTableQuery,
    sellerId: string | undefined,
  ): { params: SqlParams; cte: string; outer: string[] } {
    const params = new SqlParams();

    // Предикат ТОЧНО такой же, как в частичном индексе idx_movements_inbound
    // (миграция StockReturnIndex1787270400000) — иначе индекс не применится и
    // экран остатков начнёт читать весь журнал.
    // `RETURN` здесь наравне с приёмкой: принятый возврат — это поступление на
    // склад. Без него у возвращённого товара обе даты пусты, и фильтр по
    // периоду выбрасывает строку — принятое сегодня не видно в отчёте за сегодня.
    const inbound = [`m.reason IN ('RECEIPT', 'PUTAWAY', 'RETURN')`];
    const slices: string[] = [];

    // Нулевые срезы — шум: строка остатка не удаляется никогда, и через год
    // работы их больше, чем настоящих.
    if (!query.includeZero) slices.push('s.quantity > 0');

    if (sellerId) slices.push(`sku.seller_id = ${params.bind(sellerId)}`);

    if (query.warehouseId) {
      const bound = params.bind(query.warehouseId);
      slices.push(`s.warehouse_id = ${bound}`);
      // Тот же фильтр внутрь CTE: результат он не меняет (соединение всё равно
      // идёт по складу), а объём агрегируемого журнала режет сразу.
      inbound.push(`m.warehouse_id = ${bound}`);
    }

    const search = query.search?.trim();
    if (search) {
      // Требование звучит как «поиск по номеру заказа / SKU», поэтому это ИЛИ,
      // а не два разных поля: строка ищется и как артикул/название/штрихкод,
      // и как номер заказа — во втором случае выдача сужается до товаров,
      // которые в этом заказе есть. Номером считается и наш код FF-YES, и
      // номер клиента: оператор читает их с одной и той же бумажки.
      const pattern = params.bind(likePattern(search));
      slices.push(`(
        sku.sku_code ILIKE ${pattern}
        OR sku.name ILIKE ${pattern}
        OR EXISTS (
          SELECT 1 FROM sku_barcodes bc
           WHERE bc.sku_id = sku.id AND bc.barcode ILIKE ${pattern}
        )
        OR EXISTS (
          SELECT 1 FROM order_lines ol
            JOIN orders o ON o.id = ol.order_id
           WHERE ol.sku_id = sku.id
             AND (o.order_code ILIKE ${pattern} OR o.external_id ILIKE ${pattern})
        )
      )`);
    }

    const outer: string[] = [];
    if (query.status) outer.push(`sl.status = ${params.bind(query.status)}::inventory_status`);
    // Период — по дате ПОСЛЕДНЕГО прихода: «что приехало на этой неделе».
    outer.push(...dateRangeConditions('sl.last_received_at', params, query.dateFrom, query.dateTo));

    const cte = `
      WITH inbound AS (
        -- Группировка БЕЗ to_status: поступлением является попадание товара в
        -- ячейку, а не последующая смена статуса внутри неё. Со статусом в ключе
        -- дату находил только AVAILABLE-срез, потому что движений с
        -- to_status = 'RESERVED'/'DAMAGED'/'PICKED' в приходном журнале нет
        -- вовсе — у таких срезов дата выходила NULL, а сравнение с NULL ложно,
        -- и фильтр по периоду молча выкидывал резерв, брак, собранное и
        -- упакованное. Кладовщик делал вывод, что резерва и брака нет.
        SELECT m.sku_id, m.warehouse_id, m.to_bin_id, m.lot_id,
               min(m.occurred_at) AS first_at,
               max(m.occurred_at) AS last_at
          FROM stock_movements m
         WHERE ${inbound.join(' AND ')}
         GROUP BY m.sku_id, m.warehouse_id, m.to_bin_id, m.lot_id
      ),
      inbound_wh AS (
        -- Запасной, более грубый ответ — по складу и партии, без ячейки. Нужен
        -- потому, что часть товара уезжает во ВНУТРЕННЮЮ ячейку, куда прихода
        -- не было и быть не может: собранное лежит в зоне упаковки, упакованное
        -- в зоне отгрузки, брак — в ячейке брака. По ячейке даты у них нет, но
        -- на склад они когда-то приехали, и выбрасывать их из отчёта за период
        -- нельзя. Точность до ячейки при этом сохраняется везде, где она есть:
        -- это COALESCE, а не замена.
        SELECT i.sku_id, i.warehouse_id, i.lot_id,
               min(i.first_at) AS first_at,
               max(i.last_at)  AS last_at
          FROM inbound i
         GROUP BY i.sku_id, i.warehouse_id, i.lot_id
      ),
      slices AS (
        SELECT s.sku_id, s.warehouse_id, s.status,
               sum(s.quantity)::bigint AS quantity,
               -- Количественный остаток складывается из НЕСКОЛЬКИХ поставок,
               -- поэтому одной «даты поступления» у него не существует.
               -- Отдаём обе честные: min — возраст самого старого товара в
               -- срезе, max — когда пополняли в последний раз.
               min(coalesce(i.first_at, w.first_at)) AS first_received_at,
               max(coalesce(i.last_at,  w.last_at))  AS last_received_at
          FROM stock s
          JOIN skus sku ON sku.id = s.sku_id
          -- Оба соединения дают максимум ОДНУ строку на строку остатка: каждый
          -- CTE сгруппирован ровно по своим ключам соединения. Иначе sum(s.quantity)
          -- задвоился бы — витрина показала бы больше товара, чем лежит на складе.
          LEFT JOIN inbound i
                 ON i.sku_id = s.sku_id
                AND i.warehouse_id = s.warehouse_id
                AND i.to_bin_id = s.bin_id
                -- Именно IS NOT DISTINCT FROM: обычное «=» на партии молча
                -- выбрасывает КАЖДЫЙ непартионный срез, потому что NULL = NULL
                -- в SQL не истина, а неизвестность.
                AND i.lot_id IS NOT DISTINCT FROM s.lot_id
          LEFT JOIN inbound_wh w
                 ON w.sku_id = s.sku_id
                AND w.warehouse_id = s.warehouse_id
                AND w.lot_id IS NOT DISTINCT FROM s.lot_id
         ${whereClause(slices)}
         GROUP BY s.sku_id, s.warehouse_id, s.status
      )`;

    return { params, cte, outer };
  }
}
