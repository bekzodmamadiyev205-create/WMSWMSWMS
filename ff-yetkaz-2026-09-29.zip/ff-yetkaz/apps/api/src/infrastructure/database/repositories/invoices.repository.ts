import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/** Счёт периода, каким его видит поиск существующего: id, номер, статус. */
export interface PeriodInvoiceRow {
  id: string;
  number: string;
  status: string;
}

/** Группа начислений, из которой получится строка счёта. */
export interface GroupedChargeRow {
  kind: string;
  unit: string;
  unit_price: string;
  quantity: string;
  amount: string;
  currency: string;
}

/** Собранный наложенный платёж по захваченным счётом отправлениям. */
export interface CapturedCodTotalsRow {
  total: string;
  currency: string | null;
}

/** Начисления периода, не попавшие ни в один счёт. */
export interface UncapturedChargeRow {
  kind: string;
  count: string;
  amount: string;
  currency: string;
}

/** Счёт, чей период пересекается с собираемым. */
export interface OverlappingInvoiceRow {
  number: string;
  period_start: string;
  period_end: string;
}

/**
 * Сырой SQL счетов. Соединение не внедряется: его передаёт вызывающий —
 * `em` внутри транзакции, `this.dataSource` вне её.
 *
 * Для сборки счёта это несущее требование: захват оснований и подсчёт по
 * захваченному обязаны быть ОДНОЙ транзакцией. Возьми репозиторий соединение
 * сам — подсчёт не увидел бы незакоммиченный захват, а сам захват не откатился
 * бы вместе с неудавшейся сборкой, и начисления навсегда остались бы за
 * несуществующим счётом.
 */
@Injectable()
export class InvoicesRepository {
  /**
   * Счёт за тот же период, кроме отменённого: отмена освобождает период, и
   * мёртвый счёт не должен мешать собрать его заново.
   */
  findPeriodInvoice(
    runner: SqlRunner,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<PeriodInvoiceRow[]> {
    return runner.query(
      `SELECT id, number, status::text AS status FROM invoices
          WHERE seller_id=$1 AND period_start=$2::date AND period_end=$3::date AND status <> 'CANCELLED'`,
      [sellerId, periodStart, periodEnd],
    );
  }

  /**
   * Пустой черновик счёта. 'XXX' — код ISO 4217 «валюта не определена»:
   * настоящая проставляется, когда известно, из чего счёт собран.
   */
  insertInvoice(
    runner: SqlRunner,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<Array<{ id: string }>> {
    return runner.query(
      `INSERT INTO invoices (seller_id, period_start, period_end, currency)
         VALUES ($1, $2::date, $3::date, 'XXX')
         RETURNING id`,
      [sellerId, periodStart, periodEnd],
    );
  }

  /**
   * Снимает захват начислений с ОТМЕНЁННЫХ счетов в собираемом периоде.
   *
   * Отмена освобождает период, а захват на строке начисления об этом не знает:
   * без снятия начисления навсегда остались бы за мёртвым счётом, и собранный
   * заново период вышел бы пустым.
   */
  async releaseChargesFromCancelled(
    runner: SqlRunner,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<void> {
    await runner.query(
      `UPDATE charges c SET invoice_id = NULL
         FROM invoices i
        WHERE i.id = c.invoice_id AND i.status = 'CANCELLED'
          AND c.seller_id = $1
          AND c.occurred_at >= $2::date AND c.occurred_at < ($3::date + 1)`,
      [sellerId, periodStart, periodEnd],
    );
  }

  /** То же снятие захвата с отменённых счетов, но для собранного платежа. */
  async releaseShipmentsFromCancelled(
    runner: SqlRunner,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<void> {
    await runner.query(
      `UPDATE shipments s SET payout_invoice_id = NULL
         FROM invoices i
        WHERE i.id = s.payout_invoice_id AND i.status = 'CANCELLED'
          AND i.seller_id = $1
          AND s.cod_collected_at >= $2::date AND s.cod_collected_at < ($3::date + 1)`,
      [sellerId, periodStart, periodEnd],
    );
  }

  /**
   * ЗАХВАТ начислений периода счётом — до подсчёта, а не после.
   *
   * Условие `invoice_id IS NULL` и есть защита от гонки: чужое начисление
   * переподчинить нельзя, а параллельный прогон, добавивший строку уже после
   * захвата, просто не попадёт в этот счёт — и останется видимым как
   * незахваченное, вместо того чтобы пропасть молча.
   */
  async captureCharges(
    runner: SqlRunner,
    invoiceId: string,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<void> {
    await runner.query(
      `UPDATE charges SET invoice_id = $1
        WHERE seller_id = $2 AND invoice_id IS NULL
          AND occurred_at >= $3::date AND occurred_at < ($4::date + 1)`,
      [invoiceId, sellerId, periodStart, periodEnd],
    );
  }

  /**
   * Захват собранного платежа — так же и в том же порядке: до его подсчёта.
   * Период сам по себе принадлежности не доказывает — именно поэтому две
   * пересекающиеся сборки складывали одни и те же деньги в «к перечислению»
   * дважды.
   */
  async captureCollectedShipments(
    runner: SqlRunner,
    invoiceId: string,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<void> {
    await runner.query(
      `UPDATE shipments s
          SET payout_invoice_id = $1
         FROM orders o
        WHERE o.id = s.order_id AND o.seller_id = $2
          AND s.payout_invoice_id IS NULL
          AND s.cod_collected_at >= $3::date AND s.cod_collected_at < ($4::date + 1)`,
      [invoiceId, sellerId, periodStart, periodEnd],
    );
  }

  /**
   * Строки счёта пересобираются целиком: при пересборке черновика
   * дозахваченное начисление попадает в ту же группу (услуга, единица, цена),
   * и правкой одной строки тут не обойтись.
   */
  async deleteLines(runner: SqlRunner, invoiceId: string): Promise<void> {
    await runner.query(`DELETE FROM invoice_lines WHERE invoice_id = $1`, [invoiceId]);
  }

  /**
   * Захваченные начисления, сгруппированные по (услуга, единица, цена).
   *
   * С комбинированными тарифами эта группировка сама даёт по строке на
   * составляющую: «паллета» и «перевес по кг» отличаются единицей, и оператор
   * видит в счёте именно то, из чего сумма сложилась. Отбор идёт по
   * `invoice_id`, то есть по ЗАХВАЧЕННОМУ, а не по периоду.
   */
  groupCapturedCharges(runner: SqlRunner, invoiceId: string): Promise<GroupedChargeRow[]> {
    return runner.query(
      `SELECT kind::text, unit::text, unit_price::text,
              SUM(quantity)::text AS quantity, SUM(amount)::text AS amount, currency
         FROM charges
        WHERE invoice_id = $1
        GROUP BY kind, unit, unit_price, currency
        ORDER BY kind, unit, unit_price`,
      [invoiceId],
    );
  }

  /**
   * Собранный платёж по ЗАХВАЧЕННЫМ отправлениям, а не по периоду: захват уже
   * произошёл, и только он отвечает на вопрос «чьи это деньги».
   *
   * Валюта берётся `MAX(COALESCE(отправление, заказ))`: у дочернего заказа
   * сплита валюта остаётся на родителе, а курьер собирает деньги по ребёнку.
   */
  capturedCodTotals(runner: SqlRunner, invoiceId: string): Promise<CapturedCodTotalsRow[]> {
    return runner.query(
      `SELECT COALESCE(SUM(s.cod_collected_amount), 0)::text AS total,
              MAX(COALESCE(s.currency, o.currency)) AS currency
         FROM shipments s JOIN orders o ON o.id = s.order_id
        WHERE s.payout_invoice_id = $1`,
      [invoiceId],
    );
  }

  /** Строка счёта. Услуга и единица приводятся к своим enum'ам явно. */
  async insertLine(
    runner: SqlRunner,
    invoiceId: string,
    kind: string,
    description: string,
    quantity: string,
    unit: string,
    unitPrice: string,
    amount: string,
  ): Promise<void> {
    await runner.query(
      `INSERT INTO invoice_lines (invoice_id, kind, description, quantity, unit, unit_price, amount)
         VALUES ($1, $2::charge_kind, $3, $4, $5::tariff_unit, $6, $7)`,
      [invoiceId, kind, description, quantity, unit, unitPrice, amount],
    );
  }

  /**
   * Итоги счёта складывает БД в `numeric`, а не JS в double.
   *
   * Слагаемые берутся из тех же захваченных строк, что и строки счёта, поэтому
   * промежуточное число в памяти тут не нужно вовсе — а деньги через float в
   * этом проекте недопустимы даже там, где сумма пока помещается точно.
   * «К перечислению» — собранный за селлера платёж минус наши услуги.
   */
  async applyTotals(runner: SqlRunner, invoiceId: string, currency: string): Promise<void> {
    await runner.query(
      `UPDATE invoices i
          SET currency = $2,
              services_total = t.services,
              cod_collected_total = t.cod,
              payout_total = t.cod - t.services
         FROM (SELECT COALESCE((SELECT SUM(amount) FROM charges WHERE invoice_id = $1), 0) AS services,
                      COALESCE((SELECT SUM(cod_collected_amount) FROM shipments
                                 WHERE payout_invoice_id = $1), 0) AS cod) t
        WHERE i.id = $1`,
      [invoiceId, currency],
    );
  }

  /** Начисления периода, не попавшие ни в один счёт. */
  uncapturedCharges(
    runner: SqlRunner,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<UncapturedChargeRow[]> {
    return runner.query(
      `SELECT kind::text, count(*)::text AS count, SUM(amount)::text AS amount, currency
         FROM charges
        WHERE seller_id = $1 AND invoice_id IS NULL
          AND occurred_at >= $2::date AND occurred_at < ($3::date + 1)
        GROUP BY kind, currency
        ORDER BY kind`,
      [sellerId, periodStart, periodEnd],
    );
  }

  /**
   * Счёт с пересекающимся периодом.
   *
   * `uq_invoices_period` покрывает только ТОЧНУЮ тройку (селлер, начало,
   * конец), поэтому пересечение приходится искать сравнением границ:
   * `period_start <= конец И period_end >= начало`. Отменённые не в счёт —
   * они период не занимают. Нужен один пример, поэтому `LIMIT 1`.
   */
  overlappingInvoices(
    runner: SqlRunner,
    sellerId: string,
    periodStart: string,
    periodEnd: string,
  ): Promise<OverlappingInvoiceRow[]> {
    return runner.query(
      `SELECT number, period_start::text AS period_start, period_end::text AS period_end
           FROM invoices
          WHERE seller_id = $1 AND status <> 'CANCELLED'
            AND period_start <= $3::date AND period_end >= $2::date
          ORDER BY period_start
          LIMIT 1`,
      [sellerId, periodStart, periodEnd],
    );
  }

  /**
   * Валюта тарифного плана селлера, иначе плана по умолчанию — тот же
   * `COALESCE` из двух подзапросов, что и при подборе правил тарифа.
   */
  planCurrency(runner: SqlRunner, sellerId: string): Promise<Array<{ currency: string }>> {
    return runner.query(
      `SELECT p.currency FROM tariff_plans p
        WHERE p.id = COALESCE(
                (SELECT tariff_plan_id FROM sellers WHERE id = $1),
                (SELECT id FROM tariff_plans WHERE is_default)
              )`,
      [sellerId],
    );
  }

  /** Выставление счёта: статус и отметка времени ставит БД. */
  async markIssued(runner: SqlRunner, invoiceId: string): Promise<void> {
    await runner.query(`UPDATE invoices SET status='ISSUED', issued_at=now() WHERE id=$1`, [
      invoiceId,
    ]);
  }

  /** Строки счёта для показа. Числа отдаются текстом: деньги не через float. */
  lines(runner: SqlRunner, invoiceId: string): Promise<Array<Record<string, unknown>>> {
    return runner.query(
      `SELECT id, kind::text, description, quantity::text, unit::text,
              unit_price::text, amount::text
         FROM invoice_lines WHERE invoice_id = $1 ORDER BY kind`,
      [invoiceId],
    );
  }

  /**
   * Сверка наложенного платежа: что обещали собрать против того, что собрали.
   *
   * Считает SQL — расхождение должно быть видно на всём массиве, а не на
   * выборке, дотянутой в память. Фильтр по селлеру приклеивается только когда
   * область видимости задана, и номер placeholder'а считается по длине массива
   * параметров: жёсткий `$3` в тексте оставил бы несвязанный параметр, когда
   * области нет.
   */
  codReconciliation(
    runner: SqlRunner,
    periodStart: string,
    periodEnd: string,
    scope: string | null,
  ): Promise<Array<Record<string, unknown>>> {
    const params: unknown[] = [periodStart, periodEnd];
    let sellerFilter = '';
    if (scope) {
      params.push(scope);
      sellerFilter = `AND o.seller_id = $${params.length}`;
    }

    return runner.query(
      `SELECT s.id, s.shipment_no, o.external_id, o.seller_id,
              COALESCE(s.cod_amount, 0)::text AS expected,
              s.cod_collected_amount::text AS collected,
              (COALESCE(s.cod_collected_amount, 0) - COALESCE(s.cod_amount, 0))::text AS difference,
              COALESCE(s.currency, o.currency, '—') AS currency,
              s.delivered_at
         FROM shipments s
         JOIN orders o ON o.id = s.order_id
        WHERE s.status = 'DELIVERED'
          AND s.delivered_at >= $1::date AND s.delivered_at < ($2::date + 1)
          AND (s.cod_amount IS NOT NULL OR s.cod_collected_amount IS NOT NULL)
          ${sellerFilter}
        ORDER BY s.delivered_at`,
      params,
    );
  }
}
