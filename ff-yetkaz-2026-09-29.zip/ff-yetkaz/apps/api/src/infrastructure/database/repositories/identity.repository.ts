import { Injectable } from '@nestjs/common';
import type { SqlRunner } from '../sql-runner';

/** Строка отдела вместе с числом сотрудников — ровно то, что отдаёт SQL. */
export interface DepartmentRow {
  id: string;
  code: string;
  name: string;
  description: string | null;
  is_active: boolean;
  member_count: number | string;
  created_at: Date | string;
}

/**
 * Сырой SQL доступа: отделы, пользователи, вход. Соединение не внедряется —
 * его передаёт вызывающий тем же значением, что стояло в исходном коде.
 */
@Injectable()
export class IdentityRepository {
  /**
   * Отделы со счётчиком сотрудников.
   *
   * Число сотрудников считаем в БД одним проходом — иначе N+1 на каждый отдел.
   * LEFT JOIN обязателен: отдел без единого сотрудника обязан остаться в
   * списке с нулём, а не пропасть с экрана.
   */
  listDepartmentsWithMemberCount(runner: SqlRunner): Promise<DepartmentRow[]> {
    return runner.query(
      `SELECT d.id, d.code, d.name, d.description, d.is_active, d.created_at,
              count(u.id)::int AS member_count
         FROM departments d
         LEFT JOIN users u ON u.department_id = d.id
        GROUP BY d.id
        ORDER BY d.is_active DESC, d.name ASC`,
    );
  }

  /** Один отдел с тем же счётчиком сотрудников, что и в списке. */
  findDepartmentWithMemberCount(runner: SqlRunner, id: string): Promise<DepartmentRow[]> {
    return runner.query(
      `SELECT d.id, d.code, d.name, d.description, d.is_active, d.created_at,
              count(u.id)::int AS member_count
         FROM departments d
         LEFT JOIN users u ON u.department_id = d.id
        WHERE d.id = $1
        GROUP BY d.id`,
      [id],
    );
  }

  /**
   * Сколько ДРУГИХ действующих администраторов есть в системе.
   *
   * Счёт отдаётся текстом (`::text`): драйвер приводит bigint к строке, и
   * вызывающий сравнивает именно со строкой — приведение сделано в запросе,
   * чтобы результат не зависел от настроек парсера типов.
   */
  countOtherActiveAdmins(runner: SqlRunner, userId: string): Promise<Array<{ others: string }>> {
    return runner.query(
      `SELECT count(*)::text AS others
         FROM users u
         JOIN user_roles r ON r.user_id = u.id AND r.role = 'ADMIN'
        WHERE u.is_active AND u.id <> $1`,
      [userId],
    );
  }

  /**
   * Неудачные попытки входа этой почты за окно блокировки.
   *
   * Считаем только те, что случились ПОСЛЕ последнего успешного входа: удачный
   * вход обнуляет счётчик, а стереть append-only аудит нельзя — поэтому отсечка
   * задаётся подзапросом `max(occurred_at)`, а `COALESCE(..., 'epoch')`
   * покрывает почту, которая не входила ни разу.
   */
  countRecentFailedLogins(
    runner: SqlRunner,
    email: string,
    windowMinutes: number,
  ): Promise<Array<{ fails: string }>> {
    return runner.query(
      `SELECT count(*)::text AS fails
         FROM audit_events
        WHERE action = 'LOGIN_FAILED'
          AND lower(after->>'email') = $1
          AND occurred_at > now() - ($2 * interval '1 minute')
          AND occurred_at > COALESCE(
                (SELECT max(occurred_at) FROM audit_events
                  WHERE action = 'LOGIN_SUCCESS' AND lower(after->>'email') = $1),
                'epoch')`,
      [email, windowMinutes],
    );
  }
}
