import 'reflect-metadata';
import { join } from 'node:path';
import { config as loadDotenv } from 'dotenv';
import { DataSource, type DataSourceOptions } from 'typeorm';
import { FF_ENTITIES } from './entities';

// Нужен только CLI TypeORM (migration:run/revert) — приложение читает env через ConfigModule.
loadDotenv({ path: join(__dirname, '..', '..', '..', '.env') });

export const dataSourceOptions: DataSourceOptions = {
  type: 'postgres',
  // Миграции ходят в БД НАПРЯМУЮ, мимо пула соединений, если дан отдельный адрес.
  // Пул (PgBouncer у Neon, Supabase и прочих) работает в transaction mode: он не
  // держит сессионное состояние, а на нём стоят advisory-локи и подготовленные
  // выражения, которыми пользуется накат схемы. Приложению пул нужен, миграциям —
  // вреден, поэтому адрес отдельный, а не общий.
  url: process.env.MIGRATION_DATABASE_URL || process.env.DATABASE_URL,
  entities: FF_ENTITIES,
  migrations: [join(__dirname, 'migrations', '*.{ts,js}')],
  migrationsTableName: 'ff_migrations',
  // Схему меняем только миграциями: автосинхронизация молча роняет данные.
  synchronize: false,
  logging: process.env.TYPEORM_LOGGING === '1' ? 'all' : ['error'],
};

export default new DataSource(dataSourceOptions);
