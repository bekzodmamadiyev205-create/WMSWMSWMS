import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

/**
 * Категория заказа — справочник. Удаления нет, только `is_active = false`:
 * на категорию ссылаются заказы прошлых периодов, и отчёт за март не должен
 * менять форму от того, что направление закрыли в августе.
 */
@Entity({ name: 'order_categories' })
export class OrderCategoryEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  code: string;

  @Column({ type: 'text' })
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string | null;

  /** Цвет метки `#RRGGBB` — форму проверяет CHECK таблицы. */
  @Column({ type: 'text', nullable: true })
  color: string | null;

  @Column({ type: 'int', name: 'sort_order', default: 100 })
  sortOrder: number;

  @Column({ type: 'boolean', name: 'is_active', default: true })
  isActive: boolean;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
