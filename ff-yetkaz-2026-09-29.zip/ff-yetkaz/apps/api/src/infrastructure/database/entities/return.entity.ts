import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import {
  RETURN_ITEM_CONDITIONS,
  RETURN_STATUSES,
  type ReturnItemCondition,
  type ReturnStatus,
} from '@ff/shared';
import { SellerEntity } from './seller.entity';
import { SkuEntity } from './sku.entity';
import { WarehouseEntity } from './warehouse.entity';

/**
 * Возврат (RMA) — самостоятельный документ, а не поле заказа.
 *
 * Возврат бывает без заказа: клиент вернул мимо нас, перепутанная посылка,
 * брак партии. Привяжи его к заказу жёстко — и такие случаи просто негде
 * будет учесть, а товар окажется на складе без основания.
 */
@Entity({ name: 'returns' })
export class ReturnEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Номер выдаёт последовательность БД (`RMA000000001`) — уникальность
   *  держит схема, а не договорённость в коде. */
  @Column({ type: 'text', name: 'return_no', insert: false, update: false })
  returnNo: string;

  @Column({ type: 'enum', enum: RETURN_STATUSES as unknown as string[], enumName: 'return_status' })
  status: ReturnStatus;

  @Column({ type: 'uuid', name: 'seller_id' })
  sellerId: string;

  @ManyToOne(() => SellerEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'seller_id' })
  seller?: SellerEntity;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @ManyToOne(() => WarehouseEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'warehouse_id' })
  warehouse?: WarehouseEntity;

  @Column({ type: 'uuid', name: 'order_id', nullable: true })
  orderId: string | null;

  @Column({ type: 'text' })
  reason: string;

  @Column({ type: 'text', nullable: true })
  comment: string | null;

  @Column({ type: 'uuid', name: 'created_by', nullable: true })
  createdBy: string | null;

  @OneToMany(() => ReturnItemEntity, (item) => item.return)
  items?: ReturnItemEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;

  @Column({ type: 'timestamptz', name: 'completed_at', nullable: true })
  completedAt: Date | null;
}

@Entity({ name: 'return_items' })
export class ReturnItemEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'return_id' })
  returnId: string;

  @ManyToOne(() => ReturnEntity, (rma) => rma.items, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'return_id' })
  return?: ReturnEntity;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @ManyToOne(() => SkuEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'sku_id' })
  sku?: SkuEntity;

  @Column({ type: 'int' })
  quantity: number;

  @Column({
    type: 'enum',
    enum: RETURN_ITEM_CONDITIONS as unknown as string[],
    enumName: 'return_condition',
    default: 'GOOD',
  })
  condition: ReturnItemCondition;

  /** Сколько из принятого уже вернулось в доступный остаток. Отдельно от
   *  `quantity`: брак на полку не возвращается, а раскладка бывает частичной. */
  @Column({ type: 'int', name: 'restocked_quantity', default: 0 })
  restockedQuantity: number;

  @Column({ type: 'uuid', name: 'bin_id', nullable: true })
  binId: string | null;
}

@Entity({ name: 'return_status_history' })
export class ReturnStatusEventEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: string;

  @Column({ type: 'uuid', name: 'return_id' })
  returnId: string;

  @Column({ type: 'text', name: 'from_status', nullable: true })
  fromStatus: string | null;

  @Column({ type: 'text', name: 'to_status' })
  toStatus: string;

  @Column({ type: 'uuid', name: 'actor_user_id', nullable: true })
  actorUserId: string | null;

  @Column({ type: 'text', nullable: true })
  comment: string | null;

  @CreateDateColumn({ type: 'timestamptz', name: 'occurred_at' })
  occurredAt: Date;
}
