import { AsnEntity, AsnLineEntity } from './asn.entity';
import { AuditEventEntity } from './audit-event.entity';
import {
  BillingProblemEntity,
  ChargeEntity,
  InvoiceEntity,
  InvoiceLineEntity,
  LedgerAccountEntity,
  LedgerEntryEntity,
  LedgerTransactionEntity,
  StorageSnapshotEntity,
  TariffPlanEntity,
  TariffRuleEntity,
} from './billing.entity';
import { BinLocationEntity } from './bin-location.entity';
import { AppSettingEntity, CarrierEntity } from './config.entity';
import { DepartmentEntity } from './department.entity';
import { IdempotencyKeyEntity } from './idempotency-key.entity';
import { LotEntity } from './lot.entity';
import {
  IntegrationOutboxEntity,
  ShipmentStatusEventEntity,
  WebhookDeliveryEntity,
} from './integration.entity';
import { FieldPermissionEntity } from './field-permission.entity';
import { OrderCategoryEntity } from './order-category.entity';
import { OrderStatusEventEntity } from './order-status-event.entity';
import { OrderEntity, OrderLineEntity } from './order.entity';
import { ReturnEntity, ReturnItemEntity, ReturnStatusEventEntity } from './return.entity';
import { PackageEntity, PackageItemEntity } from './package.entity';
import { PickTaskEntity, PickTaskLineEntity, PickTaskOrderEntity } from './pick-task.entity';
import { ReceiptEntity, ReceiptLineEntity } from './receipt.entity';
import { ShipmentEntity } from './shipment.entity';
import { ReservationEntity } from './reservation.entity';
import { SellerEntity } from './seller.entity';
import { SkuEntity } from './sku.entity';
import { SkuBarcodeEntity } from './sku-barcode.entity';
import { StockEntity } from './stock.entity';
import { StockMovementEntity } from './stock-movement.entity';
import { UserEntity } from './user.entity';
import { UserRoleEntity } from './user-role.entity';
import { WarehouseEntity } from './warehouse.entity';

export * from './asn.entity';
export * from './audit-event.entity';
export * from './billing.entity';
export * from './bin-location.entity';
export * from './config.entity';
export * from './department.entity';
export * from './idempotency-key.entity';
export * from './lot.entity';
export * from './integration.entity';
export * from './field-permission.entity';
export * from './order-category.entity';
export * from './order-status-event.entity';
export * from './order.entity';
export * from './return.entity';
export * from './package.entity';
export * from './pick-task.entity';
export * from './receipt.entity';
export * from './shipment.entity';
export * from './reservation.entity';
export * from './seller.entity';
export * from './sku.entity';
export * from './sku-barcode.entity';
export * from './stock.entity';
export * from './stock-movement.entity';
export * from './user.entity';
export * from './user-role.entity';
export * from './warehouse.entity';

export const FF_ENTITIES = [
  SellerEntity,
  UserEntity,
  UserRoleEntity,
  DepartmentEntity,
  AuditEventEntity,
  IdempotencyKeyEntity,
  WarehouseEntity,
  BinLocationEntity,
  SkuEntity,
  SkuBarcodeEntity,
  LotEntity,
  StockEntity,
  StockMovementEntity,
  ReservationEntity,
  AsnEntity,
  AsnLineEntity,
  ReceiptEntity,
  ReceiptLineEntity,
  OrderCategoryEntity,
  OrderEntity,
  OrderLineEntity,
  OrderStatusEventEntity,
  PickTaskEntity,
  PickTaskOrderEntity,
  PickTaskLineEntity,
  PackageEntity,
  PackageItemEntity,
  ShipmentEntity,
  AppSettingEntity,
  CarrierEntity,
  IntegrationOutboxEntity,
  WebhookDeliveryEntity,
  ShipmentStatusEventEntity,
  TariffPlanEntity,
  TariffRuleEntity,
  LedgerAccountEntity,
  LedgerTransactionEntity,
  LedgerEntryEntity,
  ChargeEntity,
  BillingProblemEntity,
  StorageSnapshotEntity,
  InvoiceEntity,
  InvoiceLineEntity,
  ReturnEntity,
  ReturnItemEntity,
  ReturnStatusEventEntity,
  FieldPermissionEntity,
];
