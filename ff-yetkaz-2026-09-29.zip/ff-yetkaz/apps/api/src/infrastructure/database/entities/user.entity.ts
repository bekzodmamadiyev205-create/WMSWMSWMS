import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { DepartmentEntity } from './department.entity';
import { SellerEntity } from './seller.entity';
import { UserRoleEntity } from './user-role.entity';

@Entity({ name: 'users' })
export class UserEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Хранится в нижнем регистре; уникальность гарантирует индекс по lower(email). */
  @Column({ type: 'text' })
  email: string;

  @Column({ type: 'text', name: 'password_hash', select: false })
  passwordHash: string;

  @Column({ type: 'text', name: 'full_name' })
  fullName: string;

  @Column({ type: 'boolean', name: 'is_active', default: true })
  isActive: boolean;

  /**
   * Заполнен ровно у пользователей с ролью SELLER — инвариант проверяет
   * отложенный constraint-триггер в БД, не только сервисный слой.
   */
  @Column({ type: 'uuid', name: 'seller_id', nullable: true })
  sellerId: string | null;

  @ManyToOne(() => SellerEntity, { nullable: true, onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'seller_id' })
  seller?: SellerEntity | null;

  /**
   * Организационный отдел сотрудника. Пусто = не назначен. Селлеру не ставится:
   * подразделения оператора его не касаются (у него изоляция по seller_id).
   */
  @Column({ type: 'uuid', name: 'department_id', nullable: true })
  departmentId: string | null;

  @ManyToOne(() => DepartmentEntity, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'department_id' })
  department?: DepartmentEntity | null;

  @OneToMany(() => UserRoleEntity, (userRole) => userRole.user, { cascade: ['insert'] })
  userRoles: UserRoleEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
