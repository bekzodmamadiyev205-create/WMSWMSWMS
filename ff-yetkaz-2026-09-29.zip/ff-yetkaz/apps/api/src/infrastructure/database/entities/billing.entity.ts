import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import {
  CHARGE_KINDS,
  INVOICE_STATUSES,
  LEDGER_SIDES,
  TARIFF_UNITS,
  type ChargeKind,
  type InvoiceStatus,
  type LedgerSide,
  type TariffUnit,
} from '@ff/shared';

@Entity({ name: 'tariff_plans' })
export class TariffPlanEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  code: string;

  @Column({ type: 'text' })
  name: string;

  @Column({ type: 'text' })
  currency: string;

  @Column({ type: 'boolean', name: 'is_default' })
  isDefault: boolean;

  @Column({ type: 'boolean', name: 'is_active' })
  isActive: boolean;

  @OneToMany(() => TariffRuleEntity, (rule) => rule.plan)
  rules?: TariffRuleEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}

@Entity({ name: 'tariff_rules' })
export class TariffRuleEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'plan_id' })
  planId: string;

  @ManyToOne(() => TariffPlanEntity, (plan) => plan.rules, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'plan_id' })
  plan?: TariffPlanEntity;

  @Column({ type: 'enum', enum: CHARGE_KINDS as unknown as string[], enumName: 'charge_kind' })
  kind: ChargeKind;

  @Column({ type: 'enum', enum: TARIFF_UNITS as unknown as string[], enumName: 'tariff_unit' })
  unit: TariffUnit;

  /**
   * Составляющая цены: `BASE`, `WEIGHT`, `HANDLING`… Внутри одной услуги
   * единица уникальна для своей составляющей — так «паллета + перевес по кг»
   * считаются обе, а «за заказ» и «за кг» в ОДНОЙ составляющей по-прежнему
   * конфликт (его отбивает триггер `trg_tariff_rules_single_unit`).
   */
  @Column({ type: 'text', default: 'BASE' })
  component: string;

  /** numeric приходит строкой — так и держим, без float. */
  @Column({ type: 'numeric', precision: 14, scale: 4 })
  price: string;

  @Column({ type: 'numeric', name: 'min_qty', precision: 14, scale: 3 })
  minQty: string;

  @Column({ type: 'date', name: 'effective_from' })
  effectiveFrom: string;

  @Column({ type: 'date', name: 'effective_to', nullable: true })
  effectiveTo: string | null;
}

@Entity({ name: 'ledger_accounts' })
export class LedgerAccountEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  code: string;

  @Column({ type: 'text' })
  name: string;

  @Column({ type: 'text' })
  kind: string;
}

@Entity({ name: 'ledger_transactions' })
export class LedgerTransactionEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'timestamptz', name: 'occurred_at' })
  occurredAt: Date;

  @Column({ type: 'text' })
  description: string;

  @Column({ type: 'uuid', name: 'seller_id', nullable: true })
  sellerId: string | null;

  @Column({ type: 'text', name: 'reference_type', nullable: true })
  referenceType: string | null;

  @Column({ type: 'text', name: 'reference_id', nullable: true })
  referenceId: string | null;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;
}

@Entity({ name: 'ledger_entries' })
export class LedgerEntryEntity {
  @PrimaryGeneratedColumn('identity', { type: 'bigint' })
  id: string;

  @Column({ type: 'uuid', name: 'transaction_id' })
  transactionId: string;

  @Column({ type: 'uuid', name: 'account_id' })
  accountId: string;

  @Column({ type: 'uuid', name: 'seller_id', nullable: true })
  sellerId: string | null;

  @Column({ type: 'enum', enum: LEDGER_SIDES as unknown as string[], enumName: 'ledger_side' })
  side: LedgerSide;

  @Column({ type: 'numeric', precision: 14, scale: 2 })
  amount: string;

  @Column({ type: 'text' })
  currency: string;
}

@Entity({ name: 'charges' })
export class ChargeEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'seller_id' })
  sellerId: string;

  @Column({ type: 'enum', enum: CHARGE_KINDS as unknown as string[], enumName: 'charge_kind' })
  kind: ChargeKind;

  @Column({ type: 'enum', enum: TARIFF_UNITS as unknown as string[], enumName: 'tariff_unit' })
  unit: TariffUnit;

  @Column({ type: 'numeric', precision: 14, scale: 3 })
  quantity: string;

  @Column({ type: 'numeric', name: 'unit_price', precision: 14, scale: 4 })
  unitPrice: string;

  @Column({ type: 'numeric', precision: 14, scale: 2 })
  amount: string;

  @Column({ type: 'text' })
  currency: string;

  @Column({ type: 'timestamptz', name: 'occurred_at' })
  occurredAt: Date;

  @Column({ type: 'uuid', name: 'order_id', nullable: true })
  orderId: string | null;

  @Column({ type: 'uuid', name: 'shipment_id', nullable: true })
  shipmentId: string | null;

  /** Ключ идемпотентности: повторный прогон начисления не удваивает счёт. */
  @Column({ type: 'text', name: 'source_key' })
  sourceKey: string;

  @Column({ type: 'uuid', name: 'tariff_rule_id', nullable: true })
  tariffRuleId: string | null;

  @Column({ type: 'uuid', name: 'transaction_id', nullable: true })
  transactionId: string | null;

  @Column({ type: 'uuid', name: 'invoice_id', nullable: true })
  invoiceId: string | null;
}

@Entity({ name: 'billing_problems' })
export class BillingProblemEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'seller_id', nullable: true })
  sellerId: string | null;

  @Column({ type: 'enum', enum: CHARGE_KINDS as unknown as string[], enumName: 'charge_kind' })
  kind: ChargeKind;

  @Column({ type: 'text', name: 'source_key' })
  sourceKey: string;

  @Column({ type: 'text' })
  reason: string;

  @Column({ type: 'timestamptz', name: 'occurred_at' })
  occurredAt: Date;

  @Column({ type: 'timestamptz', name: 'resolved_at', nullable: true })
  resolvedAt: Date | null;
}

@Entity({ name: 'storage_snapshots' })
export class StorageSnapshotEntity {
  @PrimaryColumn({ type: 'date', name: 'snapshot_date' })
  snapshotDate: string;

  @PrimaryColumn({ type: 'uuid', name: 'seller_id' })
  sellerId: string;

  @Column({ type: 'int' })
  units: number;

  @Column({ type: 'numeric', name: 'volume_mm3', precision: 24, scale: 0 })
  volumeMm3: string;

  /**
   * Тара на срезе: сколько коробок и паллет занимал остаток в этот день.
   * Дробные — 2.4 паллеты это реальная величина, а округление вверх на каждом
   * дне превратилось бы за месяц в заметную приписку в счёте.
   */
  @Column({ type: 'numeric', precision: 14, scale: 3, default: 0 })
  boxes: string;

  @Column({ type: 'numeric', precision: 14, scale: 3, default: 0 })
  pallets: string;
}

@Entity({ name: 'invoices' })
export class InvoiceEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Номер выдаёт DEFAULT последовательности — приложение его не назначает. */
  @Column({ type: 'text', insert: false, update: false })
  number: string;

  @Column({ type: 'uuid', name: 'seller_id' })
  sellerId: string;

  @Column({ type: 'date', name: 'period_start' })
  periodStart: string;

  @Column({ type: 'date', name: 'period_end' })
  periodEnd: string;

  @Column({ type: 'text' })
  currency: string;

  @Column({ type: 'numeric', name: 'services_total', precision: 14, scale: 2 })
  servicesTotal: string;

  @Column({ type: 'numeric', name: 'cod_collected_total', precision: 14, scale: 2 })
  codCollectedTotal: string;

  @Column({ type: 'numeric', name: 'payout_total', precision: 14, scale: 2 })
  payoutTotal: string;

  @Column({
    type: 'enum',
    enum: INVOICE_STATUSES as unknown as string[],
    enumName: 'invoice_status',
  })
  status: InvoiceStatus;

  @Column({ type: 'timestamptz', name: 'issued_at', nullable: true })
  issuedAt: Date | null;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;
}

@Entity({ name: 'invoice_lines' })
export class InvoiceLineEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'invoice_id' })
  invoiceId: string;

  @Column({ type: 'enum', enum: CHARGE_KINDS as unknown as string[], enumName: 'charge_kind' })
  kind: ChargeKind;

  @Column({ type: 'text' })
  description: string;

  @Column({ type: 'numeric', precision: 14, scale: 3 })
  quantity: string;

  @Column({ type: 'enum', enum: TARIFF_UNITS as unknown as string[], enumName: 'tariff_unit' })
  unit: TariffUnit;

  @Column({ type: 'numeric', name: 'unit_price', precision: 14, scale: 4 })
  unitPrice: string;

  @Column({ type: 'numeric', precision: 14, scale: 2 })
  amount: string;
}
