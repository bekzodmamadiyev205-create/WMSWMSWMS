import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

export type IdempotencyStatus = 'IN_PROGRESS' | 'COMPLETED';

/**
 * Дедупликация write-запросов по заголовку `Idempotency-Key`.
 *
 * `request_hash` хранится, чтобы поймать переиспользование ключа с другим телом:
 * это ошибка клиента, и молча вернуть ему чужой ответ хуже, чем ответить 409.
 */
@Entity({ name: 'idempotency_keys' })
export class IdempotencyKeyEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: string;

  @Column({ type: 'text' })
  key: string;

  /** Метод + маршрут: один и тот же ключ на разных ручках не конфликтует. */
  @Column({ type: 'text' })
  endpoint: string;

  @Column({ type: 'text', name: 'request_hash' })
  requestHash: string;

  @Column({ type: 'text' })
  status: IdempotencyStatus;

  @Column({ type: 'int', name: 'response_status', nullable: true })
  responseStatus: number | null;

  @Column({ type: 'jsonb', name: 'response_body', nullable: true })
  responseBody: unknown | null;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @Column({ type: 'timestamptz', name: 'completed_at', nullable: true })
  completedAt: Date | null;

  @Column({ type: 'timestamptz', name: 'expires_at' })
  expiresAt: Date;
}
