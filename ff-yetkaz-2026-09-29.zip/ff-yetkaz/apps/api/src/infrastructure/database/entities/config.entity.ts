import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { SETTING_VALUE_TYPES, type SettingValueType } from '@ff/shared';

@Entity({ name: 'app_settings' })
export class AppSettingEntity {
  @PrimaryColumn({ type: 'text' })
  key: string;

  /** jsonb: тип значения проверяет CHECK-ограничение таблицы. */
  @Column({ type: 'jsonb' })
  value: unknown;

  @Column({
    type: 'enum',
    enum: SETTING_VALUE_TYPES as unknown as string[],
    enumName: 'setting_value_type',
    name: 'value_type',
  })
  valueType: SettingValueType;

  @Column({ type: 'text' })
  description: string;

  @Column({ type: 'uuid', name: 'updated_by', nullable: true })
  updatedBy: string | null;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}

/**
 * Перевозчик. `secret_env_key` — имя переменной окружения, а не сам ключ:
 * дамп базы не должен утаскивать за собой доступы к чужой системе.
 */
@Entity({ name: 'carriers' })
export class CarrierEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  code: string;

  @Column({ type: 'text' })
  name: string;

  @Column({ type: 'text', name: 'base_url' })
  baseUrl: string;

  @Column({ type: 'text', name: 'handoff_path' })
  handoffPath: string;

  @Column({ type: 'int', name: 'timeout_ms' })
  timeoutMs: number;

  @Column({ type: 'text', name: 'secret_env_key' })
  secretEnvKey: string;

  @Column({ type: 'boolean', name: 'is_active' })
  isActive: boolean;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
