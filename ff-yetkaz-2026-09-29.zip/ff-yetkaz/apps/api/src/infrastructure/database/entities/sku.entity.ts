import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { SellerEntity } from './seller.entity';
import { SkuBarcodeEntity } from './sku-barcode.entity';

@Entity({ name: 'skus' })
export class SkuEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'seller_id' })
  sellerId: string;

  @ManyToOne(() => SellerEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'seller_id' })
  seller?: SellerEntity;

  /** Артикул селлера. Уникален в пределах селлера, регистронезависимо. */
  @Column({ type: 'text', name: 'sku_code' })
  skuCode: string;

  @Column({ type: 'text' })
  name: string;

  @Column({ type: 'int', name: 'length_mm', nullable: true })
  lengthMm: number | null;

  @Column({ type: 'int', name: 'width_mm', nullable: true })
  widthMm: number | null;

  @Column({ type: 'int', name: 'height_mm', nullable: true })
  heightMm: number | null;

  @Column({ type: 'int', name: 'weight_g', nullable: true })
  weightG: number | null;

  /** GENERATED-колонка: считает БД, приложение её не пишет. */
  @Column({ type: 'bigint', name: 'volume_mm3', nullable: true, insert: false, update: false })
  volumeMm3: string | null;

  /**
   * Вложенность тары. Нужна для тарификации «за коробку» и «за паллету»:
   * склад считает штуки, поэтому число коробок ВЫЧИСЛЯЕТСЯ, а не вводится —
   * иначе счёт неизбежно разойдётся с фактическим движением остатка.
   * Пусто = у товара нет коробочной нормы, тарифы по таре к нему неприменимы.
   */
  @Column({ type: 'int', name: 'units_per_box', nullable: true })
  unitsPerBox: number | null;

  @Column({ type: 'int', name: 'units_per_pallet', nullable: true })
  unitsPerPallet: number | null;

  @Column({ type: 'boolean', name: 'is_lot_tracked', default: false })
  isLotTracked: boolean;

  /**
   * Учёт срока годности. Сама дата хранится на партии — здесь только политика,
   * иначе FEFO при выдаче не построить.
   */
  @Column({ type: 'boolean', name: 'is_expiry_tracked', default: false })
  isExpiryTracked: boolean;

  @Column({ type: 'int', name: 'shelf_life_days', nullable: true })
  shelfLifeDays: number | null;

  @Column({ type: 'boolean', name: 'is_active', default: true })
  isActive: boolean;

  @OneToMany(() => SkuBarcodeEntity, (barcode) => barcode.sku)
  barcodes?: SkuBarcodeEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
