import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { INVENTORY_UNIT_STATUSES, type InventoryUnitStatus } from '@ff/shared';

/**
 * Количественный остаток: строка = SKU × склад × ячейка × партия × статус.
 * Это проекция журнала `stock_movements`, а не источник правды — напрямую
 * не правится, только через InventoryService.
 */
@Entity({ name: 'stock' })
export class StockEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @Column({ type: 'uuid', name: 'bin_id' })
  binId: string;

  @Column({ type: 'uuid', name: 'lot_id', nullable: true })
  lotId: string | null;

  @Column({
    type: 'enum',
    enum: INVENTORY_UNIT_STATUSES as unknown as string[],
    enumName: 'inventory_status',
  })
  status: InventoryUnitStatus;

  @Column({ type: 'int' })
  quantity: number;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
