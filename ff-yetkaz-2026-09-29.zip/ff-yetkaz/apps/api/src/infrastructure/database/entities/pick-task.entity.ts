import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import {
  PICK_LINE_STATUSES,
  PICK_TASK_KINDS,
  PICK_TASK_STATUSES,
  type PickLineStatus,
  type PickTaskKind,
  type PickTaskStatus,
} from '@ff/shared';

@Entity({ name: 'pick_tasks' })
export class PickTaskEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @Column({ type: 'enum', enum: PICK_TASK_KINDS as unknown as string[], enumName: 'pick_task_kind' })
  kind: PickTaskKind;

  @Column({
    type: 'enum',
    enum: PICK_TASK_STATUSES as unknown as string[],
    enumName: 'pick_task_status',
  })
  status: PickTaskStatus;

  @Column({ type: 'uuid', name: 'assignee_user_id', nullable: true })
  assigneeUserId: string | null;

  @Column({ type: 'uuid', name: 'created_by', nullable: true })
  createdBy: string | null;

  @Column({ type: 'timestamptz', name: 'started_at', nullable: true })
  startedAt: Date | null;

  @Column({ type: 'timestamptz', name: 'completed_at', nullable: true })
  completedAt: Date | null;

  @OneToMany(() => PickTaskLineEntity, (line) => line.task)
  lines?: PickTaskLineEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}

@Entity({ name: 'pick_task_orders' })
export class PickTaskOrderEntity {
  @PrimaryColumn({ type: 'uuid', name: 'task_id' })
  taskId: string;

  @PrimaryColumn({ type: 'uuid', name: 'order_id' })
  orderId: string;
}

@Entity({ name: 'pick_task_lines' })
export class PickTaskLineEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'task_id' })
  taskId: string;

  @ManyToOne(() => PickTaskEntity, (task) => task.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'task_id' })
  task?: PickTaskEntity;

  @Column({ type: 'uuid', name: 'order_id' })
  orderId: string;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @Column({ type: 'uuid', name: 'bin_id' })
  binId: string;

  @Column({ type: 'uuid', name: 'lot_id', nullable: true })
  lotId: string | null;

  /** Резерв, из которого выросла строка: по мере сборки его надо гасить. */
  @Column({ type: 'uuid', name: 'reservation_id' })
  reservationId: string;

  @Column({ type: 'int', name: 'qty_requested' })
  qtyRequested: number;

  @Column({ type: 'int', name: 'qty_picked', default: 0 })
  qtyPicked: number;

  @Column({
    type: 'enum',
    enum: PICK_LINE_STATUSES as unknown as string[],
    enumName: 'pick_line_status',
  })
  status: PickLineStatus;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
