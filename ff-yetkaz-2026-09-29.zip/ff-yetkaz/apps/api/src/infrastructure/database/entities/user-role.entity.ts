import { Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { ROLES, type Role } from '@ff/shared';
import { UserEntity } from './user.entity';

/**
 * Роли — таблица, а не колонка: складской сотрудник часто одновременно
 * и PICKER, и PACKER, и WAREHOUSE_OPERATOR.
 */
@Entity({ name: 'user_roles' })
export class UserRoleEntity {
  @PrimaryColumn({ type: 'uuid', name: 'user_id' })
  userId: string;

  @PrimaryColumn({ type: 'enum', enum: ROLES as unknown as string[], enumName: 'ff_role' })
  role: Role;

  @ManyToOne(() => UserEntity, (user) => user.userRoles, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: UserEntity;
}
