import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

/**
 * Трек статусов заказа. Append-only — UPDATE/DELETE запрещены триггером:
 * история переходов, которую можно переписать, ничего не доказывает.
 *
 * Статусы здесь `text`, а не enum: журнал обязан пережить любую будущую правку
 * перечисления, включая переименование значения.
 */
@Entity({ name: 'order_status_history' })
export class OrderStatusEventEntity {
  /** bigint приходит из драйвера строкой — так и держим. */
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: string;

  @Column({ type: 'uuid', name: 'order_id' })
  orderId: string;

  @Column({ type: 'text', name: 'from_status', nullable: true })
  fromStatus: string | null;

  @Column({ type: 'text', name: 'to_status' })
  toStatus: string;

  /** Кто инициировал: роль пользователя, `carrier:<code>` или `system`. */
  @Column({ type: 'text', default: 'system' })
  source: string;

  @Column({ type: 'uuid', name: 'actor_user_id', nullable: true })
  actorUserId: string | null;

  @Column({ type: 'text', nullable: true })
  comment: string | null;

  @CreateDateColumn({ type: 'timestamptz', name: 'occurred_at' })
  occurredAt: Date;
}
