import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import {
  RECEIPT_LINE_STATUSES,
  RECEIPT_STATUSES,
  type ReceiptLineStatus,
  type ReceiptStatus,
} from '@ff/shared';
import { AsnEntity } from './asn.entity';

/** Фактическая приёмка по заявке. На один ASN может быть несколько приёмок. */
@Entity({ name: 'receipts' })
export class ReceiptEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'asn_id' })
  asnId: string;

  @ManyToOne(() => AsnEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'asn_id' })
  asn?: AsnEntity;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @Column({
    type: 'enum',
    enum: RECEIPT_STATUSES as unknown as string[],
    enumName: 'receipt_status',
  })
  status: ReceiptStatus;

  @Column({ type: 'uuid', name: 'received_by', nullable: true })
  receivedBy: string | null;

  @Column({ type: 'timestamptz', name: 'started_at' })
  startedAt: Date;

  @Column({ type: 'timestamptz', name: 'completed_at', nullable: true })
  completedAt: Date | null;

  @OneToMany(() => ReceiptLineEntity, (line) => line.receipt)
  lines?: ReceiptLineEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}

@Entity({ name: 'receipt_lines' })
export class ReceiptLineEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'receipt_id' })
  receiptId: string;

  @ManyToOne(() => ReceiptEntity, (receipt) => receipt.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'receipt_id' })
  receipt?: ReceiptEntity;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @Column({ type: 'uuid', name: 'lot_id', nullable: true })
  lotId: string | null;

  @Column({ type: 'int', name: 'qty_received' })
  qtyReceived: number;

  @Column({ type: 'int', name: 'qty_ok', default: 0 })
  qtyOk: number;

  @Column({ type: 'int', name: 'qty_damaged', default: 0 })
  qtyDamaged: number;

  /** Ячейка хранения; заполняется на put-away. */
  @Column({ type: 'uuid', name: 'bin_id', nullable: true })
  binId: string | null;

  @Column({
    type: 'enum',
    enum: RECEIPT_LINE_STATUSES as unknown as string[],
    enumName: 'receipt_line_status',
  })
  status: ReceiptLineStatus;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
