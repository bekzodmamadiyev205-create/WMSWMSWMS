import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { SHIPMENT_STATUSES, type ShipmentStatus } from '@ff/shared';

/**
 * Отправление — граница ответственности FF: до него всё внутри склада, после
 * него заказ ведёт iPost GO. Номер выдаёт последовательность БД (DEFAULT),
 * поэтому колонка не пишется приложением.
 */
@Entity({ name: 'shipments' })
export class ShipmentEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'order_id' })
  orderId: string;

  @Column({ type: 'uuid', name: 'package_id' })
  packageId: string;

  @Column({ type: 'text', name: 'shipment_no', insert: false, update: false })
  shipmentNo: string;

  @Column({
    type: 'enum',
    enum: SHIPMENT_STATUSES as unknown as string[],
    enumName: 'shipment_status',
  })
  status: ShipmentStatus;

  @Column({ type: 'text' })
  carrier: string;

  /** Трек перевозчика: появляется при передаче в iPost GO. */
  @Column({ type: 'text', name: 'tracking_no', nullable: true })
  trackingNo: string | null;

  @Column({ type: 'int', name: 'weight_g' })
  weightG: number;

  /** numeric приходит из драйвера строкой — так и держим, без float. */
  @Column({ type: 'numeric', name: 'cod_amount', precision: 14, scale: 2, nullable: true })
  codAmount: string | null;

  @Column({ type: 'text', nullable: true })
  currency: string | null;

  @Column({ type: 'timestamptz', name: 'handed_over_at', nullable: true })
  handedOverAt: Date | null;

  @Column({ type: 'timestamptz', name: 'cancelled_at', nullable: true })
  cancelledAt: Date | null;

  @Column({ type: 'timestamptz', name: 'delivered_at', nullable: true })
  deliveredAt: Date | null;

  // --- подтверждение доставки (POD) ---------------------------------------
  @Column({ type: 'text', name: 'pod_recipient_name', nullable: true })
  podRecipientName: string | null;

  @Column({ type: 'text', name: 'pod_signature_url', nullable: true })
  podSignatureUrl: string | null;

  @Column({ type: 'text', name: 'pod_photo_url', nullable: true })
  podPhotoUrl: string | null;

  /** Сколько курьер реально собрал: сверяется с `cod_amount` в биллинге. */
  @Column({
    type: 'numeric',
    name: 'cod_collected_amount',
    precision: 14,
    scale: 2,
    nullable: true,
  })
  codCollectedAmount: string | null;

  @Column({ type: 'timestamptz', name: 'cod_collected_at', nullable: true })
  codCollectedAt: Date | null;

  @Column({ type: 'text', name: 'failure_reason', nullable: true })
  failureReason: string | null;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
