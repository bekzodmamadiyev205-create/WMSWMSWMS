import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { PACKAGE_STATUSES, type PackageStatus } from '@ff/shared';

@Entity({ name: 'packages' })
export class PackageEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'order_id' })
  orderId: string;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @Column({
    type: 'enum',
    enum: PACKAGE_STATUSES as unknown as string[],
    enumName: 'package_status',
  })
  status: PackageStatus;

  /** Сумма весов позиций из справочника; null — вес есть не у всех SKU. */
  @Column({ type: 'int', name: 'expected_weight_g', nullable: true })
  expectedWeightG: number | null;

  @Column({ type: 'int', name: 'actual_weight_g', nullable: true })
  actualWeightG: number | null;

  @Column({ type: 'boolean', name: 'weight_mismatch', default: false })
  weightMismatch: boolean;

  @Column({ type: 'int', name: 'length_mm', nullable: true })
  lengthMm: number | null;

  @Column({ type: 'int', name: 'width_mm', nullable: true })
  widthMm: number | null;

  @Column({ type: 'int', name: 'height_mm', nullable: true })
  heightMm: number | null;

  @Column({ type: 'uuid', name: 'packer_user_id', nullable: true })
  packerUserId: string | null;

  @Column({ type: 'text', nullable: true })
  comment: string | null;

  @Column({ type: 'timestamptz', name: 'started_at' })
  startedAt: Date;

  @Column({ type: 'timestamptz', name: 'packed_at', nullable: true })
  packedAt: Date | null;

  @Column({ type: 'timestamptz', name: 'cancelled_at', nullable: true })
  cancelledAt: Date | null;

  @OneToMany(() => PackageItemEntity, (item) => item.package)
  items?: PackageItemEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}

@Entity({ name: 'package_items' })
export class PackageItemEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'package_id' })
  packageId: string;

  @ManyToOne(() => PackageEntity, (pkg) => pkg.items, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'package_id' })
  package?: PackageEntity;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @Column({ type: 'uuid', name: 'lot_id', nullable: true })
  lotId: string | null;

  /** Ячейка зоны упаковки, из которой позиция списывается при закрытии коробки. */
  @Column({ type: 'uuid', name: 'bin_id' })
  binId: string;

  @Column({ type: 'int' })
  quantity: number;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;
}
