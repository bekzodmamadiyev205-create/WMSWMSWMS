import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';
import type { ReservationStatus } from '@ff/shared';

/**
 * Резерв под владельца. Одна строка = один срез остатка (ячейка + партия),
 * поэтому снятие резерва возвращает количество ровно туда, откуда взяло.
 *
 * `owner_type`/`owner_id` обобщённые: модуль Orders появится следующим этапом
 * и подставит сюда свой идентификатор, не меняя Inventory.
 */
@Entity({ name: 'reservations' })
export class ReservationEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text', name: 'owner_type' })
  ownerType: string;

  @Column({ type: 'text', name: 'owner_id' })
  ownerId: string;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @Column({ type: 'uuid', name: 'bin_id' })
  binId: string;

  @Column({ type: 'uuid', name: 'lot_id', nullable: true })
  lotId: string | null;

  @Column({ type: 'int' })
  quantity: number;

  @Column({ type: 'text' })
  status: ReservationStatus;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @Column({ type: 'timestamptz', name: 'released_at', nullable: true })
  releasedAt: Date | null;
}
