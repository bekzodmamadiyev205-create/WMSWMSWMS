import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ASN_STATUSES, type AsnStatus } from '@ff/shared';
import { SellerEntity } from './seller.entity';
import { SkuEntity } from './sku.entity';
import { WarehouseEntity } from './warehouse.entity';

/** Заявка селлера на поставку. Заводит оператор (решение PM). */
@Entity({ name: 'asns' })
export class AsnEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'seller_id' })
  sellerId: string;

  @ManyToOne(() => SellerEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'seller_id' })
  seller?: SellerEntity;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @ManyToOne(() => WarehouseEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'warehouse_id' })
  warehouse?: WarehouseEntity;

  @Column({ type: 'text', name: 'external_ref', nullable: true })
  externalRef: string | null;

  @Column({ type: 'enum', enum: ASN_STATUSES as unknown as string[], enumName: 'asn_status' })
  status: AsnStatus;

  @Column({ type: 'timestamptz', name: 'expected_at', nullable: true })
  expectedAt: Date | null;

  @Column({ type: 'boolean', name: 'has_discrepancy', default: false })
  hasDiscrepancy: boolean;

  @Column({ type: 'uuid', name: 'created_by', nullable: true })
  createdBy: string | null;

  @OneToMany(() => AsnLineEntity, (line) => line.asn)
  lines?: AsnLineEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}

@Entity({ name: 'asn_lines' })
export class AsnLineEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'asn_id' })
  asnId: string;

  @ManyToOne(() => AsnEntity, (asn) => asn.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'asn_id' })
  asn?: AsnEntity;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @ManyToOne(() => SkuEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'sku_id' })
  sku?: SkuEntity;

  @Column({ type: 'int', name: 'expected_qty' })
  expectedQty: number;
}
