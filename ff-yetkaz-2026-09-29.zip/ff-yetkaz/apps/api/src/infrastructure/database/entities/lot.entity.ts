import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { SkuEntity } from './sku.entity';

/** Партия товара. Здесь живёт фактическая дата истечения — у SKU только политика учёта. */
@Entity({ name: 'lots' })
export class LotEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @ManyToOne(() => SkuEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'sku_id' })
  sku?: SkuEntity;

  @Column({ type: 'text', name: 'lot_code' })
  lotCode: string;

  /** `date` без времени — приходит из драйвера строкой 'YYYY-MM-DD'. */
  @Column({ type: 'date', name: 'expiry_date', nullable: true })
  expiryDate: string | null;

  @Column({ type: 'timestamptz', name: 'received_at' })
  receivedAt: Date;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;
}
