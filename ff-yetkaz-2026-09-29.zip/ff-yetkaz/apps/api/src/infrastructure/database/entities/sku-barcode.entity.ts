import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { BARCODE_KINDS, type BarcodeKind } from '@ff/shared';
import { SkuEntity } from './sku.entity';

@Entity({ name: 'sku_barcodes' })
export class SkuBarcodeEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @ManyToOne(() => SkuEntity, (sku) => sku.barcodes, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'sku_id' })
  sku?: SkuEntity;

  /** Уникален глобально (решение PM) — скан однозначно определяет SKU. */
  @Column({ type: 'text' })
  barcode: string;

  @Column({ type: 'enum', enum: BARCODE_KINDS as unknown as string[], enumName: 'barcode_kind' })
  kind: BarcodeKind;

  @Column({ type: 'boolean', name: 'is_primary', default: false })
  isPrimary: boolean;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;
}
