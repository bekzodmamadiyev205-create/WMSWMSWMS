import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';
import {
  INVENTORY_UNIT_STATUSES,
  MOVEMENT_REASONS,
  type InventoryUnitStatus,
  type MovementReason,
} from '@ff/shared';

/**
 * Append-only журнал движений остатка. UPDATE/DELETE/TRUNCATE запрещены триггером.
 * Приход — только «куда», списание — только «откуда», перемещение — обе стороны.
 */
@Entity({ name: 'stock_movements' })
export class StockMovementEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: string;

  @CreateDateColumn({ type: 'timestamptz', name: 'occurred_at' })
  occurredAt: Date;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @Column({ type: 'uuid', name: 'lot_id', nullable: true })
  lotId: string | null;

  @Column({ type: 'uuid', name: 'from_bin_id', nullable: true })
  fromBinId: string | null;

  @Column({
    type: 'enum',
    enum: INVENTORY_UNIT_STATUSES as unknown as string[],
    enumName: 'inventory_status',
    name: 'from_status',
    nullable: true,
  })
  fromStatus: InventoryUnitStatus | null;

  @Column({ type: 'uuid', name: 'to_bin_id', nullable: true })
  toBinId: string | null;

  @Column({
    type: 'enum',
    enum: INVENTORY_UNIT_STATUSES as unknown as string[],
    enumName: 'inventory_status',
    name: 'to_status',
    nullable: true,
  })
  toStatus: InventoryUnitStatus | null;

  @Column({ type: 'int' })
  quantity: number;

  @Column({
    type: 'enum',
    enum: MOVEMENT_REASONS as unknown as string[],
    enumName: 'movement_reason',
  })
  reason: MovementReason;

  @Column({ type: 'text', name: 'reference_type', nullable: true })
  referenceType: string | null;

  @Column({ type: 'text', name: 'reference_id', nullable: true })
  referenceId: string | null;

  @Column({ type: 'text', nullable: true })
  comment: string | null;

  @Column({ type: 'uuid', name: 'actor_user_id', nullable: true })
  actorUserId: string | null;

  @Column({ type: 'text', name: 'correlation_id', nullable: true })
  correlationId: string | null;
}
