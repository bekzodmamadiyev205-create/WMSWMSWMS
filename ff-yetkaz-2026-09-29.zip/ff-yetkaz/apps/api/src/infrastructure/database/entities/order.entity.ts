import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ORDER_STATUSES, type OrderStatus } from '@ff/shared';
import { OrderCategoryEntity } from './order-category.entity';
import { SellerEntity } from './seller.entity';
import { SkuEntity } from './sku.entity';

@Entity({ name: 'orders' })
export class OrderEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'seller_id' })
  sellerId: string;

  @ManyToOne(() => SellerEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'seller_id' })
  seller?: SellerEntity;

  @Column({ type: 'text' })
  channel: string;

  @Column({ type: 'text', name: 'external_id' })
  externalId: string;

  /**
   * Наш код заказа = штрихкод: FF-YES0000001… Выдаёт БД (`order_code_seq`),
   * приложение его не назначает (оттого insert/update: false). Клиентский номер
   * заказа — это `externalId`, его придумывает не FF.
   */
  @Column({ type: 'text', name: 'order_code', insert: false, update: false })
  orderCode: string;

  @Column({ type: 'enum', enum: ORDER_STATUSES as unknown as string[], enumName: 'order_status' })
  status: OrderStatus;

  @Column({ type: 'uuid', name: 'warehouse_id', nullable: true })
  warehouseId: string | null;

  @Column({ type: 'uuid', name: 'parent_order_id', nullable: true })
  parentOrderId: string | null;

  @Column({ type: 'boolean', name: 'is_split', default: false })
  isSplit: boolean;

  @Column({ type: 'boolean', name: 'has_shortage', default: false })
  hasShortage: boolean;

  @Column({ type: 'text', name: 'recipient_name' })
  recipientName: string;

  @Column({ type: 'text', name: 'recipient_phone' })
  recipientPhone: string;

  @Column({ type: 'text' })
  address: string;

  @Column({ type: 'text', nullable: true })
  region: string | null;

  /** numeric приходит из драйвера строкой — так и держим, без float. */
  @Column({ type: 'numeric', name: 'cod_amount', precision: 14, scale: 2, nullable: true })
  codAmount: string | null;

  @Column({ type: 'text', nullable: true })
  currency: string | null;

  /** Заявленный вес отправления, кг. numeric приходит строкой — так и держим. */
  @Column({ type: 'numeric', name: 'weight_kg', precision: 10, scale: 3, nullable: true })
  weightKg: string | null;

  /** Категория заказа (справочник `order_categories`). Мягкая связь: удаление
   *  категории обнуляет ссылку, но не трогает заказ. */
  @Column({ type: 'uuid', name: 'category_id', nullable: true })
  categoryId: string | null;

  @ManyToOne(() => OrderCategoryEntity, { onDelete: 'SET NULL' })
  @JoinColumn({ name: 'category_id' })
  category?: OrderCategoryEntity | null;

  /** Когда коробку выдали со склада («Расходный»). */
  @Column({ type: 'timestamptz', name: 'dispatched_at', nullable: true })
  dispatchedAt: Date | null;

  @Column({ type: 'uuid', name: 'created_by', nullable: true })
  createdBy: string | null;

  @OneToMany(() => OrderLineEntity, (line) => line.order)
  lines?: OrderLineEntity[];

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}

@Entity({ name: 'order_lines' })
export class OrderLineEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'order_id' })
  orderId: string;

  @ManyToOne(() => OrderEntity, (order) => order.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'order_id' })
  order?: OrderEntity;

  @Column({ type: 'uuid', name: 'sku_id' })
  skuId: string;

  @ManyToOne(() => SkuEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'sku_id' })
  sku?: SkuEntity;

  @Column({ type: 'int' })
  quantity: number;
}
