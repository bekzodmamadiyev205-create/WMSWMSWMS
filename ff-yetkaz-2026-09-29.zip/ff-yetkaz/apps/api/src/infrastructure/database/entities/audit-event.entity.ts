import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';
import type { AuditAction } from '@ff/shared';

/**
 * Append-only журнал. UPDATE/DELETE/TRUNCATE запрещены триггером в БД —
 * запрет действует даже на владельца схемы, в отличие от одних лишь грантов.
 *
 * `actor_user_id` намеренно без внешнего ключа: запись аудита должна пережить
 * удаление пользователя, а ON DELETE SET NULL — это UPDATE, который триггер отобьёт.
 */
@Entity({ name: 'audit_events' })
export class AuditEventEntity {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: string;

  @CreateDateColumn({ type: 'timestamptz', name: 'occurred_at' })
  occurredAt: Date;

  @Column({ type: 'uuid', name: 'actor_user_id', nullable: true })
  actorUserId: string | null;

  @Column({ type: 'text', name: 'actor_role', nullable: true })
  actorRole: string | null;

  @Column({ type: 'text', name: 'entity_type' })
  entityType: string;

  /** text, а не uuid: сущности FF используют разные типы ключей. */
  @Column({ type: 'text', name: 'entity_id', nullable: true })
  entityId: string | null;

  @Column({ type: 'text' })
  action: AuditAction;

  @Column({ type: 'jsonb', nullable: true })
  before: Record<string, unknown> | null;

  @Column({ type: 'jsonb', nullable: true })
  after: Record<string, unknown> | null;

  @Column({ type: 'text', name: 'correlation_id', nullable: true })
  correlationId: string | null;

  @Column({ type: 'text', nullable: true })
  ip: string | null;
}
