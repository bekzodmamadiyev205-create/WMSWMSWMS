import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { ROLES, type Role } from '@ff/shared';

/**
 * Право роли на КОЛОНКУ. Отсутствие строки означает «разрешено» — умолчание
 * открытое сознательно: матрица прав, которая с первого дня что-то ломает,
 * выключается администратором целиком и больше никогда не используется.
 */
@Entity({ name: 'field_permissions' })
export class FieldPermissionEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: ROLES as unknown as string[], enumName: 'ff_role' })
  role: Role;

  /** Имя сущности из `ACL_ENTITIES` (`order`, `stock`, …). */
  @Column({ type: 'text' })
  entity: string;

  /** Имя поля DTO — не колонки БД: закрываем то, что видит клиент. */
  @Column({ type: 'text' })
  field: string;

  @Column({ type: 'boolean', name: 'can_view', default: true })
  canView: boolean;

  @Column({ type: 'boolean', name: 'can_edit', default: true })
  canEdit: boolean;

  @Column({ type: 'boolean', name: 'can_delete', default: false })
  canDelete: boolean;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
