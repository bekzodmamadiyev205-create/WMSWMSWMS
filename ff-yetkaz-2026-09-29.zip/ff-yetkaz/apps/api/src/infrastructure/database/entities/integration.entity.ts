import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import {
  OUTBOX_STATUSES,
  SHIPMENT_STATUSES,
  WEBHOOK_RESULTS,
  type OutboxStatus,
  type ShipmentStatus,
  type WebhookResult,
} from '@ff/shared';

/**
 * Исходящее сообщение перевозчику. Строка появляется в той же транзакции, что и
 * бизнес-факт, поэтому «отправление создано, но сообщение потеряно» невозможно.
 */
@Entity({ name: 'integration_outbox' })
export class IntegrationOutboxEntity {
  @PrimaryGeneratedColumn('identity', { type: 'bigint' })
  id: string;

  @Column({ type: 'text', name: 'carrier_code' })
  carrierCode: string;

  @Column({ type: 'text' })
  topic: string;

  @Column({ type: 'text', name: 'entity_type' })
  entityType: string;

  @Column({ type: 'text', name: 'entity_id' })
  entityId: string;

  @Column({ type: 'jsonb' })
  payload: unknown;

  @Column({ type: 'enum', enum: OUTBOX_STATUSES as unknown as string[], enumName: 'outbox_status' })
  status: OutboxStatus;

  @Column({ type: 'int' })
  attempts: number;

  @Column({ type: 'timestamptz', name: 'next_attempt_at' })
  nextAttemptAt: Date;

  @Column({ type: 'timestamptz', name: 'locked_until', nullable: true })
  lockedUntil: Date | null;

  @Column({ type: 'text', name: 'last_error', nullable: true })
  lastError: string | null;

  @Column({ type: 'timestamptz', name: 'delivered_at', nullable: true })
  deliveredAt: Date | null;

  @Column({ type: 'text', name: 'correlation_id', nullable: true })
  correlationId: string | null;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}

/** Входящий вебхук целиком: и принятый, и отвергнутый. */
@Entity({ name: 'webhook_deliveries' })
export class WebhookDeliveryEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text', name: 'carrier_code' })
  carrierCode: string;

  @Column({ type: 'text', name: 'delivery_id' })
  deliveryId: string;

  @CreateDateColumn({ type: 'timestamptz', name: 'received_at' })
  receivedAt: Date;

  @Column({ type: 'jsonb' })
  payload: unknown;

  @Column({ type: 'enum', enum: WEBHOOK_RESULTS as unknown as string[], enumName: 'webhook_result' })
  result: WebhookResult;

  @Column({ type: 'text', nullable: true })
  error: string | null;

  @Column({ type: 'uuid', name: 'shipment_id', nullable: true })
  shipmentId: string | null;
}

/** История статусов отправления: и наши переходы, и присланные перевозчиком. */
@Entity({ name: 'shipment_status_events' })
export class ShipmentStatusEventEntity {
  @PrimaryGeneratedColumn('identity', { type: 'bigint' })
  id: string;

  @Column({ type: 'uuid', name: 'shipment_id' })
  shipmentId: string;

  @Column({
    type: 'enum',
    enum: SHIPMENT_STATUSES as unknown as string[],
    enumName: 'shipment_status',
    name: 'from_status',
    nullable: true,
  })
  fromStatus: ShipmentStatus | null;

  @Column({
    type: 'enum',
    enum: SHIPMENT_STATUSES as unknown as string[],
    enumName: 'shipment_status',
    name: 'to_status',
  })
  toStatus: ShipmentStatus;

  @Column({ type: 'timestamptz', name: 'occurred_at' })
  occurredAt: Date;

  @CreateDateColumn({ type: 'timestamptz', name: 'recorded_at' })
  recordedAt: Date;

  @Column({ type: 'text' })
  source: 'FF' | 'CARRIER';

  @Column({ type: 'text', nullable: true })
  comment: string | null;

  @Column({ type: 'jsonb', nullable: true })
  raw: unknown;
}
