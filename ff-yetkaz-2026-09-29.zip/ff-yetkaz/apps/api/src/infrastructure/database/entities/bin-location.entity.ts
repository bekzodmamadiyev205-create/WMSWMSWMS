import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { BIN_KINDS, type BinKind } from '@ff/shared';
import { WarehouseEntity } from './warehouse.entity';

/**
 * Ячейка адресуется плоским кодом (решение PM). Маршрут сборки в Phase 1
 * строится сортировкой по коду — коды должны быть с ведущими нулями.
 */
@Entity({ name: 'bin_locations' })
export class BinLocationEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', name: 'warehouse_id' })
  warehouseId: string;

  @ManyToOne(() => WarehouseEntity, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'warehouse_id' })
  warehouse?: WarehouseEntity;

  @Column({ type: 'text' })
  code: string;

  @Column({ type: 'enum', enum: BIN_KINDS as unknown as string[], enumName: 'bin_kind' })
  kind: BinKind;

  @Column({ type: 'boolean', name: 'is_active', default: true })
  isActive: boolean;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
