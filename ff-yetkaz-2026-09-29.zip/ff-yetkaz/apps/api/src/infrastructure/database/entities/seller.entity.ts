import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

/**
 * Селлер — клиент 3PL-оператора. В 0.1 заведён по минимуму: нужен как область
 * видимости для роли SELLER. Полный MDM (реквизиты, договор, тарифный план) — этап 0.2.
 */
@Entity({ name: 'sellers' })
export class SellerEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Короткий код селлера, используется в штрихкодах и отчётах. */
  @Column({ type: 'text' })
  code: string;

  @Column({ type: 'text', name: 'legal_name' })
  legalName: string;

  @Column({ type: 'text', name: 'tax_id', nullable: true })
  taxId: string | null;

  @Column({ type: 'text', name: 'contact_email', nullable: true })
  contactEmail: string | null;

  @Column({ type: 'text', name: 'contact_phone', nullable: true })
  contactPhone: string | null;

  @Column({ type: 'text', nullable: true })
  address: string | null;

  @Column({ type: 'boolean', name: 'is_active', default: true })
  isActive: boolean;

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz', name: 'updated_at' })
  updatedAt: Date;
}
