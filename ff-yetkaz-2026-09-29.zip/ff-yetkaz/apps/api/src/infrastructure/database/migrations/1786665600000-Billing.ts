import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 1.8 — биллинг.
 *
 * Три принципа, заложенных в схему, а не в код:
 *
 * 1. **Цены — данные.** `tariff_plans` / `tariff_rules` заполняет оператор.
 *    В коде нет ни одной ставки: при отсутствии подходящего правила начисление
 *    не выдумывается, а попадает в `billing_problems`.
 * 2. **Двойная запись.** Каждая проводка обязана сходиться: сумма дебета равна
 *    сумме кредита по каждой валюте. Это проверяет ОТЛОЖЕННЫЙ триггер на
 *    COMMIT — строки пишутся по одной, а инвариант касается всей проводки.
 * 3. **Книга неизменна.** UPDATE и DELETE по проводкам запрещены триггером.
 *    Исправление — сторнирующая проводка, как в бухгалтерии, а не правка задним
 *    числом.
 */
export class Billing1786665600000 implements MigrationInterface {
  name = 'Billing1786665600000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // --- справочник тарифов -------------------------------------------------
    await queryRunner.query(`
      CREATE TYPE charge_kind AS ENUM (
        'INBOUND', 'STORAGE', 'PICKING', 'PACKING', 'DELIVERY', 'COD_FEE', 'SURCHARGE'
      )
    `);
    await queryRunner.query(`
      CREATE TYPE tariff_unit AS ENUM (
        'PER_ORDER', 'PER_UNIT', 'PER_KG', 'PER_M3_DAY', 'PERCENT_OF_COD', 'FLAT'
      )
    `);
    await queryRunner.query(`
      CREATE TYPE invoice_status AS ENUM ('DRAFT', 'ISSUED', 'PAID', 'CANCELLED')
    `);

    await queryRunner.query(`
      CREATE TABLE tariff_plans (
        id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        code       text NOT NULL UNIQUE,
        name       text NOT NULL,
        currency   text NOT NULL,
        is_default boolean NOT NULL DEFAULT false,
        is_active  boolean NOT NULL DEFAULT false,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT tariff_plans_currency_shape CHECK (currency ~ '^[A-Z]{3}$')
      )
    `);
    // План по умолчанию ровно один — иначе «тариф по умолчанию» перестаёт быть
    // определённым понятием.
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_tariff_plans_default ON tariff_plans ((true)) WHERE is_default
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_tariff_plans_touch BEFORE UPDATE ON tariff_plans
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE tariff_rules (
        id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        plan_id        uuid NOT NULL REFERENCES tariff_plans(id) ON DELETE CASCADE,
        kind           charge_kind NOT NULL,
        unit           tariff_unit NOT NULL,
        price          numeric(14, 4) NOT NULL,
        -- Ступень объёма: правило действует, начиная с этого количества.
        min_qty        numeric(14, 3) NOT NULL DEFAULT 0,
        effective_from date NOT NULL DEFAULT current_date,
        effective_to   date,
        created_at     timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT tariff_rules_price_non_negative CHECK (price >= 0),
        CONSTRAINT tariff_rules_min_qty_non_negative CHECK (min_qty >= 0),
        CONSTRAINT tariff_rules_period_sane CHECK (effective_to IS NULL OR effective_to >= effective_from)
      )
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_tariff_rules_step
        ON tariff_rules (plan_id, kind, unit, min_qty, effective_from)
    `);
    await queryRunner.query(`
      CREATE INDEX idx_tariff_rules_lookup ON tariff_rules (plan_id, kind, effective_from)
    `);

    // План селлера: пусто — действует план по умолчанию.
    await queryRunner.query(`
      ALTER TABLE sellers ADD COLUMN tariff_plan_id uuid REFERENCES tariff_plans(id)
    `);

    // --- книга (двойная запись) ---------------------------------------------
    await queryRunner.query(`CREATE TYPE ledger_side AS ENUM ('DEBIT', 'CREDIT')`);
    await queryRunner.query(`
      CREATE TABLE ledger_accounts (
        id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        code       text NOT NULL UNIQUE,
        name       text NOT NULL,
        kind       text NOT NULL,
        CONSTRAINT ledger_accounts_kind CHECK (kind IN ('ASSET', 'LIABILITY', 'INCOME', 'EXPENSE'))
      )
    `);
    await queryRunner.query(`
      INSERT INTO ledger_accounts (code, name, kind) VALUES
        ('AR_SELLER',     'Задолженность селлеров за услуги', 'ASSET'),
        ('INCOME_FF',     'Выручка фулфилмента',              'INCOME'),
        ('AR_CARRIER',    'Наложенный платёж у перевозчика',  'ASSET'),
        ('AP_SELLER',     'Обязательства перед селлерами',    'LIABILITY'),
        ('CASH',          'Денежные средства',                'ASSET')
    `);

    await queryRunner.query(`
      CREATE TABLE ledger_transactions (
        id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        occurred_at    timestamptz NOT NULL,
        description    text NOT NULL,
        seller_id      uuid REFERENCES sellers(id) ON DELETE RESTRICT,
        reference_type text,
        reference_id   text,
        created_at     timestamptz NOT NULL DEFAULT now()
      )
    `);
    await queryRunner.query(`
      CREATE INDEX idx_ledger_tx_seller ON ledger_transactions (seller_id, occurred_at DESC)
    `);
    // Идемпотентность проводок: повторный прогон начисления не проведёт один и
    // тот же факт дважды. Уникальность держит индекс, а не проверка в коде —
    // при параллельных прогонах предварительный SELECT не спасает.
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_ledger_tx_reference ON ledger_transactions (reference_type, reference_id)
      WHERE reference_type IS NOT NULL AND reference_id IS NOT NULL
    `);

    await queryRunner.query(`
      CREATE TABLE ledger_entries (
        id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        transaction_id uuid NOT NULL REFERENCES ledger_transactions(id) ON DELETE RESTRICT,
        account_id     uuid NOT NULL REFERENCES ledger_accounts(id) ON DELETE RESTRICT,
        seller_id      uuid REFERENCES sellers(id) ON DELETE RESTRICT,
        side           ledger_side NOT NULL,
        amount         numeric(14, 2) NOT NULL,
        currency       text NOT NULL,
        created_at     timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT ledger_entries_amount_positive CHECK (amount > 0),
        CONSTRAINT ledger_entries_currency_shape CHECK (currency ~ '^[A-Z]{3}$')
      )
    `);
    await queryRunner.query(`
      CREATE INDEX idx_ledger_entries_tx ON ledger_entries (transaction_id)
    `);
    await queryRunner.query(`
      CREATE INDEX idx_ledger_entries_account ON ledger_entries (account_id, seller_id)
    `);

    // Сходимость проверяется на COMMIT: строки проводки пишутся по одной, и в
    // середине вставки равенство дебета и кредита закономерно нарушено.
    await queryRunner.query(`
      CREATE FUNCTION ff_ledger_balanced() RETURNS trigger AS $$
      DECLARE
        unbalanced record;
      BEGIN
        SELECT currency,
               SUM(CASE WHEN side = 'DEBIT' THEN amount ELSE -amount END) AS diff
          INTO unbalanced
          FROM ledger_entries
         WHERE transaction_id = NEW.transaction_id
         GROUP BY currency
        HAVING SUM(CASE WHEN side = 'DEBIT' THEN amount ELSE -amount END) <> 0
         LIMIT 1;

        IF FOUND THEN
          RAISE EXCEPTION 'Проводка % не сходится: валюта %, расхождение %',
            NEW.transaction_id, unbalanced.currency, unbalanced.diff;
        END IF;
        RETURN NULL;
      END;
      $$ LANGUAGE plpgsql
    `);
    await queryRunner.query(`
      CREATE CONSTRAINT TRIGGER trg_ledger_balanced
      AFTER INSERT ON ledger_entries
      DEFERRABLE INITIALLY DEFERRED
      FOR EACH ROW EXECUTE FUNCTION ff_ledger_balanced()
    `);

    // Книга неизменна: исправление — сторно, а не правка задним числом.
    await queryRunner.query(`
      CREATE FUNCTION ff_ledger_append_only() RETURNS trigger AS $$
      BEGIN
        RAISE EXCEPTION 'Бухгалтерская книга неизменна: используйте сторнирующую проводку.';
      END;
      $$ LANGUAGE plpgsql
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_ledger_entries_immutable
      BEFORE UPDATE OR DELETE ON ledger_entries
      FOR EACH ROW EXECUTE FUNCTION ff_ledger_append_only()
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_ledger_tx_immutable
      BEFORE UPDATE OR DELETE ON ledger_transactions
      FOR EACH ROW EXECUTE FUNCTION ff_ledger_append_only()
    `);

    // --- начисления ---------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE charges (
        id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        seller_id      uuid NOT NULL REFERENCES sellers(id) ON DELETE RESTRICT,
        kind           charge_kind NOT NULL,
        unit           tariff_unit NOT NULL,
        quantity       numeric(14, 3) NOT NULL,
        unit_price     numeric(14, 4) NOT NULL,
        amount         numeric(14, 2) NOT NULL,
        currency       text NOT NULL,
        occurred_at    timestamptz NOT NULL,
        order_id       uuid REFERENCES orders(id) ON DELETE RESTRICT,
        shipment_id    uuid REFERENCES shipments(id) ON DELETE RESTRICT,
        -- Ключ идемпотентности начисления: «складская смена за 2026-08-05»,
        -- «упаковка заказа X». Повторный прогон не удваивает счёт.
        source_key     text NOT NULL,
        tariff_rule_id uuid REFERENCES tariff_rules(id) ON DELETE RESTRICT,
        transaction_id uuid REFERENCES ledger_transactions(id) ON DELETE RESTRICT,
        invoice_id     uuid,
        created_at     timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT charges_amount_non_negative CHECK (amount >= 0),
        CONSTRAINT charges_quantity_non_negative CHECK (quantity >= 0)
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX uq_charges_source ON charges (source_key)`);
    await queryRunner.query(
      `CREATE INDEX idx_charges_period ON charges (seller_id, occurred_at)`,
    );

    // Начисление, которое не удалось посчитать: тариф не заведён, валюты
    // разошлись и т.п. Молча пропускать нельзя — это потерянные деньги.
    await queryRunner.query(`
      CREATE TABLE billing_problems (
        id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        seller_id   uuid REFERENCES sellers(id) ON DELETE RESTRICT,
        kind        charge_kind NOT NULL,
        source_key  text NOT NULL,
        reason      text NOT NULL,
        occurred_at timestamptz NOT NULL,
        resolved_at timestamptz,
        created_at  timestamptz NOT NULL DEFAULT now()
      )
    `);
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_billing_problems_source ON billing_problems (source_key) WHERE resolved_at IS NULL`,
    );

    // Ежедневный срез хранения: тариф за хранение считается по объёму и дням,
    // а остаток — величина мгновенная, из него историю не восстановить.
    await queryRunner.query(`
      CREATE TABLE storage_snapshots (
        snapshot_date date NOT NULL,
        seller_id     uuid NOT NULL REFERENCES sellers(id) ON DELETE RESTRICT,
        units         int NOT NULL,
        volume_mm3    numeric(24, 0) NOT NULL,
        created_at    timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY (snapshot_date, seller_id)
      )
    `);

    // --- счета ---------------------------------------------------------------
    await queryRunner.query(`CREATE SEQUENCE invoice_no_seq START 1`);
    await queryRunner.query(`
      CREATE TABLE invoices (
        id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        number              text NOT NULL UNIQUE
                            DEFAULT ('INV-' || to_char(now(), 'YYYYMM') || '-' ||
                                     lpad(nextval('invoice_no_seq')::text, 5, '0')),
        seller_id           uuid NOT NULL REFERENCES sellers(id) ON DELETE RESTRICT,
        period_start        date NOT NULL,
        period_end          date NOT NULL,
        currency            text NOT NULL,
        services_total      numeric(14, 2) NOT NULL DEFAULT 0,
        cod_collected_total numeric(14, 2) NOT NULL DEFAULT 0,
        payout_total        numeric(14, 2) NOT NULL DEFAULT 0,
        status              invoice_status NOT NULL DEFAULT 'DRAFT',
        issued_at           timestamptz,
        created_at          timestamptz NOT NULL DEFAULT now(),
        updated_at          timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT invoices_period_sane CHECK (period_end >= period_start),
        CONSTRAINT invoices_issued_has_time CHECK (status = 'DRAFT' OR issued_at IS NOT NULL)
      )
    `);
    // Один действующий счёт на селлера и период: два счёта за один месяц —
    // это двойное выставление, а не «версии».
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_invoices_period ON invoices (seller_id, period_start, period_end)
      WHERE status <> 'CANCELLED'
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_invoices_touch BEFORE UPDATE ON invoices
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE invoice_lines (
        id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        invoice_id  uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
        kind        charge_kind NOT NULL,
        description text NOT NULL,
        quantity    numeric(14, 3) NOT NULL,
        unit        tariff_unit NOT NULL,
        unit_price  numeric(14, 4) NOT NULL,
        amount      numeric(14, 2) NOT NULL
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_invoice_lines ON invoice_lines (invoice_id)`);

    await queryRunner.query(`
      ALTER TABLE charges ADD CONSTRAINT charges_invoice_fk
        FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE RESTRICT
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE charges DROP CONSTRAINT IF EXISTS charges_invoice_fk`);
    await queryRunner.query(`DROP TABLE IF EXISTS invoice_lines`);
    await queryRunner.query(`DROP TABLE IF EXISTS invoices`);
    await queryRunner.query(`DROP SEQUENCE IF EXISTS invoice_no_seq`);
    await queryRunner.query(`DROP TABLE IF EXISTS storage_snapshots`);
    await queryRunner.query(`DROP TABLE IF EXISTS billing_problems`);
    await queryRunner.query(`DROP TABLE IF EXISTS charges`);
    await queryRunner.query(`DROP TRIGGER IF EXISTS trg_ledger_tx_immutable ON ledger_transactions`);
    await queryRunner.query(`DROP TRIGGER IF EXISTS trg_ledger_entries_immutable ON ledger_entries`);
    await queryRunner.query(`DROP TRIGGER IF EXISTS trg_ledger_balanced ON ledger_entries`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_ledger_append_only`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_ledger_balanced`);
    await queryRunner.query(`DROP TABLE IF EXISTS ledger_entries`);
    await queryRunner.query(`DROP TABLE IF EXISTS ledger_transactions`);
    await queryRunner.query(`DROP TABLE IF EXISTS ledger_accounts`);
    await queryRunner.query(`DROP TYPE IF EXISTS ledger_side`);
    await queryRunner.query(`ALTER TABLE sellers DROP COLUMN IF EXISTS tariff_plan_id`);
    await queryRunner.query(`DROP TABLE IF EXISTS tariff_rules`);
    await queryRunner.query(`DROP TABLE IF EXISTS tariff_plans`);
    await queryRunner.query(`DROP TYPE IF EXISTS invoice_status`);
    await queryRunner.query(`DROP TYPE IF EXISTS tariff_unit`);
    await queryRunner.query(`DROP TYPE IF EXISTS charge_kind`);
  }
}
