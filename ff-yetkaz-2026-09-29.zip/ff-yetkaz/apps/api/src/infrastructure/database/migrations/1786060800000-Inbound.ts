import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 1.2 — Inbound: заявка на поставку и приёмка.
 *
 * Решения PM, зашитые в схему:
 *  - `receipts.asn_id` NOT NULL — приёмка без заявки запрещена;
 *  - на один ASN допускается несколько приёмок (частичные поставки), поэтому
 *    уникальности по asn_id нет;
 *  - расхождение факта с планом не блокирует приёмку, а поднимает флаг
 *    `asns.has_discrepancy`: машина на складе уже разгружена.
 */
export class Inbound1786060800000 implements MigrationInterface {
  name = 'Inbound1786060800000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TYPE asn_status AS ENUM ('DRAFT', 'SUBMITTED', 'RECEIVING', 'COMPLETED', 'CANCELLED')
    `);
    await queryRunner.query(`
      CREATE TYPE receipt_status AS ENUM ('OPEN', 'COMPLETED', 'CANCELLED')
    `);
    await queryRunner.query(`
      CREATE TYPE receipt_line_status AS ENUM ('RECEIVED', 'PUT_AWAY')
    `);

    // --- asns ---------------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE asns (
        id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        seller_id       uuid NOT NULL REFERENCES sellers(id) ON DELETE RESTRICT,
        warehouse_id    uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        external_ref    text,
        status          asn_status NOT NULL DEFAULT 'DRAFT',
        expected_at     timestamptz,
        has_discrepancy boolean NOT NULL DEFAULT false,
        created_by      uuid,
        created_at      timestamptz NOT NULL DEFAULT now(),
        updated_at      timestamptz NOT NULL DEFAULT now()
      )
    `);
    // Защита от двойного заведения одной и той же поставки селлера.
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_asns_external_ref ON asns (seller_id, lower(external_ref))
      WHERE external_ref IS NOT NULL
    `);
    await queryRunner.query(`CREATE INDEX idx_asns_seller ON asns (seller_id, status)`);
    await queryRunner.query(`
      CREATE TRIGGER trg_asns_touch BEFORE UPDATE ON asns
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE asn_lines (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        asn_id       uuid NOT NULL REFERENCES asns(id) ON DELETE CASCADE,
        sku_id       uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        expected_qty int NOT NULL,
        CONSTRAINT asn_lines_qty_positive CHECK (expected_qty > 0)
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX uq_asn_lines_sku ON asn_lines (asn_id, sku_id)`);

    // --- receipts -----------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE receipts (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        asn_id       uuid NOT NULL REFERENCES asns(id) ON DELETE RESTRICT,
        warehouse_id uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        status       receipt_status NOT NULL DEFAULT 'OPEN',
        received_by  uuid,
        started_at   timestamptz NOT NULL DEFAULT now(),
        completed_at timestamptz,
        created_at   timestamptz NOT NULL DEFAULT now(),
        updated_at   timestamptz NOT NULL DEFAULT now()
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_receipts_asn ON receipts (asn_id, status)`);
    await queryRunner.query(`
      CREATE TRIGGER trg_receipts_touch BEFORE UPDATE ON receipts
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE receipt_lines (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        receipt_id   uuid NOT NULL REFERENCES receipts(id) ON DELETE CASCADE,
        sku_id       uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        lot_id       uuid REFERENCES lots(id) ON DELETE RESTRICT,
        qty_received int NOT NULL,
        qty_ok       int NOT NULL DEFAULT 0,
        qty_damaged  int NOT NULL DEFAULT 0,
        bin_id       uuid REFERENCES bin_locations(id) ON DELETE RESTRICT,
        status       receipt_line_status NOT NULL DEFAULT 'RECEIVED',
        created_at   timestamptz NOT NULL DEFAULT now(),
        updated_at   timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT receipt_lines_qty_positive CHECK (qty_received > 0),
        CONSTRAINT receipt_lines_disposition_non_negative CHECK (qty_ok >= 0 AND qty_damaged >= 0),
        -- Разложить больше, чем принято, невозможно.
        CONSTRAINT receipt_lines_disposition_fits CHECK (qty_ok + qty_damaged <= qty_received),
        -- Разложенная позиция обязана иметь ячейку и полную раскладку.
        CONSTRAINT receipt_lines_put_away_complete CHECK (
          status <> 'PUT_AWAY' OR (bin_id IS NOT NULL AND qty_ok + qty_damaged = qty_received)
        )
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_receipt_lines_receipt ON receipt_lines (receipt_id)`);
    await queryRunner.query(`
      CREATE TRIGGER trg_receipt_lines_touch BEFORE UPDATE ON receipt_lines
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS receipt_lines`);
    await queryRunner.query(`DROP TABLE IF EXISTS receipts`);
    await queryRunner.query(`DROP TABLE IF EXISTS asn_lines`);
    await queryRunner.query(`DROP TABLE IF EXISTS asns`);
    await queryRunner.query(`DROP TYPE IF EXISTS receipt_line_status`);
    await queryRunner.query(`DROP TYPE IF EXISTS receipt_status`);
    await queryRunner.query(`DROP TYPE IF EXISTS asn_status`);
  }
}
