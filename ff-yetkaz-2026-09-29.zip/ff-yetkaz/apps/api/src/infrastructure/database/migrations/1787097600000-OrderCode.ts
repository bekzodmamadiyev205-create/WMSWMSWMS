import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Наш собственный код заказа = штрихкод: `FF-YES0000001`, `FF-YES0000002`, …
 *
 * Отличается от `external_id`: тот — номер заказа У КЛИЕНТА (из канала), его мы
 * не придумываем. А `order_code` присваивает система при создании — из
 * последовательности БД, как `shipment_no`. Всегда есть, уникален, руками не
 * вводится. Существующие заказы нумеруются в порядке создания, счётчик сдвигается
 * за них, дальше новые получают следующий номер сами (DEFAULT).
 */
export class OrderCode1787097600000 implements MigrationInterface {
  name = 'OrderCode1787097600000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE SEQUENCE IF NOT EXISTS order_code_seq START 1`);
    await queryRunner.query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS order_code text`);

    // Бэкфилл в порядке создания: FF-YES0000001, 0000002, …
    await queryRunner.query(`
      UPDATE orders o
         SET order_code = 'FF-YES' || lpad(sub.rn::text, 7, '0')
        FROM (SELECT id, row_number() OVER (ORDER BY created_at, id) AS rn FROM orders) sub
       WHERE o.id = sub.id AND o.order_code IS NULL
    `);

    // Сдвигаем счётчик за занятые номера. Пусто → next = 1; иначе → next = count+1.
    await queryRunner.query(
      `SELECT setval('order_code_seq', GREATEST((SELECT count(*) FROM orders), 1), (SELECT count(*) FROM orders) > 0)`,
    );

    await queryRunner.query(
      `ALTER TABLE orders ALTER COLUMN order_code SET DEFAULT ('FF-YES' || lpad(nextval('order_code_seq')::text, 7, '0'))`,
    );
    await queryRunner.query(`ALTER TABLE orders ALTER COLUMN order_code SET NOT NULL`);
    await queryRunner.query(
      `CREATE UNIQUE INDEX IF NOT EXISTS uq_orders_order_code ON orders (order_code)`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS uq_orders_order_code`);
    await queryRunner.query(`ALTER TABLE orders DROP COLUMN IF EXISTS order_code`);
    await queryRunner.query(`DROP SEQUENCE IF EXISTS order_code_seq`);
  }
}
