import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Вес заказа в килограммах.
 *
 * Заявленный вес отправления — атрибут уровня заказа (как наложенный платёж):
 * нужен для тарификации доставки и передачи перевозчику. Хранится numeric,
 * а не float — вес участвует в расчётах и округлениях. Nullable: у старых
 * заказов веса нет, вводится он необязательно.
 */
export class OrderWeight1786838400000 implements MigrationInterface {
  name = 'OrderWeight1786838400000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE orders
        ADD COLUMN weight_kg numeric(10,3)
          CONSTRAINT orders_weight_nonneg CHECK (weight_kg IS NULL OR weight_kg >= 0)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE orders DROP COLUMN IF EXISTS weight_kg`);
  }
}
