import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап Orders — приём заказов из внешних каналов.
 *
 * Ключевое в схеме — естественный ключ `(seller, channel, external_id)`.
 * Заголовок `Idempotency-Key` защищает от ретрая в пределах суток, а этот
 * индекс — от повторной выгрузки канала через неделю, когда ключ уже протух.
 *
 * Разделение между складами: заказ-контейнер сохраняет ВСЕ позиции канала и
 * помечается `is_split`, а исполняют его дочерние заказы (`parent_order_id`).
 * Так запись канала остаётся неизменной, а у каждой отгружаемой части свой
 * жизненный цикл.
 */
export class Orders1786147200000 implements MigrationInterface {
  name = 'Orders1786147200000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TYPE order_status AS ENUM (
        'NEW', 'VALIDATED', 'RESERVED', 'PICKING', 'PICKED', 'PACKING', 'PACKED',
        'READY_TO_SHIP', 'SHIPPED', 'DELIVERED', 'RETURNED', 'CANCELLED'
      )
    `);

    await queryRunner.query(`
      CREATE TABLE orders (
        id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        seller_id       uuid NOT NULL REFERENCES sellers(id) ON DELETE RESTRICT,
        channel         text NOT NULL,
        external_id     text NOT NULL,
        status          order_status NOT NULL DEFAULT 'NEW',
        warehouse_id    uuid REFERENCES warehouses(id) ON DELETE RESTRICT,
        parent_order_id uuid REFERENCES orders(id) ON DELETE RESTRICT,
        is_split        boolean NOT NULL DEFAULT false,
        has_shortage    boolean NOT NULL DEFAULT false,
        recipient_name  text NOT NULL,
        recipient_phone text NOT NULL,
        address         text NOT NULL,
        region          text,
        cod_amount      numeric(14, 2),
        currency        text,
        created_by      uuid,
        created_at      timestamptz NOT NULL DEFAULT now(),
        updated_at      timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT orders_channel_not_blank CHECK (length(btrim(channel)) > 0),
        CONSTRAINT orders_external_not_blank CHECK (length(btrim(external_id)) > 0),
        CONSTRAINT orders_recipient_not_blank CHECK (length(btrim(recipient_name)) > 0),
        CONSTRAINT orders_cod_non_negative CHECK (cod_amount IS NULL OR cod_amount >= 0),
        -- Сумма наложенного платежа без валюты бессмысленна, и наоборот.
        CONSTRAINT orders_cod_needs_currency CHECK ((cod_amount IS NULL) = (currency IS NULL)),
        CONSTRAINT orders_not_own_parent CHECK (parent_order_id IS NULL OR parent_order_id <> id)
      )
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_orders_channel_external
        ON orders (seller_id, channel, lower(external_id))
    `);
    await queryRunner.query(`CREATE INDEX idx_orders_status ON orders (seller_id, status)`);
    await queryRunner.query(`
      CREATE INDEX idx_orders_parent ON orders (parent_order_id)
      WHERE parent_order_id IS NOT NULL
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_orders_touch BEFORE UPDATE ON orders
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE order_lines (
        id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        sku_id   uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        quantity int NOT NULL,
        CONSTRAINT order_lines_qty_positive CHECK (quantity > 0)
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX uq_order_lines_sku ON order_lines (order_id, sku_id)`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS order_lines`);
    await queryRunner.query(`DROP TABLE IF EXISTS orders`);
    await queryRunner.query(`DROP TYPE IF EXISTS order_status`);
  }
}
