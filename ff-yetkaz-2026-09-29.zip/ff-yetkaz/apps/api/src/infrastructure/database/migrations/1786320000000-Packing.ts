import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 1.4 — Packing: упаковка собранного заказа и оформление отправления.
 *
 * Состав упаковки фиксируется отдельной таблицей, а не выводится из заказа:
 * при недоборе в коробку уезжает не то, что просил канал, а то, что реально
 * дошло до зоны упаковки. Именно этот состав едет к получателю, по нему
 * считается расчётный вес и печатается этикетка.
 *
 * Номер отправления выдаёт последовательность БД: он попадает на штрихкод
 * этикетки, поэтому уникальность должна держаться на уровне схемы, а не на
 * договорённости в коде. Трек перевозчика (`tracking_no`) появляется позже —
 * при передаче в iPost GO.
 */
export class Packing1786320000000 implements MigrationInterface {
  name = 'Packing1786320000000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TYPE package_status AS ENUM ('OPEN', 'PACKED')`);
    await queryRunner.query(`
      CREATE TYPE shipment_status AS ENUM (
        'READY', 'HANDED_OVER', 'IN_TRANSIT', 'DELIVERED', 'FAILED', 'RETURNING'
      )
    `);

    await queryRunner.query(`
      CREATE TABLE packages (
        id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        -- Одна упаковка на заказ: этикетка, отправление и трек однозначны.
        -- Дробление заказа на несколько мест в MVP не предусмотрено.
        order_id          uuid NOT NULL UNIQUE REFERENCES orders(id) ON DELETE RESTRICT,
        warehouse_id      uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        status            package_status NOT NULL DEFAULT 'OPEN',
        expected_weight_g int,
        actual_weight_g   int,
        weight_mismatch   boolean NOT NULL DEFAULT false,
        length_mm         int,
        width_mm          int,
        height_mm         int,
        packer_user_id    uuid,
        comment           text,
        started_at        timestamptz NOT NULL DEFAULT now(),
        packed_at         timestamptz,
        created_at        timestamptz NOT NULL DEFAULT now(),
        updated_at        timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT packages_weights_positive CHECK (
          (expected_weight_g IS NULL OR expected_weight_g > 0)
          AND (actual_weight_g IS NULL OR actual_weight_g > 0)
        ),
        CONSTRAINT packages_dims_positive CHECK (
          (length_mm IS NULL OR length_mm > 0)
          AND (width_mm IS NULL OR width_mm > 0)
          AND (height_mm IS NULL OR height_mm > 0)
        ),
        -- Закрытая коробка обязана иметь взвешивание и время: без них ни
        -- этикетку напечатать, ни тариф посчитать.
        CONSTRAINT packages_packed_is_weighed CHECK (
          status <> 'PACKED' OR (actual_weight_g IS NOT NULL AND packed_at IS NOT NULL)
        )
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_packages_warehouse ON packages (warehouse_id, status)`);
    await queryRunner.query(`
      CREATE TRIGGER trg_packages_touch BEFORE UPDATE ON packages
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE package_items (
        id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        package_id uuid NOT NULL REFERENCES packages(id) ON DELETE CASCADE,
        sku_id     uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        lot_id     uuid REFERENCES lots(id) ON DELETE RESTRICT,
        -- Ячейка, из которой позиция уезжает: собранное лежит в зоне упаковки,
        -- и списывать при закрытии коробки надо ровно оттуда.
        bin_id     uuid NOT NULL REFERENCES bin_locations(id) ON DELETE RESTRICT,
        quantity   int NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT package_items_qty_positive CHECK (quantity > 0)
      )
    `);
    // NULLS NOT DISTINCT обязателен: без него SKU без партионного учёта
    // размножил бы строки — обычный UNIQUE не считает два NULL одинаковыми.
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_package_items_line
        ON package_items (package_id, sku_id, lot_id, bin_id) NULLS NOT DISTINCT
    `);

    await queryRunner.query(`CREATE SEQUENCE shipment_no_seq START 1`);
    await queryRunner.query(`
      CREATE TABLE shipments (
        id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        order_id       uuid NOT NULL UNIQUE REFERENCES orders(id) ON DELETE RESTRICT,
        package_id     uuid NOT NULL UNIQUE REFERENCES packages(id) ON DELETE RESTRICT,
        -- Номер выдаёт БД: он уходит на штрихкод этикетки, поэтому уникальность
        -- должна держаться схемой, а не договорённостью в коде.
        shipment_no    text NOT NULL UNIQUE
                       DEFAULT ('FF' || lpad(nextval('shipment_no_seq')::text, 9, '0')),
        status         shipment_status NOT NULL DEFAULT 'READY',
        carrier        text NOT NULL DEFAULT 'IPOST_GO',
        tracking_no    text,
        weight_g       int NOT NULL,
        -- Сумма наложенного платежа замораживается на момент отгрузки: дальше
        -- её сверяет биллинг с тем, что вернул перевозчик.
        cod_amount     numeric(14, 2),
        currency       text,
        handed_over_at timestamptz,
        created_at     timestamptz NOT NULL DEFAULT now(),
        updated_at     timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT shipments_weight_positive CHECK (weight_g > 0),
        CONSTRAINT shipments_cod_needs_currency CHECK ((cod_amount IS NULL) = (currency IS NULL)),
        -- Передано в доставку — значит время передачи проставлено.
        CONSTRAINT shipments_handover_has_time CHECK (
          status = 'READY' OR handed_over_at IS NOT NULL
        )
      )
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_shipments_tracking ON shipments (tracking_no)
      WHERE tracking_no IS NOT NULL
    `);
    await queryRunner.query(`CREATE INDEX idx_shipments_status ON shipments (status)`);
    await queryRunner.query(`
      CREATE TRIGGER trg_shipments_touch BEFORE UPDATE ON shipments
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS shipments`);
    await queryRunner.query(`DROP SEQUENCE IF EXISTS shipment_no_seq`);
    await queryRunner.query(`DROP TABLE IF EXISTS package_items`);
    await queryRunner.query(`DROP TABLE IF EXISTS packages`);
    await queryRunner.query(`DROP TYPE IF EXISTS shipment_status`);
    await queryRunner.query(`DROP TYPE IF EXISTS package_status`);
  }
}
