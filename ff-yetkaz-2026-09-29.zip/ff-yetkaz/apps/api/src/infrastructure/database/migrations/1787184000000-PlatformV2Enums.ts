import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Новые значения существующих перечислений — ОТДЕЛЬНОЙ миграцией.
 *
 * Почему отдельно: PostgreSQL разрешает `ALTER TYPE … ADD VALUE` внутри
 * транзакции, но запрещает ИСПОЛЬЗОВАТЬ добавленное значение до её коммита.
 * Если сложить добавление и первую вставку/CHECK с этим значением в один файл,
 * миграция упадёт на боевой базе — и упадёт не сразу, а на конкретных данных.
 * Поэтому здесь только ALTER TYPE, а всё, что этими значениями пользуется,
 * живёт в следующей миграции.
 *
 * `down()` пустой намеренно: удалять значение из enum PostgreSQL не умеет
 * (тот же приём, что и в миграции ReceiverRole).
 */
export class PlatformV2Enums1787184000000 implements MigrationInterface {
  name = 'PlatformV2Enums1787184000000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // «Расходный» — выдача со склада. Ставим ПОСЛЕ READY_TO_SHIP: порядок
    // значений enum задаёт сортировку статусов, а стадия идёт именно там.
    await queryRunner.query(
      `ALTER TYPE order_status ADD VALUE IF NOT EXISTS 'DISPATCHED' AFTER 'READY_TO_SHIP'`,
    );

    // Тарификация по таре: разовая (обработка) и посуточная (хранение).
    await queryRunner.query(`ALTER TYPE tariff_unit ADD VALUE IF NOT EXISTS 'PER_BOX'`);
    await queryRunner.query(`ALTER TYPE tariff_unit ADD VALUE IF NOT EXISTS 'PER_PALLET'`);
    await queryRunner.query(`ALTER TYPE tariff_unit ADD VALUE IF NOT EXISTS 'PER_BOX_DAY'`);
    await queryRunner.query(`ALTER TYPE tariff_unit ADD VALUE IF NOT EXISTS 'PER_PALLET_DAY'`);

    // Возврат — своя причина движения: в журнале должно быть видно, что товар
    // приехал обратно, а не поступил новой поставкой.
    await queryRunner.query(`ALTER TYPE movement_reason ADD VALUE IF NOT EXISTS 'RETURN'`);
  }

  public async down(): Promise<void> {
    // PostgreSQL не удаляет значения перечислений.
  }
}
