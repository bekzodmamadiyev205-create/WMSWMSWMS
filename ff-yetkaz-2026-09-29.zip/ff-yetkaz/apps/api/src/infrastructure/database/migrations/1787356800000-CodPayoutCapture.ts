import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Захват собранного наложенного платежа счётом — как у начислений.
 *
 * У начислений принадлежность счёту хранится на самой строке
 * (`charges.invoice_id`), и второй счёт ту же строку уже не заберёт. У
 * собранного платежа такой метки не было: сумма считалась запросом по периоду,
 * поэтому два пересекающихся периода складывали одни и те же деньги дважды в
 * «к перечислению». Пересечение до сих пор держалось проверкой в сервисе —
 * защита от последовательного сценария, но не от гонки двух одновременных
 * сборок. Колонка эту дыру закрывает по-настоящему.
 *
 * `ON DELETE RESTRICT` — тот же выбор, что у остальных денежных ссылок: счёт,
 * за которым числятся собранные деньги, не должен исчезать вместе с ними.
 */
export class CodPayoutCapture1787356800000 implements MigrationInterface {
  name = 'CodPayoutCapture1787356800000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE shipments
        ADD COLUMN IF NOT EXISTS payout_invoice_id uuid REFERENCES invoices(id) ON DELETE RESTRICT
    `);

    /**
     * Индекс под сам захват: `... WHERE payout_invoice_id IS NULL AND
     * cod_collected_at BETWEEN ...`. Предикат намеренно повторяет ТОЛЬКО
     * условие незахваченности — то, что есть в запросе дословно. Добавь сюда
     * лишнее условие (скажем, `cod_collected_amount IS NOT NULL`) — ошибки не
     * будет, индекс просто молча перестанет применяться, и сборка счёта
     * начнёт читать таблицу отправлений целиком.
     */
    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS idx_shipments_payout_uncaptured
        ON shipments (cod_collected_at)
        WHERE payout_invoice_id IS NULL
    `);

    // Обратный проход — «что захвачено этим счётом»: по нему считается сумма
    // собранного платежа при КАЖДОЙ сборке, и снимается захват с отменённого
    // счёта. Без индекса это чтение всей таблицы отправлений.
    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS idx_shipments_payout_invoice
        ON shipments (payout_invoice_id)
        WHERE payout_invoice_id IS NOT NULL
    `);

    /**
     * Разметка того, что уже сосчитано выставленными счетами.
     *
     * Без неё колонка на боевой базе осталась бы пустой у всей истории, и
     * инвариант «собранные деньги, попавшие в счёт, помечены этим счётом» был
     * бы верен только для новых счетов. Привязка детерминирована (самый ранний
     * период, затем самый ранний счёт), чтобы результат не зависел от порядка
     * строк, если в истории всё-таки остались пересекающиеся периоды.
     */
    await queryRunner.query(`
      UPDATE shipments s
         SET payout_invoice_id = pick.invoice_id
        FROM (
              SELECT DISTINCT ON (s2.id) s2.id AS shipment_id, i.id AS invoice_id
                FROM shipments s2
                JOIN orders o2 ON o2.id = s2.order_id
                JOIN invoices i ON i.seller_id = o2.seller_id
                               AND i.status <> 'CANCELLED'
                               AND s2.cod_collected_at >= i.period_start
                               AND s2.cod_collected_at < (i.period_end + 1)
               WHERE s2.payout_invoice_id IS NULL
               ORDER BY s2.id, i.period_start, i.created_at
             ) pick
       WHERE s.id = pick.shipment_id
    `);

    /**
     * Уборка мусора от прошлой правки: права на поле `stock.receivedAt`.
     *
     * Поля с таким именем в ответе никогда не было, поэтому запись ничего не
     * ограничивает — но занимает строку в матрице прав и единицу в счётчике на
     * экране, то есть врёт администратору о том, что где-то что-то закрыто.
     *
     * Чистка едет миграцией, а не руками по базе, по той же причине, по
     * которой сюда едет любая правка схемы: контуров несколько (боевой,
     * тестовый, локальный, каждый новый стенд), и выполненная руками команда
     * повторяется ровно в одном из них. Миграция применяется в каждом, ровно
     * один раз и в известном порядке — а ещё видна в ревью, чего у команды в
     * чужой консоли нет.
     */
    await queryRunner.query(
      `DELETE FROM field_permissions WHERE entity = 'stock' AND field = 'receivedAt'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS idx_shipments_payout_invoice`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_shipments_payout_uncaptured`);
    await queryRunner.query(`ALTER TABLE shipments DROP COLUMN IF EXISTS payout_invoice_id`);
    // Удалённые права НЕ восстанавливаются: они не значили ничего, и вернуть
    // их значило бы вернуть враньё в матрицу. Ролей, у которых они стояли, мы
    // к тому же не знаем — запись была мусором, а не настройкой.
  }
}
