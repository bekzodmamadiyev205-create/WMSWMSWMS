import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 1.5 — отмена заказа после сборки.
 *
 * До этой миграции отмена снимала только резервы. У собранного заказа их уже нет
 * (погашены при сборке), поэтому товар оставался в зоне упаковки/отгрузки в
 * статусе PICKED/PACKED и не возвращался в доступный остаток.
 *
 * Возврат на склад — не RMA: товар физически не покидал склад, коробку вскрывают
 * и раскладывают обратно. Отсюда новая причина движения `PUT_BACK` и отменяемые
 * состояния у упаковки и отправления.
 */
export class OrderCancellation1786406400000 implements MigrationInterface {
  name = 'OrderCancellation1786406400000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // PostgreSQL 12+ разрешает ADD VALUE внутри транзакции, но пользоваться новым
    // значением можно только после коммита — здесь мы его и не используем.
    await queryRunner.query(`ALTER TYPE movement_reason ADD VALUE IF NOT EXISTS 'PUT_BACK'`);
    await queryRunner.query(`ALTER TYPE package_status ADD VALUE IF NOT EXISTS 'CANCELLED'`);
    await queryRunner.query(`ALTER TYPE shipment_status ADD VALUE IF NOT EXISTS 'CANCELLED'`);
    // Строку задания отменённого заказа нельзя оставить PENDING: сборщик будет
    // ходить за товаром, который уже никому не нужен.
    await queryRunner.query(`ALTER TYPE pick_line_status ADD VALUE IF NOT EXISTS 'CANCELLED'`);

    await queryRunner.query(`ALTER TABLE packages ADD COLUMN cancelled_at timestamptz`);
    await queryRunner.query(`ALTER TABLE shipments ADD COLUMN cancelled_at timestamptz`);

    // Прежнее ограничение требовало время передачи у всего, кроме READY, —
    // отменённое отправление под него не подходит.
    await queryRunner.query(
      `ALTER TABLE shipments DROP CONSTRAINT shipments_handover_has_time`,
    );
    await queryRunner.query(`
      ALTER TABLE shipments ADD CONSTRAINT shipments_handover_has_time CHECK (
        status IN ('READY', 'CANCELLED') OR handed_over_at IS NOT NULL
      )
    `);
    await queryRunner.query(`
      ALTER TABLE shipments ADD CONSTRAINT shipments_cancelled_has_time CHECK (
        status <> 'CANCELLED' OR cancelled_at IS NOT NULL
      )
    `);
    await queryRunner.query(`
      ALTER TABLE packages ADD CONSTRAINT packages_cancelled_has_time CHECK (
        status <> 'CANCELLED' OR cancelled_at IS NOT NULL
      )
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE packages DROP CONSTRAINT IF EXISTS packages_cancelled_has_time`,
    );
    await queryRunner.query(
      `ALTER TABLE shipments DROP CONSTRAINT IF EXISTS shipments_cancelled_has_time`,
    );
    await queryRunner.query(`ALTER TABLE packages DROP COLUMN IF EXISTS cancelled_at`);
    await queryRunner.query(`ALTER TABLE shipments DROP COLUMN IF EXISTS cancelled_at`);
    // Значения enum'а PostgreSQL удалять не умеет — они остаются.
  }
}
