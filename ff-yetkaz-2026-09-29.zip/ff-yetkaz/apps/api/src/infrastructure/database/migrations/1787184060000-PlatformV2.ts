import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Платформа v2: категории заказов, трек статусов, возвраты (RMA),
 * комбинированные тарифы по таре, права на уровне колонок и витрины для BI.
 *
 * Всё аддитивно: ни одна существующая колонка не меняет тип и не исчезает.
 * Новые значения перечислений добавлены предыдущей миграцией — здесь ими уже
 * можно пользоваться (PostgreSQL разрешает это в следующей транзакции).
 */
export class PlatformV21787184060000 implements MigrationInterface {
  name = 'PlatformV21787184060000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // =====================================================================
    // 1. Категории заказов
    // =====================================================================
    await queryRunner.query(`
      CREATE TABLE order_categories (
        id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        code        text NOT NULL UNIQUE,
        name        text NOT NULL,
        description text,
        color       text,
        sort_order  int NOT NULL DEFAULT 100,
        is_active   boolean NOT NULL DEFAULT true,
        created_at  timestamptz NOT NULL DEFAULT now(),
        updated_at  timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT order_categories_code_shape CHECK (code ~ '^[A-Z][A-Z0-9_]*$'),
        CONSTRAINT order_categories_name_not_blank CHECK (btrim(name) <> ''),
        CONSTRAINT order_categories_color_shape CHECK (color IS NULL OR color ~ '^#[0-9a-fA-F]{6}$')
      )
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_order_categories_touch BEFORE UPDATE ON order_categories
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // Категорию НЕ удаляем вместе со ссылками: заказ прошлого года не должен
    // терять разрез отчёта из-за того, что направление закрыли.
    await queryRunner.query(`
      ALTER TABLE orders
        ADD COLUMN category_id uuid REFERENCES order_categories(id) ON DELETE SET NULL
    `);
    await queryRunner.query(
      `CREATE INDEX idx_orders_category ON orders (category_id) WHERE category_id IS NOT NULL`,
    );

    await queryRunner.query(`
      INSERT INTO order_categories (code, name, description, color, sort_order) VALUES
        ('MARKETPLACE', 'Маркетплейс', 'Заказы из Uzum, Wildberries и других площадок', '#6366f1', 10),
        ('RETAIL',      'Розница',     'Прямые заказы конечных покупателей',            '#0ea5e9', 20),
        ('B2B',         'Оптовый',     'Отгрузки юридическим лицам, паллетами',         '#10b981', 30),
        ('OTHER',       'Прочее',      'Всё, что не попало в остальные категории',      '#94a3b8', 90)
      ON CONFLICT (code) DO NOTHING
    `);

    // =====================================================================
    // 2. «Расходный» — момент выдачи со склада
    // =====================================================================
    await queryRunner.query(`ALTER TABLE orders ADD COLUMN dispatched_at timestamptz`);
    await queryRunner.query(
      `CREATE INDEX idx_orders_dispatched ON orders (dispatched_at DESC) WHERE dispatched_at IS NOT NULL`,
    );

    // =====================================================================
    // 3. Трек статусов заказа
    //
    // Отдельная таблица, а не выборка из audit_events: аудит хранит разнородные
    // действия в jsonb, по нему нельзя ни отсортировать заказы по времени
    // сборки, ни построить воронку без разбора JSON на каждой строке.
    // Статусы здесь text, а не enum: это ЖУРНАЛ, он обязан пережить любую
    // будущую правку перечисления, включая переименование.
    // =====================================================================
    await queryRunner.query(`
      CREATE TABLE order_status_history (
        id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        order_id      uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        from_status   text,
        to_status     text NOT NULL,
        source        text NOT NULL DEFAULT 'system',
        actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
        comment       text,
        occurred_at   timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT order_status_history_to_not_blank CHECK (btrim(to_status) <> '')
      )
    `);
    await queryRunner.query(
      `CREATE INDEX idx_order_status_history_order ON order_status_history (order_id, occurred_at)`,
    );
    await queryRunner.query(
      `CREATE INDEX idx_order_status_history_to ON order_status_history (to_status, occurred_at DESC)`,
    );

    // Журнал append-only тем же приёмом, что и stock_movements: трек, который
    // можно переписать, ничего не доказывает.
    await queryRunner.query(`
      CREATE OR REPLACE FUNCTION ff_order_status_history_append_only() RETURNS trigger AS $$
      BEGIN
        RAISE EXCEPTION 'order_status_history — журнал только на добавление'
          USING ERRCODE = '42501';
      END;
      $$ LANGUAGE plpgsql
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_order_status_history_no_change
      BEFORE UPDATE OR DELETE ON order_status_history
      FOR EACH STATEMENT EXECUTE FUNCTION ff_order_status_history_append_only()
    `);

    // Бэкфилл: у существующих заказов трек восстанавливается из аудита, где
    // FsmService писал каждый переход. Без этого карточка старого заказа
    // показывала бы пустую историю, и трек выглядел бы сломанным.
    await queryRunner.query(`
      INSERT INTO order_status_history (order_id, from_status, to_status, source, actor_user_id, occurred_at)
      SELECT o.id,
             NULLIF(a.before ->> 'status', ''),
             a.after ->> 'status',
             COALESCE(NULLIF(a.actor_role, ''), 'audit'),
             a.actor_user_id,
             a.occurred_at
      FROM audit_events a
      JOIN orders o ON o.id::text = a.entity_id
      WHERE a.action = 'STATE_TRANSITION'
        AND lower(a.entity_type) IN ('order', 'orders')
        AND a.after ->> 'status' IS NOT NULL
    `);
    // …и точка отсчёта: сам факт появления заказа.
    await queryRunner.query(`
      INSERT INTO order_status_history (order_id, from_status, to_status, source, actor_user_id, occurred_at)
      SELECT o.id, NULL, 'NEW', 'backfill', o.created_by, o.created_at
      FROM orders o
      WHERE NOT EXISTS (
        SELECT 1 FROM order_status_history h WHERE h.order_id = o.id AND h.from_status IS NULL
      )
    `);

    // =====================================================================
    // 4. Возвраты (обратная логистика)
    // =====================================================================
    await queryRunner.query(`
      CREATE TYPE return_status AS ENUM ('ACCEPTED', 'IN_STORAGE', 'MOVING', 'COMPLETED', 'CANCELLED')
    `);
    await queryRunner.query(`
      CREATE TYPE return_condition AS ENUM ('GOOD', 'DAMAGED')
    `);
    await queryRunner.query(`CREATE SEQUENCE return_no_seq START 1`);

    await queryRunner.query(`
      CREATE TABLE returns (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        return_no    text NOT NULL UNIQUE
                     DEFAULT ('RMA' || lpad(nextval('return_no_seq')::text, 9, '0')),
        status       return_status NOT NULL DEFAULT 'ACCEPTED',
        seller_id    uuid NOT NULL REFERENCES sellers(id) ON DELETE RESTRICT,
        warehouse_id uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        order_id     uuid REFERENCES orders(id) ON DELETE RESTRICT,
        reason       text NOT NULL,
        comment      text,
        created_by   uuid REFERENCES users(id) ON DELETE SET NULL,
        created_at   timestamptz NOT NULL DEFAULT now(),
        updated_at   timestamptz NOT NULL DEFAULT now(),
        completed_at timestamptz,
        CONSTRAINT returns_completed_has_time
          CHECK (status <> 'COMPLETED' OR completed_at IS NOT NULL)
      )
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_returns_touch BEFORE UPDATE ON returns
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);
    await queryRunner.query(
      `CREATE INDEX idx_returns_seller ON returns (seller_id, created_at DESC)`,
    );
    await queryRunner.query(`CREATE INDEX idx_returns_status ON returns (status, created_at DESC)`);
    await queryRunner.query(
      `CREATE INDEX idx_returns_order ON returns (order_id) WHERE order_id IS NOT NULL`,
    );

    await queryRunner.query(`
      CREATE TABLE return_items (
        id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        return_id          uuid NOT NULL REFERENCES returns(id) ON DELETE CASCADE,
        sku_id             uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        quantity           int NOT NULL,
        condition          return_condition NOT NULL DEFAULT 'GOOD',
        restocked_quantity int NOT NULL DEFAULT 0,
        bin_id             uuid REFERENCES bin_locations(id) ON DELETE SET NULL,
        CONSTRAINT return_items_quantity_positive CHECK (quantity > 0),
        CONSTRAINT return_items_restocked_sane
          CHECK (restocked_quantity >= 0 AND restocked_quantity <= quantity)
      )
    `);
    // Один SKU — одна строка возврата: две строки на один артикул означали бы,
    // что «сколько всего вернулось» зависит от порядка ввода.
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_return_items_sku ON return_items (return_id, sku_id)`,
    );

    await queryRunner.query(`
      CREATE TABLE return_status_history (
        id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        return_id     uuid NOT NULL REFERENCES returns(id) ON DELETE CASCADE,
        from_status   text,
        to_status     text NOT NULL,
        actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
        comment       text,
        occurred_at   timestamptz NOT NULL DEFAULT now()
      )
    `);
    await queryRunner.query(
      `CREATE INDEX idx_return_status_history ON return_status_history (return_id, occurred_at)`,
    );

    // =====================================================================
    // 5. Тарифы: тара и комбинирование
    // =====================================================================
    // Сколько единиц в коробке и на паллете. Считаемая величина, а не
    // вводимая кладовщиком: склад считает штуки, и требовать от него ещё и
    // число коробок значит гарантированно получить расхождение в счёте.
    await queryRunner.query(`
      ALTER TABLE skus
        ADD COLUMN units_per_box    int,
        ADD COLUMN units_per_pallet int,
        ADD CONSTRAINT skus_units_per_box_positive
          CHECK (units_per_box IS NULL OR units_per_box > 0),
        ADD CONSTRAINT skus_units_per_pallet_positive
          CHECK (units_per_pallet IS NULL OR units_per_pallet > 0)
    `);

    // Составляющая цены. 'BASE' — то, что до сих пор было единственной строкой,
    // поэтому существующие правила получают именно её и ничего не меняется.
    await queryRunner.query(`
      ALTER TABLE tariff_rules
        ADD COLUMN component text NOT NULL DEFAULT 'BASE',
        ADD CONSTRAINT tariff_rules_component_shape CHECK (component ~ '^[A-Z][A-Z0-9_]*$')
    `);
    await queryRunner.query(`DROP INDEX IF EXISTS uq_tariff_rules_step`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_tariff_rules_step
        ON tariff_rules (plan_id, kind, component, unit, min_qty, effective_from)
    `);

    // «Одна единица на составляющую» переезжает из сервиса в БД. В коде эта
    // проверка была гонкой: два одновременных POST с разными единицами оба
    // проходили SELECT и оба вставлялись, а начисление потом брало rules[0] —
    // то есть цена зависела от порядка выдачи.
    await queryRunner.query(`
      CREATE OR REPLACE FUNCTION ff_tariff_rules_single_unit() RETURNS trigger AS $$
      BEGIN
        IF EXISTS (
          SELECT 1 FROM tariff_rules r
          WHERE r.plan_id = NEW.plan_id
            AND r.kind = NEW.kind
            AND r.component = NEW.component
            AND r.unit <> NEW.unit
            AND r.id <> NEW.id
            AND (r.effective_to IS NULL OR r.effective_to >= NEW.effective_from)
            AND (NEW.effective_to IS NULL OR NEW.effective_to >= r.effective_from)
        ) THEN
          RAISE EXCEPTION
            'У составляющей % услуги % уже задана другая единица тарификации', NEW.component, NEW.kind
            USING ERRCODE = '23505';
        END IF;
        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_tariff_rules_single_unit
      BEFORE INSERT OR UPDATE ON tariff_rules
      FOR EACH ROW EXECUTE FUNCTION ff_tariff_rules_single_unit()
    `);

    // Срез хранения обзаводится тарой: без неё «хранение за паллето-сутки»
    // считать не из чего.
    await queryRunner.query(`
      ALTER TABLE storage_snapshots
        ADD COLUMN boxes   numeric(14,3) NOT NULL DEFAULT 0,
        ADD COLUMN pallets numeric(14,3) NOT NULL DEFAULT 0
    `);

    // =====================================================================
    // 6. Права на уровне колонок
    // =====================================================================
    await queryRunner.query(`
      CREATE TABLE field_permissions (
        id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        role       ff_role NOT NULL,
        entity     text NOT NULL,
        field      text NOT NULL,
        can_view   boolean NOT NULL DEFAULT true,
        can_edit   boolean NOT NULL DEFAULT true,
        can_delete boolean NOT NULL DEFAULT false,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT field_permissions_entity_not_blank CHECK (btrim(entity) <> ''),
        CONSTRAINT field_permissions_field_not_blank CHECK (btrim(field) <> '')
      )
    `);
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_field_permissions ON field_permissions (role, entity, field)`,
    );
    await queryRunner.query(`
      CREATE TRIGGER trg_field_permissions_touch BEFORE UPDATE ON field_permissions
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // Стартовый набор намеренно узкий: «склад не видит деньги». Всё остальное
    // остаётся открытым — матрица, которая с первого дня что-то ломает,
    // выключается администратором целиком и больше не используется.
    await queryRunner.query(`
      INSERT INTO field_permissions (role, entity, field, can_view, can_edit, can_delete) VALUES
        ('PICKER',   'order', 'codAmount', false, false, false),
        ('PICKER',   'order', 'currency',  false, false, false),
        ('PACKER',   'order', 'codAmount', false, false, false),
        ('PACKER',   'order', 'currency',  false, false, false),
        ('RECEIVER', 'order', 'codAmount', false, false, false),
        ('RECEIVER', 'order', 'currency',  false, false, false)
      ON CONFLICT (role, entity, field) DO NOTHING
    `);

    // =====================================================================
    // 7. Индексы под новые списки, фильтры и поиск
    // =====================================================================
    await queryRunner.query(
      `CREATE INDEX idx_orders_seller_created ON orders (seller_id, created_at DESC)`,
    );
    await queryRunner.query(`CREATE INDEX idx_orders_created ON orders (created_at DESC)`);

    // Дата поступления для витрины остатков берётся из журнала. Без этого
    // индекса поиск «когда приехал этот срез» превращается в чтение всего
    // журнала — и именно он становится самой дорогой частью экрана остатков.
    await queryRunner.query(`
      CREATE INDEX idx_movements_inbound
        ON stock_movements (sku_id, warehouse_id, to_bin_id, to_status, occurred_at)
        WHERE reason IN ('RECEIPT', 'PUTAWAY')
    `);

    // Триграммы дают быстрый поиск подстрокой. Расширение может быть недоступно
    // на урезанной инсталляции — тогда поиск просто останется последовательным,
    // и это не повод валить миграцию.
    await queryRunner.query(`
      DO $$
      BEGIN
        CREATE EXTENSION IF NOT EXISTS pg_trgm;
      EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'pg_trgm недоступен: поиск будет без триграммных индексов';
      END
      $$
    `);
    await queryRunner.query(`
      DO $$
      BEGIN
        IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_trgm') THEN
          EXECUTE 'CREATE INDEX IF NOT EXISTS idx_orders_trgm_recipient ON orders USING gin (recipient_name gin_trgm_ops)';
          EXECUTE 'CREATE INDEX IF NOT EXISTS idx_orders_trgm_external ON orders USING gin (external_id gin_trgm_ops)';
          EXECUTE 'CREATE INDEX IF NOT EXISTS idx_orders_trgm_phone ON orders USING gin (recipient_phone gin_trgm_ops)';
          EXECUTE 'CREATE INDEX IF NOT EXISTS idx_skus_trgm_name ON skus USING gin (name gin_trgm_ops)';
          EXECUTE 'CREATE INDEX IF NOT EXISTS idx_skus_trgm_code ON skus USING gin (sku_code gin_trgm_ops)';
        END IF;
      END
      $$
    `);

    // =====================================================================
    // 8. Витрины для внешнего BI (Metabase / Superset)
    //
    // Представления, а не выгрузки: аналитик подключается к базе только на
    // чтение и видит плоские факты с уже разрешёнными связями. Без них первый
    // же дашборд снаружи начнётся с самостоятельных JOIN'ов по шести таблицам
    // и разойдётся с цифрами внутри системы.
    // =====================================================================
    await queryRunner.query(`
      CREATE OR REPLACE VIEW bi_orders AS
      SELECT
        o.id                                   AS order_id,
        o.order_code,
        o.external_id,
        o.channel,
        o.status::text                         AS status,
        o.seller_id,
        s.code                                 AS seller_code,
        s.legal_name                           AS seller_name,
        o.warehouse_id,
        w.code                                 AS warehouse_code,
        o.category_id,
        c.code                                 AS category_code,
        c.name                                 AS category_name,
        o.region,
        o.is_split,
        o.has_shortage,
        o.cod_amount,
        o.currency,
        o.weight_kg,
        o.created_at,
        o.dispatched_at,
        sh.handed_over_at,
        sh.delivered_at,
        sh.cod_collected_amount,
        sh.tracking_no,
        COALESCE(li.units, 0)                  AS units,
        COALESCE(li.lines_count, 0)            AS lines_count
      FROM orders o
      JOIN sellers s ON s.id = o.seller_id
      LEFT JOIN warehouses w ON w.id = o.warehouse_id
      LEFT JOIN order_categories c ON c.id = o.category_id
      LEFT JOIN shipments sh ON sh.order_id = o.id
      LEFT JOIN LATERAL (
        SELECT SUM(ol.quantity)::int AS units, COUNT(*)::int AS lines_count
        FROM order_lines ol WHERE ol.order_id = o.id
      ) li ON true
    `);

    await queryRunner.query(`
      CREATE OR REPLACE VIEW bi_order_status_history AS
      SELECT
        h.id,
        h.order_id,
        o.order_code,
        o.seller_id,
        h.from_status,
        h.to_status,
        h.source,
        h.occurred_at,
        EXTRACT(EPOCH FROM (
          h.occurred_at - LAG(h.occurred_at) OVER (PARTITION BY h.order_id ORDER BY h.occurred_at)
        ))::bigint AS seconds_in_previous_status
      FROM order_status_history h
      JOIN orders o ON o.id = h.order_id
    `);

    await queryRunner.query(`
      CREATE OR REPLACE VIEW bi_stock AS
      SELECT
        st.sku_id,
        sk.sku_code,
        sk.name             AS sku_name,
        sk.seller_id,
        s.code              AS seller_code,
        s.legal_name        AS seller_name,
        st.warehouse_id,
        w.code              AS warehouse_code,
        b.code              AS bin_code,
        b.kind::text        AS bin_kind,
        st.lot_id,
        l.lot_code,
        l.expiry_date,
        st.status::text     AS status,
        st.quantity,
        sk.weight_g,
        sk.volume_mm3,
        sk.units_per_box,
        sk.units_per_pallet,
        st.updated_at
      FROM stock st
      JOIN skus sk ON sk.id = st.sku_id
      JOIN sellers s ON s.id = sk.seller_id
      JOIN warehouses w ON w.id = st.warehouse_id
      JOIN bin_locations b ON b.id = st.bin_id
      LEFT JOIN lots l ON l.id = st.lot_id
      WHERE st.quantity > 0
    `);

    await queryRunner.query(`
      CREATE OR REPLACE VIEW bi_returns AS
      SELECT
        r.id                AS return_id,
        r.return_no,
        r.status::text      AS status,
        r.seller_id,
        s.code              AS seller_code,
        s.legal_name        AS seller_name,
        r.warehouse_id,
        w.code              AS warehouse_code,
        r.order_id,
        o.order_code,
        r.reason,
        r.created_at,
        r.completed_at,
        COALESCE(it.quantity, 0)  AS total_quantity,
        COALESCE(it.restocked, 0) AS total_restocked,
        COALESCE(it.damaged, 0)   AS damaged_quantity
      FROM returns r
      JOIN sellers s ON s.id = r.seller_id
      JOIN warehouses w ON w.id = r.warehouse_id
      LEFT JOIN orders o ON o.id = r.order_id
      LEFT JOIN LATERAL (
        SELECT SUM(i.quantity)::int AS quantity,
               SUM(i.restocked_quantity)::int AS restocked,
               SUM(CASE WHEN i.condition = 'DAMAGED' THEN i.quantity ELSE 0 END)::int AS damaged
        FROM return_items i WHERE i.return_id = r.id
      ) it ON true
    `);

    // Дни без событий в витрине отсутствуют намеренно: это таблица фактов,
    // а календарь BI-инструмент добавляет своим измерением дат.
    await queryRunner.query(`
      CREATE OR REPLACE VIEW bi_seller_daily AS
      SELECT
        t.seller_id,
        s.code       AS seller_code,
        s.legal_name AS seller_name,
        t.day,
        SUM(t.orders)::int        AS orders,
        SUM(t.units)::int         AS units,
        SUM(t.delivered)::int     AS delivered,
        SUM(t.cancelled)::int     AS cancelled,
        SUM(t.returns_count)::int AS returns_count,
        SUM(t.returned_units)::int AS returned_units,
        SUM(t.revenue)::numeric(14,2) AS revenue,
        SUM(t.stock_units)::int   AS stock_units,
        SUM(t.pallets)::numeric(14,3) AS stock_pallets
      FROM (
        SELECT o.seller_id, o.created_at::date AS day,
               COUNT(*) AS orders,
               COALESCE(SUM((SELECT SUM(ol.quantity) FROM order_lines ol WHERE ol.order_id = o.id)), 0) AS units,
               COUNT(*) FILTER (WHERE o.status = 'DELIVERED') AS delivered,
               COUNT(*) FILTER (WHERE o.status = 'CANCELLED') AS cancelled,
               0 AS returns_count, 0 AS returned_units,
               0 AS revenue, 0 AS stock_units, 0 AS pallets
        FROM orders o
        WHERE o.is_split = false
        GROUP BY 1, 2

        UNION ALL

        SELECT r.seller_id, r.created_at::date,
               0, 0, 0, 0,
               COUNT(*) AS returns_count,
               COALESCE(SUM((SELECT SUM(i.quantity) FROM return_items i WHERE i.return_id = r.id)), 0) AS returned_units,
               0, 0, 0
        FROM returns r
        WHERE r.status <> 'CANCELLED'
        GROUP BY 1, 2

        UNION ALL

        SELECT ch.seller_id, ch.occurred_at::date,
               0, 0, 0, 0, 0, 0,
               SUM(ch.amount) AS revenue,
               0, 0
        FROM charges ch
        GROUP BY 1, 2

        UNION ALL

        SELECT ss.seller_id, ss.snapshot_date,
               0, 0, 0, 0, 0, 0, 0,
               ss.units, ss.pallets
        FROM storage_snapshots ss
      ) t
      JOIN sellers s ON s.id = t.seller_id
      GROUP BY t.seller_id, s.code, s.legal_name, t.day
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP VIEW IF EXISTS bi_seller_daily`);
    await queryRunner.query(`DROP VIEW IF EXISTS bi_returns`);
    await queryRunner.query(`DROP VIEW IF EXISTS bi_stock`);
    await queryRunner.query(`DROP VIEW IF EXISTS bi_order_status_history`);
    await queryRunner.query(`DROP VIEW IF EXISTS bi_orders`);

    await queryRunner.query(`DROP INDEX IF EXISTS idx_skus_trgm_code`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_skus_trgm_name`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_orders_trgm_phone`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_orders_trgm_external`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_orders_trgm_recipient`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_movements_inbound`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_orders_created`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_orders_seller_created`);

    await queryRunner.query(`DROP TABLE IF EXISTS field_permissions`);

    await queryRunner.query(`ALTER TABLE storage_snapshots DROP COLUMN IF EXISTS pallets`);
    await queryRunner.query(`ALTER TABLE storage_snapshots DROP COLUMN IF EXISTS boxes`);
    await queryRunner.query(
      `DROP TRIGGER IF EXISTS trg_tariff_rules_single_unit ON tariff_rules`,
    );
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_tariff_rules_single_unit()`);
    await queryRunner.query(`DROP INDEX IF EXISTS uq_tariff_rules_step`);
    await queryRunner.query(`ALTER TABLE tariff_rules DROP COLUMN IF EXISTS component`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_tariff_rules_step
        ON tariff_rules (plan_id, kind, unit, min_qty, effective_from)
    `);
    await queryRunner.query(`ALTER TABLE skus DROP COLUMN IF EXISTS units_per_pallet`);
    await queryRunner.query(`ALTER TABLE skus DROP COLUMN IF EXISTS units_per_box`);

    await queryRunner.query(`DROP TABLE IF EXISTS return_status_history`);
    await queryRunner.query(`DROP TABLE IF EXISTS return_items`);
    await queryRunner.query(`DROP TABLE IF EXISTS returns`);
    await queryRunner.query(`DROP SEQUENCE IF EXISTS return_no_seq`);
    await queryRunner.query(`DROP TYPE IF EXISTS return_condition`);
    await queryRunner.query(`DROP TYPE IF EXISTS return_status`);

    await queryRunner.query(
      `DROP TRIGGER IF EXISTS trg_order_status_history_no_change ON order_status_history`,
    );
    await queryRunner.query(`DROP TABLE IF EXISTS order_status_history`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_order_status_history_append_only()`);

    await queryRunner.query(`ALTER TABLE orders DROP COLUMN IF EXISTS dispatched_at`);
    await queryRunner.query(`ALTER TABLE orders DROP COLUMN IF EXISTS category_id`);
    await queryRunner.query(`DROP TABLE IF EXISTS order_categories`);
  }
}
