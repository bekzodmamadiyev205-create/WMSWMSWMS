import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 1.6 — конфигурация переезжает в БД.
 *
 * Пороги, адреса интеграций и тарифы — это данные, а не код: менять их должен
 * оператор через интерфейс, не пересобирая и не передеплоивая сервис. В коде
 * остаются только значения по умолчанию на случай пустой таблицы.
 *
 * Секреты в БД НЕ хранятся: у перевозчика лежит имя переменной окружения, из
 * которой сервис берёт ключ. Дамп базы не должен утаскивать за собой доступы.
 */
export class Configuration1786492800000 implements MigrationInterface {
  name = 'Configuration1786492800000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TYPE setting_value_type AS ENUM ('number', 'string', 'boolean', 'json')
    `);

    await queryRunner.query(`
      CREATE TABLE app_settings (
        key         text PRIMARY KEY,
        value       jsonb NOT NULL,
        value_type  setting_value_type NOT NULL,
        description text NOT NULL,
        updated_by  uuid,
        updated_at  timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT app_settings_key_shape CHECK (key ~ '^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$'),
        -- Тип и значение обязаны совпадать: иначе конфиг превращается в свалку,
        -- где число внезапно оказывается строкой.
        CONSTRAINT app_settings_value_matches_type CHECK (
          (value_type = 'number'  AND jsonb_typeof(value) = 'number')
          OR (value_type = 'string'  AND jsonb_typeof(value) = 'string')
          OR (value_type = 'boolean' AND jsonb_typeof(value) = 'boolean')
          OR (value_type = 'json'    AND jsonb_typeof(value) IN ('object', 'array'))
        )
      )
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_app_settings_touch BEFORE UPDATE ON app_settings
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // Только технические пороги и то, что прямо задано в ТЗ (допуск ±5%).
    // Коммерческие величины — тарифы, сроки, скидки — сюда не выдумываются.
    await queryRunner.query(`
      INSERT INTO app_settings (key, value, value_type, description) VALUES
        ('packing.weight_tolerance_pct', '5'::jsonb, 'number',
         'Допустимое отклонение фактического веса от расчётного, %'),
        ('integration.outbox_max_attempts', '8'::jsonb, 'number',
         'Сколько раз пытаться доставить исходящее сообщение перед пометкой FAILED'),
        ('integration.outbox_backoff_base_seconds', '15'::jsonb, 'number',
         'База экспоненциального бэкоффа между попытками доставки, сек'),
        ('integration.outbox_batch_size', '25'::jsonb, 'number',
         'Сколько сообщений разбирать за один проход диспетчера'),
        ('integration.webhook_tolerance_seconds', '300'::jsonb, 'number',
         'Допустимый возраст подписи входящего вебхука, сек (защита от повтора)')
    `);

    await queryRunner.query(`
      CREATE TABLE carriers (
        id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        code           text NOT NULL UNIQUE,
        name           text NOT NULL,
        base_url       text NOT NULL,
        handoff_path   text NOT NULL DEFAULT '/api/ff/shipments',
        timeout_ms     int  NOT NULL DEFAULT 10000,
        -- Не сам секрет, а имя переменной окружения с ним.
        secret_env_key text NOT NULL,
        is_active      boolean NOT NULL DEFAULT false,
        created_at     timestamptz NOT NULL DEFAULT now(),
        updated_at     timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT carriers_timeout_sane CHECK (timeout_ms BETWEEN 1000 AND 120000),
        CONSTRAINT carriers_base_url_shape CHECK (base_url ~ '^https?://'),
        CONSTRAINT carriers_secret_env_shape CHECK (secret_env_key ~ '^[A-Z][A-Z0-9_]*$')
      )
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_carriers_touch BEFORE UPDATE ON carriers
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // Заготовка выключена: адрес и секрет прописывает оператор перед включением.
    await queryRunner.query(`
      INSERT INTO carriers (code, name, base_url, secret_env_key, is_active)
      VALUES ('IPOST_GO', 'iPost GO (last-mile)', 'http://localhost:8080',
              'FF_IPOST_GO_SECRET', false)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS carriers`);
    await queryRunner.query(`DROP TABLE IF EXISTS app_settings`);
    await queryRunner.query(`DROP TYPE IF EXISTS setting_value_type`);
  }
}
