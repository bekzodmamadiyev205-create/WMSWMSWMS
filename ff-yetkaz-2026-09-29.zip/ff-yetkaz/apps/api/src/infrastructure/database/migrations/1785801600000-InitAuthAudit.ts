import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 0.1 — auth, аудит, идемпотентность.
 *
 * Три инварианта вынесены в БД, а не оставлены только в коде:
 *  1. `audit_events` append-only — триггер, а не гранты: владелец схемы гранты обходит.
 *  2. seller_id ровно у роли SELLER — отложенный constraint-триггер, потому что
 *     пользователь и его роли пишутся разными INSERT'ами в одной транзакции.
 *  3. уникальность email по lower(email) — регистр в почте не должен плодить дубли.
 */
export class InitAuthAudit1785801600000 implements MigrationInterface {
  name = 'InitAuthAudit1785801600000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TYPE ff_role AS ENUM (
        'ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER', 'PACKER', 'FINANCE', 'SELLER'
      )
    `);

    await queryRunner.query(`
      CREATE FUNCTION ff_touch_updated_at() RETURNS trigger AS $$
      BEGIN
        NEW.updated_at = now();
        RETURN NEW;
      END
      $$ LANGUAGE plpgsql
    `);

    // --- sellers -----------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE sellers (
        id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        code       text NOT NULL,
        legal_name text NOT NULL,
        is_active  boolean NOT NULL DEFAULT true,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT sellers_code_not_blank CHECK (length(btrim(code)) > 0)
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX uq_sellers_code ON sellers (lower(code))`);
    await queryRunner.query(`
      CREATE TRIGGER trg_sellers_touch BEFORE UPDATE ON sellers
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // --- users / user_roles ------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE users (
        id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        email         text NOT NULL,
        password_hash text NOT NULL,
        full_name     text NOT NULL,
        is_active     boolean NOT NULL DEFAULT true,
        seller_id     uuid REFERENCES sellers(id) ON DELETE RESTRICT,
        created_at    timestamptz NOT NULL DEFAULT now(),
        updated_at    timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT users_email_shape CHECK (position('@' in email) > 1)
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX uq_users_email ON users (lower(email))`);
    await queryRunner.query(
      `CREATE INDEX idx_users_seller ON users (seller_id) WHERE seller_id IS NOT NULL`,
    );
    await queryRunner.query(`
      CREATE TRIGGER trg_users_touch BEFORE UPDATE ON users
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE user_roles (
        user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        role    ff_role NOT NULL,
        PRIMARY KEY (user_id, role)
      )
    `);

    // Инвариант области видимости: seller_id есть тогда и только тогда,
    // когда у пользователя есть роль SELLER.
    await queryRunner.query(`
      CREATE FUNCTION ff_assert_seller_scope(p_user_id uuid) RETURNS void AS $$
      DECLARE
        v_seller_id uuid;
        v_is_seller boolean;
      BEGIN
        SELECT seller_id INTO v_seller_id FROM users WHERE id = p_user_id;
        IF NOT FOUND THEN
          RETURN;  -- пользователь удалён в этой же транзакции
        END IF;

        SELECT EXISTS (
          SELECT 1 FROM user_roles WHERE user_id = p_user_id AND role = 'SELLER'
        ) INTO v_is_seller;

        IF v_is_seller AND v_seller_id IS NULL THEN
          RAISE EXCEPTION 'Роль SELLER требует seller_id (user %)', p_user_id
            USING ERRCODE = '23514';
        END IF;

        IF NOT v_is_seller AND v_seller_id IS NOT NULL THEN
          RAISE EXCEPTION 'seller_id допустим только для роли SELLER (user %)', p_user_id
            USING ERRCODE = '23514';
        END IF;
      END
      $$ LANGUAGE plpgsql
    `);

    await queryRunner.query(`
      CREATE FUNCTION ff_trg_seller_scope_user() RETURNS trigger AS $$
      BEGIN
        PERFORM ff_assert_seller_scope(NEW.id);
        RETURN NULL;
      END
      $$ LANGUAGE plpgsql
    `);
    await queryRunner.query(`
      CREATE FUNCTION ff_trg_seller_scope_role() RETURNS trigger AS $$
      BEGIN
        PERFORM ff_assert_seller_scope(COALESCE(NEW.user_id, OLD.user_id));
        RETURN NULL;
      END
      $$ LANGUAGE plpgsql
    `);

    await queryRunner.query(`
      CREATE CONSTRAINT TRIGGER trg_users_seller_scope
        AFTER INSERT OR UPDATE OF seller_id ON users
        DEFERRABLE INITIALLY DEFERRED
        FOR EACH ROW EXECUTE FUNCTION ff_trg_seller_scope_user()
    `);
    await queryRunner.query(`
      CREATE CONSTRAINT TRIGGER trg_user_roles_seller_scope
        AFTER INSERT OR UPDATE OR DELETE ON user_roles
        DEFERRABLE INITIALLY DEFERRED
        FOR EACH ROW EXECUTE FUNCTION ff_trg_seller_scope_role()
    `);

    // --- audit_events ------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE audit_events (
        id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        occurred_at    timestamptz NOT NULL DEFAULT now(),
        actor_user_id  uuid,
        actor_role     text,
        entity_type    text NOT NULL,
        entity_id      text,
        action         text NOT NULL,
        before         jsonb,
        after          jsonb,
        correlation_id text,
        ip             text
      )
    `);
    await queryRunner.query(`
      CREATE INDEX idx_audit_entity ON audit_events (entity_type, entity_id, occurred_at DESC)
    `);
    await queryRunner.query(`CREATE INDEX idx_audit_occurred ON audit_events (occurred_at DESC)`);
    await queryRunner.query(`
      CREATE INDEX idx_audit_actor ON audit_events (actor_user_id, occurred_at DESC)
      WHERE actor_user_id IS NOT NULL
    `);

    await queryRunner.query(`
      CREATE FUNCTION ff_audit_events_append_only() RETURNS trigger AS $$
      BEGIN
        RAISE EXCEPTION 'audit_events — append-only, операция % запрещена', TG_OP
          USING ERRCODE = '42501';
      END
      $$ LANGUAGE plpgsql
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_audit_events_no_change BEFORE UPDATE OR DELETE ON audit_events
      FOR EACH STATEMENT EXECUTE FUNCTION ff_audit_events_append_only()
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_audit_events_no_truncate BEFORE TRUNCATE ON audit_events
      FOR EACH STATEMENT EXECUTE FUNCTION ff_audit_events_append_only()
    `);

    // --- idempotency_keys --------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE idempotency_keys (
        id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        key             text NOT NULL,
        endpoint        text NOT NULL,
        request_hash    text NOT NULL,
        status          text NOT NULL,
        response_status int,
        response_body   jsonb,
        created_at      timestamptz NOT NULL DEFAULT now(),
        completed_at    timestamptz,
        expires_at      timestamptz NOT NULL,
        CONSTRAINT idempotency_status_known CHECK (status IN ('IN_PROGRESS', 'COMPLETED')),
        CONSTRAINT idempotency_completed_has_response CHECK (
          status <> 'COMPLETED' OR (response_status IS NOT NULL AND completed_at IS NOT NULL)
        )
      )
    `);
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_idempotency_key_endpoint ON idempotency_keys (key, endpoint)`,
    );
    await queryRunner.query(`CREATE INDEX idx_idempotency_expires ON idempotency_keys (expires_at)`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS idempotency_keys`);
    await queryRunner.query(`DROP TABLE IF EXISTS audit_events`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_audit_events_append_only()`);
    await queryRunner.query(`DROP TABLE IF EXISTS user_roles`);
    await queryRunner.query(`DROP TABLE IF EXISTS users`);
    await queryRunner.query(`DROP TABLE IF EXISTS sellers`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_trg_seller_scope_role()`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_trg_seller_scope_user()`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_assert_seller_scope(uuid)`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_touch_updated_at()`);
    await queryRunner.query(`DROP TYPE IF EXISTS ff_role`);
  }
}
