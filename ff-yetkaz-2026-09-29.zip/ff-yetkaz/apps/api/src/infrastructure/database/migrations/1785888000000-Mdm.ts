import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 0.2 — MDM: склады, ячейки, SKU со штрихкодами + расширение селлера.
 *
 * Решения PM, зашитые в схему:
 *  - штрихкод уникален ГЛОБАЛЬНО (`uq_sku_barcodes_barcode`): скан однозначно
 *    даёт SKU без знания селлера. Обратная сторона — второй селлер с тем же EAN
 *    получит 409; сервис объясняет, за каким SKU код уже закреплён;
 *  - ячейка адресуется плоским кодом, без zone/aisle/rack/shelf. Порядок обхода
 *    при сборке в Phase 1 = сортировка по коду, поэтому коды должны быть с
 *    ведущими нулями (`A-01-03-02`);
 *  - срок годности живёт на партии, у SKU только политика учёта. Отсюда
 *    ограничение `skus_expiry_needs_lot`.
 */
export class Mdm1785888000000 implements MigrationInterface {
  name = 'Mdm1785888000000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // --- sellers: реквизиты ------------------------------------------------
    await queryRunner.query(`
      ALTER TABLE sellers
        ADD COLUMN tax_id        text,
        ADD COLUMN contact_email text,
        ADD COLUMN contact_phone text,
        ADD COLUMN address       text
    `);

    // --- warehouses --------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE warehouses (
        id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        code       text NOT NULL,
        name       text NOT NULL,
        address    text,
        timezone   text NOT NULL DEFAULT 'Asia/Tashkent',
        is_active  boolean NOT NULL DEFAULT true,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT warehouses_code_not_blank CHECK (length(btrim(code)) > 0),
        CONSTRAINT warehouses_tz_not_blank   CHECK (length(btrim(timezone)) > 0)
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX uq_warehouses_code ON warehouses (lower(code))`);
    await queryRunner.query(`
      CREATE TRIGGER trg_warehouses_touch BEFORE UPDATE ON warehouses
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // --- bin_locations -----------------------------------------------------
    await queryRunner.query(`
      CREATE TYPE bin_kind AS ENUM (
        'RECEIVING', 'STORAGE', 'PICKING', 'PACKING', 'QUARANTINE', 'DAMAGED', 'SHIPPING'
      )
    `);
    await queryRunner.query(`
      CREATE TABLE bin_locations (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        warehouse_id uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        code         text NOT NULL,
        kind         bin_kind NOT NULL DEFAULT 'STORAGE',
        is_active    boolean NOT NULL DEFAULT true,
        created_at   timestamptz NOT NULL DEFAULT now(),
        updated_at   timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT bin_locations_code_not_blank CHECK (length(btrim(code)) > 0)
      )
    `);
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_bin_locations_code ON bin_locations (warehouse_id, lower(code))`,
    );
    await queryRunner.query(`
      CREATE INDEX idx_bin_locations_kind ON bin_locations (warehouse_id, kind)
      WHERE is_active
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_bin_locations_touch BEFORE UPDATE ON bin_locations
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // --- skus --------------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE skus (
        id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        seller_id         uuid NOT NULL REFERENCES sellers(id) ON DELETE RESTRICT,
        sku_code          text NOT NULL,
        name              text NOT NULL,
        length_mm         int,
        width_mm          int,
        height_mm         int,
        weight_g          int,
        volume_mm3        bigint GENERATED ALWAYS AS
                            (length_mm::bigint * width_mm::bigint * height_mm::bigint) STORED,
        is_lot_tracked    boolean NOT NULL DEFAULT false,
        is_expiry_tracked boolean NOT NULL DEFAULT false,
        shelf_life_days   int,
        is_active         boolean NOT NULL DEFAULT true,
        created_at        timestamptz NOT NULL DEFAULT now(),
        updated_at        timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT skus_code_not_blank CHECK (length(btrim(sku_code)) > 0),
        CONSTRAINT skus_dims_positive CHECK (
          (length_mm IS NULL OR length_mm > 0)
          AND (width_mm  IS NULL OR width_mm  > 0)
          AND (height_mm IS NULL OR height_mm > 0)
        ),
        CONSTRAINT skus_weight_positive CHECK (weight_g IS NULL OR weight_g > 0),
        CONSTRAINT skus_shelf_life_positive CHECK (shelf_life_days IS NULL OR shelf_life_days > 0),
        -- Фактическая дата истечения живёт на партии, поэтому учёт срока
        -- невозможен без партионного учёта.
        CONSTRAINT skus_expiry_needs_lot CHECK (NOT is_expiry_tracked OR is_lot_tracked),
        CONSTRAINT skus_shelf_life_needs_expiry CHECK (shelf_life_days IS NULL OR is_expiry_tracked)
      )
    `);
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_skus_seller_code ON skus (seller_id, lower(sku_code))`,
    );
    await queryRunner.query(`CREATE INDEX idx_skus_seller ON skus (seller_id) WHERE is_active`);
    await queryRunner.query(`
      CREATE TRIGGER trg_skus_touch BEFORE UPDATE ON skus
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // --- sku_barcodes ------------------------------------------------------
    await queryRunner.query(
      `CREATE TYPE barcode_kind AS ENUM ('EAN13', 'EAN8', 'UPC', 'CODE128', 'INTERNAL')`,
    );
    await queryRunner.query(`
      CREATE TABLE sku_barcodes (
        id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        sku_id     uuid NOT NULL REFERENCES skus(id) ON DELETE CASCADE,
        barcode    text NOT NULL,
        kind       barcode_kind NOT NULL DEFAULT 'INTERNAL',
        is_primary boolean NOT NULL DEFAULT false,
        created_at timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT sku_barcodes_not_blank CHECK (length(btrim(barcode)) > 0)
      )
    `);
    // Решение PM: глобальная уникальность штрихкода.
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_sku_barcodes_barcode ON sku_barcodes (barcode)`,
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_sku_barcodes_primary ON sku_barcodes (sku_id) WHERE is_primary`,
    );
    await queryRunner.query(`CREATE INDEX idx_sku_barcodes_sku ON sku_barcodes (sku_id)`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS sku_barcodes`);
    await queryRunner.query(`DROP TYPE IF EXISTS barcode_kind`);
    await queryRunner.query(`DROP TABLE IF EXISTS skus`);
    await queryRunner.query(`DROP TABLE IF EXISTS bin_locations`);
    await queryRunner.query(`DROP TYPE IF EXISTS bin_kind`);
    await queryRunner.query(`DROP TABLE IF EXISTS warehouses`);
    await queryRunner.query(`
      ALTER TABLE sellers
        DROP COLUMN IF EXISTS tax_id,
        DROP COLUMN IF EXISTS contact_email,
        DROP COLUMN IF EXISTS contact_phone,
        DROP COLUMN IF EXISTS address
    `);
  }
}
