import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 1.3 — Picking: задания на сборку.
 *
 * Строки задания рождаются из АКТИВНЫХ РЕЗЕРВОВ заказа: резерв уже знает ячейку
 * и партию, поэтому маршрут сборщика — это сортировка строк по коду ячейки.
 * Ссылка `reservation_id` обязательна: по мере сборки резерв надо гасить,
 * иначе отмена заказа попыталась бы вернуть в AVAILABLE то, что уже собрано.
 */
export class Picking1786233600000 implements MigrationInterface {
  name = 'Picking1786233600000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TYPE pick_task_status AS ENUM (
        'NEW', 'ASSIGNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'
      )
    `);
    await queryRunner.query(`CREATE TYPE pick_task_kind AS ENUM ('SINGLE', 'BATCH')`);
    await queryRunner.query(`CREATE TYPE pick_line_status AS ENUM ('PENDING', 'PICKED', 'SHORT')`);

    await queryRunner.query(`
      CREATE TABLE pick_tasks (
        id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        warehouse_id     uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        kind             pick_task_kind NOT NULL DEFAULT 'SINGLE',
        status           pick_task_status NOT NULL DEFAULT 'NEW',
        assignee_user_id uuid,
        created_by       uuid,
        started_at       timestamptz,
        completed_at     timestamptz,
        created_at       timestamptz NOT NULL DEFAULT now(),
        updated_at       timestamptz NOT NULL DEFAULT now(),
        -- Взятое в работу задание обязано иметь исполнителя.
        CONSTRAINT pick_tasks_started_has_assignee CHECK (
          status IN ('NEW', 'CANCELLED') OR assignee_user_id IS NOT NULL
        )
      )
    `);
    await queryRunner.query(`
      CREATE INDEX idx_pick_tasks_assignee ON pick_tasks (assignee_user_id, status)
      WHERE assignee_user_id IS NOT NULL
    `);
    await queryRunner.query(`
      CREATE INDEX idx_pick_tasks_warehouse ON pick_tasks (warehouse_id, status)
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_pick_tasks_touch BEFORE UPDATE ON pick_tasks
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE pick_task_orders (
        task_id  uuid NOT NULL REFERENCES pick_tasks(id) ON DELETE CASCADE,
        order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
        PRIMARY KEY (task_id, order_id)
      )
    `);
    // Заказ не может одновременно собираться в двух заданиях.
    await queryRunner.query(
      `CREATE UNIQUE INDEX uq_pick_task_orders_order ON pick_task_orders (order_id)`,
    );

    await queryRunner.query(`
      CREATE TABLE pick_task_lines (
        id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        task_id        uuid NOT NULL REFERENCES pick_tasks(id) ON DELETE CASCADE,
        order_id       uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
        sku_id         uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        bin_id         uuid NOT NULL REFERENCES bin_locations(id) ON DELETE RESTRICT,
        lot_id         uuid REFERENCES lots(id) ON DELETE RESTRICT,
        reservation_id uuid NOT NULL REFERENCES reservations(id) ON DELETE RESTRICT,
        qty_requested  int NOT NULL,
        qty_picked     int NOT NULL DEFAULT 0,
        status         pick_line_status NOT NULL DEFAULT 'PENDING',
        created_at     timestamptz NOT NULL DEFAULT now(),
        updated_at     timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT pick_lines_qty_positive CHECK (qty_requested > 0),
        -- Собрать больше, чем зарезервировано, физически невозможно.
        CONSTRAINT pick_lines_picked_fits CHECK (qty_picked >= 0 AND qty_picked <= qty_requested),
        CONSTRAINT pick_lines_done_is_full CHECK (status <> 'PICKED' OR qty_picked = qty_requested)
      )
    `);
    await queryRunner.query(`CREATE INDEX idx_pick_lines_task ON pick_task_lines (task_id)`);
    await queryRunner.query(`CREATE INDEX idx_pick_lines_order ON pick_task_lines (order_id)`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS pick_task_lines`);
    await queryRunner.query(`DROP TABLE IF EXISTS pick_task_orders`);
    await queryRunner.query(`DROP TABLE IF EXISTS pick_tasks`);
    await queryRunner.query(`DROP TYPE IF EXISTS pick_line_status`);
    await queryRunner.query(`DROP TYPE IF EXISTS pick_task_kind`);
    await queryRunner.query(`DROP TYPE IF EXISTS pick_task_status`);
  }
}
