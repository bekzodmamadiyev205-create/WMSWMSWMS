import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Возврат — тоже поступление. Приёмка возврата пишет движение с причиной
 * `RETURN`, а частичный индекс `idx_movements_inbound` знал только `RECEIPT`
 * и `PUTAWAY`. Витрина остатков берёт дату поступления из журнала по этому же
 * набору причин, поэтому у принятого возврата обе даты оставались пустыми, и
 * фильтр по периоду выбрасывал строку: товар, принятый сегодня, не был виден
 * в отчёте за сегодня.
 *
 * Индекс пересоздаётся ТОЛЬКО ради предиката — набор колонок прежний.
 *
 * ПРЕДИКАТ ОБЯЗАН ДОСЛОВНО СОВПАДАТЬ с условием в
 * `StockTableService.buildSource` (`m.reason IN ('RECEIPT', 'PUTAWAY', 'RETURN')`).
 * Частичный индекс планировщик применяет, только если ДОКАЗАЛ, что условие
 * запроса влечёт предикат индекса. Разойдись они хоть на одно значение —
 * ошибки не будет: индекс просто молча перестанет применяться, и самая дорогая
 * часть экрана остатков превратится в последовательное чтение всего журнала
 * движений. Меняешь список причин здесь — меняй и там, и наоборот.
 *
 * Значение `RETURN` добавлено в enum `movement_reason` миграцией
 * `PlatformV2Enums1787184000000`, то есть давно закоммичено — пользоваться им
 * в предикате можно (в одной транзакции с `ADD VALUE` было бы нельзя).
 */
export class StockReturnIndex1787270400000 implements MigrationInterface {
  name = 'StockReturnIndex1787270400000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS idx_movements_inbound`);
    await queryRunner.query(`
      CREATE INDEX idx_movements_inbound
        ON stock_movements (sku_id, warehouse_id, to_bin_id, to_status, occurred_at)
        WHERE reason IN ('RECEIPT', 'PUTAWAY', 'RETURN')
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS idx_movements_inbound`);
    await queryRunner.query(`
      CREATE INDEX idx_movements_inbound
        ON stock_movements (sku_id, warehouse_id, to_bin_id, to_status, occurred_at)
        WHERE reason IN ('RECEIPT', 'PUTAWAY')
    `);
  }
}
