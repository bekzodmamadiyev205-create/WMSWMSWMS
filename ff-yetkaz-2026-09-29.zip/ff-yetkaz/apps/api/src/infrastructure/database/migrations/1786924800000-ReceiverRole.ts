import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Отдельная роль RECEIVER — «приёмщик»: делает только приём (склад через ТСД),
 * не видит сборку/упаковку/заказы. Изменение строго аддитивное — новое значение
 * enum'а `ff_role`, ничего существующего не переписывается.
 *
 * Заказов и статусов не касается: приёмщик ходит по тем же эндпоинтам приёмки,
 * что и оператор склада, и через те же статусные машины ASN/приёмки. Меняется
 * только список ролей в `@Roles` и в меню фронта, не бизнес-логика.
 */
export class ReceiverRole1786924800000 implements MigrationInterface {
  name = 'ReceiverRole1786924800000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // PostgreSQL 12+ разрешает ADD VALUE внутри транзакции; пользоваться новым
    // значением можно только после коммита — здесь мы его и не используем.
    await queryRunner.query(`ALTER TYPE ff_role ADD VALUE IF NOT EXISTS 'RECEIVER'`);
  }

  public async down(): Promise<void> {
    // Значения enum'а PostgreSQL удалять не умеет — RECEIVER остаётся в ff_role.
    // Откат — на уровне ролей пользователей (снять роль), а не типа.
  }
}
