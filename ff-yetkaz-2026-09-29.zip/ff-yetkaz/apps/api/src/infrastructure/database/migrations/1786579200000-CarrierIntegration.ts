import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 1.7 — интеграция с перевозчиком (iPost GO).
 *
 * Исходящие сообщения кладутся в `integration_outbox` В ТОЙ ЖЕ транзакции, что
 * и бизнес-факт. Иначе получается классическая рассинхронизация: отправление
 * создано, а сообщение потеряно (или наоборот — отправлено то, что откатилось).
 * Отдельный диспетчер разбирает очередь с бэкоффом.
 *
 * Входящие вебхуки записываются целиком в `webhook_deliveries` с уникальным
 * `delivery_id`: перевозчик обязан повторять доставку при таймауте, и повтор
 * не должен второй раз двигать статус.
 */
export class CarrierIntegration1786579200000 implements MigrationInterface {
  name = 'CarrierIntegration1786579200000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TYPE outbox_status AS ENUM ('PENDING', 'IN_PROGRESS', 'DELIVERED', 'FAILED')
    `);
    await queryRunner.query(`
      CREATE TYPE webhook_result AS ENUM ('ACCEPTED', 'DUPLICATE', 'REJECTED')
    `);

    await queryRunner.query(`
      CREATE TABLE integration_outbox (
        id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        carrier_code    text NOT NULL,
        topic           text NOT NULL,
        entity_type     text NOT NULL,
        entity_id       text NOT NULL,
        payload         jsonb NOT NULL,
        status          outbox_status NOT NULL DEFAULT 'PENDING',
        attempts        int NOT NULL DEFAULT 0,
        next_attempt_at timestamptz NOT NULL DEFAULT now(),
        locked_until    timestamptz,
        last_error      text,
        delivered_at    timestamptz,
        correlation_id  text,
        created_at      timestamptz NOT NULL DEFAULT now(),
        updated_at      timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT outbox_attempts_non_negative CHECK (attempts >= 0),
        CONSTRAINT outbox_delivered_has_time CHECK (
          status <> 'DELIVERED' OR delivered_at IS NOT NULL
        )
      )
    `);
    // Одно сообщение на сущность и тему: повторный вызов ставит в очередь то же
    // самое, а не плодит дубли у перевозчика.
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_outbox_topic_entity ON integration_outbox (topic, entity_id)
    `);
    // Индекс покрывает и просроченную аренду: упавший диспетчер оставляет
    // строку в IN_PROGRESS, и её должен подобрать следующий проход.
    await queryRunner.query(`
      CREATE INDEX idx_outbox_due ON integration_outbox (status, next_attempt_at, locked_until)
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_outbox_touch BEFORE UPDATE ON integration_outbox
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      CREATE TABLE webhook_deliveries (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        carrier_code text NOT NULL,
        delivery_id  text NOT NULL,
        received_at  timestamptz NOT NULL DEFAULT now(),
        payload      jsonb NOT NULL,
        result       webhook_result NOT NULL,
        error        text,
        shipment_id  uuid REFERENCES shipments(id) ON DELETE SET NULL
      )
    `);
    // Уникальность только для ПРИНЯТЫХ доставок: повтор уже применённого
    // события не должен второй раз двигать статус, а отвергнутое перевозчик
    // имеет право прислать снова — например, после починки своей подписи.
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_webhook_delivery ON webhook_deliveries (carrier_code, delivery_id)
      WHERE result = 'ACCEPTED'
    `);
    await queryRunner.query(`
      CREATE INDEX idx_webhook_deliveries_recent ON webhook_deliveries (carrier_code, received_at DESC)
    `);

    await queryRunner.query(`
      CREATE TABLE shipment_status_events (
        id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        shipment_id uuid NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
        from_status shipment_status,
        to_status   shipment_status NOT NULL,
        -- Время у перевозчика и время записи различаются: вебхук мог опоздать.
        occurred_at timestamptz NOT NULL,
        recorded_at timestamptz NOT NULL DEFAULT now(),
        source      text NOT NULL,
        comment     text,
        raw         jsonb,
        CONSTRAINT shipment_events_source CHECK (source IN ('FF', 'CARRIER'))
      )
    `);
    await queryRunner.query(`
      CREATE INDEX idx_shipment_events ON shipment_status_events (shipment_id, recorded_at DESC)
    `);

    // Подтверждение доставки и фактически собранный наложенный платёж.
    await queryRunner.query(`
      ALTER TABLE shipments
        ADD COLUMN delivered_at         timestamptz,
        ADD COLUMN pod_recipient_name   text,
        ADD COLUMN pod_signature_url    text,
        ADD COLUMN pod_photo_url        text,
        ADD COLUMN cod_collected_amount numeric(14, 2),
        ADD COLUMN cod_collected_at     timestamptz,
        ADD COLUMN failure_reason       text
    `);
    await queryRunner.query(`
      ALTER TABLE shipments ADD CONSTRAINT shipments_cod_collected_non_negative CHECK (
        cod_collected_amount IS NULL OR cod_collected_amount >= 0
      )
    `);
    // Собранная сумма без времени сбора — не факт, а слух.
    await queryRunner.query(`
      ALTER TABLE shipments ADD CONSTRAINT shipments_cod_collected_has_time CHECK (
        (cod_collected_amount IS NULL) = (cod_collected_at IS NULL)
      )
    `);
    await queryRunner.query(`
      ALTER TABLE shipments ADD CONSTRAINT shipments_delivered_has_time CHECK (
        status <> 'DELIVERED' OR delivered_at IS NOT NULL
      )
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE shipments
        DROP CONSTRAINT IF EXISTS shipments_delivered_has_time,
        DROP CONSTRAINT IF EXISTS shipments_cod_collected_has_time,
        DROP CONSTRAINT IF EXISTS shipments_cod_collected_non_negative,
        DROP COLUMN IF EXISTS delivered_at,
        DROP COLUMN IF EXISTS pod_recipient_name,
        DROP COLUMN IF EXISTS pod_signature_url,
        DROP COLUMN IF EXISTS pod_photo_url,
        DROP COLUMN IF EXISTS cod_collected_amount,
        DROP COLUMN IF EXISTS cod_collected_at,
        DROP COLUMN IF EXISTS failure_reason
    `);
    await queryRunner.query(`DROP TABLE IF EXISTS shipment_status_events`);
    await queryRunner.query(`DROP TABLE IF EXISTS webhook_deliveries`);
    await queryRunner.query(`DROP TABLE IF EXISTS integration_outbox`);
    await queryRunner.query(`DROP TYPE IF EXISTS webhook_result`);
    await queryRunner.query(`DROP TYPE IF EXISTS outbox_status`);
  }
}
