import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Этап 1.1 — Inventory: партии, остатки, журнал движений, резервы.
 *
 * Главное решение: `stock` — это ПРОЕКЦИЯ, а не источник правды. Любое изменение
 * остатка обязано быть строкой в append-only журнале `stock_movements`, поэтому
 * на вопрос «откуда взялось это количество» всегда есть ответ, а инвентаризация —
 * обычное движение с обязательной причиной.
 *
 * Остаток количественный (решение PM): строка = SKU × склад × ячейка × партия ×
 * статус. `UNIQUE NULLS NOT DISTINCT` обязателен — иначе строки с NULL-партией
 * (SKU без партионного учёта) размножатся, потому что обычный UNIQUE не считает
 * два NULL одинаковыми.
 */
export class Inventory1785974400000 implements MigrationInterface {
  name = 'Inventory1785974400000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TYPE inventory_status AS ENUM (
        'EXPECTED', 'RECEIVED', 'INSPECTED', 'AVAILABLE', 'RESERVED',
        'PICKED', 'PACKED', 'SHIPPED', 'DAMAGED', 'QUARANTINE'
      )
    `);
    await queryRunner.query(`
      CREATE TYPE movement_reason AS ENUM (
        'RECEIPT', 'PUTAWAY', 'MOVE', 'RESERVE', 'RELEASE', 'ADJUSTMENT',
        'INSPECTION', 'DAMAGE', 'PICK', 'PACK', 'SHIP', 'WRITE_OFF'
      )
    `);

    // --- lots ---------------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE lots (
        id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        sku_id      uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        lot_code    text NOT NULL,
        expiry_date date,
        received_at timestamptz NOT NULL DEFAULT now(),
        created_at  timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT lots_code_not_blank CHECK (length(btrim(lot_code)) > 0)
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX uq_lots_sku_code ON lots (sku_id, lower(lot_code))`);
    // Порядок выдачи FEFO: сначала партии с ближайшим сроком.
    await queryRunner.query(`CREATE INDEX idx_lots_expiry ON lots (sku_id, expiry_date)`);

    // --- stock --------------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE stock (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        sku_id       uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        warehouse_id uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        bin_id       uuid NOT NULL REFERENCES bin_locations(id) ON DELETE RESTRICT,
        lot_id       uuid REFERENCES lots(id) ON DELETE RESTRICT,
        status       inventory_status NOT NULL,
        quantity     int NOT NULL,
        created_at   timestamptz NOT NULL DEFAULT now(),
        updated_at   timestamptz NOT NULL DEFAULT now(),
        -- Отрицательный остаток невозможен на уровне БД, а не только в коде.
        CONSTRAINT stock_quantity_non_negative CHECK (quantity >= 0)
      )
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX uq_stock_slice ON stock
        (sku_id, warehouse_id, bin_id, lot_id, status) NULLS NOT DISTINCT
    `);
    await queryRunner.query(`
      CREATE INDEX idx_stock_lookup ON stock (sku_id, warehouse_id, status)
      WHERE quantity > 0
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_stock_touch BEFORE UPDATE ON stock
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    // --- stock_movements ----------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE stock_movements (
        id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        occurred_at    timestamptz NOT NULL DEFAULT now(),
        sku_id         uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        warehouse_id   uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        lot_id         uuid REFERENCES lots(id) ON DELETE RESTRICT,
        from_bin_id    uuid REFERENCES bin_locations(id) ON DELETE RESTRICT,
        from_status    inventory_status,
        to_bin_id      uuid REFERENCES bin_locations(id) ON DELETE RESTRICT,
        to_status      inventory_status,
        quantity       int NOT NULL,
        reason         movement_reason NOT NULL,
        reference_type text,
        reference_id   text,
        comment        text,
        actor_user_id  uuid,
        correlation_id text,
        CONSTRAINT movements_quantity_positive CHECK (quantity > 0),
        -- Движение обязано иметь хотя бы одну сторону: приход (только «куда»),
        -- списание (только «откуда») или перемещение (обе).
        CONSTRAINT movements_has_side CHECK (
          (from_bin_id IS NOT NULL AND from_status IS NOT NULL)
          OR (to_bin_id IS NOT NULL AND to_status IS NOT NULL)
        ),
        -- Корректировка без объяснения превращает журнал в бесполезный.
        CONSTRAINT movements_adjustment_needs_comment CHECK (
          reason <> 'ADJUSTMENT' OR (comment IS NOT NULL AND length(btrim(comment)) > 0)
        )
      )
    `);
    await queryRunner.query(`
      CREATE INDEX idx_movements_sku ON stock_movements (sku_id, warehouse_id, occurred_at DESC)
    `);
    await queryRunner.query(`
      CREATE INDEX idx_movements_reference ON stock_movements (reference_type, reference_id)
      WHERE reference_id IS NOT NULL
    `);

    // Журнал неизменяем — тем же приёмом, что и audit_events.
    await queryRunner.query(`
      CREATE FUNCTION ff_stock_movements_append_only() RETURNS trigger AS $$
      BEGIN
        RAISE EXCEPTION 'stock_movements — append-only, операция % запрещена', TG_OP
          USING ERRCODE = '42501';
      END
      $$ LANGUAGE plpgsql
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_movements_no_change BEFORE UPDATE OR DELETE ON stock_movements
      FOR EACH STATEMENT EXECUTE FUNCTION ff_stock_movements_append_only()
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_movements_no_truncate BEFORE TRUNCATE ON stock_movements
      FOR EACH STATEMENT EXECUTE FUNCTION ff_stock_movements_append_only()
    `);

    // --- reservations -------------------------------------------------------
    await queryRunner.query(`
      CREATE TABLE reservations (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        owner_type   text NOT NULL,
        owner_id     text NOT NULL,
        sku_id       uuid NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
        warehouse_id uuid NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
        bin_id       uuid NOT NULL REFERENCES bin_locations(id) ON DELETE RESTRICT,
        lot_id       uuid REFERENCES lots(id) ON DELETE RESTRICT,
        quantity     int NOT NULL,
        status       text NOT NULL DEFAULT 'ACTIVE',
        created_at   timestamptz NOT NULL DEFAULT now(),
        released_at  timestamptz,
        CONSTRAINT reservations_quantity_positive CHECK (quantity > 0),
        CONSTRAINT reservations_status_known CHECK (status IN ('ACTIVE', 'RELEASED', 'CONSUMED'))
      )
    `);
    await queryRunner.query(`
      CREATE INDEX idx_reservations_owner ON reservations (owner_type, owner_id)
    `);
    await queryRunner.query(`
      CREATE INDEX idx_reservations_active ON reservations (sku_id, warehouse_id)
      WHERE status = 'ACTIVE'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS reservations`);
    await queryRunner.query(`DROP TABLE IF EXISTS stock_movements`);
    await queryRunner.query(`DROP FUNCTION IF EXISTS ff_stock_movements_append_only()`);
    await queryRunner.query(`DROP TABLE IF EXISTS stock`);
    await queryRunner.query(`DROP TABLE IF EXISTS lots`);
    await queryRunner.query(`DROP TYPE IF EXISTS movement_reason`);
    await queryRunner.query(`DROP TYPE IF EXISTS inventory_status`);
  }
}
