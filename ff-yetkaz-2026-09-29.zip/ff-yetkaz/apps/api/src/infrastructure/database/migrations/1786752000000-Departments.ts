import type { MigrationInterface, QueryRunner } from 'typeorm';

/**
 * Отделы (подразделения) + привязка сотрудника к отделу.
 *
 * Отдел — организационная метка над учётной записью: доступ по-прежнему решает
 * роль, а отдел отвечает «из какого подразделения сотрудник». Связь мягкая:
 * при удалении отдела пользователь не пропадает (ON DELETE SET NULL), да и
 * удалять отделы штатно нельзя — их выключают is_active.
 *
 * Селлеру (внешнему клиенту) отдел не назначается: у него изоляция по seller_id,
 * подразделения оператора его не касаются. Это правило держит сервисный слой.
 */
export class Departments1786752000000 implements MigrationInterface {
  name = 'Departments1786752000000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE departments (
        id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        code        text NOT NULL UNIQUE,
        name        text NOT NULL,
        description text,
        is_active   boolean NOT NULL DEFAULT true,
        created_at  timestamptz NOT NULL DEFAULT now(),
        updated_at  timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT departments_code_shape CHECK (code ~ '^[A-Z][A-Z0-9_]*$'),
        CONSTRAINT departments_name_not_blank CHECK (btrim(name) <> '')
      )
    `);
    await queryRunner.query(`
      CREATE TRIGGER trg_departments_touch BEFORE UPDATE ON departments
      FOR EACH ROW EXECUTE FUNCTION ff_touch_updated_at()
    `);

    await queryRunner.query(`
      ALTER TABLE users
        ADD COLUMN department_id uuid REFERENCES departments(id) ON DELETE SET NULL
    `);
    await queryRunner.query(`CREATE INDEX idx_users_department ON users(department_id)`);

    // Стартовый набор — оператор переименует и дополнит под свою структуру.
    await queryRunner.query(`
      INSERT INTO departments (code, name, description) VALUES
        ('WAREHOUSE', 'Склад',   'Приёмка, хранение, сборка и упаковка'),
        ('OFFICE',    'Офис',    'Операторы: работа с заказами и клиентами'),
        ('FINANCE',   'Финансы', 'Тарифы, счета, сверка платежей')
      ON CONFLICT (code) DO NOTHING
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE users DROP COLUMN IF EXISTS department_id`);
    await queryRunner.query(`DROP TABLE IF EXISTS departments`);
  }
}
