import { QueryFailedError } from 'typeorm';

/**
 * Имя нарушенного уникального ограничения, если ошибка — это 23505.
 *
 * Нужно, чтобы сервис объяснил конфликт по-человечески («штрихкод уже закреплён
 * за таким-то SKU»), а не отдал наружу текст ошибки индекса.
 */
export function uniqueViolationConstraint(error: unknown): string | null {
  if (!(error instanceof QueryFailedError)) return null;
  const driverError = error.driverError as { code?: string; constraint?: string } | undefined;
  if (driverError?.code !== '23505') return null;
  return driverError.constraint ?? '';
}

/** Имя нарушенного CHECK-ограничения, если ошибка — это 23514. */
export function checkViolationConstraint(error: unknown): string | null {
  if (!(error instanceof QueryFailedError)) return null;
  const driverError = error.driverError as { code?: string; constraint?: string } | undefined;
  if (driverError?.code !== '23514') return null;
  return driverError.constraint ?? '';
}

/** Ошибка — нарушение внешнего ключа (23503): на запись ещё кто-то ссылается. */
export function isForeignKeyViolation(error: unknown): boolean {
  if (!(error instanceof QueryFailedError)) return false;
  const driverError = error.driverError as { code?: string } | undefined;
  return driverError?.code === '23503';
}
