/**
 * Форма правки перевозчика для сервиса конфигурации.
 *
 * Сервис не должен импортировать класс DTO из presentation: это зависимость на
 * транспорт, а декораторы class-validator нужны только разбору HTTP-запроса.
 * Класс `UpdateCarrierDto` объявлен `implements` этого интерфейса — расхождение
 * формы поймает сборка.
 */
export interface UpdateCarrierInput {
  name?: string;
  baseUrl?: string;
  handoffPath?: string;
  timeoutMs?: number;
  /** Имя переменной окружения с секретом, а не сам секрет. */
  secretEnvKey?: string;
  isActive?: boolean;
}
