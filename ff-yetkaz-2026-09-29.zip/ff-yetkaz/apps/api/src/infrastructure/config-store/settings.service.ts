import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import {
  SETTING_FALLBACKS,
  type AppSettingDto,
  type SettingKey,
} from '@ff/shared';
import { TtlCache } from '../cache';
import { AuditService } from '../logging/audit/audit.service';
import type { ActorContext } from '../../domain/types/actor';
import { AppSettingEntity } from '../database/entities';

/** Настройка читается почти на каждом запросе — держим её в памяти на секунды. */
const CACHE_TTL_MS = 15_000;

/**
 * Доступ к настройкам из `app_settings`.
 *
 * Значения из `SETTING_FALLBACKS` берутся только когда строки в базе нет —
 * чтобы сервис поднялся на голой БД. Источник правды всегда таблица: иначе
 * оператор поменяет допуск в интерфейсе, а сервис продолжит жить с константой.
 */
@Injectable()
export class SettingsService {
  private readonly logger = new Logger(SettingsService.name);
  /**
   * Вся таблица одним снимком в памяти процесса. Про то, что экземпляров на
   * serverless несколько и сброс доходит только до одного, — в `TtlCache`.
   */
  private readonly cache = new TtlCache<Map<string, unknown>>(CACHE_TTL_MS, () => this.read());

  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
  ) {}

  async getNumber(key: SettingKey): Promise<number> {
    const raw = await this.raw(key);
    if (typeof raw === 'number' && Number.isFinite(raw)) return raw;
    return SETTING_FALLBACKS[key];
  }

  async list(): Promise<AppSettingDto[]> {
    const rows = await this.dataSource
      .getRepository(AppSettingEntity)
      .find({ order: { key: 'ASC' } });
    return rows.map((row) => this.toDto(row));
  }

  /**
   * Правка настройки. Тип менять нельзя: он объявлен вместе с ключом и
   * проверяется ограничением таблицы — новое значение обязано ему отвечать.
   */
  async update(key: string, value: unknown, actor: ActorContext): Promise<AppSettingDto> {
    const repo = this.dataSource.getRepository(AppSettingEntity);
    const existing = await repo.findOne({ where: { key } });
    if (!existing) throw new NotFoundException(`Настройка «${key}» не заведена.`);

    const actualType = Array.isArray(value) ? 'json' : typeof value;
    const expected = existing.valueType;
    const matches =
      (expected === 'number' && actualType === 'number' && Number.isFinite(value as number)) ||
      (expected === 'string' && actualType === 'string') ||
      (expected === 'boolean' && actualType === 'boolean') ||
      (expected === 'json' && (actualType === 'json' || actualType === 'object'));
    if (!matches) {
      throw new BadRequestException(
        `Настройка «${key}» имеет тип ${expected}, а передано ${actualType}.`,
      );
    }

    await repo.update({ key }, { value: value as object, updatedBy: actor.user.id });

    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'AppSetting',
      entityId: key,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      before: { value: existing.value },
      after: { value },
    });

    this.invalidate();
    const updated = await repo.findOne({ where: { key } });
    return this.toDto(updated as AppSettingEntity);
  }

  invalidate(): void {
    this.cache.invalidate();
  }

  // ------------------------------------------------------------ внутреннее

  private async raw(key: string): Promise<unknown> {
    const values = await this.cache.get();
    return values.get(key);
  }

  private async read(): Promise<Map<string, unknown>> {
    try {
      const rows = await this.dataSource.getRepository(AppSettingEntity).find();
      // Явные параметры типа: без них `map` выводит массив союзов вместо пар,
      // и strict-режим не принимает его за список записей Map.
      return new Map<string, unknown>(rows.map((row) => [row.key, row.value]));
    } catch (error) {
      // Пустая или недоступная таблица не должна ронять запрос: работаем на
      // значениях по умолчанию и говорим об этом в лог. Отказ намеренно НЕ
      // пробрасывается наружу: иначе кэш не запомнил бы ничего и каждый
      // следующий запрос снова шёл бы в недоступную базу. Возвращаем прежний
      // снимок (или пустой, если его ещё не было) — он проживёт свой TTL, и
      // повтор случится не чаще раза в TTL, как и до вынесения кэша в слой.
      this.logger.warn(`Не удалось прочитать app_settings: ${(error as Error).message}`);
      return this.cache.peek() ?? new Map<string, unknown>();
    }
  }

  private toDto(row: AppSettingEntity): AppSettingDto {
    return {
      key: row.key,
      value: row.value,
      valueType: row.valueType,
      description: row.description,
      updatedAt: row.updatedAt.toISOString(),
    };
  }
}
