import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import type { CarrierDto } from '@ff/shared';
import { AuditService } from '../logging/audit/audit.service';
import type { ActorContext } from '../../domain/types/actor';
import { CarrierEntity } from '../database/entities';
import type { UpdateCarrierInput } from './config-store.input';

/** Перевозчик вместе с разрешённым секретом. Наружу секрет не отдаётся. */
export interface ResolvedCarrier {
  entity: CarrierEntity;
  secret: string;
}

@Injectable()
export class CarriersService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly audit: AuditService,
  ) {}

  async list(): Promise<CarrierDto[]> {
    const rows = await this.dataSource.getRepository(CarrierEntity).find({ order: { code: 'ASC' } });
    return rows.map((row) => this.toDto(row));
  }

  async update(code: string, dto: UpdateCarrierInput, actor: ActorContext): Promise<CarrierDto> {
    const repo = this.dataSource.getRepository(CarrierEntity);
    const carrier = await repo.findOne({ where: { code } });
    if (!carrier) throw new NotFoundException(`Перевозчик «${code}» не заведён.`);

    if (dto.isActive === true) {
      // Включать перевозчика без секрета бессмысленно: первая же передача
      // упадёт на подписи, но уже после того, как заказ уйдёт в очередь.
      const key = dto.secretEnvKey ?? carrier.secretEnvKey;
      if (!process.env[key]) {
        throw new ConflictException(
          `Переменная окружения ${key} не задана — перевозчика нельзя включить.`,
        );
      }
    }

    const before = this.toDto(carrier);
    await repo.update(
      { code },
      {
        name: dto.name ?? carrier.name,
        baseUrl: dto.baseUrl ?? carrier.baseUrl,
        handoffPath: dto.handoffPath ?? carrier.handoffPath,
        timeoutMs: dto.timeoutMs ?? carrier.timeoutMs,
        secretEnvKey: dto.secretEnvKey ?? carrier.secretEnvKey,
        isActive: dto.isActive ?? carrier.isActive,
      },
    );

    const updated = (await repo.findOne({ where: { code } })) as CarrierEntity;
    await this.audit.record({
      action: 'CONFIG_UPDATED',
      entityType: 'Carrier',
      entityId: updated.id,
      actorUserId: actor.user.id,
      actorRole: actor.user.roles.join(','),
      correlationId: actor.correlationId,
      before: { ...before },
      after: { ...this.toDto(updated) },
    });

    return this.toDto(updated);
  }

  /** Активный перевозчик с секретом. Бросает, если он не настроен. */
  async resolve(code: string): Promise<ResolvedCarrier> {
    const carrier = await this.dataSource
      .getRepository(CarrierEntity)
      .findOne({ where: { code } });
    if (!carrier) throw new NotFoundException(`Перевозчик «${code}» не заведён.`);
    if (!carrier.isActive) throw new ConflictException(`Перевозчик «${code}» выключен.`);

    const secret = process.env[carrier.secretEnvKey];
    if (!secret) {
      throw new ConflictException(
        `Секрет перевозчика «${code}» отсутствует: переменная ${carrier.secretEnvKey} не задана.`,
      );
    }
    return { entity: carrier, secret };
  }

  /** Секрет для проверки входящей подписи; null — перевозчик не настроен. */
  async secretFor(code: string): Promise<string | null> {
    const carrier = await this.dataSource
      .getRepository(CarrierEntity)
      .findOne({ where: { code } });
    if (!carrier || !carrier.isActive) return null;
    return process.env[carrier.secretEnvKey] ?? null;
  }

  private toDto(row: CarrierEntity): CarrierDto {
    return {
      id: row.id,
      code: row.code,
      name: row.name,
      baseUrl: row.baseUrl,
      handoffPath: row.handoffPath,
      timeoutMs: row.timeoutMs,
      secretEnvKey: row.secretEnvKey,
      isActive: row.isActive,
      secretConfigured: Boolean(process.env[row.secretEnvKey]),
      updatedAt: row.updatedAt.toISOString(),
    };
  }
}
