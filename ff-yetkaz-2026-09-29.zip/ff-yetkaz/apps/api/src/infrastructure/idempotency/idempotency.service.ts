import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { LessThan, Repository } from 'typeorm';
import { IdempotencyKeyEntity } from '../database/entities';

export type BeginResult =
  | { kind: 'proceed'; id: string }
  | { kind: 'replay'; status: number; body: unknown }
  | { kind: 'conflict'; reason: 'BODY_MISMATCH' | 'IN_PROGRESS' };

@Injectable()
export class IdempotencyService {
  constructor(
    @InjectRepository(IdempotencyKeyEntity)
    private readonly repo: Repository<IdempotencyKeyEntity>,
    private readonly config: ConfigService,
  ) {}

  /**
   * Захватывает ключ под текущий запрос.
   *
   * Гонку решает уникальный индекс, а не предварительный SELECT: два
   * одновременных запроса с одним ключом — вставка выигрывает ровно у одного,
   * второй получает IN_PROGRESS и 409, а не вторую бизнес-операцию.
   */
  async begin(key: string, endpoint: string, requestHash: string): Promise<BeginResult> {
    // Вторая попытка нужна на случай, если конкурент удалил протухшую или
    // прерванную строку между нашей вставкой и чтением.
    for (let attempt = 0; attempt < 2; attempt++) {
      const ttlHours = this.config.get<number>('IDEMPOTENCY_TTL_HOURS') ?? 24;
      const expiresAt = new Date(Date.now() + ttlHours * 3600 * 1000);

      const inserted = await this.repo
        .createQueryBuilder()
        .insert()
        .into(IdempotencyKeyEntity)
        .values({ key, endpoint, requestHash, status: 'IN_PROGRESS', expiresAt })
        .orIgnore()
        .returning(['id'])
        .execute();

      const insertedId = (inserted.raw as Array<{ id: string }>)[0]?.id;
      if (insertedId) return { kind: 'proceed', id: String(insertedId) };

      const existing = await this.repo.findOne({ where: { key, endpoint } });
      if (!existing) continue;

      if (existing.expiresAt.getTime() <= Date.now()) {
        await this.repo.delete({ id: existing.id });
        continue;
      }

      if (existing.requestHash !== requestHash) {
        return { kind: 'conflict', reason: 'BODY_MISMATCH' };
      }
      if (existing.status === 'COMPLETED') {
        return { kind: 'replay', status: existing.responseStatus ?? 200, body: existing.responseBody };
      }
      return { kind: 'conflict', reason: 'IN_PROGRESS' };
    }

    return { kind: 'conflict', reason: 'IN_PROGRESS' };
  }

  /** Фиксирует успешный ответ — повтор с тем же ключом вернёт именно его. */
  async complete(id: string, status: number, body: unknown): Promise<void> {
    // save, а не update: типы update() в TypeORM не пропускают jsonb-значение.
    await this.repo.save({
      id,
      status: 'COMPLETED' as const,
      responseStatus: status,
      responseBody: body ?? null,
      completedAt: new Date(),
    });
  }

  /**
   * Освобождает ключ после неуспеха. Ошибку не кэшируем: клиент должен иметь
   * возможность повторить тот же запрос тем же ключом.
   */
  async abandon(id: string): Promise<void> {
    await this.repo.delete({ id });
  }

  async purgeExpired(): Promise<number> {
    const result = await this.repo.delete({ expiresAt: LessThan(new Date()) });
    return result.affected ?? 0;
  }
}
