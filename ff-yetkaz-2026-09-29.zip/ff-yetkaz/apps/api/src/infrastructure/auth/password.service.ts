import { Injectable, type OnModuleInit } from '@nestjs/common';
import { hash, verify } from '@node-rs/argon2';
import { randomBytes } from 'node:crypto';

/**
 * Параметры argon2id по рекомендации OWASP: m=19 МиБ, t=2, p=1.
 */
const ARGON2_OPTIONS = {
  memoryCost: 19_456,
  timeCost: 2,
  parallelism: 1,
} as const;

@Injectable()
export class PasswordService implements OnModuleInit {
  /**
   * Хэш заведомо несуществующего пароля. Нужен, чтобы логин неизвестного email
   * стоил столько же времени, сколько логин известного, — иначе по времени
   * ответа перебором вычисляются существующие учётные записи.
   */
  private dummyHash = '';

  async onModuleInit(): Promise<void> {
    this.dummyHash = await this.hash(randomBytes(32).toString('hex'));
  }

  hash(plain: string): Promise<string> {
    return hash(plain, ARGON2_OPTIONS);
  }

  async verify(hashed: string, plain: string): Promise<boolean> {
    try {
      return await verify(hashed, plain, ARGON2_OPTIONS);
    } catch {
      // Битый или чужой формат хэша — это «не совпало», а не 500.
      return false;
    }
  }

  /** Сжигает то же время, что и настоящая проверка, и всегда возвращает false. */
  async verifyDummy(plain: string): Promise<false> {
    if (this.dummyHash) await this.verify(this.dummyHash, plain);
    return false;
  }
}
