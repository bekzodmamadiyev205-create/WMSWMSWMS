/**
 * Можно ли в этом окружении держать фоновые таймеры.
 *
 * На serverless-платформе процесс замораживается между запросами: `setInterval`
 * там не тикает, а создаёт иллюзию работающего фона. Хуже всего то, что это не
 * падает — очередь просто перестаёт разбираться, а хранение тарифицироваться.
 *
 * Поэтому таймеры выключают себя сами, а не ждут, что кто-то не забудет
 * выставить флаг. На Vercel их место занимает Cron, дёргающий `/cron/*`.
 */
export function backgroundTimersSupported(): boolean {
  // Признак платформы, который Vercel выставляет и в сборке, и в рантайме.
  if (process.env.VERCEL) return false;
  if (process.env.AWS_LAMBDA_FUNCTION_NAME) return false;
  return true;
}

/** Человеческое объяснение для лога — чтобы «фон не работает» не был загадкой. */
export function backgroundTimersReason(): string {
  if (process.env.VERCEL) return 'serverless-окружение Vercel: фон переведён на Cron';
  if (process.env.AWS_LAMBDA_FUNCTION_NAME) return 'AWS Lambda: фон переведён на внешний планировщик';
  return 'выключено настройкой';
}
