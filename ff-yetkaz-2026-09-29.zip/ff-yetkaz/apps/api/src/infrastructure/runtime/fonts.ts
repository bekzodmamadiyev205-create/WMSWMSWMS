import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';

/**
 * Путь к шрифту для PDF.
 *
 * Сначала ищем копию рядом со скомпилированным кодом (`dist/assets/fonts`) —
 * её кладёт `scripts/copy-assets.cjs` при сборке. Это единственный надёжный
 * вариант на serverless: сборщик функций включает в бандл лишь те файлы, до
 * которых дотянулся статическим анализом, а `.ttf`, открываемый по вычисленному
 * пути, туда не попадает.
 *
 * Если копии нет (ts-node в разработке и тестах) — берём из node_modules.
 */
export function fontPath(file: string): string {
  const bundled = join(__dirname, '..', '..', 'assets', 'fonts', file);
  if (existsSync(bundled)) return bundled;
  return join(dirname(require.resolve('dejavu-fonts-ttf/package.json')), 'ttf', file);
}
