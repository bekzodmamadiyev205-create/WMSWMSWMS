/**
 * Code 128, набор B — штрихкод для этикетки отправления.
 *
 * Написан здесь, а не взят зависимостью: кодировка полностью описана
 * стандартом, укладывается в таблицу и полсотни строк, зато её можно
 * проверить тестом (см. `test/code128.test.ts`) и не тащить в прод
 * генератор картинок ради двух десятков прямоугольников в PDF.
 *
 * Каждый символ — 6 чередующихся модулей (штрих, пробел, штрих, …) суммарной
 * шириной 11 модулей; исключение — стоп-символ из 7 модулей шириной 13.
 */
export const CODE128_PATTERNS: readonly string[] = [
  '212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312',
  '132212', '221213', '221312', '231212', '112232', '122132', '122231', '113222',
  '123122', '123221', '223211', '221132', '221231', '213212', '223112', '312131',
  '311222', '321122', '321221', '312212', '322112', '322211', '212123', '212321',
  '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313',
  '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121',
  '313121', '211331', '231131', '213113', '213311', '213131', '311123', '311321',
  '331121', '312113', '312311', '332111', '314111', '221411', '431111', '111224',
  '111422', '121124', '121421', '141122', '141221', '112214', '112412', '122114',
  '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111',
  '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112',
  '421211', '212141', '214121', '412121', '111143', '111341', '131141', '114113',
  '114311', '411113', '411311', '113141', '114131', '311141', '411131', '211412',
  '211214', '211232', '2331112',
];

/** Стартовый символ набора B: печатаемый ASCII 32…126 без переключений. */
export const CODE128_START_B = 104;
export const CODE128_STOP = 106;

const FIRST_CHAR_CODE = 32;
const LAST_CHAR_CODE = 126;
/** Контрольная сумма считается по модулю 103 — числу значимых символов. */
const CHECKSUM_MODULO = 103;

export class Code128Error extends Error {}

/** Значения символов набора B без служебных: 'A' → 33. */
export function code128BValues(value: string): number[] {
  const values: number[] = [];
  for (const char of value) {
    const code = char.charCodeAt(0);
    if (code < FIRST_CHAR_CODE || code > LAST_CHAR_CODE) {
      throw new Code128Error(
        `Символ «${char}» вне набора Code 128 B — штрихкод построить нельзя.`,
      );
    }
    values.push(code - FIRST_CHAR_CODE);
  }
  return values;
}

/** Взвешенная сумма: старт + Σ (позиция × значение), по модулю 103. */
export function code128BChecksum(value: string): number {
  const values = code128BValues(value);
  let sum = CODE128_START_B;
  values.forEach((item, index) => {
    sum += item * (index + 1);
  });
  return sum % CHECKSUM_MODULO;
}

/** Полная последовательность символов: старт, данные, контрольный, стоп. */
export function encodeCode128B(value: string): number[] {
  if (value.length === 0) throw new Code128Error('Пустая строка не кодируется.');
  return [CODE128_START_B, ...code128BValues(value), code128BChecksum(value), CODE128_STOP];
}

export interface Code128Bar {
  /** Смещение от начала штрихкода в модулях. */
  offset: number;
  width: number;
}

export interface Code128Bars {
  bars: Code128Bar[];
  /** Полная ширина в модулях — по ней считается масштаб под ширину этикетки. */
  modules: number;
}

/**
 * Раскладка чёрных полос. Ширины идут парами штрих/пробел начиная со штриха,
 * поэтому в вывод попадают элементы с чётным индексом.
 */
export function code128Bars(value: string): Code128Bars {
  const bars: Code128Bar[] = [];
  let offset = 0;

  for (const symbol of encodeCode128B(value)) {
    const pattern = CODE128_PATTERNS[symbol];
    for (let index = 0; index < pattern.length; index += 1) {
      const width = Number(pattern[index]);
      if (index % 2 === 0) bars.push({ offset, width });
      offset += width;
    }
  }

  return { bars, modules: offset };
}
