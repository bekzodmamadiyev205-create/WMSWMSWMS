import type { AuthPrincipal } from '@ff/shared';

/** Кто и в рамках какого запроса выполняет операцию — всё, что нужно аудиту. */
export interface ActorContext {
  user: AuthPrincipal;
  ip: string | null;
  correlationId: string | null;
}
