// Кладёт шрифты рядом со скомпилированным кодом.
//
// PDF-этикетка и счёт вшивают DejaVu Sans: стандартные шрифты PDF не содержат
// кириллицы. В разработке шрифт берётся из node_modules, но на serverless
// сборщик кладёт в бандл только те файлы, до которых дотянулся статическим
// анализом — .ttf, открываемый по вычисленному пути, туда не попадает.
// Поэтому копируем его в dist явно: иначе печать упадёт ENOENT уже в проде.
'use strict';
const { copyFileSync, mkdirSync } = require('node:fs');
const { dirname, join } = require('node:path');

const FONTS = ['DejaVuSans.ttf', 'DejaVuSans-Bold.ttf'];

const source = join(dirname(require.resolve('dejavu-fonts-ttf/package.json')), 'ttf');
const target = join(__dirname, '..', 'dist', 'assets', 'fonts');

mkdirSync(target, { recursive: true });
for (const file of FONTS) {
  copyFileSync(join(source, file), join(target, file));
}
console.log(`Шрифты скопированы в ${target}: ${FONTS.join(', ')}`);
