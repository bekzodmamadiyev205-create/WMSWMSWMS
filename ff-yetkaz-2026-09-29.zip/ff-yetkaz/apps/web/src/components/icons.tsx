import * as React from 'react';

/**
 * Иконки — инлайн-SVG в стиле lucide (stroke 2, скруглённые концы).
 * Без иконочной библиотеки: нужен десяток картинок, а не пакет на мегабайт.
 * Цвет берётся из currentColor — красится текстовыми классами Tailwind.
 */
function Svg({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <svg
      className={className ?? 'h-4 w-4'}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      {children}
    </svg>
  );
}

export const Icon = {
  home: (c?: string) => (
    <Svg className={c}>
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5 9.5V21h14V9.5" />
      <path d="M9 21v-6h6v6" />
    </Svg>
  ),
  inbound: (c?: string) => (
    <Svg className={c}>
      <path d="M12 3v10" />
      <path d="m8 9 4 4 4-4" />
      <path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4" />
    </Svg>
  ),
  picking: (c?: string) => (
    <Svg className={c}>
      <path d="M6 6h15l-1.5 9h-12z" />
      <path d="M6 6 5 3H2" />
      <circle cx="9" cy="20" r="1.6" />
      <circle cx="17" cy="20" r="1.6" />
    </Svg>
  ),
  packing: (c?: string) => (
    <Svg className={c}>
      <path d="M21 8 12 3 3 8v8l9 5 9-5z" />
      <path d="M3 8l9 5 9-5" />
      <path d="M12 13v8" />
    </Svg>
  ),
  stock: (c?: string) => (
    <Svg className={c}>
      <path d="m12 2 8 4.5-8 4.5-8-4.5z" />
      <path d="m4 11.5 8 4.5 8-4.5" />
      <path d="m4 16.5 8 4.5 8-4.5" />
    </Svg>
  ),
  orders: (c?: string) => (
    <Svg className={c}>
      <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" />
      <path d="M3 6h18" />
      <path d="M16 10a4 4 0 0 1-8 0" />
    </Svg>
  ),
  catalog: (c?: string) => (
    <Svg className={c}>
      <path d="M12.6 2.6 21.4 11.4a2 2 0 0 1 0 2.8l-7.2 7.2a2 2 0 0 1-2.8 0L2.6 12.6A2 2 0 0 1 2 11.2V4a2 2 0 0 1 2-2h7.2a2 2 0 0 1 1.4.6Z" />
      <circle cx="7.5" cy="7.5" r="1.3" />
    </Svg>
  ),
  users: (c?: string) => (
    <Svg className={c}>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </Svg>
  ),
  chart: (c?: string) => (
    <Svg className={c}>
      <path d="M3 3v18h18" />
      <path d="M7 15v-4" />
      <path d="M12 17V8" />
      <path d="M17 13v-2" />
    </Svg>
  ),
  store: (c?: string) => (
    <Svg className={c}>
      <path d="M4 10v10h16V10" />
      <path d="M2 6l2-4h16l2 4a3 3 0 0 1-6 0 3 3 0 0 1-6 0 3 3 0 0 1-6 0z" />
      <path d="M10 20v-6h4v6" />
    </Svg>
  ),
  warehouse: (c?: string) => (
    <Svg className={c}>
      <path d="M3 21V8l9-5 9 5v13" />
      <path d="M7 21v-8h10v8" />
      <path d="M7 17h10" />
    </Svg>
  ),
  alert: (c?: string) => (
    <Svg className={c}>
      <path d="M12 9v4" />
      <path d="M12 17h.01" />
      <path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" />
    </Svg>
  ),
  check: (c?: string) => (
    <Svg className={c}>
      <circle cx="12" cy="12" r="9" />
      <path d="m8.5 12 2.5 2.5 4.5-5" />
    </Svg>
  ),
  truck: (c?: string) => (
    <Svg className={c}>
      <path d="M1 6h14v11H1z" />
      <path d="M15 10h4l4 4v3h-8z" />
      <circle cx="6" cy="19.5" r="1.8" />
      <circle cx="18" cy="19.5" r="1.8" />
    </Svg>
  ),
  plus: (c?: string) => (
    <Svg className={c}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 8v8M8 12h8" />
    </Svg>
  ),
  settings: (c?: string) => (
    <Svg className={c}>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 13a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </Svg>
  ),
  building: (c?: string) => (
    <Svg className={c}>
      <path d="M3 21V5a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v16" />
      <path d="M17 21V9h2a2 2 0 0 1 2 2v10" />
      <path d="M7 7h2M7 11h2M7 15h2" />
      <path d="M2 21h20" />
    </Svg>
  ),
} as const;

export type IconName = keyof typeof Icon;
