import * as React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { AppShell } from '@/components/AppShell';
import { useAuth } from '@/lib/auth';

export function ProtectedRoute(): React.ReactElement {
  const { token, isLoading } = useAuth();

  if (!token) return <Navigate to="/login" replace />;
  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center text-sm text-muted-foreground">
        Загрузка профиля…
      </div>
    );
  }
  // Оболочка живёт здесь, а не в каждой странице: боковое меню и шапка
  // обязаны выглядеть одинаково на всех защищённых экранах.
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
