import * as React from 'react';
import type { Language } from '@/lib/i18n';
import { cn } from '@/lib/utils';

/**
 * Флаги — инлайн-SVG, а НЕ emoji. Windows не содержит глифов флагов-emoji и
 * показывает вместо 🇷🇺 две буквы «RU» — на скриншотах владельца именно это и
 * было видно. Нарисованные флажки рендерятся одинаково везде.
 *
 * Скругление даёт CSS (`rounded` + `overflow-hidden` на самом svg): рисуем
 * прямоугольные полосы, а углы обрезает бордер-радиус — не нужен clipPath с
 * уникальными id на каждый экземпляр.
 */
const BASE = 'inline-block h-3.5 w-[21px] shrink-0 overflow-hidden rounded-[3px]';

/** Пятиконечная звезда единичного радиуса — для флага КНР. */
function Star({ x, y, s, r = 0 }: { x: number; y: number; s: number; r?: number }) {
  return (
    <path
      transform={`translate(${x} ${y}) scale(${s}) rotate(${r})`}
      d="M0,-1 L0.2245,-0.309 0.9511,-0.309 0.3633,0.118 0.5878,0.809 0,0.382 -0.5878,0.809 -0.3633,0.118 -0.9511,-0.309 -0.2245,-0.309 Z"
    />
  );
}

function FlagRU({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 16" className={cn(BASE, className)} aria-hidden>
      <rect width="24" height="16" fill="#fff" />
      <rect y="5.33" width="24" height="5.34" fill="#0039A6" />
      <rect y="10.67" width="24" height="5.33" fill="#D52B1E" />
    </svg>
  );
}

function FlagUZ({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 16" className={cn(BASE, className)} aria-hidden>
      <rect width="24" height="16" fill="#fff" />
      <rect width="24" height="5" fill="#0099B5" />
      <rect y="11" width="24" height="5" fill="#1EB53A" />
      <rect y="4.7" width="24" height="0.6" fill="#CE1126" />
      <rect y="10.7" width="24" height="0.6" fill="#CE1126" />
      <circle cx="4.4" cy="2.5" r="1.7" fill="#fff" />
      <circle cx="5.2" cy="2.5" r="1.45" fill="#0099B5" />
    </svg>
  );
}

function FlagGB({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 16" className={cn(BASE, className)} aria-hidden>
      <rect width="24" height="16" fill="#012169" />
      <path d="M0 0 L24 16 M24 0 L0 16" stroke="#fff" strokeWidth="3.2" />
      <path d="M0 0 L24 16 M24 0 L0 16" stroke="#C8102E" strokeWidth="1.3" />
      <rect x="9.5" width="5" height="16" fill="#fff" />
      <rect y="5.5" width="24" height="5" fill="#fff" />
      <rect x="10.5" width="3" height="16" fill="#C8102E" />
      <rect y="6.5" width="24" height="3" fill="#C8102E" />
    </svg>
  );
}

function FlagCN({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 16" className={cn(BASE, className)} aria-hidden>
      <rect width="24" height="16" fill="#DE2910" />
      <g fill="#FFDE00">
        <Star x={4} y={4} s={2.7} />
        <Star x={8.4} y={1.7} s={0.85} r={23} />
        <Star x={10} y={3.6} s={0.85} r={45} />
        <Star x={10} y={6} s={0.85} r={20} />
        <Star x={8.4} y={7.8} s={0.85} r={-5} />
      </g>
    </svg>
  );
}

const BY_CODE: Record<Language, (p: { className?: string }) => React.ReactElement> = {
  ru: FlagRU,
  uz: FlagUZ,
  en: FlagGB,
  zh: FlagCN,
};

export function Flag({ code, className }: { code: Language; className?: string }): React.ReactElement {
  const Component = BY_CODE[code] ?? FlagRU;
  return <Component className={className} />;
}
