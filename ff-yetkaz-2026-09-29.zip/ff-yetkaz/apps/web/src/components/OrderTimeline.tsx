import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import type { OrderStatus, OrderStatusEventDto, OrderTrackDto } from '@ff/shared';
import { apiFetch } from '@/lib/api';
import { useI18n, type Language, type MessageKey } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import { Skeleton, SkeletonText } from '@/components/ui/skeleton';
import {
  ORDER_PIPELINE,
  ORDER_STAGE_TONE,
  OrderStatusBadge,
  orderStatusKey,
  type OrderTone,
} from '@/components/OrderStatusBadge';

const LOCALE: Record<Language, string> = {
  ru: 'ru-RU',
  uz: 'uz-UZ',
  en: 'en-GB',
  zh: 'zh-CN',
};

/** Заливка точки по тону статуса: у бейджа тон полупрозрачный, у точки — плотный. */
const TONE_DOT: Record<OrderTone, string> = {
  default: 'bg-primary',
  secondary: 'bg-muted-foreground',
  outline: 'bg-border',
  success: 'bg-success',
  warning: 'bg-warning',
  info: 'bg-info',
  destructive: 'bg-destructive',
  muted: 'bg-muted-foreground/60',
};

type Translate = (key: MessageKey, params?: Record<string, string | number>) => string;

function pipelineIndex(status: OrderStatus | null): number {
  if (!status) return -1;
  return (ORDER_PIPELINE as readonly OrderStatus[]).indexOf(status);
}

/**
 * Длительность людьми: две старшие единицы и не больше. «2 д 5 ч» отвечает на
 * вопрос «долго ли», а «2 д 5 ч 13 мин 4 с» на него уже не отвечает — цифры
 * приходится складывать глазами.
 */
export function formatDuration(ms: number, t: Translate): string {
  const total = Math.max(0, Math.round(ms / 1000));
  const days = Math.floor(total / 86_400);
  const hours = Math.floor((total % 86_400) / 3_600);
  const minutes = Math.floor((total % 3_600) / 60);
  const seconds = total % 60;

  if (days > 0) {
    const head = t('orderTimeline.unit.d', { n: days });
    return hours > 0 ? `${head} ${t('orderTimeline.unit.h', { n: hours })}` : head;
  }
  if (hours > 0) {
    const head = t('orderTimeline.unit.h', { n: hours });
    return minutes > 0 ? `${head} ${t('orderTimeline.unit.m', { n: minutes })}` : head;
  }
  if (minutes > 0) return t('orderTimeline.unit.m', { n: minutes });
  return t('orderTimeline.unit.s', { n: seconds });
}

/** Тикающие «сейчас»: без них длительность текущего статуса замерзает на минуте открытия карточки. */
function useNow(intervalMs = 30_000): number {
  const [now, setNow] = React.useState(() => Date.now());
  React.useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);
  return now;
}

/* ───────────────────────────── горизонтальный трек ───────────────────────── */

interface TrackStep {
  status: OrderStatus;
  state: 'done' | 'current' | 'future';
}

function buildSteps(currentStatus: OrderStatus, events: OrderStatusEventDto[]): {
  steps: TrackStep[];
  branch: OrderStatus | null;
} {
  const terminal = currentStatus === 'CANCELLED' || currentStatus === 'RETURNED';

  if (!terminal) {
    const currentIndex = Math.max(0, pipelineIndex(currentStatus));
    return {
      steps: ORDER_PIPELINE.map((status, index) => ({
        status,
        state: index < currentIndex ? 'done' : index === currentIndex ? 'current' : 'future',
      })),
      branch: null,
    };
  }

  // Точка ветвления — статус, ИЗ которого заказ ушёл в терминальный. Берём его
  // из события перехода: гадать по «последнему известному» нельзя, вебхук
  // возврата может прийти позже других записей.
  const exit = [...events].reverse().find((event) => event.toStatus === currentStatus);
  const fromIndex = pipelineIndex(exit?.fromStatus ?? null);
  const reached = events.reduce((max, event) => Math.max(max, pipelineIndex(event.toStatus)), -1);
  const branchIndex = Math.max(0, fromIndex >= 0 ? fromIndex : reached);

  return {
    steps: ORDER_PIPELINE.slice(0, branchIndex + 1).map((status) => ({ status, state: 'done' })),
    branch: currentStatus,
  };
}

function ProgressTrack({
  currentStatus,
  events,
}: {
  currentStatus: OrderStatus;
  events: OrderStatusEventDto[];
}): React.ReactElement {
  const { t } = useI18n();
  const { steps, branch } = buildSteps(currentStatus, events);

  // Ветка окрашивает ВЕСЬ пройденный путь: отменённый заказ не должен выглядеть
  // как успешно доехавший до предпоследнего шага.
  const branchTone: 'destructive' | 'warning' | null =
    branch === 'CANCELLED' ? 'destructive' : branch === 'RETURNED' ? 'warning' : null;

  const doneBar = branchTone === 'destructive' ? 'bg-destructive' : branchTone === 'warning' ? 'bg-warning' : 'brand-gradient';
  const doneDot = doneBar;

  return (
    <div className="overflow-x-auto pb-1">
      <ol
        aria-label={t('orderTimeline.trackLabel')}
        className="flex min-w-max items-start"
      >
        {steps.map((step, index) => (
          <li
            key={step.status}
            className="relative flex w-[5.5rem] shrink-0 flex-col items-center gap-2 sm:w-24"
          >
            {index > 0 ? (
              <span
                aria-hidden="true"
                className={cn(
                  'absolute right-1/2 top-[7px] h-[3px] w-full rounded-full',
                  step.state === 'future' ? 'bg-border' : doneBar,
                )}
              />
            ) : null}

            {step.state === 'current' && !branchTone ? (
              <span
                aria-hidden="true"
                className="absolute left-1/2 top-0 h-4 w-4 -translate-x-1/2 animate-pulse rounded-full bg-primary/25"
              />
            ) : null}

            <span
              aria-hidden="true"
              className={cn(
                'relative z-10 mt-[1px] h-3.5 w-3.5 rounded-full',
                step.state === 'done' && doneDot,
                step.state === 'current' && (branchTone ? doneDot : 'bg-primary ring-2 ring-primary/40 ring-offset-2 ring-offset-card'),
                step.state === 'future' && 'bg-muted ring-1 ring-inset ring-border',
              )}
            />

            <span
              className={cn(
                'px-1 text-center text-[11px] leading-tight',
                step.state === 'future' ? 'text-muted-foreground/70' : 'font-medium text-foreground',
              )}
            >
              {t(orderStatusKey(step.status))}
            </span>
            <span className="sr-only">
              {step.state === 'done'
                ? t('orderTimeline.stepDone')
                : step.state === 'current'
                  ? t('orderTimeline.stepCurrent')
                  : t('orderTimeline.stepFuture')}
            </span>
          </li>
        ))}

        {branch ? (
          <li className="relative flex w-[5.5rem] shrink-0 flex-col items-center gap-2 sm:w-24">
            <span
              aria-hidden="true"
              className={cn('absolute right-1/2 top-[7px] h-[3px] w-full rounded-full', doneBar)}
            />
            <span
              aria-hidden="true"
              className={cn(
                'relative z-10 mt-[1px] h-3.5 w-3.5 rounded-full ring-2 ring-offset-2 ring-offset-card',
                branchTone === 'destructive'
                  ? 'bg-destructive ring-destructive/40'
                  : 'bg-warning ring-warning/40',
              )}
            />
            <span
              className={cn(
                'px-1 text-center text-[11px] font-medium leading-tight',
                branchTone === 'destructive' ? 'text-destructive' : 'text-warning',
              )}
            >
              {t(orderStatusKey(branch))}
            </span>
          </li>
        ) : null}
      </ol>
    </div>
  );
}

/* ─────────────────────────────── вертикальный лог ────────────────────────── */

function EventRow({
  event,
  nextOccurredAt,
  now,
  isLast,
  locale,
}: {
  event: OrderStatusEventDto;
  nextOccurredAt: string | null;
  now: number;
  isLast: boolean;
  locale: string;
}): React.ReactElement {
  const { t } = useI18n();
  const startedAt = Date.parse(event.occurredAt);
  const endedAt = nextOccurredAt ? Date.parse(nextOccurredAt) : now;
  // Длительность привязана к статусу, в который заказ ВОШЁЛ: именно она отвечает
  // на вопрос «где заказ стоит», ради которого трек и ведётся.
  const spent = Number.isFinite(startedAt) ? formatDuration(endedAt - startedAt, t) : null;
  const ongoing = nextOccurredAt === null;

  return (
    <li className="relative flex gap-3 pb-5 last:pb-0">
      <div className="relative flex w-3.5 shrink-0 justify-center">
        {!isLast ? (
          <span
            aria-hidden="true"
            className="absolute left-1/2 top-3 h-full w-px -translate-x-1/2 bg-border"
          />
        ) : null}
        <span
          aria-hidden="true"
          className={cn(
            'relative z-10 mt-1 h-2.5 w-2.5 rounded-full ring-4 ring-card',
            TONE_DOT[ORDER_STAGE_TONE[event.toStatus]],
          )}
        />
      </div>

      <div className="min-w-0 flex-1 space-y-1.5">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <OrderStatusBadge status={event.toStatus} size="sm" />
          <time
            dateTime={event.occurredAt}
            className="text-xs tabular-nums text-muted-foreground"
          >
            {Number.isFinite(startedAt) ? new Date(startedAt).toLocaleString(locale) : event.occurredAt}
          </time>
        </div>

        <p className="text-xs text-muted-foreground">
          {event.actorName ?? t('orderTimeline.systemActor')}
          <span className="mx-1.5 text-border">·</span>
          {t('orderTimeline.source', { source: event.source })}
        </p>

        {event.comment ? (
          <p className="rounded-md bg-muted/60 px-2 py-1 text-xs text-foreground">{event.comment}</p>
        ) : null}

        {spent ? (
          <span
            className={cn(
              'inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium tabular-nums',
              ongoing ? 'bg-info/10 text-info ring-1 ring-inset ring-info/20' : 'bg-muted text-muted-foreground',
            )}
          >
            {ongoing ? t('orderTimeline.spentNow', { value: spent }) : t('orderTimeline.spent', { value: spent })}
          </span>
        ) : null}
      </div>
    </li>
  );
}

/* ────────────────────────────────── компонент ────────────────────────────── */

export function OrderTimeline({
  orderId,
  currentStatus,
}: {
  orderId: string;
  currentStatus: OrderStatus;
}): React.ReactElement {
  const { t, language } = useI18n();
  const now = useNow();
  const locale = LOCALE[language];

  const track = useQuery({
    queryKey: ['order', orderId, 'track'],
    queryFn: () => apiFetch<OrderTrackDto>(`/orders/${orderId}/track`),
    enabled: Boolean(orderId),
  });

  const events = React.useMemo(
    () =>
      [...(track.data?.events ?? [])].sort(
        (left, right) => Date.parse(left.occurredAt) - Date.parse(right.occurredAt),
      ),
    [track.data],
  );

  if (track.isLoading) {
    return (
      <div className="premium-card space-y-5 p-4 sm:p-5">
        <Skeleton className="h-4 w-32" />
        <Skeleton className="h-9 w-full" />
        <SkeletonText lines={4} />
      </div>
    );
  }

  return (
    <section className="premium-card space-y-5 p-4 sm:p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-sm font-semibold tracking-tight text-foreground">
          {t('orderTimeline.title')}
        </h2>
        {track.isError ? (
          <button
            type="button"
            onClick={() => void track.refetch()}
            className="text-xs text-primary underline-offset-2 hover:underline"
          >
            {t('ui.retry')}
          </button>
        ) : null}
      </div>

      <ProgressTrack currentStatus={currentStatus} events={events} />

      {track.isError ? (
        <p className="text-xs text-destructive">{t('orderTimeline.loadError')}</p>
      ) : events.length === 0 ? (
        <p className="text-xs text-muted-foreground">{t('orderTimeline.empty')}</p>
      ) : (
        <ol className="border-t border-border pt-4">
          {events.map((event, index) => (
            <EventRow
              key={event.id}
              event={event}
              nextOccurredAt={events[index + 1]?.occurredAt ?? null}
              now={now}
              isLast={index === events.length - 1}
              locale={locale}
            />
          ))}
        </ol>
      )}
    </section>
  );
}
