import * as React from 'react';
import type { OrderStatus } from '@ff/shared';
import { Badge, type BadgeProps } from '@/components/ui/badge';
import { useI18n, type MessageKey } from '@/lib/i18n';

/**
 * Магистраль заказа — статусы строго по порядку прохождения.
 *
 * CANCELLED и RETURNED сюда НЕ входят: это ветки, а не шаги. Полоса прогресса,
 * где отмена стоит последним «этапом», читается как «осталось отменить» —
 * ровно наоборот смыслу. Ветки рисуются отдельным терминальным узлом.
 */
export const ORDER_PIPELINE = [
  'NEW',
  'VALIDATED',
  'RESERVED',
  'PICKING',
  'PICKED',
  'PACKING',
  'PACKED',
  'READY_TO_SHIP',
  'DISPATCHED',
  'SHIPPED',
  'DELIVERED',
] as const satisfies readonly OrderStatus[];

export type OrderPipelineStage = (typeof ORDER_PIPELINE)[number];

/** Терминальные ветки вне магистрали. */
export const ORDER_BRANCH_STATUSES = ['RETURNED', 'CANCELLED'] as const satisfies readonly OrderStatus[];

export type OrderTone = NonNullable<BadgeProps['variant']>;

/**
 * Цвет статуса — один на всё приложение: бейдж в таблице, колонка канбана и
 * точка на треке обязаны совпадать, иначе оператор перестаёт читать цвет.
 * Смысл шкалы: серый — ещё не в работе, синий — принят, жёлтый — руками на
 * складе, фиолетовый (primary) — готов, зелёный — уехал, красный — отменён.
 */
export const ORDER_STAGE_TONE: Record<OrderStatus, OrderTone> = {
  NEW: 'muted',
  VALIDATED: 'info',
  RESERVED: 'info',
  PICKING: 'warning',
  PICKED: 'warning',
  PACKING: 'warning',
  PACKED: 'default',
  READY_TO_SHIP: 'default',
  DISPATCHED: 'success',
  SHIPPED: 'success',
  DELIVERED: 'success',
  RETURNED: 'warning',
  CANCELLED: 'destructive',
};

/** Ключ словаря для статуса. Вынесен, чтобы приведение к MessageKey было в одном месте. */
export function orderStatusKey(status: OrderStatus): MessageKey {
  return `orderStatus.${status}` as MessageKey;
}

/** Статусы, из которых заказ ещё можно отменить: после доставки/возврата — нет. */
export function isOrderCancellable(status: OrderStatus): boolean {
  return status !== 'DELIVERED' && status !== 'RETURNED' && status !== 'CANCELLED';
}

export function OrderStatusBadge({
  status,
  size,
}: {
  status: OrderStatus;
  size?: 'sm' | 'default';
}): React.ReactElement {
  const { t } = useI18n();
  return (
    <Badge variant={ORDER_STAGE_TONE[status]} size={size} dot>
      {t(orderStatusKey(status))}
    </Badge>
  );
}
