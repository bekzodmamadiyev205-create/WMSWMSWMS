import * as React from 'react';
import { cn } from '@/lib/utils';
import { useI18n } from '@/lib/i18n';
import { Select } from '@/components/ui/select';

/**
 * Правка значения по месту — в ячейке таблицы или в карточке.
 *
 * Главное решение: в покое поле НЕ выглядит полем. Сетка из рамок нечитаема,
 * поэтому подсказка (подложка + карандаш) появляется только под курсором или
 * фокусом, а размеры в режиме чтения и правки совпадают — строка таблицы не
 * дёргается в момент клика.
 */
export interface InlineEditBaseProps {
  onSubmit: (next: string) => void | Promise<void>;
  disabled?: boolean;
  className?: string;
  placeholder?: string;
  emptyLabel?: string;
  align?: 'left' | 'right';
  ariaLabel?: string;
}

type Align = 'left' | 'right';

/* ────────────────────────────── общая механика ───────────────────────────── */

interface CommitRequest {
  next: string;
  unchanged: boolean;
  /** Непустая строка = значение не прошло проверку, запрос не уходит. */
  invalid?: string | null;
  restoreFocus: boolean;
  submit: (next: string) => void | Promise<void>;
  revert: () => void;
}

interface InlineEditor {
  editing: boolean;
  pending: boolean;
  error: string | null;
  triggerRef: React.MutableRefObject<HTMLButtonElement | null>;
  begin: () => void;
  close: (restoreFocus: boolean) => void;
  commit: (request: CommitRequest) => void;
  clearError: () => void;
}

function useInlineEditor(): InlineEditor {
  const [editing, setEditing] = React.useState(false);
  const [pending, setPending] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const triggerRef = React.useRef<HTMLButtonElement | null>(null);
  // Синхронное зеркало editing: blur прилетает раньше ре-рендера, и по стейту
  // из замыкания уже закрытый редактор успел бы отправить второй запрос.
  const activeRef = React.useRef(false);
  const mountedRef = React.useRef(true);
  const restoreRef = React.useRef(false);

  React.useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  // Фокус возвращаем только после Enter/Escape. После blur человек уже увёл
  // курсор сам — отбирать у него фокус обратно значит ломать переход по Tab.
  React.useEffect(() => {
    if (editing || !restoreRef.current) return;
    restoreRef.current = false;
    triggerRef.current?.focus();
  }, [editing]);

  const begin = React.useCallback((): void => {
    activeRef.current = true;
    setError(null);
    setEditing(true);
  }, []);

  const close = React.useCallback((restoreFocus: boolean): void => {
    activeRef.current = false;
    restoreRef.current = restoreFocus;
    setError(null);
    setEditing(false);
  }, []);

  const commit = React.useCallback(
    (request: CommitRequest): void => {
      if (!activeRef.current) return;
      if (request.invalid) {
        setError(request.invalid);
        return;
      }
      // Запись тем же значением — мусор в журнале аудита, а не сохранение.
      if (request.unchanged) {
        close(request.restoreFocus);
        return;
      }
      activeRef.current = false;
      setError(null);
      setPending(true);
      void (async () => {
        try {
          await request.submit(request.next);
          if (!mountedRef.current) return;
          setPending(false);
          restoreRef.current = request.restoreFocus;
          setEditing(false);
        } catch (failure) {
          if (!mountedRef.current) return;
          setPending(false);
          activeRef.current = true;
          request.revert();
          setError(failure instanceof Error ? failure.message : String(failure));
        }
      })();
    },
    [close],
  );

  const clearError = React.useCallback((): void => setError(null), []);

  return { editing, pending, error, triggerRef, begin, close, commit, clearError };
}

/* ─────────────────────────────── оформление ──────────────────────────────── */

function fieldClass(align: Align, invalid: boolean): string {
  return cn(
    '-mx-1.5 w-full rounded-md bg-background px-1.5 py-0.5 text-sm text-foreground',
    'outline-none ring-1 ring-ring transition-colors placeholder:text-muted-foreground',
    // Поле на время сохранения выключено, но должно остаться читаемым:
    // текст, который уходит на сервер, гасить незачем.
    'disabled:cursor-progress disabled:opacity-100',
    align === 'right' && 'text-right',
    invalid && 'ring-destructive',
  );
}

function PencilIcon({ className }: { className?: string }): React.ReactElement {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" />
    </svg>
  );
}

function Spinner(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 shrink-0 animate-spin text-muted-foreground" aria-hidden="true">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeOpacity="0.25" strokeWidth="3" />
      <path d="M21 12a9 9 0 0 0-9-9" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

function InlineError({ id, message }: { id: string; message: string | null }): React.ReactElement | null {
  if (!message) return null;
  return (
    <p id={id} role="alert" className="mt-1 animate-fade-in text-xs text-destructive">
      {message}
    </p>
  );
}

interface ReadValueProps {
  text: string;
  empty: boolean;
  align: Align;
  wrap: boolean;
  hint: string;
  ariaLabel?: string;
  suffix?: string;
  onOpen: () => void;
}

const ReadValue = React.forwardRef<HTMLButtonElement, ReadValueProps>(
  ({ text, empty, align, wrap, hint, ariaLabel, suffix, onOpen }, ref) => (
    <button
      ref={ref}
      type="button"
      onClick={onOpen}
      title={hint}
      aria-label={ariaLabel}
      className={cn(
        'group -mx-1.5 flex w-full cursor-text items-center gap-1.5 rounded-md px-1.5 py-0.5 text-sm',
        'transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
        align === 'right' ? 'justify-end text-right' : 'justify-start text-left',
      )}
    >
      <span className={cn(wrap ? 'whitespace-pre-line' : 'truncate', empty && 'text-muted-foreground')}>{text}</span>
      {suffix ? <span className="shrink-0 text-muted-foreground">{suffix}</span> : null}
      <PencilIcon className="h-3 w-3 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-70 group-focus-visible:opacity-70" />
    </button>
  ),
);
ReadValue.displayName = 'ReadValue';

function ReadOnlyValue({
  text,
  empty,
  align,
  wrap,
  suffix,
  className,
}: {
  text: string;
  empty: boolean;
  align: Align;
  wrap: boolean;
  suffix?: string;
  className?: string;
}): React.ReactElement {
  return (
    <div className={cn('w-full text-sm', align === 'right' && 'text-right', className)}>
      <span className={cn(wrap && 'whitespace-pre-line', empty && 'text-muted-foreground')}>{text}</span>
      {suffix ? <span className="ml-1 text-muted-foreground">{suffix}</span> : null}
    </div>
  );
}

/* ───────────────────────────────── текст ─────────────────────────────────── */

export function InlineText({
  value,
  multiline = false,
  maxLength,
  onSubmit,
  disabled = false,
  className,
  placeholder,
  emptyLabel = '—',
  align = 'left',
  ariaLabel,
}: InlineEditBaseProps & { value: string; multiline?: boolean; maxLength?: number }): React.ReactElement {
  const { t } = useI18n();
  const editor = useInlineEditor();
  const [draft, setDraft] = React.useState(value);
  const fieldRef = React.useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);
  const errorId = React.useId();

  // Значение, приехавшее снаружи, не затирает набранное: правка длиннее рефетча.
  React.useEffect(() => {
    if (!editor.editing) setDraft(value);
  }, [value, editor.editing]);

  React.useEffect(() => {
    if (!editor.editing) return;
    const field = fieldRef.current;
    if (!field) return;
    field.focus();
    field.select();
  }, [editor.editing]);

  const empty = value.trim() === '';
  const finish = (restoreFocus: boolean): void => {
    editor.commit({
      next: draft,
      unchanged: draft === value,
      restoreFocus,
      submit: onSubmit,
      revert: () => setDraft(value),
    });
  };

  if (disabled) {
    return (
      <ReadOnlyValue text={empty ? emptyLabel : value} empty={empty} align={align} wrap={multiline} className={className} />
    );
  }

  if (!editor.editing) {
    return (
      <div className={cn('w-full', className)}>
        <ReadValue
          ref={editor.triggerRef}
          text={empty ? emptyLabel : value}
          empty={empty}
          align={align}
          wrap={multiline}
          hint={t('ui.inline.hint')}
          ariaLabel={ariaLabel}
          onOpen={() => {
            setDraft(value);
            editor.begin();
          }}
        />
      </div>
    );
  }

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>): void => {
    if (event.key === 'Escape') {
      event.preventDefault();
      setDraft(value);
      editor.close(true);
      return;
    }
    if (event.key !== 'Enter') return;
    // В многострочном поле Enter — это перенос строки, отправка на Ctrl/Cmd+Enter.
    if (multiline && !(event.ctrlKey || event.metaKey)) return;
    event.preventDefault();
    finish(true);
  };

  const shared = {
    value: draft,
    disabled: editor.pending,
    placeholder,
    maxLength,
    'aria-label': ariaLabel,
    'aria-busy': editor.pending || undefined,
    'aria-invalid': editor.error ? true : undefined,
    'aria-describedby': editor.error ? errorId : undefined,
    onKeyDown: handleKeyDown,
    onBlur: () => finish(false),
  };

  return (
    <div className={cn('w-full', className)}>
      <div className="relative flex items-center gap-1.5">
        {multiline ? (
          <textarea
            {...shared}
            ref={(element) => {
              fieldRef.current = element;
            }}
            rows={3}
            onChange={(event) => {
              editor.clearError();
              setDraft(event.target.value);
            }}
            className={cn(fieldClass(align, Boolean(editor.error)), 'resize-y leading-5')}
          />
        ) : (
          <input
            {...shared}
            ref={(element) => {
              fieldRef.current = element;
            }}
            type="text"
            onChange={(event) => {
              editor.clearError();
              setDraft(event.target.value);
            }}
            className={fieldClass(align, Boolean(editor.error))}
          />
        )}
        {editor.pending ? (
          <span className="pointer-events-none absolute right-1 top-1 flex items-center" title={t('ui.inline.saving')}>
            <Spinner />
            <span className="sr-only">{t('ui.inline.saving')}</span>
          </span>
        ) : null}
      </div>
      <InlineError id={errorId} message={editor.error} />
    </div>
  );
}

/* ───────────────────────────────── число ─────────────────────────────────── */

function parseNumber(raw: string): number | null {
  const normalized = raw.trim().replace(',', '.');
  if (normalized === '' || !/^-?\d+(\.\d+)?$/.test(normalized)) return null;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function decimalsOf(step: number): number {
  return String(step).split('.')[1]?.length ?? 0;
}

/**
 * Сообщение о неверном числе собирается из самих границ («10 … 100»), а не из
 * словаря: фраз про валидацию в наборе ключей нет, а знаки неравенства
 * читаются одинаково на всех четырёх языках интерфейса.
 */
function rangeHint(min?: number, max?: number): string {
  if (min !== undefined && max !== undefined) return `${min} … ${max}`;
  if (min !== undefined) return `≥ ${min}`;
  if (max !== undefined) return `≤ ${max}`;
  return '0–9';
}

export function InlineNumber({
  value,
  min,
  max,
  step = 1,
  suffix,
  onSubmit,
  disabled = false,
  className,
  placeholder,
  emptyLabel = '—',
  align = 'right',
  ariaLabel,
}: InlineEditBaseProps & {
  value: number | string | null;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
}): React.ReactElement {
  const { t } = useI18n();
  const editor = useInlineEditor();
  const original = value === null ? '' : String(value);
  const [draft, setDraft] = React.useState(original);
  const fieldRef = React.useRef<HTMLInputElement | null>(null);
  const errorId = React.useId();

  React.useEffect(() => {
    if (!editor.editing) setDraft(original);
  }, [original, editor.editing]);

  React.useEffect(() => {
    if (!editor.editing) return;
    fieldRef.current?.focus();
    fieldRef.current?.select();
  }, [editor.editing]);

  const empty = original.trim() === '';
  const normalized = draft.trim().replace(',', '.');

  const finish = (restoreFocus: boolean): void => {
    const parsed = parseNumber(draft);
    const bad =
      normalized !== '' &&
      (parsed === null || (min !== undefined && parsed < min) || (max !== undefined && parsed > max));
    editor.commit({
      next: normalized,
      unchanged: normalized === original,
      invalid: bad ? rangeHint(min, max) : null,
      restoreFocus,
      submit: onSubmit,
      revert: () => setDraft(original),
    });
  };

  if (disabled) {
    return (
      <ReadOnlyValue
        text={empty ? emptyLabel : original}
        empty={empty}
        align={align}
        wrap={false}
        suffix={empty ? undefined : suffix}
        className={className}
      />
    );
  }

  if (!editor.editing) {
    return (
      <div className={cn('w-full', className)}>
        <ReadValue
          ref={editor.triggerRef}
          text={empty ? emptyLabel : original}
          empty={empty}
          align={align}
          wrap={false}
          suffix={empty ? undefined : suffix}
          hint={t('ui.inline.hint')}
          ariaLabel={ariaLabel}
          onOpen={() => {
            setDraft(original);
            editor.begin();
          }}
        />
      </div>
    );
  }

  const nudge = (direction: 1 | -1): void => {
    const base = parseNumber(draft) ?? min ?? 0;
    let next = base + direction * step;
    if (min !== undefined) next = Math.max(min, next);
    if (max !== undefined) next = Math.min(max, next);
    editor.clearError();
    setDraft(next.toFixed(decimalsOf(step)));
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>): void => {
    if (event.key === 'Escape') {
      event.preventDefault();
      setDraft(original);
      editor.close(true);
      return;
    }
    if (event.key === 'Enter') {
      event.preventDefault();
      finish(true);
      return;
    }
    // Стрелки заменяют «крутилки» type=number, от которого мы отказались.
    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
      event.preventDefault();
      nudge(event.key === 'ArrowUp' ? 1 : -1);
    }
  };

  return (
    <div className={cn('w-full', className)}>
      <div className="relative flex items-center gap-1.5">
        {/* type=text, а не number: колесо мыши над числовым полем меняет значение
            прямо в прокручиваемой таблице, и запятая как разделитель не проходит. */}
        <input
          ref={fieldRef}
          type="text"
          inputMode="decimal"
          value={draft}
          disabled={editor.pending}
          placeholder={placeholder}
          aria-label={ariaLabel}
          aria-busy={editor.pending || undefined}
          aria-invalid={editor.error ? true : undefined}
          aria-describedby={editor.error ? errorId : undefined}
          onChange={(event) => {
            editor.clearError();
            setDraft(event.target.value);
          }}
          onKeyDown={handleKeyDown}
          onBlur={() => finish(false)}
          className={fieldClass(align, Boolean(editor.error))}
        />
        {suffix ? <span className="shrink-0 text-sm text-muted-foreground">{suffix}</span> : null}
        {editor.pending ? (
          <span className="pointer-events-none absolute right-1 top-1 flex items-center" title={t('ui.inline.saving')}>
            <Spinner />
            <span className="sr-only">{t('ui.inline.saving')}</span>
          </span>
        ) : null}
      </div>
      <InlineError id={errorId} message={editor.error} />
    </div>
  );
}

/* ────────────────────────────────── выбор ────────────────────────────────── */

export function InlineSelect({
  value,
  options,
  onSubmit,
  disabled = false,
  className,
  emptyLabel = '—',
  align = 'left',
  ariaLabel,
}: Omit<InlineEditBaseProps, 'placeholder'> & {
  value: string;
  options: Array<{ value: string; label: string }>;
}): React.ReactElement {
  const { t } = useI18n();
  const editor = useInlineEditor();
  const fieldRef = React.useRef<HTMLSelectElement | null>(null);
  const errorId = React.useId();

  React.useEffect(() => {
    if (!editor.editing) return;
    const field = fieldRef.current;
    if (!field) return;
    field.focus();
    // Список раскрываем сразу — иначе на клик по значению человек получает
    // такой же с виду текст и должен кликнуть второй раз. showPicker есть не
    // везде и требует жеста пользователя, поэтому вызов необязательный.
    const withPicker = field as HTMLSelectElement & { showPicker?: () => void };
    try {
      withPicker.showPicker?.();
    } catch {
      /* без жеста браузер откажет — останется обычный фокус */
    }
  }, [editor.editing]);

  const current = options.find((option) => option.value === value);
  const empty = !current;

  const finish = (next: string, restoreFocus: boolean): void => {
    editor.commit({
      next,
      unchanged: next === value,
      restoreFocus,
      submit: onSubmit,
      revert: () => undefined,
    });
  };

  if (disabled) {
    return (
      <ReadOnlyValue text={current?.label ?? emptyLabel} empty={empty} align={align} wrap={false} className={className} />
    );
  }

  if (!editor.editing) {
    return (
      <div className={cn('w-full', className)}>
        <ReadValue
          ref={editor.triggerRef}
          text={current?.label ?? emptyLabel}
          empty={empty}
          align={align}
          wrap={false}
          hint={t('ui.inline.hint')}
          ariaLabel={ariaLabel}
          onOpen={editor.begin}
        />
      </div>
    );
  }

  return (
    <div className={cn('w-full', className)}>
      <div className="relative flex items-center gap-1.5">
        <Select
          ref={fieldRef}
          value={value}
          disabled={editor.pending}
          aria-label={ariaLabel}
          aria-busy={editor.pending || undefined}
          aria-invalid={editor.error ? true : undefined}
          aria-describedby={editor.error ? errorId : undefined}
          onChange={(event) => finish(event.target.value, true)}
          onBlur={(event) => finish(event.target.value, false)}
          onKeyDown={(event) => {
            if (event.key !== 'Escape') return;
            event.preventDefault();
            editor.close(true);
          }}
          className={cn(
            '-mx-1.5 h-auto rounded-md border-transparent px-1.5 py-0.5 text-sm',
            'ring-1 ring-ring ring-offset-0 focus-visible:ring-2',
            'disabled:cursor-progress disabled:opacity-100',
            align === 'right' && 'text-right',
            editor.error && 'ring-destructive',
          )}
        >
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </Select>
        {editor.pending ? (
          <span className="pointer-events-none absolute right-1 top-1 flex items-center" title={t('ui.inline.saving')}>
            <Spinner />
            <span className="sr-only">{t('ui.inline.saving')}</span>
          </span>
        ) : null}
      </div>
      <InlineError id={errorId} message={editor.error} />
    </div>
  );
}
