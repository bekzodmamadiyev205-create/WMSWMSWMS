import * as React from 'react';
import { cva } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * Один рецепт на все варианты: заливка /10 плюс внутреннее кольцо /20 от того же
 * токена. Насыщенный фон пришлось бы подбирать отдельно под светлую и тёмную темы,
 * а полупрозрачный оттенок ложится на любой фон и остаётся читаемым сам собой.
 */
const badgeVariants = cva(
  'inline-flex items-center gap-1.5 whitespace-nowrap rounded-md font-medium leading-none ring-1 ring-inset transition-colors',
  {
    variants: {
      variant: {
        default: 'bg-primary/10 text-primary ring-primary/20',
        secondary: 'bg-accent text-foreground ring-border',
        outline: 'bg-transparent text-foreground ring-border',
        success: 'bg-success/10 text-success ring-success/20',
        warning: 'bg-warning/10 text-warning ring-warning/20',
        info: 'bg-info/10 text-info ring-info/20',
        destructive: 'bg-destructive/10 text-destructive ring-destructive/20',
        muted: 'bg-muted text-muted-foreground ring-border/60',
      },
      size: {
        sm: 'px-1.5 py-0.5 text-[11px]',
        default: 'px-2 py-0.5 text-xs',
      },
    },
    defaultVariants: { variant: 'default', size: 'default' },
  },
);

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'default' | 'secondary' | 'outline' | 'success' | 'warning' | 'info' | 'destructive' | 'muted';
  size?: 'sm' | 'default';
  /** Точка перед текстом: статус узнаётся по цвету и без чтения подписи. */
  dot?: boolean;
}

export function Badge({
  className,
  variant,
  size,
  dot = false,
  children,
  ...props
}: BadgeProps): React.ReactElement {
  return (
    <span className={cn(badgeVariants({ variant, size }), className)} {...props}>
      {dot ? (
        // Цвет точки — `currentColor`: она не может разъехаться с текстом варианта.
        <span aria-hidden="true" className="h-1.5 w-1.5 shrink-0 rounded-full bg-current" />
      ) : null}
      {children}
    </span>
  );
}

export { badgeVariants };
