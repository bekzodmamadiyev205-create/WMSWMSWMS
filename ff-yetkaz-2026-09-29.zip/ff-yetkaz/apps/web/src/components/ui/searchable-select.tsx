import * as React from 'react';
import { useI18n } from '@/lib/i18n';
import { cn } from '@/lib/utils';

export interface SearchableOption {
  value: string;
  /** Что показать в списке. */
  label: string;
  /** Что показать в кнопке-триггере, если короче label (по умолчанию label). */
  triggerLabel?: string;
  /** Текст для поиска, если отличается от label. */
  keywords?: string;
}

interface SearchableSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: SearchableOption[];
  /** Пункт-сброс наверху списка (value = ''), например «Все селлеры». */
  clearLabel?: string;
  placeholder?: string;
  searchPlaceholder?: string;
  id?: string;
  className?: string;
}

/**
 * Дропдаун с поиском: тот же формат выпадающего списка, но с полем поиска сверху.
 * Нативный <select> искать по названию не умеет, а при десятках селлеров это нужно.
 * Закрывается кликом мимо и по Esc; на выбор — закрытие и сброс запроса.
 */
export function SearchableSelect({
  value,
  onChange,
  options,
  clearLabel,
  placeholder,
  searchPlaceholder,
  id,
  className,
}: SearchableSelectProps): React.ReactElement {
  const { t } = useI18n();
  const [open, setOpen] = React.useState(false);
  const [query, setQuery] = React.useState('');
  const ref = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!open) return;
    const onDown = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        setOpen(false);
        setQuery('');
      }
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open]);

  const selected = options.find((option) => option.value === value);
  const triggerText =
    value === ''
      ? clearLabel ?? placeholder ?? ''
      : selected?.triggerLabel ?? selected?.label ?? value;

  const q = query.trim().toLowerCase();
  const filtered = q
    ? options.filter((option) => (option.keywords ?? option.label).toLowerCase().includes(q))
    : options;

  const pick = (next: string) => {
    onChange(next);
    setOpen(false);
    setQuery('');
  };

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        id={id}
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen((prev) => !prev)}
        className={cn(
          'flex h-10 w-full items-center justify-between gap-2 rounded-md border border-input',
          'bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none',
          'focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
          className,
        )}
      >
        <span className={cn('truncate', value === '' && 'text-muted-foreground')}>
          {triggerText || placeholder}
        </span>
        <span aria-hidden className="shrink-0 text-xs text-muted-foreground">
          ▾
        </span>
      </button>

      {open && (
        <div className="absolute left-0 z-50 mt-1 w-full min-w-[15rem] overflow-hidden rounded-md border bg-card shadow-xl">
          <div className="border-b p-2">
            <input
              autoFocus
              value={query}
              placeholder={searchPlaceholder ?? t('common.search')}
              onChange={(event) => setQuery(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Escape') {
                  setOpen(false);
                  setQuery('');
                }
              }}
              className="h-8 w-full rounded border border-input bg-background px-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>
          <div className="max-h-60 overflow-y-auto p-1">
            {clearLabel !== undefined && (
              <button
                type="button"
                onClick={() => pick('')}
                className={cn(
                  'flex w-full items-center rounded px-2 py-1.5 text-left text-sm hover:bg-accent',
                  value === '' && 'bg-muted font-medium',
                )}
              >
                {clearLabel}
              </button>
            )}
            {filtered.length === 0 && (
              <div className="px-2 py-2 text-sm text-muted-foreground">{t('common.nothingFound')}</div>
            )}
            {filtered.map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => pick(option.value)}
                className={cn(
                  'flex w-full items-center rounded px-2 py-1.5 text-left text-sm hover:bg-accent',
                  option.value === value && 'bg-muted font-medium',
                )}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
