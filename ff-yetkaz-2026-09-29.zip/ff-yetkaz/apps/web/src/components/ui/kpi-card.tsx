import * as React from 'react';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { Sparkline } from '@/components/ui/charts';

export type KpiTone = 'default' | 'success' | 'warning' | 'destructive' | 'info';

export interface KpiCardProps {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  delta?: { value: number; suffix?: string; positiveIsGood?: boolean };
  icon?: React.ReactNode;
  tone?: KpiTone;
  spark?: number[];
  loading?: boolean;
  onClick?: () => void;
  className?: string;
}

// Классы собраны в таблицы, а не в шаблонные строки: Tailwind вырезает всё,
// чего не видит в исходнике целиком, и `bg-${tone}/10` не попал бы в сборку.
const TONE_ICON: Record<KpiTone, string> = {
  default: 'bg-primary/10 text-primary',
  success: 'bg-success/10 text-success',
  warning: 'bg-warning/10 text-warning',
  destructive: 'bg-destructive/10 text-destructive',
  info: 'bg-info/10 text-info',
};

const TONE_TEXT: Record<KpiTone, string> = {
  default: 'text-primary',
  success: 'text-success',
  warning: 'text-warning',
  destructive: 'text-destructive',
  info: 'text-info',
};

function DeltaArrow({ up }: { up: boolean }): React.ReactElement {
  return (
    <svg viewBox="0 0 8 8" aria-hidden="true" className="h-2 w-2 shrink-0 fill-current">
      {up ? <path d="M4 0.5 7.5 7.5H0.5Z" /> : <path d="M4 7.5 0.5 0.5h7Z" />}
    </svg>
  );
}

/**
 * Плитка метрики. Знак «хорошо/плохо» у дельты задаёт вызывающий
 * (`positiveIsGood`), а не выводится из знака числа: рост процента возвратов
 * или просрочки — плохая новость, хотя число растёт.
 */
export function KpiCard({
  label,
  value,
  hint,
  delta,
  icon,
  tone = 'default',
  spark,
  loading = false,
  onClick,
  className,
}: KpiCardProps): React.ReactElement {
  const deltaPill = delta ? renderDelta(delta) : null;

  const body = (
    <>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 space-y-1.5">
          {loading ? (
            <Skeleton className="h-3 w-24" />
          ) : (
            <div className="truncate text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {label}
            </div>
          )}
          {loading ? (
            <Skeleton className="h-7 w-28" />
          ) : (
            <div className="text-2xl font-semibold leading-tight tabular-nums text-card-foreground">
              {value}
            </div>
          )}
        </div>
        {icon ? (
          <span
            aria-hidden="true"
            className={cn(
              'flex shrink-0 items-center justify-center rounded-lg p-2 [&>svg]:h-4 [&>svg]:w-4',
              TONE_ICON[tone],
            )}
          >
            {icon}
          </span>
        ) : null}
      </div>

      {deltaPill || hint ? (
        <div className="mt-2 flex flex-wrap items-center gap-2">
          {loading && delta ? <Skeleton className="h-5 w-16 rounded-full" /> : deltaPill}
          {loading && hint ? (
            <Skeleton className="h-3 w-20" />
          ) : hint ? (
            <span className="truncate text-xs text-muted-foreground">{hint}</span>
          ) : null}
        </div>
      ) : null}

      {spark ? (
        <div className={cn('mt-3', TONE_TEXT[tone])}>
          {loading ? (
            <Skeleton className="h-8 w-full" />
          ) : (
            // currentColor вместо переменной темы: цвет берётся у обёртки,
            // так плитка и линия не могут разъехаться по тону.
            <Sparkline values={spark} height={32} color="currentColor" />
          )}
        </div>
      ) : null}
    </>
  );

  const shell = cn('premium-card p-4', className);

  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        aria-busy={loading || undefined}
        className={cn(
          shell,
          'w-full text-left transition-all duration-150 hover:-translate-y-0.5 hover:shadow-md',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        )}
      >
        {body}
      </button>
    );
  }

  return (
    <div aria-busy={loading || undefined} className={shell}>
      {body}
    </div>
  );
}

function renderDelta(delta: NonNullable<KpiCardProps['delta']>): React.ReactElement {
  const { value, suffix, positiveIsGood = true } = delta;
  const magnitude = Math.abs(value);
  const text = `${Number.isInteger(magnitude) ? magnitude : magnitude.toFixed(1)}${suffix ?? ''}`;

  if (value === 0) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-xs font-medium tabular-nums text-muted-foreground">
        {text}
      </span>
    );
  }

  const good = value > 0 ? positiveIsGood : !positiveIsGood;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium tabular-nums',
        good ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive',
      )}
    >
      <DeltaArrow up={value > 0} />
      {/* Знак дублирует стрелку намеренно: скринридер иконку не читает. */}
      {value > 0 ? '+' : '−'}
      {text}
    </span>
  );
}

export function KpiGrid({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}): React.ReactElement {
  return (
    <div className={cn('grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4', className)}>
      {children}
    </div>
  );
}
