import * as React from 'react';
import { useI18n } from '@/lib/i18n';
import { Select } from '@/components/ui/select';
import { cn } from '@/lib/utils';

export interface PaginationProps {
  page: number; // 1-based
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  pageSizeOptions?: number[]; // default [20, 50, 100, 200]
  className?: string;
  compact?: boolean;
}

const DEFAULT_PAGE_SIZE_OPTIONS = [20, 50, 100, 200];

type PageItem = { kind: 'page'; page: number } | { kind: 'gap'; key: string };

/**
 * Окно номеров: первая, последняя и текущая ±2, разрывы схлопнуты в многоточие.
 * Рисовать все страницы нельзя — на 12 тысячах заказов строка номеров сама
 * становится длиннее таблицы.
 */
function buildPageItems(page: number, pageCount: number): PageItem[] {
  const wanted = new Set<number>([1, pageCount]);
  for (let candidate = page - 2; candidate <= page + 2; candidate += 1) {
    if (candidate >= 1 && candidate <= pageCount) wanted.add(candidate);
  }

  const items: PageItem[] = [];
  let previous = 0;
  for (const current of [...wanted].sort((a, b) => a - b)) {
    if (previous > 0 && current - previous > 1) items.push({ kind: 'gap', key: `gap-${previous}` });
    items.push({ kind: 'page', page: current });
    previous = current;
  }
  return items;
}

/**
 * Управление страницами: слева — что именно сейчас показано, справа — размер
 * страницы и переходы. Пустой список не должен показывать «0–0 из 0», поэтому при
 * total = 0 компонент исчезает целиком.
 */
export function Pagination({
  page,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = DEFAULT_PAGE_SIZE_OPTIONS,
  className,
  compact = false,
}: PaginationProps): React.ReactElement | null {
  const { t } = useI18n();
  const labelId = React.useId();
  const sizeId = React.useId();

  if (total <= 0) return null;

  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  // Страницу извне могли передать за пределами диапазона (например, после смены
  // фильтра): зажимаем её здесь, иначе подсветка активной кнопки пропадёт молча.
  const current = Math.min(Math.max(1, page), pageCount);
  const from = (current - 1) * pageSize + 1;
  const to = Math.min(current * pageSize, total);

  const go = (next: number): void => {
    const clamped = Math.min(Math.max(1, next), pageCount);
    if (clamped !== current) onPageChange(clamped);
  };

  // Текущий размер может не входить в список опций (пришёл из URL) — без этого
  // нативный select показал бы первый пункт и соврал бы о реальном размере страницы.
  const sizes = pageSizeOptions.includes(pageSize)
    ? pageSizeOptions
    : [...pageSizeOptions, pageSize].sort((a, b) => a - b);

  const navButton = cn(
    'inline-flex h-8 w-8 items-center justify-center rounded-md border border-input bg-background',
    'text-muted-foreground transition-colors hover:bg-accent hover:text-foreground',
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
    'focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-40',
  );

  return (
    <nav
      aria-labelledby={labelId}
      className={cn('flex flex-wrap items-center justify-between gap-3', className)}
    >
      <p id={labelId} className="text-xs tabular-nums text-muted-foreground">
        {t('ui.page.showing', { from: String(from), to: String(to), total: String(total) })}
      </p>

      <div className="flex items-center gap-3">
        {!compact && onPageSizeChange ? (
          <div className="flex items-center gap-2">
            <label htmlFor={sizeId} className="text-xs text-muted-foreground">
              {t('ui.page.size')}
            </label>
            <Select
              id={sizeId}
              value={pageSize}
              onChange={(event) => onPageSizeChange(Number(event.target.value))}
              className="h-8 w-auto px-2 py-0 text-xs"
            >
              {sizes.map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
            </Select>
          </div>
        ) : null}

        <div className="flex items-center gap-1">
          <button
            type="button"
            className={navButton}
            onClick={() => go(1)}
            disabled={current === 1}
            aria-label={t('ui.page.first')}
            title={t('ui.page.first')}
          >
            <Chevron direction="left" double />
          </button>
          <button
            type="button"
            className={navButton}
            onClick={() => go(current - 1)}
            disabled={current === 1}
            aria-label={t('ui.page.prev')}
            title={t('ui.page.prev')}
          >
            <Chevron direction="left" />
          </button>

          {compact ? (
            <span className="px-2 text-xs tabular-nums text-muted-foreground">
              {current} {t('ui.page.of')} {pageCount}
            </span>
          ) : (
            <div className="flex items-center gap-1">
              {buildPageItems(current, pageCount).map((item) =>
                item.kind === 'gap' ? (
                  <span
                    key={item.key}
                    aria-hidden="true"
                    className="px-1 text-xs text-muted-foreground"
                  >
                    …
                  </span>
                ) : (
                  <button
                    key={item.page}
                    type="button"
                    onClick={() => go(item.page)}
                    aria-current={item.page === current ? 'page' : undefined}
                    className={cn(
                      'inline-flex h-8 min-w-[2rem] items-center justify-center rounded-md px-2 text-xs font-medium tabular-nums transition-colors',
                      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
                      item.page === current
                        ? 'bg-primary/10 text-primary ring-1 ring-inset ring-primary/20'
                        : 'text-muted-foreground hover:bg-accent hover:text-foreground',
                    )}
                  >
                    {item.page}
                  </button>
                ),
              )}
            </div>
          )}

          <button
            type="button"
            className={navButton}
            onClick={() => go(current + 1)}
            disabled={current === pageCount}
            aria-label={t('ui.page.next')}
            title={t('ui.page.next')}
          >
            <Chevron direction="right" />
          </button>
          <button
            type="button"
            className={navButton}
            onClick={() => go(pageCount)}
            disabled={current === pageCount}
            aria-label={t('ui.page.last')}
            title={t('ui.page.last')}
          >
            <Chevron direction="right" double />
          </button>
        </div>
      </div>
    </nav>
  );
}

function Chevron({
  direction,
  double = false,
}: {
  direction: 'left' | 'right';
  double?: boolean;
}): React.ReactElement {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn('h-4 w-4', direction === 'right' && 'rotate-180')}
    >
      {double ? (
        <>
          <path d="m17 18-6-6 6-6" />
          <path d="m10 18-6-6 6-6" />
        </>
      ) : (
        <path d="m15 18-6-6 6-6" />
      )}
    </svg>
  );
}
