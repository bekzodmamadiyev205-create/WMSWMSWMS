import * as React from 'react';
import { cn } from '@/lib/utils';

type Align = 'left' | 'center' | 'right';

const ALIGN: Record<Align, string> = {
  left: 'text-left',
  center: 'text-center',
  right: 'text-right',
};

/**
 * Примитивы таблицы. Горизонтальный скролл НЕ здесь: контейнер заводит
 * вызывающий код — иначе таблицу нельзя вложить в карточку, у которой скроллит
 * только область строк, а шапка и подвал стоят на месте.
 *
 * `border-separate` вместо схлопнутых границ выбран ради липкой шапки:
 * при `border-collapse` рамки принадлежат таблице, а не ячейке, и у `sticky`-шапки
 * они просто не едут вместе с ней — линия остаётся наверху списка.
 */
export function Table({ className, ...props }: React.TableHTMLAttributes<HTMLTableElement>): React.ReactElement {
  return (
    <table
      className={cn('w-full caption-bottom border-separate border-spacing-0 text-sm', className)}
      {...props}
    />
  );
}

export function THead({
  className,
  ...props
}: React.HTMLAttributes<HTMLTableSectionElement>): React.ReactElement {
  return <thead className={cn(className)} {...props} />;
}

export function TBody({
  className,
  ...props
}: React.HTMLAttributes<HTMLTableSectionElement>): React.ReactElement {
  return <tbody className={cn(className)} {...props} />;
}

export function TFoot({
  className,
  ...props
}: React.HTMLAttributes<HTMLTableSectionElement>): React.ReactElement {
  return <tfoot className={cn('text-muted-foreground', className)} {...props} />;
}

export function TR({ className, ...props }: React.HTMLAttributes<HTMLTableRowElement>): React.ReactElement {
  return <tr className={cn('transition-colors hover:bg-muted/40', className)} {...props} />;
}

export function TH({
  className,
  align = 'left',
  ...props
}: React.ThHTMLAttributes<HTMLTableCellElement> & { align?: Align }): React.ReactElement {
  return (
    <th
      className={cn(
        'whitespace-nowrap border-b border-border px-3 py-2.5 text-xs font-medium text-muted-foreground',
        ALIGN[align],
        className,
      )}
      {...props}
    />
  );
}

export function TD({
  className,
  align = 'left',
  ...props
}: React.TdHTMLAttributes<HTMLTableCellElement> & { align?: Align }): React.ReactElement {
  return (
    <td
      className={cn('border-b border-border/60 px-3 py-2.5 align-middle', ALIGN[align], className)}
      {...props}
    />
  );
}
