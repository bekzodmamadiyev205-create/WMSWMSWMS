import * as React from 'react';
import { useI18n } from '@/lib/i18n';
import { cn } from '@/lib/utils';

export type DropdownItem =
  | {
      key: string;
      label: React.ReactNode;
      icon?: React.ReactNode;
      onSelect: () => void;
      danger?: boolean;
      disabled?: boolean;
    }
  | { key: string; separator: true };

export interface DropdownMenuProps {
  /** Содержимое кнопки; по умолчанию — иконка «⋯». Свой `<button>` вкладывать нельзя. */
  trigger?: React.ReactNode;
  items: DropdownItem[];
  align?: 'start' | 'end';
  className?: string;
  triggerClassName?: string;
  /** aria-label для кнопки без текста. */
  label?: string;
}

function isSeparator(item: DropdownItem): item is { key: string; separator: true } {
  return 'separator' in item;
}

/**
 * Меню действий над строкой или карточкой.
 *
 * Сознательно не построено на `Popover`: у меню своя семантика (`role="menu"`, фокус
 * переезжает НА пункт стрелками) — общий поповер пришлось бы разветвлять изнутри,
 * и оба компонента стали бы хрупкими. Клавиши слушает обёртка: фокус может быть и на
 * триггере (меню открыли мышью), и на пункте, а обработчик нужен один.
 */
export function DropdownMenu({
  trigger,
  items,
  align = 'end',
  className,
  triggerClassName,
  label,
}: DropdownMenuProps): React.ReactElement {
  const { t } = useI18n();
  const [open, setOpen] = React.useState(false);
  const [active, setActive] = React.useState(-1);

  const wrapperRef = React.useRef<HTMLDivElement>(null);
  const triggerRef = React.useRef<HTMLButtonElement>(null);
  const menuRef = React.useRef<HTMLDivElement>(null);
  const itemRefs = React.useRef<Array<HTMLButtonElement | null>>([]);
  const menuId = React.useId();

  const defaultTrigger = trigger === undefined;
  const triggerLabel = label ?? t('ui.more');

  /** Индексы пунктов, на которые вообще можно встать: разделители и отключённые пропускаем. */
  const reachable = React.useMemo(
    () => items.map((item, index) => (isSeparator(item) || item.disabled ? -1 : index)).filter((index) => index >= 0),
    [items],
  );

  const close = React.useCallback((restoreFocus: boolean): void => {
    setOpen(false);
    setActive(-1);
    if (restoreFocus) triggerRef.current?.focus();
  }, []);

  React.useEffect(() => {
    if (!open || active < 0) return;
    itemRefs.current[active]?.focus();
  }, [open, active]);

  React.useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: MouseEvent): void => {
      if (wrapperRef.current?.contains(event.target as Node)) return;
      close(menuRef.current?.contains(document.activeElement) ?? false);
    };
    document.addEventListener('mousedown', onPointerDown);
    return () => document.removeEventListener('mousedown', onPointerDown);
  }, [open, close]);

  const step = (direction: 1 | -1): void => {
    if (reachable.length === 0) return;
    const position = reachable.indexOf(active);
    const next =
      position < 0
        ? direction === 1
          ? 0
          : reachable.length - 1
        : (position + direction + reachable.length) % reachable.length;
    setActive(reachable[next] ?? -1);
  };

  const onKeyDown = (event: React.KeyboardEvent<HTMLDivElement>): void => {
    switch (event.key) {
      case 'ArrowDown':
        event.preventDefault();
        if (!open) setOpen(true);
        step(1);
        break;
      case 'ArrowUp':
        event.preventDefault();
        if (!open) setOpen(true);
        step(-1);
        break;
      case 'Home':
        if (!open) return;
        event.preventDefault();
        setActive(reachable[0] ?? -1);
        break;
      case 'End':
        if (!open) return;
        event.preventDefault();
        setActive(reachable[reachable.length - 1] ?? -1);
        break;
      case 'Escape':
        if (!open) return;
        event.stopPropagation();
        close(true);
        break;
      case 'Tab':
        // Таб не перехватываем: пользователь уходит дальше по странице, меню просто закрывается.
        if (open) close(false);
        break;
      default:
        break;
    }
  };

  return (
    <div ref={wrapperRef} onKeyDown={onKeyDown} className={cn('relative inline-block', className)}>
      <button
        ref={triggerRef}
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={open ? menuId : undefined}
        aria-label={defaultTrigger || label ? triggerLabel : undefined}
        onClick={() => (open ? close(false) : setOpen(true))}
        className={cn(
          'inline-flex items-center justify-center gap-2 rounded-lg text-sm transition-colors',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
          'focus-visible:ring-offset-2 focus-visible:ring-offset-background',
          defaultTrigger && 'h-8 w-8 text-muted-foreground hover:bg-accent hover:text-foreground',
          defaultTrigger && open && 'bg-accent text-foreground',
          triggerClassName,
        )}
      >
        {defaultTrigger ? (
          <svg viewBox="0 0 20 20" className="h-4 w-4" fill="currentColor" aria-hidden>
            <circle cx="4" cy="10" r="1.5" />
            <circle cx="10" cy="10" r="1.5" />
            <circle cx="16" cy="10" r="1.5" />
          </svg>
        ) : (
          trigger
        )}
      </button>

      {open && (
        <div
          ref={menuRef}
          id={menuId}
          role="menu"
          aria-orientation="vertical"
          className={cn(
            'premium-popover absolute z-50 mt-2 min-w-[11rem] origin-top p-1 animate-scale-in',
            align === 'end' ? 'right-0' : 'left-0',
          )}
        >
          {items.map((item, index) =>
            isSeparator(item) ? (
              <div key={item.key} role="separator" className="my-1 h-px bg-border" />
            ) : (
              <button
                key={item.key}
                ref={(element) => {
                  itemRefs.current[index] = element;
                }}
                type="button"
                role="menuitem"
                tabIndex={-1}
                disabled={item.disabled}
                onMouseEnter={() => setActive(index)}
                onClick={() => {
                  close(true);
                  item.onSelect();
                }}
                className={cn(
                  'flex w-full items-center gap-2.5 rounded-md px-2.5 py-1.5 text-left text-sm',
                  'transition-colors focus:outline-none disabled:pointer-events-none disabled:opacity-50',
                  item.danger
                    ? 'text-destructive hover:bg-destructive/10 focus:bg-destructive/10'
                    : 'text-card-foreground hover:bg-accent focus:bg-accent',
                )}
              >
                {item.icon ? (
                  <span
                    aria-hidden
                    className={cn(
                      'flex h-4 w-4 shrink-0 items-center justify-center',
                      !item.danger && 'text-muted-foreground',
                    )}
                  >
                    {item.icon}
                  </span>
                ) : null}
                <span className="truncate">{item.label}</span>
              </button>
            ),
          )}
        </div>
      )}
    </div>
  );
}
