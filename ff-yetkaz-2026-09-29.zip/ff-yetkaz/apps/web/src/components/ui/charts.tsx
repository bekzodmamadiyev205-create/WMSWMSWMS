import * as React from 'react';
import { cn } from '@/lib/utils';
import { useI18n } from '@/lib/i18n';

/**
 * Графики нарисованы вручную на SVG вместо recharts/chart.js: зависимость ради
 * четырёх видов диаграмм тянет за собой свою систему тем, и цвета неминуемо
 * разъезжаются с палитрой приложения. Здесь цвет всегда токен из index.css,
 * поэтому тёмная тема достаётся даром.
 */

export const CHART_COLORS: readonly string[] = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
  'hsl(var(--chart-6))',
];

const GRID_COLOR = 'hsl(var(--border))';
const GUIDE_COLOR = 'hsl(var(--muted-foreground))';
const SURFACE_COLOR = 'hsl(var(--background))';

export interface ChartSeries {
  key: string;
  name: string;
  color?: string;
}

export interface ChartPoint {
  label: string;
  values: Record<string, number>;
}

export interface BaseChartProps {
  points: ChartPoint[];
  series: ChartSeries[];
  height?: number;
  formatValue?: (v: number) => string;
  className?: string;
  legend?: boolean;
  emptyMessage?: string;
}

export interface DonutSlice {
  key: string;
  name: string;
  value: number;
  color?: string;
}

/* ────────────────────────────── числа и шкалы ────────────────────────────── */

const compactFormatter = new Intl.NumberFormat('ru-RU', {
  notation: 'compact',
  maximumFractionDigits: 1,
});

function defaultFormat(v: number): string {
  return compactFormatter.format(v);
}

/** Одна битая цифра в выгрузке не должна гасить весь дашборд — NaN/Infinity = 0. */
function num(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function clamp(v: number, min: number, max: number): number {
  return v < min ? min : v > max ? max : v;
}

function niceStep(rough: number): number {
  if (!(rough > 0)) return 1;
  const exp = Math.floor(Math.log10(rough));
  const base = 10 ** exp;
  const frac = rough / base;
  const nice = frac <= 1 ? 1 : frac <= 2 ? 2 : frac <= 5 ? 5 : 10;
  return nice * base;
}

interface Scale {
  min: number;
  max: number;
  ticks: number[];
}

/**
 * Ось всегда включает ноль: столбик, растущий от произвольной середины, врёт
 * о пропорциях. Вырожденный набор (всё по нулям, одна точка) не должен делить
 * на ноль — поэтому пустой диапазон разворачивается в 0…1.
 */
function niceScale(dataMin: number, dataMax: number, target = 4): Scale {
  let lo = Math.min(0, dataMin);
  let hi = Math.max(0, dataMax);
  if (hi - lo === 0) hi = lo + 1;
  const step = niceStep((hi - lo) / target);
  lo = Math.floor(lo / step) * step;
  hi = Math.ceil(hi / step) * step;
  const ticks: number[] = [];
  const count = Math.round((hi - lo) / step);
  for (let i = 0; i <= count; i += 1) {
    // накопление шага плавает на дробных значениях — считаем от начала
    ticks.push(Number((lo + step * i).toPrecision(12)));
  }
  return { min: lo, max: hi, ticks };
}

function estimateAxisWidth(labels: string[], max = 84): number {
  const longest = labels.reduce((acc, s) => Math.max(acc, s.length), 0);
  return clamp(longest * 6 + 12, 30, max);
}

/** Подписи прореживаются по ширине: перекрывшиеся подписи хуже отсутствующих. */
function labelStride(count: number, room: number, slot: number): number {
  const maxLabels = Math.max(1, Math.floor(room / slot));
  return Math.max(1, Math.ceil(count / maxLabels));
}

function pointValue(p: ChartPoint, key: string): number {
  return num(p.values[key]);
}

function seriesColor(s: ChartSeries, index: number): string {
  return s.color ?? CHART_COLORS[index % CHART_COLORS.length];
}

function roundedRect(
  x: number,
  y: number,
  w: number,
  h: number,
  radii: [number, number, number, number],
): string {
  const lim = Math.max(0, Math.min(w, h) / 2);
  const [tl, tr, br, bl] = radii.map((r) => clamp(r, 0, lim)) as [number, number, number, number];
  return [
    `M${x + tl},${y}`,
    `H${x + w - tr}`,
    tr ? `A${tr},${tr} 0 0 1 ${x + w},${y + tr}` : '',
    `V${y + h - br}`,
    br ? `A${br},${br} 0 0 1 ${x + w - br},${y + h}` : '',
    `H${x + bl}`,
    bl ? `A${bl},${bl} 0 0 1 ${x},${y + h - bl}` : '',
    `V${y + tl}`,
    tl ? `A${tl},${tl} 0 0 1 ${x + tl},${y}` : '',
    'Z',
  ]
    .filter(Boolean)
    .join(' ');
}

interface Pt {
  x: number;
  y: number;
}

function linePath(pts: Pt[]): string {
  if (pts.length === 0) return '';
  return pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.y}`).join(' ');
}

/** Catmull-Rom → кубическая Безье: сглаживание без выхода кривой за точки данных. */
function smoothPath(pts: Pt[]): string {
  if (pts.length < 3) return linePath(pts);
  let d = `M${pts[0].x},${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i += 1) {
    const p0 = pts[i - 1] ?? pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] ?? p2;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C${c1x},${c1y} ${c2x},${c2y} ${p2.x},${p2.y}`;
  }
  return d;
}

/* ────────────────────────────── измерение ширины ────────────────────────────── */

/**
 * Ширина берётся из ResizeObserver, а не из масштабируемого viewBox: растянутый
 * viewBox тянет вместе с графиком шрифт и толщину линий — именно это и выдаёт
 * самодельные диаграммы. Высота фиксирована, ширина всегда в реальных пикселях.
 */
function useMeasuredWidth(): [React.RefObject<HTMLDivElement>, number] {
  const ref = React.useRef<HTMLDivElement>(null);
  const [width, setWidth] = React.useState(0);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const apply = (w: number): void => setWidth(Math.max(0, Math.round(w)));
    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) apply(entry.contentRect.width);
    });
    ro.observe(el);
    apply(el.getBoundingClientRect().width);
    return () => ro.disconnect();
  }, []);

  return [ref, width];
}

/* ────────────────────────────── общие части ────────────────────────────── */

function useHiddenSeries(): {
  hidden: ReadonlySet<string>;
  toggle: (key: string) => void;
} {
  const [hidden, setHidden] = React.useState<ReadonlySet<string>>(() => new Set<string>());
  const toggle = React.useCallback((key: string): void => {
    setHidden((prev) => {
      const next = new Set(prev);
      if (!next.delete(key)) next.add(key);
      return next;
    });
  }, []);
  return { hidden, toggle };
}

interface LegendItem {
  key: string;
  name: string;
  color: string;
  meta?: string;
}

function ChartLegend({
  items,
  hidden,
  onToggle,
}: {
  items: LegendItem[];
  hidden?: ReadonlySet<string>;
  onToggle?: (key: string) => void;
}): React.ReactElement {
  return (
    <ul className="mt-3 flex flex-wrap items-center gap-x-1 gap-y-0.5">
      {items.map((it) => {
        const off = hidden?.has(it.key) ?? false;
        return (
          <li key={it.key}>
            <button
              type="button"
              onClick={onToggle ? () => onToggle(it.key) : undefined}
              disabled={!onToggle}
              aria-pressed={onToggle ? !off : undefined}
              className={cn(
                'inline-flex items-center gap-1.5 rounded-md px-1.5 py-1 text-xs transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:ring-offset-background',
                onToggle ? 'hover:bg-accent' : 'cursor-default',
                off && 'opacity-40',
              )}
            >
              <span
                aria-hidden="true"
                className="h-2 w-2 shrink-0 rounded-full"
                style={{ backgroundColor: it.color }}
              />
              <span className="text-muted-foreground">{it.name}</span>
              {it.meta ? <span className="tabular-nums text-foreground">{it.meta}</span> : null}
            </button>
          </li>
        );
      })}
    </ul>
  );
}

interface HoverState {
  index: number;
  x: number;
  y: number;
}

function ChartTooltip({
  hover,
  width,
  height,
  label,
  rows,
}: {
  hover: HoverState;
  width: number;
  height: number;
  label: string;
  rows: Array<{ key: string; name: string; color: string; value: string }>;
}): React.ReactElement {
  // у правого края подсказка переезжает на другую сторону курсора — иначе её обрежет карточка
  const flip = hover.x > width * 0.6;
  return (
    <div
      role="presentation"
      className="premium-popover pointer-events-none absolute z-20 animate-fade-in whitespace-nowrap rounded-lg px-2.5 py-2 text-xs"
      style={{
        left: flip ? hover.x - 12 : hover.x + 12,
        top: clamp(hover.y, 8, Math.max(8, height - 8)),
        transform: `translate(${flip ? '-100%' : '0'}, -50%)`,
      }}
    >
      <div className="mb-1 font-medium text-foreground">{label}</div>
      <div className="flex flex-col gap-0.5">
        {rows.map((r) => (
          <div key={r.key} className="flex items-center gap-2">
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: r.color }} />
            <span className="text-muted-foreground">{r.name}</span>
            <span className="ml-auto pl-3 font-medium tabular-nums text-foreground">{r.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function EmptyPlot({ height, message }: { height: number; message: string }): React.ReactElement {
  return (
    <div
      className="flex items-center justify-center rounded-lg border border-dashed border-border text-xs text-muted-foreground"
      style={{ height }}
    >
      {message}
    </div>
  );
}

/* ────────────────────────────── LineChart ────────────────────────────── */

export function LineChart(
  props: BaseChartProps & { area?: boolean; curved?: boolean },
): React.ReactElement {
  const {
    points,
    series,
    height = 240,
    formatValue = defaultFormat,
    className,
    legend,
    emptyMessage,
    area = false,
    curved = false,
  } = props;
  const { t } = useI18n();
  const [ref, width] = useMeasuredWidth();
  const { hidden, toggle } = useHiddenSeries();
  const [hover, setHover] = React.useState<HoverState | null>(null);
  const uid = React.useId().replace(/:/g, '');

  const visible = series.filter((s) => !hidden.has(s.key));
  const showLegend = legend ?? series.length > 1;
  const empty = points.length === 0 || series.length === 0;

  let content: React.ReactNode = null;
  let ariaLabel = emptyMessage ?? t('ui.chart.noData');

  if (width > 0 && !empty) {
    const vals = points.flatMap((p) => visible.map((s) => pointValue(p, s.key)));
    const scale = niceScale(
      vals.length ? Math.min(...vals) : 0,
      vals.length ? Math.max(...vals) : 0,
    );
    const tickLabels = scale.ticks.map(formatValue);
    const padLeft = estimateAxisWidth(tickLabels, 72);
    const padTop = 12;
    const padRight = 12;
    const padBottom = 24;
    const innerW = Math.max(1, width - padLeft - padRight);
    const innerH = Math.max(1, height - padTop - padBottom);

    const xAt = (i: number): number =>
      points.length === 1 ? padLeft + innerW / 2 : padLeft + (i / (points.length - 1)) * innerW;
    const yAt = (v: number): number =>
      padTop + innerH - ((v - scale.min) / (scale.max - scale.min)) * innerH;

    const stride = labelStride(points.length, innerW, 64);
    const showDots = points.length <= 30;

    const total = vals.reduce((a, b) => a + b, 0);
    ariaLabel = `${series.map((s) => s.name).join(', ')} · ${t('ui.chart.total')} ${formatValue(total)}`;

    const onMove = (e: React.PointerEvent<SVGRectElement>): void => {
      const box = ref.current?.getBoundingClientRect();
      if (!box) return;
      const px = e.clientX - box.left;
      const rel = points.length === 1 ? 0 : (px - padLeft) / innerW;
      const index = clamp(Math.round(rel * (points.length - 1)), 0, points.length - 1);
      setHover({ index, x: xAt(index), y: clamp(e.clientY - box.top, padTop, padTop + innerH) });
    };

    content = (
      <>
        <svg
          width={width}
          height={height}
          role="img"
          aria-label={ariaLabel}
          className="block overflow-visible"
        >
          <title>{ariaLabel}</title>
          <defs aria-hidden="true">
            {visible.map((s) => {
              const i = series.indexOf(s);
              return (
                <linearGradient key={s.key} id={`${uid}-a${i}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={seriesColor(s, i)} stopOpacity={0.28} />
                  <stop offset="100%" stopColor={seriesColor(s, i)} stopOpacity={0} />
                </linearGradient>
              );
            })}
          </defs>

          <g aria-hidden="true">
            {scale.ticks.map((tick, i) => (
              <g key={tick}>
                <line
                  x1={padLeft}
                  x2={padLeft + innerW}
                  y1={yAt(tick)}
                  y2={yAt(tick)}
                  stroke={GRID_COLOR}
                  strokeWidth={1}
                  shapeRendering="crispEdges"
                />
                <text
                  x={padLeft - 8}
                  y={yAt(tick)}
                  textAnchor="end"
                  dominantBaseline="middle"
                  className="fill-muted-foreground text-[10px]"
                >
                  {tickLabels[i]}
                </text>
              </g>
            ))}
          </g>

          <g aria-hidden="true">
            {points.map((p, i) =>
              i % stride === 0 ? (
                <text
                  key={`${p.label}-${i}`}
                  x={xAt(i)}
                  y={padTop + innerH + 15}
                  textAnchor="middle"
                  className="fill-muted-foreground text-[10px]"
                >
                  {p.label}
                </text>
              ) : null,
            )}
          </g>

          {hover ? (
            <line
              aria-hidden="true"
              x1={xAt(hover.index)}
              x2={xAt(hover.index)}
              y1={padTop}
              y2={padTop + innerH}
              stroke={GUIDE_COLOR}
              strokeOpacity={0.45}
              strokeWidth={1}
              strokeDasharray="3 3"
            />
          ) : null}

          <g aria-hidden="true">
            {visible.map((s) => {
              const i = series.indexOf(s);
              const color = seriesColor(s, i);
              const pts = points.map((p, idx) => ({ x: xAt(idx), y: yAt(pointValue(p, s.key)) }));
              const d = curved ? smoothPath(pts) : linePath(pts);
              const base = yAt(clamp(0, scale.min, scale.max));
              return (
                <g key={s.key}>
                  {area && pts.length > 1 ? (
                    <path
                      d={`${d} L${pts[pts.length - 1].x},${base} L${pts[0].x},${base} Z`}
                      fill={`url(#${uid}-a${i})`}
                    />
                  ) : null}
                  <path
                    d={d}
                    fill="none"
                    stroke={color}
                    strokeWidth={2}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  {(showDots || pts.length === 1) &&
                    pts.map((p, idx) => (
                      <circle
                        key={idx}
                        cx={p.x}
                        cy={p.y}
                        r={hover?.index === idx ? 4 : 2.5}
                        fill={hover?.index === idx ? color : SURFACE_COLOR}
                        stroke={color}
                        strokeWidth={2}
                      />
                    ))}
                  {!showDots && hover ? (
                    <circle
                      cx={pts[hover.index].x}
                      cy={pts[hover.index].y}
                      r={4}
                      fill={color}
                      stroke={SURFACE_COLOR}
                      strokeWidth={2}
                    />
                  ) : null}
                </g>
              );
            })}
          </g>

          <rect
            x={padLeft}
            y={padTop}
            width={innerW}
            height={innerH}
            fill="transparent"
            onPointerMove={onMove}
            onPointerLeave={() => setHover(null)}
          />
        </svg>

        {hover && visible.length > 0 ? (
          <ChartTooltip
            hover={hover}
            width={width}
            height={height}
            label={points[hover.index].label}
            rows={visible.map((s) => ({
              key: s.key,
              name: s.name,
              color: seriesColor(s, series.indexOf(s)),
              value: formatValue(pointValue(points[hover.index], s.key)),
            }))}
          />
        ) : null}
      </>
    );
  }

  return (
    <div ref={ref} className={cn('relative w-full', className)}>
      {width === 0 ? (
        <div style={{ height }} />
      ) : empty ? (
        <EmptyPlot height={height} message={emptyMessage ?? t('ui.chart.noData')} />
      ) : (
        content
      )}
      {showLegend && !empty && width > 0 ? (
        <ChartLegend
          items={series.map((s, i) => ({ key: s.key, name: s.name, color: seriesColor(s, i) }))}
          hidden={hidden}
          onToggle={toggle}
        />
      ) : null}
    </div>
  );
}

/* ────────────────────────────── BarChart ────────────────────────────── */

export function BarChart(
  props: BaseChartProps & { stacked?: boolean; horizontal?: boolean },
): React.ReactElement {
  const {
    points,
    series,
    height = 240,
    formatValue = defaultFormat,
    className,
    legend,
    emptyMessage,
    stacked = false,
    horizontal = false,
  } = props;
  const { t } = useI18n();
  const [ref, width] = useMeasuredWidth();
  const { hidden, toggle } = useHiddenSeries();
  const [hover, setHover] = React.useState<HoverState | null>(null);

  const visible = series.filter((s) => !hidden.has(s.key));
  const showLegend = legend ?? series.length > 1;
  const empty = points.length === 0 || series.length === 0;

  let content: React.ReactNode = null;
  let ariaLabel = emptyMessage ?? t('ui.chart.noData');

  if (width > 0 && !empty) {
    // в накоплении складываются положительные и отрицательные части по отдельности,
    // иначе столбик с разнознаковыми слагаемыми показывает не ту высоту
    const extents = points.map((p) => {
      let up = 0;
      let down = 0;
      let hi = 0;
      let lo = 0;
      for (const s of visible) {
        const v = pointValue(p, s.key);
        if (stacked) {
          if (v >= 0) up += v;
          else down += v;
        } else {
          hi = Math.max(hi, v);
          lo = Math.min(lo, v);
        }
      }
      return stacked ? { hi: up, lo: down } : { hi, lo };
    });
    const scale = niceScale(
      extents.length ? Math.min(...extents.map((e) => e.lo)) : 0,
      extents.length ? Math.max(...extents.map((e) => e.hi)) : 0,
    );

    const tickLabels = scale.ticks.map(formatValue);
    const catLabels = points.map((p) => p.label);
    const padLeft = horizontal
      ? estimateAxisWidth(catLabels, 96)
      : estimateAxisWidth(tickLabels, 72);
    const padTop = 12;
    const padRight = 12;
    const padBottom = 24;
    const innerW = Math.max(1, width - padLeft - padRight);
    const innerH = Math.max(1, height - padTop - padBottom);

    const bandRoom = horizontal ? innerH : innerW;
    const bandSize = bandRoom / points.length;
    const groupSize = bandSize * 0.72;
    const bandStart = (i: number): number =>
      (horizontal ? padTop : padLeft) + i * bandSize + (bandSize - groupSize) / 2;
    const bandCenter = (i: number): number =>
      (horizontal ? padTop : padLeft) + i * bandSize + bandSize / 2;

    const ratio = (v: number): number => (v - scale.min) / (scale.max - scale.min);
    const vp = (v: number): number =>
      horizontal ? padLeft + ratio(v) * innerW : padTop + innerH - ratio(v) * innerH;
    const zero = vp(clamp(0, scale.min, scale.max));

    const stride = horizontal
      ? labelStride(points.length, innerH, 18)
      : labelStride(points.length, innerW, 64);

    const total = points.reduce(
      (acc, p) => acc + visible.reduce((a, s) => a + pointValue(p, s.key), 0),
      0,
    );
    ariaLabel = `${series.map((s) => s.name).join(', ')} · ${t('ui.chart.total')} ${formatValue(total)}`;

    const onMove = (e: React.PointerEvent<SVGRectElement>): void => {
      const box = ref.current?.getBoundingClientRect();
      if (!box) return;
      const pos = horizontal ? e.clientY - box.top - padTop : e.clientX - box.left - padLeft;
      const index = clamp(Math.floor(pos / bandSize), 0, points.length - 1);
      setHover({
        index,
        x: horizontal ? clamp(e.clientX - box.left, padLeft, padLeft + innerW) : bandCenter(index),
        y: horizontal ? bandCenter(index) : clamp(e.clientY - box.top, padTop, padTop + innerH),
      });
    };

    interface Piece {
      key: string;
      color: string;
      x: number;
      y: number;
      w: number;
      h: number;
      radii: [number, number, number, number];
    }

    const pieces: Piece[] = [];
    points.forEach((p, i) => {
      let upCursor = 0;
      let downCursor = 0;
      visible.forEach((s, j) => {
        const v = pointValue(p, s.key);
        const color = seriesColor(s, series.indexOf(s));
        const positive = v >= 0;
        let from: number;
        let to: number;
        let offset: number;
        let thickness: number;

        if (stacked) {
          const base = positive ? upCursor : downCursor;
          if (positive) upCursor += v;
          else downCursor += v;
          from = vp(clamp(base, scale.min, scale.max));
          to = vp(clamp(base + v, scale.min, scale.max));
          offset = 0;
          thickness = groupSize;
        } else {
          const slot = groupSize / visible.length;
          thickness = Math.max(1, slot - 2);
          offset = j * slot + (slot - thickness) / 2;
          from = zero;
          to = vp(clamp(v, scale.min, scale.max));
        }

        const near = Math.min(from, to);
        const span = Math.max(stacked && v === 0 ? 0 : 1, Math.abs(to - from));
        if (span <= 0) return;
        const r = Math.min(4, thickness / 2);
        // скругляется только дальний от базовой линии конец — иначе столбик «отрывается» от оси
        const topSegment = !stacked || j === visible.length - 1;
        const radius = topSegment ? r : 0;

        pieces.push({
          key: `${i}-${s.key}`,
          color,
          x: horizontal ? near : bandStart(i) + offset,
          y: horizontal ? bandStart(i) + offset : near,
          w: horizontal ? span : thickness,
          h: horizontal ? thickness : span,
          radii: horizontal
            ? positive
              ? [0, radius, radius, 0]
              : [radius, 0, 0, radius]
            : positive
              ? [radius, radius, 0, 0]
              : [0, 0, radius, radius],
        });
      });
    });

    content = (
      <>
        <svg
          width={width}
          height={height}
          role="img"
          aria-label={ariaLabel}
          className="block overflow-visible"
        >
          <title>{ariaLabel}</title>

          <g aria-hidden="true">
            {scale.ticks.map((tick, i) =>
              horizontal ? (
                <g key={tick}>
                  <line
                    x1={vp(tick)}
                    x2={vp(tick)}
                    y1={padTop}
                    y2={padTop + innerH}
                    stroke={GRID_COLOR}
                    strokeWidth={1}
                    shapeRendering="crispEdges"
                  />
                  <text
                    x={vp(tick)}
                    y={padTop + innerH + 15}
                    textAnchor="middle"
                    className="fill-muted-foreground text-[10px]"
                  >
                    {tickLabels[i]}
                  </text>
                </g>
              ) : (
                <g key={tick}>
                  <line
                    x1={padLeft}
                    x2={padLeft + innerW}
                    y1={vp(tick)}
                    y2={vp(tick)}
                    stroke={GRID_COLOR}
                    strokeWidth={1}
                    shapeRendering="crispEdges"
                  />
                  <text
                    x={padLeft - 8}
                    y={vp(tick)}
                    textAnchor="end"
                    dominantBaseline="middle"
                    className="fill-muted-foreground text-[10px]"
                  >
                    {tickLabels[i]}
                  </text>
                </g>
              ),
            )}
          </g>

          {hover ? (
            <rect
              aria-hidden="true"
              x={horizontal ? padLeft : bandCenter(hover.index) - bandSize / 2}
              y={horizontal ? bandCenter(hover.index) - bandSize / 2 : padTop}
              width={horizontal ? innerW : bandSize}
              height={horizontal ? bandSize : innerH}
              fill={GUIDE_COLOR}
              fillOpacity={0.08}
            />
          ) : null}

          <g aria-hidden="true">
            {pieces.map((b) => (
              <path
                key={b.key}
                d={roundedRect(b.x, b.y, b.w, b.h, b.radii)}
                fill={b.color}
                className="transition-opacity"
                opacity={hover && !b.key.startsWith(`${hover.index}-`) ? 0.55 : 1}
              />
            ))}
          </g>

          <g aria-hidden="true">
            {points.map((p, i) =>
              i % stride === 0 ? (
                horizontal ? (
                  <text
                    key={`${p.label}-${i}`}
                    x={padLeft - 8}
                    y={bandCenter(i)}
                    textAnchor="end"
                    dominantBaseline="middle"
                    className="fill-muted-foreground text-[10px]"
                  >
                    {p.label}
                  </text>
                ) : (
                  <text
                    key={`${p.label}-${i}`}
                    x={bandCenter(i)}
                    y={padTop + innerH + 15}
                    textAnchor="middle"
                    className="fill-muted-foreground text-[10px]"
                  >
                    {p.label}
                  </text>
                )
              ) : null,
            )}
          </g>

          <rect
            x={padLeft}
            y={padTop}
            width={innerW}
            height={innerH}
            fill="transparent"
            onPointerMove={onMove}
            onPointerLeave={() => setHover(null)}
          />
        </svg>

        {hover && visible.length > 0 ? (
          <ChartTooltip
            hover={hover}
            width={width}
            height={height}
            label={points[hover.index].label}
            rows={visible.map((s) => ({
              key: s.key,
              name: s.name,
              color: seriesColor(s, series.indexOf(s)),
              value: formatValue(pointValue(points[hover.index], s.key)),
            }))}
          />
        ) : null}
      </>
    );
  }

  return (
    <div ref={ref} className={cn('relative w-full', className)}>
      {width === 0 ? (
        <div style={{ height }} />
      ) : empty ? (
        <EmptyPlot height={height} message={emptyMessage ?? t('ui.chart.noData')} />
      ) : (
        content
      )}
      {showLegend && !empty && width > 0 ? (
        <ChartLegend
          items={series.map((s, i) => ({ key: s.key, name: s.name, color: seriesColor(s, i) }))}
          hidden={hidden}
          onToggle={toggle}
        />
      ) : null}
    </div>
  );
}

/* ────────────────────────────── DonutChart ────────────────────────────── */

export function DonutChart(props: {
  slices: DonutSlice[];
  size?: number;
  thickness?: number;
  centerLabel?: string;
  centerValue?: string;
  formatValue?: (v: number) => string;
  legend?: boolean;
  className?: string;
}): React.ReactElement {
  const {
    slices,
    size = 180,
    thickness = 18,
    centerLabel,
    centerValue,
    formatValue = defaultFormat,
    legend = true,
    className,
  } = props;
  const { t } = useI18n();
  const { hidden, toggle } = useHiddenSeries();
  const [active, setActive] = React.useState<string | null>(null);

  const visible = slices.filter((s) => !hidden.has(s.key));
  const values = visible.map((s) => Math.max(0, num(s.value)));
  const total = values.reduce((a, b) => a + b, 0);

  const radius = (size - thickness - 6) / 2;
  const circumference = 2 * Math.PI * radius;
  const gap = total > 0 ? 1 : 0; // 1px просвет между секторами — иначе соседние цвета слипаются

  const ariaLabel =
    total > 0
      ? `${visible.map((s) => `${s.name}: ${formatValue(num(s.value))}`).join(', ')} · ${t('ui.chart.total')} ${formatValue(total)}`
      : t('ui.chart.noData');

  let offset = 0;
  const arcs = visible.map((s) => {
    const value = Math.max(0, num(s.value));
    const length = total > 0 ? (value / total) * circumference : 0;
    const dash = Math.max(0, length - gap);
    const arc = {
      key: s.key,
      color: s.color ?? CHART_COLORS[slices.indexOf(s) % CHART_COLORS.length],
      dash,
      offset,
      value,
      percent: total > 0 ? value / total : 0,
    };
    offset += length;
    return arc;
  });

  return (
    <div className={cn('flex flex-col items-center gap-2 sm:flex-row sm:items-center', className)}>
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} role="img" aria-label={ariaLabel} className="block">
          <title>{ariaLabel}</title>
          <g
            aria-hidden="true"
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
            fill="none"
            strokeLinecap="butt"
          >
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              stroke={GRID_COLOR}
              strokeWidth={thickness}
              opacity={total > 0 ? 0.5 : 1}
            />
            {arcs.map((a) =>
              a.dash > 0 ? (
                <circle
                  key={a.key}
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  stroke={a.color}
                  strokeWidth={active === a.key ? thickness + 4 : thickness}
                  strokeDasharray={`${a.dash} ${circumference - a.dash}`}
                  strokeDashoffset={-a.offset}
                  className="transition-all duration-150"
                  onPointerEnter={() => setActive(a.key)}
                  onPointerLeave={() => setActive(null)}
                />
              ) : null,
            )}
          </g>
          <g aria-hidden="true">
            {centerValue ? (
              <text
                x={size / 2}
                y={size / 2 - (centerLabel ? 2 : 0)}
                textAnchor="middle"
                dominantBaseline="middle"
                className="fill-foreground text-lg font-semibold tabular-nums"
              >
                {centerValue}
              </text>
            ) : null}
            {centerLabel ? (
              <text
                x={size / 2}
                y={size / 2 + (centerValue ? 16 : 0)}
                textAnchor="middle"
                dominantBaseline="middle"
                className="fill-muted-foreground text-[11px]"
              >
                {centerLabel}
              </text>
            ) : null}
          </g>
        </svg>
      </div>

      <div className="min-w-0 flex-1">
        {total > 0 ? null : (
          <p className="text-xs text-muted-foreground">{t('ui.chart.noData')}</p>
        )}
        {legend ? (
          <ChartLegend
            items={slices.map((s, i) => {
              const arc = arcs.find((a) => a.key === s.key);
              return {
                key: s.key,
                name: s.name,
                color: s.color ?? CHART_COLORS[i % CHART_COLORS.length],
                meta: arc
                  ? `${formatValue(arc.value)} · ${Math.round(arc.percent * 100)}%`
                  : formatValue(num(s.value)),
              };
            })}
            hidden={hidden}
            onToggle={toggle}
          />
        ) : null}
      </div>
    </div>
  );
}

/* ────────────────────────────── Sparkline ────────────────────────────── */

export function Sparkline(props: {
  values: number[];
  height?: number;
  color?: string;
  className?: string;
}): React.ReactElement {
  const { values, height = 32, color = CHART_COLORS[0], className } = props;
  const { t } = useI18n();
  const [ref, width] = useMeasuredWidth();

  const clean = values.map(num);
  const pad = 3;
  let body: React.ReactNode = null;
  let ariaLabel = t('ui.chart.noData');

  if (width > 0 && clean.length > 0) {
    const min = Math.min(...clean);
    const max = Math.max(...clean);
    const span = max - min || 1;
    const innerW = Math.max(1, width - pad * 2);
    const innerH = Math.max(1, height - pad * 2);
    const pts: Pt[] = clean.map((v, i) => ({
      x: pad + (clean.length === 1 ? innerW / 2 : (i / (clean.length - 1)) * innerW),
      y: pad + innerH - ((v - min) / span) * innerH,
    }));
    const last = pts[pts.length - 1];
    ariaLabel = `${t('ui.chart.total')} ${defaultFormat(clean.reduce((a, b) => a + b, 0))}`;

    body = (
      <svg width={width} height={height} role="img" aria-label={ariaLabel} className="block">
        <title>{ariaLabel}</title>
        <g aria-hidden="true">
          <path
            d={linePath(pts)}
            fill="none"
            stroke={color}
            strokeWidth={1.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx={last.x} cy={last.y} r={2.5} fill={color} />
        </g>
      </svg>
    );
  }

  return (
    <div ref={ref} className={cn('w-full', className)}>
      {body ?? <div style={{ height }} />}
    </div>
  );
}
