import * as React from 'react';
import { cn } from '@/lib/utils';
import { useI18n } from '@/lib/i18n';

export type ToastVariant = 'default' | 'success' | 'error' | 'warning' | 'info';

export interface ToastOptions {
  title: string;
  description?: string;
  variant?: ToastVariant;
  /** мс; 0 — висит, пока не закроют руками. */
  duration?: number;
  action?: { label: string; onClick: () => void };
}

export interface ToastApi {
  toast: (options: ToastOptions) => string;
  success: (title: string, description?: string) => string;
  error: (title: string, description?: string) => string;
  dismiss: (id: string) => void;
}

interface ToastRecord extends ToastOptions {
  id: string;
}

const DEFAULT_DURATION = 4500;

/** Больше четырёх сообщений сразу читать некому — старое вытесняется новым. */
const MAX_VISIBLE = 4;

/**
 * Счётчик модуля плюс отметка времени: id обязан быть уникальным между
 * перемонтированиями провайдера, а тянуть uuid-зависимость ради тоста незачем.
 */
let sequence = 0;
function nextId(): string {
  sequence += 1;
  return `toast-${Date.now().toString(36)}-${sequence}`;
}

const ToastContext = React.createContext<ToastApi | null>(null);

const ACCENT: Record<ToastVariant, string> = {
  default: 'bg-primary',
  success: 'bg-success',
  error: 'bg-destructive',
  warning: 'bg-warning',
  info: 'bg-info',
};

const ICON_TONE: Record<ToastVariant, string> = {
  default: 'text-muted-foreground',
  success: 'text-success',
  error: 'text-destructive',
  warning: 'text-warning',
  info: 'text-info',
};

const PROGRESS_TONE: Record<ToastVariant, string> = {
  default: 'bg-primary/40',
  success: 'bg-success/40',
  error: 'bg-destructive/40',
  warning: 'bg-warning/40',
  info: 'bg-info/40',
};

function VariantIcon({ variant }: { variant: ToastVariant }): React.ReactElement {
  const props = {
    viewBox: '0 0 20 20',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.6,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    'aria-hidden': true,
    className: cn('mt-0.5 h-4 w-4 shrink-0', ICON_TONE[variant]),
  };

  if (variant === 'success') {
    return (
      <svg {...props}>
        <circle cx="10" cy="10" r="7.25" />
        <path d="m6.75 10.25 2.2 2.2 4.3-4.7" />
      </svg>
    );
  }
  if (variant === 'error') {
    return (
      <svg {...props}>
        <circle cx="10" cy="10" r="7.25" />
        <path d="m7.5 7.5 5 5m0-5-5 5" />
      </svg>
    );
  }
  if (variant === 'warning') {
    return (
      <svg {...props}>
        <path d="M10 3.4 3 16.2h14z" />
        <path d="M10 8.4v3.4" />
        <path d="M10 14.05h.01" />
      </svg>
    );
  }
  return (
    <svg {...props}>
      <circle cx="10" cy="10" r="7.25" />
      <path d="M10 9.4v4.1" />
      <path d="M10 6.6h.01" />
    </svg>
  );
}

interface ToastItemProps {
  item: ToastRecord;
  onDismiss: (id: string) => void;
}

/**
 * Таймер живёт в самом тосте, а не в провайдере: пауза по наведению — это
 * состояние одного сообщения, и держать в списке ещё и часы каждого элемента
 * значит перерисовывать всю очередь на каждое движение мыши.
 */
function ToastItem({ item, onDismiss }: ToastItemProps): React.ReactElement {
  const { t } = useI18n();
  const variant = item.variant ?? 'default';
  const duration = item.duration ?? DEFAULT_DURATION;
  const timed = duration > 0;

  const [paused, setPaused] = React.useState(false);
  const [bar, setBar] = React.useState<{ width: number; ms: number }>({ width: 100, ms: 0 });
  const remainingRef = React.useRef(duration);
  const startedAtRef = React.useRef(0);

  React.useEffect(() => {
    if (!timed) return;

    if (paused) {
      // Остаток запоминаем, иначе после ухода курсора отсчёт начался бы заново
      // и сообщение висело бы полный срок после каждого касания мышью.
      remainingRef.current = Math.max(0, remainingRef.current - (Date.now() - startedAtRef.current));
      setBar({ width: (remainingRef.current / duration) * 100, ms: 0 });
      return;
    }

    startedAtRef.current = Date.now();
    const left = remainingRef.current;
    const timer = window.setTimeout(() => onDismiss(item.id), left);
    // Полоску запускаем следующим кадром: иначе браузер увидит начальную и
    // конечную ширину в одной отрисовке и переход не проиграется вовсе.
    const frame = window.requestAnimationFrame(() => setBar({ width: 0, ms: left }));

    return () => {
      window.clearTimeout(timer);
      window.cancelAnimationFrame(frame);
    };
  }, [paused, timed, duration, item.id, onDismiss]);

  const handleKeyDown = (event: React.KeyboardEvent<HTMLLIElement>): void => {
    if (event.key === 'Escape') {
      event.stopPropagation();
      onDismiss(item.id);
    }
  };

  return (
    <li
      className="premium-popover pointer-events-auto relative flex animate-slide-in-right items-start gap-3 overflow-hidden py-3 pl-4 pr-2"
      aria-atomic="true"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      onKeyDown={handleKeyDown}
    >
      <span aria-hidden className={cn('absolute inset-y-0 left-0 w-[3px]', ACCENT[variant])} />

      <VariantIcon variant={variant} />

      <div className="min-w-0 flex-1">
        <p className="break-words text-sm font-medium leading-5 text-card-foreground">{item.title}</p>
        {item.description ? (
          <p className="mt-0.5 break-words text-xs leading-5 text-muted-foreground">{item.description}</p>
        ) : null}
        {item.action ? (
          <button
            type="button"
            onClick={() => {
              item.action?.onClick();
              // Действие выполнено — оставлять сообщение на экране уже нечего.
              onDismiss(item.id);
            }}
            className="mt-2 rounded-md text-xs font-medium text-primary transition-colors hover:text-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            {item.action.label}
          </button>
        ) : null}
      </div>

      <button
        type="button"
        aria-label={t('ui.close')}
        onClick={() => onDismiss(item.id)}
        className="-mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <svg
          viewBox="0 0 20 20"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.6}
          strokeLinecap="round"
          aria-hidden
          className="h-3.5 w-3.5"
        >
          <path d="m6 6 8 8m0-8-8 8" />
        </svg>
      </button>

      {timed ? (
        <span
          aria-hidden
          className={cn('absolute bottom-0 left-0 h-0.5', PROGRESS_TONE[variant])}
          style={{ width: `${bar.width}%`, transition: `width ${bar.ms}ms linear` }}
        />
      ) : null}
    </li>
  );
}

/**
 * Очередь всплывающих сообщений. Область живая (`aria-live`) и рендерится
 * всегда, даже пустой: если вставлять её вместе с первым тостом, скринридер
 * не успевает подписаться и первое же сообщение проходит мимо него.
 */
export function ToastProvider({ children }: { children: React.ReactNode }): React.ReactElement {
  const [items, setItems] = React.useState<ToastRecord[]>([]);

  const dismiss = React.useCallback((id: string): void => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const toast = React.useCallback((options: ToastOptions): string => {
    const id = nextId();
    setItems((prev) => [...prev, { ...options, id }].slice(-MAX_VISIBLE));
    return id;
  }, []);

  const success = React.useCallback(
    (title: string, description?: string): string => toast({ title, description, variant: 'success' }),
    [toast],
  );

  const error = React.useCallback(
    (title: string, description?: string): string => toast({ title, description, variant: 'error' }),
    [toast],
  );

  // Ссылка на api обязана быть стабильной: `toast` кладут в зависимости эффектов,
  // и новый объект на каждый рендер провайдера зациклил бы их.
  const api = React.useMemo<ToastApi>(() => ({ toast, success, error, dismiss }), [toast, success, error, dismiss]);

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div
        role="region"
        aria-live="polite"
        className="pointer-events-none fixed bottom-4 left-4 right-4 z-[100] flex flex-col-reverse gap-2 sm:left-auto sm:w-full sm:max-w-sm"
      >
        <ul className="flex flex-col-reverse gap-2">
          {items.map((item) => (
            <ToastItem key={item.id} item={item} onDismiss={dismiss} />
          ))}
        </ul>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastApi {
  const api = React.useContext(ToastContext);
  if (!api) {
    // Молчаливая заглушка спрятала бы забытый ToastProvider до продакшена —
    // там сообщения просто перестали бы показываться, и никто бы не заметил.
    throw new Error('useToast использован вне <ToastProvider> — оберните приложение провайдером.');
  }
  return api;
}
