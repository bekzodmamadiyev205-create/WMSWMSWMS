import * as React from 'react';
import { cn } from '@/lib/utils';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Popover } from '@/components/ui/popover';
import {
  DATE_RANGE_PRESETS,
  detectPreset,
  formatRangeLabel,
  isoDate,
  parseIso,
  presetRange,
  type DateRange,
  type DateRangePresetKey,
} from '@/lib/date-range';

const PRESET_LABEL: Record<DateRangePresetKey, MessageKey> = {
  today: 'ui.date.today',
  yesterday: 'ui.date.yesterday',
  last7: 'ui.date.last7',
  last30: 'ui.date.last30',
  thisMonth: 'ui.date.thisMonth',
  lastMonth: 'ui.date.lastMonth',
  thisQuarter: 'ui.date.thisQuarter',
  thisYear: 'ui.date.thisYear',
  allTime: 'ui.date.allTime',
  custom: 'ui.date.custom',
};

function firstOfMonth(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

function addMonths(d: Date, months: number): Date {
  return new Date(d.getFullYear(), d.getMonth() + months, 1);
}

function addDaysIso(iso: string, days: number): string {
  const d = parseIso(iso);
  return isoDate(new Date(d.getFullYear(), d.getMonth(), d.getDate() + days));
}

/**
 * Шесть недель всегда, даже когда месяц укладывается в пять: иначе панель
 * «прыгает» по высоте при перелистывании и кнопки уезжают из-под курсора.
 */
function monthMatrix(month: Date): Date[] {
  const first = firstOfMonth(month);
  // Неделя начинается с понедельника, а getDay() отдаёт 0 для воскресенья.
  const shift = (first.getDay() + 6) % 7;
  return Array.from(
    { length: 42 },
    (_, i) => new Date(first.getFullYear(), first.getMonth(), 1 - shift + i),
  );
}

function CalendarIcon(): React.ReactElement {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      className="h-4 w-4 shrink-0 text-muted-foreground"
      aria-hidden="true"
    >
      <rect x="3" y="5" width="18" height="16" rx="3" />
      <path d="M3 10h18M8 3v4M16 3v4" />
    </svg>
  );
}

function ChevronIcon({ className }: { className?: string }): React.ReactElement {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn('h-3.5 w-3.5 shrink-0', className)}
      aria-hidden="true"
    >
      <path d="m6 9 6 6 6-6" />
    </svg>
  );
}

interface MonthGridProps {
  month: Date;
  draft: DateRange;
  previewEnd: string | null;
  todayIso: string;
  focusIso: string;
  /** Один и тот же день попадает в сетки соседних месяцев — фокус держит только одна. */
  ownsFocus: boolean;
  monthName: (m: number) => string;
  weekdays: Array<{ short: string; full: string }>;
  onPick: (iso: string) => void;
  onHover: (iso: string | null) => void;
  className?: string;
}

function MonthGrid({
  month,
  draft,
  previewEnd,
  todayIso,
  focusIso,
  ownsFocus,
  monthName,
  weekdays,
  onPick,
  onHover,
  className,
}: MonthGridProps): React.ReactElement {
  const days = monthMatrix(month);
  const title = `${monthName(month.getMonth() + 1)} ${month.getFullYear()}`;
  const weeks: Date[][] = [];
  for (let i = 0; i < days.length; i += 7) weeks.push(days.slice(i, i + 7));

  return (
    <div role="grid" aria-label={title} className={cn('select-none', className)}>
      <div role="row" className="grid grid-cols-7">
        {weekdays.map((day) => (
          <span
            key={day.full}
            role="columnheader"
            aria-label={day.full}
            className="py-1 text-center text-xs font-medium text-muted-foreground"
          >
            {day.short}
          </span>
        ))}
      </div>

      {weeks.map((week) => (
        <div role="row" key={isoDate(week[0])} className="grid grid-cols-7">
          {week.map((day) => {
            const iso = isoDate(day);
            const inMonth = day.getMonth() === month.getMonth();
            const isStart = draft.from === iso;
            const isEnd = previewEnd === iso;
            // ISO-даты сравниваются лексикографически — отдельный парсинг не нужен.
            const inBand =
              draft.from !== null &&
              previewEnd !== null &&
              iso >= draft.from &&
              iso <= previewEnd;
            const isEdge = isStart || isEnd;
            const focused = ownsFocus && iso === focusIso;

            return (
              <div
                role="gridcell"
                key={iso}
                className={cn(
                  'flex h-9 items-center justify-center transition-colors',
                  inBand && 'bg-accent',
                  isStart && 'rounded-l-lg',
                  isEnd && 'rounded-r-lg',
                )}
              >
                <button
                  type="button"
                  data-focus={focused ? 'true' : undefined}
                  tabIndex={focused ? 0 : -1}
                  aria-pressed={isEdge || inBand}
                  aria-label={`${day.getDate()} ${monthName(day.getMonth() + 1)} ${day.getFullYear()}`}
                  onClick={() => onPick(iso)}
                  onMouseEnter={() => onHover(iso)}
                  onFocus={() => onHover(iso)}
                  className={cn(
                    'flex h-8 w-8 items-center justify-center rounded-lg text-sm transition-colors',
                    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:ring-offset-background',
                    inMonth ? 'text-foreground' : 'text-muted-foreground/50',
                    !isEdge && 'hover:bg-muted',
                    isEdge && 'bg-primary font-semibold text-primary-foreground shadow-sm',
                    !isEdge && iso === todayIso && 'ring-1 ring-ring',
                  )}
                >
                  {day.getDate()}
                </button>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

export interface DateRangePickerProps {
  value: DateRange;
  onChange: (range: DateRange) => void;
  className?: string;
  align?: 'start' | 'end';
  /** По умолчанию показывается пресет «за всё время»: не всякий отчёт его выдержит. */
  allowAllTime?: boolean;
  /** Уменьшенный триггер для панелей инструментов. */
  compact?: boolean;
}

/**
 * Глобальный фильтр по датам: слева — пресеты, справа — календарь на два месяца.
 * Выбор ведётся в черновике и уезжает наружу только по «Применить» или по клику
 * на пресет — иначе каждый промежуточный клик по дню перезапрашивал бы отчёт,
 * а незакрытый диапазон (выбрано только начало) уходил бы на сервер как обрезанный.
 */
export function DateRangePicker({
  value,
  onChange,
  className,
  align = 'start',
  allowAllTime = true,
  compact = false,
}: DateRangePickerProps): React.ReactElement {
  const { t } = useI18n();
  const rootRef = React.useRef<HTMLSpanElement>(null);
  const gridRef = React.useRef<HTMLDivElement>(null);
  const keyboardRef = React.useRef(false);

  const [open, setOpen] = React.useState(false);
  const [draft, setDraft] = React.useState<DateRange>(value);
  const [hover, setHover] = React.useState<string | null>(null);
  const [viewMonth, setViewMonth] = React.useState<Date>(() =>
    firstOfMonth(value.from ? parseIso(value.from) : new Date()),
  );
  const [focusIso, setFocusIso] = React.useState<string>(() => value.from ?? isoDate(new Date()));

  const monthName = React.useCallback(
    (m: number): string => t(`ui.month.${m}` as MessageKey),
    [t],
  );

  const now = new Date();
  const todayIso = isoDate(now);
  const preset = detectPreset(value, now);
  const label = preset === 'custom' ? formatRangeLabel(value, monthName) : t(PRESET_LABEL[preset]);

  const weekdays = React.useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => {
        const full = t(`ui.weekday.${i + 1}` as MessageKey);
        // Словарь отдаёт полные названия; в шапку 7-колоночной сетки влезают две
        // буквы. Короткие (иероглифические) названия не режем.
        return { full, short: full.length > 3 ? full.slice(0, 2) : full };
      }),
    [t],
  );

  // Popover возвращает фокус не сам; без этого после Escape фокус улетает
  // в начало страницы и клавиатурная работа с фильтром обрывается.
  const restoreFocus = React.useCallback((): void => {
    window.requestAnimationFrame(() => {
      const root = rootRef.current;
      if (!root) return;
      const active = document.activeElement;
      if (active !== document.body && active !== null && !root.contains(active)) return;
      root.querySelector<HTMLButtonElement>('button')?.focus();
    });
  }, []);

  const handleOpenChange = React.useCallback(
    (next: boolean): void => {
      if (next) {
        const anchor = value.from ? parseIso(value.from) : new Date();
        setDraft(value);
        setViewMonth(firstOfMonth(anchor));
        setFocusIso(value.from ?? isoDate(new Date()));
        setHover(null);
      }
      setOpen(next);
      if (!next) restoreFocus();
    },
    [restoreFocus, value],
  );

  const commit = React.useCallback(
    (range: DateRange): void => {
      onChange(range);
      setOpen(false);
      restoreFocus();
    },
    [onChange, restoreFocus],
  );

  const pickDay = React.useCallback((iso: string): void => {
    setFocusIso(iso);
    setDraft((prev) => {
      // Клик раньше начала — не «перевёрнутый» диапазон, а новая точка отсчёта.
      if (prev.from === null || prev.to !== null || iso < prev.from) return { from: iso, to: null };
      return { from: prev.from, to: iso };
    });
    setHover(null);
  }, []);

  const moveFocus = React.useCallback(
    (days: number): void => {
      const next = addDaysIso(focusIso, days);
      const nextDate = parseIso(next);
      keyboardRef.current = true;
      setFocusIso(next);
      // Месяц перелистываем только когда день вышел за обе видимые сетки.
      const rightMonth = addMonths(viewMonth, 1);
      const sameAsLeft =
        nextDate.getFullYear() === viewMonth.getFullYear() &&
        nextDate.getMonth() === viewMonth.getMonth();
      const sameAsRight =
        nextDate.getFullYear() === rightMonth.getFullYear() &&
        nextDate.getMonth() === rightMonth.getMonth();
      if (!sameAsLeft && !sameAsRight) setViewMonth(firstOfMonth(nextDate));
    },
    [focusIso, viewMonth],
  );

  const handleGridKeyDown = React.useCallback(
    (event: React.KeyboardEvent<HTMLDivElement>): void => {
      const weekday = (parseIso(focusIso).getDay() + 6) % 7;
      let step: number | null = null;
      switch (event.key) {
        case 'ArrowLeft':
          step = -1;
          break;
        case 'ArrowRight':
          step = 1;
          break;
        case 'ArrowUp':
          step = -7;
          break;
        case 'ArrowDown':
          step = 7;
          break;
        case 'Home':
          step = -weekday;
          break;
        case 'End':
          step = 6 - weekday;
          break;
        case 'PageUp':
          event.preventDefault();
          setViewMonth((prev) => addMonths(prev, -1));
          return;
        case 'PageDown':
          event.preventDefault();
          setViewMonth((prev) => addMonths(prev, 1));
          return;
        default:
          return;
      }
      event.preventDefault();
      moveFocus(step);
    },
    [focusIso, moveFocus],
  );

  React.useEffect(() => {
    if (!open || !keyboardRef.current) return;
    keyboardRef.current = false;
    gridRef.current?.querySelector<HTMLButtonElement>('[data-focus="true"]')?.focus();
  }, [focusIso, open, viewMonth]);

  const presets = allowAllTime
    ? DATE_RANGE_PRESETS
    : DATE_RANGE_PRESETS.filter((key) => key !== 'allTime');

  const rightMonth = addMonths(viewMonth, 1);
  const focusInLeft = monthMatrix(viewMonth).some((d) => isoDate(d) === focusIso);
  const previewEnd =
    draft.to ?? (draft.from !== null && hover !== null && hover >= draft.from ? hover : null);

  return (
    <span ref={rootRef} className={cn('inline-block', className)}>
      <Popover
        open={open}
        onOpenChange={handleOpenChange}
        align={align}
        className="rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        contentClassName="p-0"
        trigger={
          <span
            className={cn(
              'inline-flex max-w-[16rem] items-center gap-2 rounded-lg border border-input bg-background font-medium transition-colors hover:bg-accent hover:text-accent-foreground',
              compact ? 'h-8 px-2.5 text-xs' : 'h-9 px-3 text-sm',
            )}
          >
            <CalendarIcon />
            <span className="sr-only">{t('ui.date.range')}</span>
            <span className="truncate">{label}</span>
            <ChevronIcon className={cn('transition-transform', open && 'rotate-180')} />
          </span>
        }
      >
        <div className="flex w-[17.5rem] flex-col sm:w-auto sm:flex-row">
          <div
            className={cn(
              'flex shrink-0 gap-1 overflow-x-auto border-b border-border p-2',
              'sm:w-44 sm:flex-col sm:overflow-visible sm:border-b-0 sm:border-r',
            )}
          >
            {presets.map((key) => (
              <button
                key={key}
                type="button"
                aria-pressed={preset === key}
                onClick={() => commit(presetRange(key, new Date()))}
                className={cn(
                  'whitespace-nowrap rounded-lg px-2.5 py-1.5 text-left text-sm transition-colors',
                  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                  preset === key
                    ? 'bg-accent font-medium text-accent-foreground'
                    : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground',
                )}
              >
                {t(PRESET_LABEL[key])}
              </button>
            ))}
          </div>

          <div className="p-3">
            <div className="flex items-center gap-1 pb-2">
              <button
                type="button"
                aria-label={t('ui.page.prev')}
                onClick={() => setViewMonth((prev) => addMonths(prev, -1))}
                className="flex h-7 w-7 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <ChevronIcon className="rotate-90" />
              </button>
              <div className="flex flex-1 items-center justify-around text-sm font-medium">
                <span>{`${monthName(viewMonth.getMonth() + 1)} ${viewMonth.getFullYear()}`}</span>
                <span className="hidden sm:inline">
                  {`${monthName(rightMonth.getMonth() + 1)} ${rightMonth.getFullYear()}`}
                </span>
              </div>
              <button
                type="button"
                aria-label={t('ui.page.next')}
                onClick={() => setViewMonth((prev) => addMonths(prev, 1))}
                className="flex h-7 w-7 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <ChevronIcon className="-rotate-90" />
              </button>
            </div>

            <div
              ref={gridRef}
              onKeyDown={handleGridKeyDown}
              onMouseLeave={() => setHover(null)}
              className="flex gap-4"
            >
              <MonthGrid
                month={viewMonth}
                draft={draft}
                previewEnd={previewEnd}
                todayIso={todayIso}
                focusIso={focusIso}
                ownsFocus={focusInLeft}
                monthName={monthName}
                weekdays={weekdays}
                onPick={pickDay}
                onHover={setHover}
              />
              <MonthGrid
                month={rightMonth}
                draft={draft}
                previewEnd={previewEnd}
                todayIso={todayIso}
                focusIso={focusIso}
                ownsFocus={!focusInLeft}
                monthName={monthName}
                weekdays={weekdays}
                onPick={pickDay}
                onHover={setHover}
                className="hidden sm:block"
              />
            </div>

            <div className="mt-3 flex items-center justify-between gap-3 border-t border-border pt-3">
              <span className="min-w-0 truncate text-xs text-muted-foreground">
                {draft.from ? formatRangeLabel(draft, monthName) : t('ui.date.range')}
              </span>
              <div className="flex shrink-0 gap-2">
                <Button variant="ghost" size="sm" onClick={() => commit(presetRange('allTime'))}>
                  {t('ui.date.clear')}
                </Button>
                <Button
                  size="sm"
                  disabled={draft.from === null}
                  // Незакрытый диапазон применяем как один день: иначе кнопка
                  // молча ничего не делает после единственного клика по дате.
                  onClick={() => commit({ from: draft.from, to: draft.to ?? draft.from })}
                >
                  {t('ui.date.apply')}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Popover>
    </span>
  );
}
