import * as React from 'react';
import { cn } from '@/lib/utils';
import { useI18n } from '@/lib/i18n';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from '@/components/ui/empty-state';
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table';

export interface DataTableColumn<T> {
  key: string;
  header: React.ReactNode;
  cell: (row: T, index: number) => React.ReactNode;
  sortable?: boolean;
  align?: 'left' | 'center' | 'right';
  width?: string;
  className?: string;
  headerClassName?: string;
  hideable?: boolean;
  defaultHidden?: boolean;
}

export interface DataTableSort {
  key: string;
  direction: 'asc' | 'desc';
}

export interface DataTableProps<T> {
  columns: Array<DataTableColumn<T>>;
  rows: T[];
  getRowKey: (row: T, index: number) => string;
  loading?: boolean;
  skeletonRows?: number;
  sort?: DataTableSort | null;
  onSortChange?: (sort: DataTableSort | null) => void;
  onRowClick?: (row: T) => void;
  rowClassName?: (row: T) => string | undefined;
  emptyTitle?: string;
  emptyDescription?: string;
  emptyAction?: React.ReactNode;
  toolbar?: React.ReactNode;
  footer?: React.ReactNode;
  stickyHeader?: boolean;
  maxHeight?: string;
  dense?: boolean;
  className?: string;
  columnVisibility?: boolean;
}

/** Элементы, которые сами обрабатывают клик: по ним строка открываться не должна. */
const INTERACTIVE = 'a,button,input,select,textarea,label,[role="button"],[role="menuitem"]';

function ChevronUp({ className }: { className?: string }): React.ReactElement {
  return (
    <svg viewBox="0 0 16 16" fill="none" aria-hidden="true" className={cn('h-3 w-3', className)}>
      <path d="M4 10 8 6l4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ChevronDown({ className }: { className?: string }): React.ReactElement {
  return (
    <svg viewBox="0 0 16 16" fill="none" aria-hidden="true" className={cn('h-3 w-3', className)}>
      <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function CheckMark({ visible }: { visible: boolean }): React.ReactElement {
  return (
    <svg
      viewBox="0 0 16 16"
      fill="none"
      aria-hidden="true"
      className={cn('h-3.5 w-3.5 shrink-0 transition-opacity', visible ? 'opacity-100' : 'opacity-0')}
    >
      <path d="M3.5 8.5 6.5 11.5 12.5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ColumnsIcon(): React.ReactElement {
  return (
    <svg viewBox="0 0 16 16" fill="none" aria-hidden="true" className="h-3.5 w-3.5">
      <rect x="2" y="2.5" width="12" height="11" rx="1.6" stroke="currentColor" strokeWidth="1.3" />
      <path d="M6.5 2.5v11M10 2.5v11" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  );
}

function TableGlyph(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" className="h-8 w-8 text-muted-foreground/50">
      <rect x="3" y="4" width="18" height="16" rx="2.5" stroke="currentColor" strokeWidth="1.4" />
      <path d="M3 9h18M9 9v11" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

/**
 * Меню видимости колонок. Свой выпадающий список, а не общий dropdown-menu:
 * таблица не должна тянуть за собой соседний примитив ради одного меню.
 * Фокус возвращается на кнопку при закрытии — иначе после Escape он улетает
 * в начало документа и клавиатурная навигация по таблице начинается заново.
 */
function ColumnMenu<T>({
  columns,
  hidden,
  onToggle,
}: {
  columns: Array<DataTableColumn<T>>;
  hidden: ReadonlySet<string>;
  onToggle: (key: string) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [open, setOpen] = React.useState(false);
  const rootRef = React.useRef<HTMLDivElement | null>(null);
  const triggerRef = React.useRef<HTMLButtonElement | null>(null);
  const itemsRef = React.useRef<Array<HTMLButtonElement | null>>([]);

  React.useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: MouseEvent): void => {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') {
        setOpen(false);
        triggerRef.current?.focus();
      }
    };
    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [open]);

  React.useEffect(() => {
    if (open) itemsRef.current[0]?.focus();
  }, [open]);

  const move = (from: number, delta: number): void => {
    const items = itemsRef.current.filter((el): el is HTMLButtonElement => el !== null);
    if (items.length === 0) return;
    const next = (from + delta + items.length) % items.length;
    items[next]?.focus();
  };

  return (
    <div ref={rootRef} className="relative shrink-0">
      <button
        ref={triggerRef}
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className={cn(
          'inline-flex h-8 items-center gap-1.5 rounded-lg border border-input px-2.5 text-xs font-medium',
          'text-muted-foreground transition-colors hover:bg-accent hover:text-foreground',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
          open && 'bg-accent text-foreground',
        )}
      >
        <ColumnsIcon />
        {t('ui.columns')}
      </button>

      {open ? (
        <div
          role="menu"
          aria-label={t('ui.columns')}
          className="premium-popover absolute right-0 top-full z-20 mt-1.5 min-w-[13rem] animate-scale-in p-1"
        >
          {columns.map((column, index) => {
            const isVisible = !hidden.has(column.key);
            return (
              <button
                key={column.key}
                ref={(el) => {
                  itemsRef.current[index] = el;
                }}
                type="button"
                role="menuitemcheckbox"
                aria-checked={isVisible}
                onClick={() => onToggle(column.key)}
                onKeyDown={(event) => {
                  if (event.key === 'ArrowDown') {
                    event.preventDefault();
                    move(index, 1);
                  } else if (event.key === 'ArrowUp') {
                    event.preventDefault();
                    move(index, -1);
                  }
                }}
                className={cn(
                  'flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition-colors',
                  'hover:bg-accent focus-visible:bg-accent focus-visible:outline-none',
                  isVisible ? 'text-foreground' : 'text-muted-foreground',
                )}
              >
                <CheckMark visible={isVisible} />
                <span className="truncate">{column.header}</span>
              </button>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}

/**
 * Таблица данных. Скроллит ТОЛЬКО область строк: панель фильтров сверху и
 * пагинация снизу остаются на месте, иначе на длинном списке пользователь
 * теряет и то, и другое.
 *
 * Скелет при загрузке рисуется теми же колонками, что и данные, — страница не
 * прыгает в момент, когда ответ приходит. Пустое состояние во время загрузки не
 * показывается никогда: «ничего не найдено» на полпути к ответу — это ложь.
 */
export function DataTable<T>({
  columns,
  rows,
  getRowKey,
  loading = false,
  skeletonRows = 8,
  sort = null,
  onSortChange,
  onRowClick,
  rowClassName,
  emptyTitle,
  emptyDescription,
  emptyAction,
  toolbar,
  footer,
  stickyHeader = true,
  maxHeight,
  dense = false,
  className,
  columnVisibility = false,
}: DataTableProps<T>): React.ReactElement {
  const { t } = useI18n();

  const [hidden, setHidden] = React.useState<ReadonlySet<string>>(
    () => new Set(columns.filter((c) => c.defaultHidden).map((c) => c.key)),
  );

  const toggleColumn = React.useCallback((key: string): void => {
    setHidden((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  const visible = columns.filter((column) => !hidden.has(column.key));
  const hideable = columns.filter((column) => column.hideable);
  const showToolbarRow = Boolean(toolbar) || (columnVisibility && hideable.length > 0);
  const clickable = typeof onRowClick === 'function';
  const pad = dense ? 'py-1.5' : undefined;

  const handleSort = (column: DataTableColumn<T>): void => {
    if (!onSortChange) return;
    if (!sort || sort.key !== column.key) onSortChange({ key: column.key, direction: 'asc' });
    else if (sort.direction === 'asc') onSortChange({ key: column.key, direction: 'desc' });
    else onSortChange(null);
  };

  const sortStateOf = (column: DataTableColumn<T>): 'asc' | 'desc' | null =>
    sort && sort.key === column.key ? sort.direction : null;

  return (
    <div className={cn('premium-card flex flex-col overflow-hidden', className)}>
      {showToolbarRow ? (
        <div className="flex items-center gap-2 border-b border-border px-3 py-2.5">
          <div className="min-w-0 flex-1">{toolbar}</div>
          {columnVisibility && hideable.length > 0 ? (
            <ColumnMenu columns={hideable} hidden={hidden} onToggle={toggleColumn} />
          ) : null}
        </div>
      ) : null}

      <div className="overflow-auto" style={maxHeight ? { maxHeight } : undefined}>
        <Table>
          <colgroup>
            {visible.map((column) => (
              <col key={column.key} style={column.width ? { width: column.width } : undefined} />
            ))}
          </colgroup>

          <THead>
            <tr>
              {visible.map((column) => {
                const state = sortStateOf(column);
                const isSortable = Boolean(column.sortable && onSortChange);
                return (
                  <TH
                    key={column.key}
                    align={column.align ?? 'left'}
                    scope="col"
                    aria-sort={
                      isSortable
                        ? state === 'asc'
                          ? 'ascending'
                          : state === 'desc'
                            ? 'descending'
                            : 'none'
                        : undefined
                    }
                    className={cn(
                      // Прозрачная липкая шапка просвечивает строками при прокрутке —
                      // фон обязателен, поэтому bg-card задан явно.
                      stickyHeader && 'sticky top-0 z-10 bg-card',
                      pad,
                      column.headerClassName,
                    )}
                  >
                    {isSortable ? (
                      <button
                        type="button"
                        onClick={() => handleSort(column)}
                        className={cn(
                          'group -mx-1 inline-flex max-w-full items-center gap-1 rounded px-1 py-0.5',
                          'transition-colors hover:text-foreground focus-visible:outline-none',
                          'focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1',
                          state && 'text-foreground',
                          column.align === 'right' && 'flex-row-reverse',
                        )}
                      >
                        <span className="truncate">{column.header}</span>
                        <span className="shrink-0">
                          {state === 'asc' ? (
                            <ChevronUp />
                          ) : state === 'desc' ? (
                            <ChevronDown />
                          ) : (
                            <ChevronDown className="opacity-0 transition-opacity group-hover:opacity-60 group-focus-visible:opacity-60" />
                          )}
                        </span>
                        <span className="sr-only">
                          {state === 'asc'
                            ? t('ui.sort.asc')
                            : state === 'desc'
                              ? t('ui.sort.desc')
                              : t('ui.sort.none')}
                        </span>
                      </button>
                    ) : (
                      column.header
                    )}
                  </TH>
                );
              })}
            </tr>
          </THead>

          <TBody>
            {loading ? (
              Array.from({ length: Math.max(1, skeletonRows) }, (_unused, rowIndex) => (
                <TR key={`skeleton-${rowIndex}`} className="hover:bg-transparent">
                  {visible.map((column) => (
                    <TD key={column.key} className={pad}>
                      <Skeleton className="h-4 w-full" />
                    </TD>
                  ))}
                </TR>
              ))
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={Math.max(1, visible.length)} className="px-6 py-14">
                  <EmptyState
                    icon={<TableGlyph />}
                    title={emptyTitle ?? t('ui.noData')}
                    description={emptyDescription ?? t('ui.noDataHint')}
                    action={emptyAction}
                  />
                </td>
              </tr>
            ) : (
              rows.map((row, rowIndex) => (
                <TR
                  key={getRowKey(row, rowIndex)}
                  // Роль строки НЕ подменяется на button: это выбросило бы её из
                  // дерева доступности таблицы, и скринридер перестал бы связывать
                  // ячейки с заголовками. Клавиатура закрывается tabIndex + Enter/Space.
                  tabIndex={clickable ? 0 : undefined}
                  onClick={
                    clickable
                      ? (event) => {
                          // Клик по кнопке внутри ячейки не должен ещё и открывать строку.
                          if ((event.target as HTMLElement).closest(INTERACTIVE)) return;
                          onRowClick?.(row);
                        }
                      : undefined
                  }
                  onKeyDown={
                    clickable
                      ? (event) => {
                          if (event.target !== event.currentTarget) return;
                          if (event.key === 'Enter' || event.key === ' ') {
                            event.preventDefault();
                            onRowClick?.(row);
                          }
                        }
                      : undefined
                  }
                  className={cn(
                    clickable &&
                      'cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring',
                    rowClassName?.(row),
                  )}
                >
                  {visible.map((column) => (
                    <TD
                      key={column.key}
                      align={column.align ?? 'left'}
                      className={cn(
                        column.align === 'right' && 'tabular-nums',
                        pad,
                        column.className,
                      )}
                    >
                      {column.cell(row, rowIndex)}
                    </TD>
                  ))}
                </TR>
              ))
            )}
          </TBody>
        </Table>
      </div>

      {footer ? <div className="border-t border-border px-3 py-2.5">{footer}</div> : null}
    </div>
  );
}
