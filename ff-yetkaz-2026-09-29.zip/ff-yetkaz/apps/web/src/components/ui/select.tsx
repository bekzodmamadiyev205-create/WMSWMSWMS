import * as React from 'react';
import { cn } from '@/lib/utils';

/**
 * Обычный `<select>` в оформлении остальных полей. Не выпадашка на div'ах:
 * нативный список сам открывается колесом прокрутки на телефоне и работает с
 * клавиатуры — на складе это важнее анимаций.
 */
export const Select = React.forwardRef<HTMLSelectElement, React.ComponentProps<'select'>>(
  ({ className, ...props }, ref) => (
    <select
      ref={ref}
      className={cn(
        'flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm',
        'ring-offset-background focus-visible:outline-none focus-visible:ring-2',
        'focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed',
        'disabled:opacity-50',
        className,
      )}
      {...props}
    />
  ),
);
Select.displayName = 'Select';
