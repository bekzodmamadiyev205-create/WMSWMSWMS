import * as React from 'react';
import { cn } from '@/lib/utils';

export interface PopoverProps {
  /** Содержимое кнопки-триггера: сам `<button>` рисует Popover, вкладывать свой нельзя. */
  trigger: React.ReactNode;
  children: React.ReactNode | ((close: () => void) => React.ReactNode);
  align?: 'start' | 'center' | 'end';
  className?: string;
  triggerClassName?: string;
  contentClassName?: string;
  /** Передан — компонент управляемый; иначе состояние живёт внутри. */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const ALIGNMENT: Record<'start' | 'center' | 'end', string> = {
  start: 'left-0',
  center: 'left-1/2 -translate-x-1/2',
  end: 'right-0',
};

/**
 * Всплывающий слой у кнопки: фильтры, выбор периода, короткие формы.
 *
 * Фокус возвращается на триггер только когда он был ВНУТРИ панели (Esc, выбор пункта,
 * клик мимо из поля панели). Иначе клик по соседнему полю тут же терял бы каретку:
 * поповер закрывался и утаскивал фокус к себе на кнопку.
 */
export function Popover({
  trigger,
  children,
  align = 'start',
  className,
  triggerClassName,
  contentClassName,
  open: openProp,
  onOpenChange,
}: PopoverProps): React.ReactElement {
  const controlled = openProp !== undefined;
  const [innerOpen, setInnerOpen] = React.useState(false);
  const open = controlled ? openProp : innerOpen;

  const wrapperRef = React.useRef<HTMLDivElement>(null);
  const triggerRef = React.useRef<HTMLButtonElement>(null);
  const contentRef = React.useRef<HTMLDivElement>(null);
  const contentId = React.useId();

  const change = React.useCallback(
    (next: boolean, restoreFocus: boolean): void => {
      if (!controlled) setInnerOpen(next);
      onOpenChange?.(next);
      // Триггер смонтирован всегда, поэтому фокус переносим сразу, не дожидаясь
      // перерисовки: к моменту эффекта панель уже исчезнет и фокус улетит в body.
      if (!next && restoreFocus) triggerRef.current?.focus();
    },
    [controlled, onOpenChange],
  );

  React.useEffect(() => {
    if (!open) return;

    const onPointerDown = (event: MouseEvent): void => {
      if (wrapperRef.current?.contains(event.target as Node)) return;
      const focusWasInside = contentRef.current?.contains(document.activeElement) ?? false;
      change(false, focusWasInside);
    };
    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') change(false, true);
    };

    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [open, change]);

  const close = React.useCallback((): void => change(false, true), [change]);

  return (
    <div ref={wrapperRef} className={cn('relative inline-block', className)}>
      <button
        ref={triggerRef}
        type="button"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? contentId : undefined}
        onClick={() => change(!open, false)}
        className={cn(
          'inline-flex items-center justify-center gap-2 rounded-lg text-sm transition-colors',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
          'focus-visible:ring-offset-2 focus-visible:ring-offset-background',
          triggerClassName,
        )}
      >
        {trigger}
      </button>

      {open && (
        <div
          ref={contentRef}
          id={contentId}
          role="dialog"
          className={cn(
            'premium-popover absolute z-50 mt-2 min-w-[12rem] origin-top p-3 animate-scale-in',
            ALIGNMENT[align],
            contentClassName,
          )}
        >
          {typeof children === 'function' ? children(close) : children}
        </div>
      )}
    </div>
  );
}
