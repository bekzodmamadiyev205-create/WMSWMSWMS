import * as React from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

export interface PageHeaderProps {
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  breadcrumbs?: Array<{ label: string; to?: string }>;
  icon?: React.ReactNode;
  className?: string;
}

/**
 * Шапка страницы. Заголовок всегда `<h1>`: на экране он один, и оболочка своего
 * не рисует — иначе у половины страниц уровень заголовка зависел бы от вёрстки.
 */
export function PageHeader({
  title,
  description,
  actions,
  breadcrumbs,
  icon,
  className,
}: PageHeaderProps): React.ReactElement {
  return (
    <header className={cn('space-y-2', className)}>
      {breadcrumbs && breadcrumbs.length > 0 ? (
        <nav>
          <ol className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
            {breadcrumbs.map((crumb, index) => {
              const last = index === breadcrumbs.length - 1;
              return (
                <li key={`${crumb.label}-${index}`} className="flex items-center gap-1.5">
                  {index > 0 ? <span aria-hidden="true">⁄</span> : null}
                  {crumb.to && !last ? (
                    <Link
                      to={crumb.to}
                      className="rounded transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                    >
                      {crumb.label}
                    </Link>
                  ) : (
                    <span
                      aria-current={last ? 'page' : undefined}
                      className={last ? 'text-foreground' : undefined}
                    >
                      {crumb.label}
                    </span>
                  )}
                </li>
              );
            })}
          </ol>
        </nav>
      ) : null}

      <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-3">
        <div className="flex min-w-0 items-start gap-3">
          {icon ? (
            <span
              aria-hidden="true"
              className="flex shrink-0 items-center justify-center rounded-lg bg-primary/10 p-2 text-primary [&>svg]:h-5 [&>svg]:w-5"
            >
              {icon}
            </span>
          ) : null}
          <div className="min-w-0 space-y-1">
            <h1 className="text-xl font-semibold tracking-tight text-foreground">{title}</h1>
            {description ? (
              <p className="text-sm text-muted-foreground">{description}</p>
            ) : null}
          </div>
        </div>
        {actions ? (
          <div className="flex flex-wrap items-center gap-2">{actions}</div>
        ) : null}
      </div>
    </header>
  );
}

/**
 * Единая рамка страницы. Ширина ограничена и на всех экранах одинакова —
 * без неё соседние разделы разъезжаются по отступам на широком мониторе.
 */
export function PageContainer({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}): React.ReactElement {
  return (
    <div className={cn('mx-auto w-full max-w-[1600px] space-y-5 p-4 sm:p-6', className)}>
      {children}
    </div>
  );
}
