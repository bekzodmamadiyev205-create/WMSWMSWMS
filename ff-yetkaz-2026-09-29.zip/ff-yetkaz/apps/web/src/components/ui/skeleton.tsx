import * as React from 'react';
import { cn } from '@/lib/utils';

/**
 * Плейсхолдер загрузки — бегущий блик, а не пульсация. Мигающий блок читается как
 * сломанный элемент, который то появляется, то исчезает; проезжающая слева направо
 * подсветка однозначно означает «данные едут». Блик — отдельный слой внутри, чтобы
 * не завязывать анимацию на прозрачность самой плашки.
 */
export function Skeleton({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>): React.ReactElement {
  return (
    <div className={cn('relative overflow-hidden rounded-md bg-muted', className)} {...props}>
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-foreground/10 to-transparent"
      />
      {children}
    </div>
  );
}

export interface SkeletonTextProps {
  /** Сколько строк-заглушек нарисовать. */
  lines?: number;
  className?: string;
}

/**
 * Полоски скрыты от скринридера: озвучивать пустые прямоугольники нечем, а вот
 * состояние занятости на контейнере — настоящая информация для пользователя.
 */
export function SkeletonText({ lines = 3, className }: SkeletonTextProps): React.ReactElement {
  const count = Math.max(1, Math.floor(lines));
  return (
    <div role="status" aria-busy="true" className={cn('flex w-full flex-col gap-2', className)}>
      {Array.from({ length: count }, (_, index) => (
        <Skeleton
          key={index}
          aria-hidden="true"
          className={cn('h-3.5', index === count - 1 && count > 1 ? 'w-2/3' : 'w-full')}
        />
      ))}
    </div>
  );
}
