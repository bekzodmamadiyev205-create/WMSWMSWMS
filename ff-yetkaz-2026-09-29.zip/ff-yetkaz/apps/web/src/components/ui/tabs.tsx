import * as React from 'react';
import { cn } from '@/lib/utils';

export interface TabItem<T extends string> {
  value: T;
  label: React.ReactNode;
  /** Счётчик справа от подписи (например, число заказов в очереди). */
  badge?: React.ReactNode;
  disabled?: boolean;
}

export interface TabsProps<T extends string> {
  value: T;
  onValueChange: (v: T) => void;
  items: Array<TabItem<T>>;
  className?: string;
}

/**
 * Сегментированный переключатель, а не вкладки с подчёркиванием: он читается как
 * один орган управления с выбранным положением и не притворяется навигацией по
 * страницам — переключение здесь меняет срез данных, а не раздел.
 *
 * Внутри группы работает roving tabindex: в неё ведёт один Tab, дальше — стрелки.
 * Иначе на панели из шести срезов пользователь клавиатуры проходит шесть остановок
 * прежде, чем добраться до таблицы.
 */
export function Tabs<T extends string>({
  value,
  onValueChange,
  items,
  className,
}: TabsProps<T>): React.ReactElement {
  const refs = React.useRef<Array<HTMLButtonElement | null>>([]);

  const activeIndex = items.findIndex((item) => item.value === value);
  // Если value не совпало ни с одним пунктом, фокус всё равно должен куда-то вести —
  // иначе группа выпадает из обхода клавиатурой целиком.
  const focusIndex = activeIndex >= 0 ? activeIndex : 0;

  const move = (from: number, step: number): void => {
    if (items.length === 0) return;
    let index = from;
    for (let hop = 0; hop < items.length; hop += 1) {
      index = (index + step + items.length) % items.length;
      const candidate = items[index];
      if (candidate && !candidate.disabled) {
        refs.current[index]?.focus();
        onValueChange(candidate.value);
        return;
      }
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLButtonElement>, index: number): void => {
    if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
      event.preventDefault();
      move(index, 1);
    } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
      event.preventDefault();
      move(index, -1);
    } else if (event.key === 'Home') {
      event.preventDefault();
      move(items.length - 1, 1);
    } else if (event.key === 'End') {
      event.preventDefault();
      move(0, -1);
    }
  };

  return (
    <div
      role="tablist"
      aria-orientation="horizontal"
      className={cn('inline-flex items-center gap-1 rounded-lg bg-muted p-1', className)}
    >
      {items.map((item, index) => {
        const active = item.value === value;
        return (
          <button
            key={item.value}
            ref={(node) => {
              refs.current[index] = node;
            }}
            type="button"
            role="tab"
            aria-selected={active}
            disabled={item.disabled}
            tabIndex={index === focusIndex ? 0 : -1}
            onClick={() => onValueChange(item.value)}
            onKeyDown={(event) => handleKeyDown(event, index)}
            className={cn(
              'inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-all duration-150',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
              'disabled:pointer-events-none disabled:opacity-50',
              active
                ? 'bg-card text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground',
            )}
          >
            <span className="truncate">{item.label}</span>
            {item.badge !== undefined && item.badge !== null ? (
              <span
                className={cn(
                  'inline-flex min-w-[1.25rem] items-center justify-center rounded-full px-1.5 py-0.5 text-[11px] font-semibold leading-none tabular-nums',
                  active ? 'bg-primary/10 text-primary' : 'bg-background/70 text-muted-foreground',
                )}
              >
                {item.badge}
              </span>
            ) : null}
          </button>
        );
      })}
    </div>
  );
}
