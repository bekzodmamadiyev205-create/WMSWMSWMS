import * as React from 'react';
import { cn } from '@/lib/utils';
import { useI18n } from '@/lib/i18n';

export function Toolbar({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}): React.ReactElement {
  return <div className={cn('flex flex-wrap items-end gap-2', className)}>{children}</div>;
}

/**
 * Подписанная колонка фильтра. С подписью обёртка — `<label>`: `htmlFor` тут
 * задать нечем (контрол передают снаружи), а неявная привязка работает и делает
 * саму подпись кликабельной — на складе по ней и целятся.
 */
export function ToolbarGroup({
  children,
  label,
  className,
}: {
  children: React.ReactNode;
  label?: string;
  className?: string;
}): React.ReactElement {
  const classes = cn('flex min-w-0 flex-col gap-1', className);
  const caption = label ? (
    <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
      {label}
    </span>
  ) : null;

  if (label) {
    return (
      <label className={classes}>
        {caption}
        {children}
      </label>
    );
  }
  return <div className={classes}>{children}</div>;
}

export interface ToolbarSearchProps {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
  autoFocus?: boolean;
}

export function ToolbarSearch({
  value,
  onChange,
  placeholder,
  className,
  autoFocus,
}: ToolbarSearchProps): React.ReactElement {
  const { t } = useI18n();

  return (
    <div className={cn('relative', className)}>
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
        aria-hidden="true"
        className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
      >
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-3.3-3.3" />
      </svg>
      <input
        type="search"
        value={value}
        autoFocus={autoFocus}
        placeholder={placeholder ?? t('ui.search')}
        onChange={(event) => onChange(event.target.value)}
        // Escape очищает поиск, не дожидаясь мыши: фильтр сбрасывают чаще, чем задают.
        onKeyDown={(event) => {
          if (event.key === 'Escape' && value) {
            event.preventDefault();
            onChange('');
          }
        }}
        className={cn(
          'h-9 w-full rounded-md border border-input bg-background pl-8 pr-8 text-sm',
          'ring-offset-background placeholder:text-muted-foreground transition-colors',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
          'disabled:cursor-not-allowed disabled:opacity-50',
          // Своя «крестик»-кнопка уже есть — родная от WebKit дала бы вторую.
          '[&::-webkit-search-cancel-button]:appearance-none',
        )}
      />
      {value ? (
        <button
          type="button"
          aria-label={t('ui.reset')}
          onClick={() => onChange('')}
          className="absolute right-1 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <CrossIcon />
        </button>
      ) : null}
    </div>
  );
}

/** Разрыв в панели: всё, что после него, прижимается вправо. */
export function ToolbarSpacer(): React.ReactElement {
  return <div aria-hidden="true" className="ml-auto" />;
}

export function FilterChip({
  label,
  value,
  onClear,
}: {
  label: string;
  value: string;
  onClear: () => void;
}): React.ReactElement {
  const { t } = useI18n();

  return (
    <span className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-border bg-muted/50 py-1 pl-2.5 pr-1 text-xs">
      <span className="shrink-0 text-muted-foreground">{label}:</span>
      <span className="truncate font-medium text-foreground">{value}</span>
      <button
        type="button"
        // Подпись фильтра входит в метку кнопки: иначе в списке чипов
        // скринридер читает подряд несколько одинаковых «Сбросить».
        aria-label={`${t('ui.reset')}: ${label}`}
        onClick={onClear}
        className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-accent hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <CrossIcon className="h-3 w-3" />
      </button>
    </span>
  );
}

function CrossIcon({ className }: { className?: string }): React.ReactElement {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      aria-hidden="true"
      className={cn('h-3.5 w-3.5', className)}
    >
      <path d="M6 6 18 18M18 6 6 18" />
    </svg>
  );
}
