import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  RETURN_ITEM_CONDITIONS,
  RETURN_REASONS,
  type CreateReturnPayload,
  type OrderDto,
  type ReturnDto,
  type ReturnItemCondition,
  type ReturnReason,
} from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { ordersApi } from '@/lib/orders';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Dialog } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { Select } from '@/components/ui/select';
import { useToast } from '@/components/ui/toast';

interface ItemRow {
  /** Ключ строки формы: `skuId` для этого не годится — он пустой у новой строки. */
  key: string;
  skuId: string;
  quantity: string;
  condition: ReturnItemCondition;
}

interface ReturnCreateDialogProps {
  open: boolean;
  onClose: () => void;
  onCreated: (created: ReturnDto) => void;
}

let rowSequence = 0;
function newRow(skuId = '', quantity = '1', condition: ReturnItemCondition = 'GOOD'): ItemRow {
  rowSequence += 1;
  return { key: `row-${rowSequence}`, skuId, quantity, condition };
}

function errorText(error: unknown): string {
  return error instanceof ApiError ? error.message : (error as Error).message;
}

/**
 * Оформление возврата: «этот заказ приехал обратно».
 *
 * Заказ необязателен (клиент мог вернуть товар мимо нас, бывает пересорт и брак
 * партии), но если он найден — позиции подставляются из него: в реальной приёмке
 * возврата оператор не набирает состав руками, он сверяет коробку с заказом.
 */
export function ReturnCreateDialog({
  open,
  onClose,
  onCreated,
}: ReturnCreateDialogProps): React.ReactElement {
  const { t } = useI18n();
  const toast = useToast();
  const queryClient = useQueryClient();
  const baseId = React.useId();

  const [sellerId, setSellerId] = React.useState('');
  const [warehouseId, setWarehouseId] = React.useState('');
  const [orderCode, setOrderCode] = React.useState('');
  const [order, setOrder] = React.useState<OrderDto | null>(null);
  const [orderError, setOrderError] = React.useState<string | null>(null);
  const [reason, setReason] = React.useState<ReturnReason>('CUSTOMER_REFUSED');
  const [comment, setComment] = React.useState('');
  const [markOrderReturned, setMarkOrderReturned] = React.useState(true);
  const [rows, setRows] = React.useState<ItemRow[]>(() => [newRow()]);
  const [showErrors, setShowErrors] = React.useState(false);

  // Форма живёт ровно одно открытие: остаток прошлого возврата в полях — это
  // чужой товар, списанный на нового селлера.
  React.useEffect(() => {
    if (!open) return;
    setSellerId('');
    setWarehouseId('');
    setOrderCode('');
    setOrder(null);
    setOrderError(null);
    setReason('CUSTOMER_REFUSED');
    setComment('');
    setMarkOrderReturned(true);
    setRows([newRow()]);
    setShowErrors(false);
  }, [open]);

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers, enabled: open });
  const warehouses = useQuery({
    queryKey: ['mdm', 'warehouses'],
    queryFn: mdmApi.warehouses,
    enabled: open,
  });
  const skus = useQuery({
    queryKey: ['mdm', 'skus', sellerId],
    queryFn: () => mdmApi.skus({ sellerId }),
    enabled: open && sellerId !== '',
  });

  const lookup = useMutation({
    mutationFn: (code: string) => ordersApi.byCode(code),
    onSuccess: (found) => {
      setOrder(found);
      setOrderError(null);
      setSellerId(found.sellerId);
      if (found.warehouseId) setWarehouseId(found.warehouseId);
      // Позиции заказа = ожидаемый состав возврата. Оператор правит количества
      // под то, что реально доехало, а не набирает список с нуля.
      setRows(found.lines.map((line) => newRow(line.skuId, String(line.quantity))));
    },
    onError: (error) => {
      setOrder(null);
      setOrderError(error instanceof ApiError && error.status === 404
        ? t('returns.create.orderNotFound')
        : errorText(error));
    },
  });

  const create = useMutation({
    mutationFn: (payload: CreateReturnPayload) =>
      apiFetch<ReturnDto>('/returns', { method: 'POST', body: payload }),
    onSuccess: (created) => {
      toast.success(t('returns.create.created', { no: created.returnNo }));
      onCreated(created);
      onClose();
    },
    onError: (error) => toast.error(t('returns.create.failed'), errorText(error)),
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ['returns'] });
      void queryClient.invalidateQueries({ queryKey: ['orders'] });
    },
  });

  /**
   * Варианты для выбора товара: каталог селлера плюс позиции найденного заказа.
   * Без второй половины подставленная из заказа строка показывала бы голый
   * идентификатор всё время, пока грузится каталог.
   */
  const skuOptions = React.useMemo(() => {
    const byId = new Map<string, { value: string; label: string; triggerLabel: string; keywords: string }>();
    for (const line of order?.lines ?? []) {
      byId.set(line.skuId, {
        value: line.skuId,
        label: `${line.skuCode} — ${line.skuName}`,
        triggerLabel: line.skuCode,
        keywords: `${line.skuCode} ${line.skuName}`,
      });
    }
    for (const sku of skus.data ?? []) {
      byId.set(sku.id, {
        value: sku.id,
        label: `${sku.skuCode} — ${sku.name}`,
        triggerLabel: sku.skuCode,
        keywords: `${sku.skuCode} ${sku.name}`,
      });
    }
    return [...byId.values()];
  }, [order, skus.data]);

  const skuLabel = React.useCallback(
    (id: string): string => skuOptions.find((option) => option.value === id)?.triggerLabel ?? id,
    [skuOptions],
  );

  const patchRow = (key: string, patch: Partial<ItemRow>): void =>
    setRows((prev) => prev.map((row) => (row.key === key ? { ...row, ...patch } : row)));

  const removeRow = (key: string): void =>
    setRows((prev) => (prev.length === 1 ? prev : prev.filter((row) => row.key !== key)));

  /**
   * Проверки повторяют ограничения бэкенда сознательно. `UNIQUE(return_id, sku_id)`
   * отбил бы дубль артикула 409-м — но уже после того, как оператор нажал «Оформить»,
   * и без указания, какая из строк лишняя.
   */
  const problems: string[] = [];
  if (!sellerId) problems.push(t('returns.create.err.seller'));
  if (!warehouseId) problems.push(t('returns.create.err.warehouse'));
  if (rows.length === 0) problems.push(t('returns.create.err.noItems'));
  if (rows.some((row) => !row.skuId)) problems.push(t('returns.create.err.skuRequired'));
  if (rows.some((row) => !Number.isInteger(Number(row.quantity)) || Number(row.quantity) < 1)) {
    problems.push(t('returns.create.err.qty'));
  }
  const duplicated = rows
    .filter((row) => row.skuId)
    .filter((row, index, all) => all.findIndex((other) => other.skuId === row.skuId) !== index);
  for (const row of duplicated) {
    problems.push(t('returns.create.err.duplicate', { sku: skuLabel(row.skuId) }));
  }

  const submit = (): void => {
    if (problems.length > 0) {
      setShowErrors(true);
      return;
    }
    create.mutate({
      sellerId,
      warehouseId,
      orderId: order?.id ?? null,
      reason,
      comment: comment.trim() || null,
      items: rows.map((row) => ({
        skuId: row.skuId,
        quantity: Number(row.quantity),
        condition: row.condition,
      })),
      markOrderReturned: order ? markOrderReturned : false,
    });
  };

  return (
    <Dialog
      open={open}
      onClose={create.isPending ? () => undefined : onClose}
      title={t('returns.create.title')}
      description={t('returns.create.description')}
      size="xl"
      closeOnOverlay={!create.isPending}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={create.isPending}>
            {t('ui.cancel')}
          </Button>
          <Button size="sm" onClick={submit} disabled={create.isPending} className="gap-2">
            {create.isPending ? (
              <span
                aria-hidden="true"
                className="h-3.5 w-3.5 shrink-0 animate-spin rounded-full border-2 border-current border-t-transparent"
              />
            ) : null}
            {t('returns.create.submit')}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label htmlFor={`${baseId}-seller`}>{t('returns.create.seller')}</Label>
            <SearchableSelect
              id={`${baseId}-seller`}
              value={sellerId}
              onChange={setSellerId}
              placeholder={t('returns.create.selectSeller')}
              searchPlaceholder={t('returns.create.searchSeller')}
              options={(sellers.data ?? []).map((seller) => ({
                value: seller.id,
                triggerLabel: seller.code,
                label: `${seller.code} — ${seller.legalName}`,
                keywords: `${seller.code} ${seller.legalName}`,
              }))}
            />
          </div>

          <div className="space-y-1">
            <Label htmlFor={`${baseId}-warehouse`}>{t('returns.create.warehouse')}</Label>
            <Select
              id={`${baseId}-warehouse`}
              value={warehouseId}
              onChange={(event) => setWarehouseId(event.target.value)}
            >
              <option value="">{t('returns.create.selectWarehouse')}</option>
              {(warehouses.data ?? []).map((warehouse) => (
                <option key={warehouse.id} value={warehouse.id}>
                  {warehouse.code} — {warehouse.name}
                </option>
              ))}
            </Select>
          </div>
        </div>

        <div className="space-y-1">
          <Label htmlFor={`${baseId}-order`}>{t('returns.create.order')}</Label>
          <div className="flex flex-wrap items-center gap-2">
            <Input
              id={`${baseId}-order`}
              value={orderCode}
              autoComplete="off"
              placeholder={t('returns.create.orderPlaceholder')}
              className="h-10 w-full sm:w-64"
              onChange={(event) => setOrderCode(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter' && orderCode.trim()) {
                  event.preventDefault();
                  lookup.mutate(orderCode.trim());
                }
              }}
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={!orderCode.trim() || lookup.isPending}
              onClick={() => lookup.mutate(orderCode.trim())}
            >
              {t('returns.create.orderFind')}
            </Button>
            {order ? (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => {
                  setOrder(null);
                  setOrderCode('');
                  setOrderError(null);
                }}
              >
                {t('returns.create.orderClear')}
              </Button>
            ) : null}
          </div>

          {order ? (
            <p className="text-xs text-success">
              {t('returns.create.orderFound', {
                code: order.orderCode,
                recipient: order.recipientName,
              })}
            </p>
          ) : orderError ? (
            <p className="text-xs text-destructive">{orderError}</p>
          ) : (
            <p className="text-xs text-muted-foreground">{t('returns.create.orderHint')}</p>
          )}
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label htmlFor={`${baseId}-reason`}>{t('returns.create.reason')}</Label>
            <Select
              id={`${baseId}-reason`}
              value={reason}
              onChange={(event) => setReason(event.target.value as ReturnReason)}
            >
              {RETURN_REASONS.map((value) => (
                <option key={value} value={value}>
                  {t(`returns.reason.${value}` as MessageKey)}
                </option>
              ))}
            </Select>
          </div>

          <div className="space-y-1">
            <Label htmlFor={`${baseId}-comment`}>{t('returns.create.comment')}</Label>
            <Input
              id={`${baseId}-comment`}
              value={comment}
              placeholder={t('returns.create.commentPlaceholder')}
              onChange={(event) => setComment(event.target.value)}
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <Label>{t('returns.create.items')}</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setRows((prev) => [...prev, newRow()])}
            >
              {t('returns.create.addItem')}
            </Button>
          </div>

          <div className="space-y-2">
            {rows.map((row, index) => (
              <div
                key={row.key}
                className="grid grid-cols-1 gap-2 rounded-lg border border-border p-2 sm:grid-cols-[minmax(0,1fr)_6rem_9rem_auto] sm:items-end sm:border-0 sm:p-0"
              >
                <div className="space-y-1">
                  {index === 0 ? (
                    <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                      {t('returns.create.sku')}
                    </span>
                  ) : null}
                  <SearchableSelect
                    value={row.skuId}
                    onChange={(value) => patchRow(row.key, { skuId: value })}
                    placeholder={t('returns.create.pickSku')}
                    searchPlaceholder={t('returns.create.searchSku')}
                    options={skuOptions}
                  />
                </div>

                <div className="space-y-1">
                  {index === 0 ? (
                    <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                      {t('returns.create.qty')}
                    </span>
                  ) : null}
                  <Input
                    inputMode="numeric"
                    value={row.quantity}
                    className="text-right tabular-nums"
                    onChange={(event) =>
                      patchRow(row.key, { quantity: event.target.value.replace(/[^\d]/g, '') })
                    }
                  />
                </div>

                <div className="space-y-1">
                  {index === 0 ? (
                    <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                      {t('returns.create.condition')}
                    </span>
                  ) : null}
                  <Select
                    value={row.condition}
                    onChange={(event) =>
                      patchRow(row.key, { condition: event.target.value as ReturnItemCondition })
                    }
                  >
                    {RETURN_ITEM_CONDITIONS.map((value) => (
                      <option key={value} value={value}>
                        {t(`returns.condition.${value}` as MessageKey)}
                      </option>
                    ))}
                  </Select>
                </div>

                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  aria-label={t('returns.create.removeItem')}
                  title={t('returns.create.removeItem')}
                  disabled={rows.length === 1}
                  onClick={() => removeRow(row.key)}
                  className="justify-self-start text-muted-foreground sm:justify-self-auto"
                >
                  ✕
                </Button>
              </div>
            ))}
          </div>
        </div>

        {order ? (
          <label className="flex items-start gap-2 rounded-lg bg-muted/50 p-3 text-sm">
            <input
              type="checkbox"
              checked={markOrderReturned}
              onChange={(event) => setMarkOrderReturned(event.target.checked)}
              className="mt-0.5 h-4 w-4 shrink-0 rounded border-input accent-primary"
            />
            <span>
              <span className="font-medium text-foreground">
                {t('returns.create.markOrderReturned')}
              </span>
              <span className="mt-0.5 block text-xs text-muted-foreground">
                {t('returns.create.markOrderReturnedHint')}
              </span>
            </span>
          </label>
        ) : null}

        {showErrors && problems.length > 0 ? (
          <ul
            role="alert"
            className={cn(
              'space-y-1 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2',
              'text-xs text-destructive',
            )}
          >
            {problems.map((problem) => (
              <li key={problem}>{problem}</li>
            ))}
          </ul>
        ) : null}
      </div>
    </Dialog>
  );
}
