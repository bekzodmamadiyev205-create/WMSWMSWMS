import * as React from 'react';
import type { ReturnStatus, ReturnStatusEventDto } from '@ff/shared';
import { useI18n, type Language, type MessageKey } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import { Badge, type BadgeProps } from '@/components/ui/badge';

type BadgeTone = NonNullable<BadgeProps['variant']>;

/**
 * Тон статуса возврата. Живёт здесь, а не в каждой странице: список и карточка
 * обязаны красить один и тот же статус одинаково — иначе оператор считает
 * «жёлтый в списке» и «синий в карточке» разными состояниями документа.
 */
export const RETURN_STATUS_TONE: Record<ReturnStatus, BadgeTone> = {
  ACCEPTED: 'info',
  IN_STORAGE: 'default',
  MOVING: 'warning',
  COMPLETED: 'success',
  CANCELLED: 'destructive',
};

/**
 * Маршрут документа. `CANCELLED` в дорожку не входит намеренно: отмена — это
 * обрыв пути, а не его шаг, и рисовать её пятым кружком значит обещать, что
 * каждый возврат туда придёт.
 */
export const RETURN_FLOW: readonly ReturnStatus[] = ['ACCEPTED', 'IN_STORAGE', 'MOVING', 'COMPLETED'];

export function returnStatusKey(status: ReturnStatus): MessageKey {
  return `returns.status.${status}` as MessageKey;
}

/**
 * Дата показывается в локали выбранного языка, а не всегда русской: «20.08.2026»
 * посреди английского экрана читается как чужая вставка, а китайский формат
 * отличается и порядком частей.
 */
const LOCALE: Record<Language, string> = { ru: 'ru-RU', uz: 'uz-UZ', en: 'en-GB', zh: 'zh-CN' };

export function dateLocale(language: Language): string {
  return LOCALE[language];
}

type Translate = (key: MessageKey, params?: Record<string, string | number>) => string;

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

/**
 * Длительность стадии человеческим текстом. Две старшие единицы и не больше:
 * «2 д 3 ч» читается с одного взгляда, «2 д 3 ч 17 мин 4 с» — уже нет.
 */
function formatDuration(ms: number, t: Translate): string {
  if (ms < MINUTE) return t('returns.dur.lessMinute');

  const days = Math.floor(ms / DAY);
  const hours = Math.floor((ms % DAY) / HOUR);
  const minutes = Math.floor((ms % HOUR) / MINUTE);

  if (days > 0) {
    return hours > 0
      ? `${days} ${t('returns.dur.d')} ${hours} ${t('returns.dur.h')}`
      : `${days} ${t('returns.dur.d')}`;
  }
  if (hours > 0) {
    return minutes > 0
      ? `${hours} ${t('returns.dur.h')} ${minutes} ${t('returns.dur.m')}`
      : `${hours} ${t('returns.dur.h')}`;
  }
  return `${minutes} ${t('returns.dur.m')}`;
}

function CheckIcon(): React.ReactElement {
  return (
    <svg viewBox="0 0 16 16" fill="none" aria-hidden="true" className="h-3.5 w-3.5">
      <path
        d="M3.5 8.5 6.5 11.5 12.5 5"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

interface TrackStep {
  status: ReturnStatus;
  state: 'done' | 'current' | 'pending';
}

/**
 * Состояние дорожки собирается из СОБЫТИЙ, а не из позиции текущего статуса в
 * списке: `IN_STORAGE ⇄ MOVING` ходит в обе стороны, и «всё, что левее текущего,
 * пройдено» — неверное допущение. Пройденным считается то, в чём документ реально
 * побывал.
 */
function buildTrack(events: ReturnStatusEventDto[], status: ReturnStatus): TrackStep[] {
  const visited = new Set<ReturnStatus>(events.map((event) => event.toStatus));
  // Возврат всегда начинается с приёмки, даже если журнал событий пуст.
  visited.add('ACCEPTED');

  return RETURN_FLOW.map((step) => ({
    status: step,
    state: step === status ? 'current' : visited.has(step) ? 'done' : 'pending',
  }));
}

const DOT_STATE: Record<TrackStep['state'], string> = {
  done: 'border-success bg-success text-success-foreground',
  current: 'border-primary bg-primary text-primary-foreground',
  pending: 'border-border bg-card text-muted-foreground',
};

const LABEL_STATE: Record<TrackStep['state'], string> = {
  done: 'text-foreground',
  current: 'text-foreground font-medium',
  pending: 'text-muted-foreground',
};

export interface ReturnTimelineProps {
  events: ReturnStatusEventDto[];
  status: ReturnStatus;
  className?: string;
}

/**
 * История возврата: дорожка стадий сверху и журнал событий снизу.
 *
 * Ничего не запрашивает — события приезжают вместе с карточкой возврата.
 * Отдельный запрос за историей означал бы второй источник правды: карточка уже
 * обновилась после действия, а история осталась бы прежней до своего рефетча.
 */
export function ReturnTimeline({ events, status, className }: ReturnTimelineProps): React.ReactElement {
  const { t, language } = useI18n();

  // Сервер может отдать события в любом порядке — сортируем по времени сами,
  // иначе длительности стадий считаются между случайными парами записей.
  const ordered = React.useMemo(
    () => [...events].sort((a, b) => Date.parse(a.occurredAt) - Date.parse(b.occurredAt)),
    [events],
  );

  const track = buildTrack(ordered, status);
  const cancelled = status === 'CANCELLED';
  const terminal = cancelled || status === 'COMPLETED';
  const last = ordered[ordered.length - 1];

  return (
    <section className={cn('premium-card p-4', className)}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-medium text-card-foreground">{t('returns.timeline.title')}</h2>
        <Badge variant={RETURN_STATUS_TONE[status]} dot>
          {t(returnStatusKey(status))}
        </Badge>
      </div>

      {/* Дорожка стадий: горизонтальная на широком экране, вертикальная на телефоне. */}
      <ol className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-start sm:gap-0">
        {track.map((step, index) => (
          <li key={step.status} className="flex min-w-0 flex-1 items-center gap-3 sm:flex-col sm:gap-2">
            <div className="flex items-center gap-0 sm:w-full">
              <span
                aria-hidden="true"
                className={cn(
                  'hidden h-0.5 flex-1 sm:block',
                  index === 0 && 'invisible',
                  step.state === 'pending' ? 'bg-border' : 'bg-success',
                )}
              />
              <span
                className={cn(
                  'flex h-7 w-7 shrink-0 items-center justify-center rounded-full border text-xs font-semibold tabular-nums',
                  DOT_STATE[step.state],
                  cancelled && step.state !== 'done' && 'opacity-50',
                )}
              >
                {step.state === 'done' ? <CheckIcon /> : index + 1}
              </span>
              <span
                aria-hidden="true"
                className={cn(
                  'hidden h-0.5 flex-1 sm:block',
                  index === track.length - 1 && 'invisible',
                  track[index + 1] && track[index + 1].state === 'pending' ? 'bg-border' : 'bg-success',
                )}
              />
            </div>
            <span className={cn('truncate text-xs sm:text-center', LABEL_STATE[step.state])}>
              {t(returnStatusKey(step.status))}
            </span>
          </li>
        ))}
      </ol>

      {cancelled ? (
        <p className="mt-3 rounded-md bg-destructive/10 px-3 py-2 text-xs text-destructive">
          {t('returns.timeline.cancelled')}
        </p>
      ) : null}

      <div className="mt-5 border-t border-border pt-4">
        {ordered.length === 0 ? (
          <p className="text-xs text-muted-foreground">{t('returns.timeline.empty')}</p>
        ) : (
          <ol className="space-y-0">
            {ordered.map((event, index) => {
              const previous = index > 0 ? ordered[index - 1] : null;
              const sincePrevious = previous
                ? Date.parse(event.occurredAt) - Date.parse(previous.occurredAt)
                : null;

              return (
                <li key={event.id} className="relative flex gap-3 pb-4 last:pb-0">
                  {/* Вертикальная линия рисуется псевдо-элементом строки, а не общей
                      колонкой: у последнего события она не должна уходить в пустоту. */}
                  <div className="flex flex-col items-center">
                    <span
                      aria-hidden="true"
                      className={cn(
                        'mt-1 h-2.5 w-2.5 shrink-0 rounded-full ring-4 ring-card',
                        event.toStatus === 'CANCELLED'
                          ? 'bg-destructive'
                          : index === ordered.length - 1
                            ? 'bg-primary'
                            : 'bg-success',
                      )}
                    />
                    {index < ordered.length - 1 ? (
                      <span aria-hidden="true" className="mt-1 w-px flex-1 bg-border" />
                    ) : null}
                  </div>

                  <div className="min-w-0 flex-1 pb-1">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <Badge variant={RETURN_STATUS_TONE[event.toStatus]} size="sm">
                        {t(returnStatusKey(event.toStatus))}
                      </Badge>
                      {event.fromStatus ? (
                        <span className="text-xs text-muted-foreground">
                          {t('returns.timeline.from', { status: t(returnStatusKey(event.fromStatus)) })}
                        </span>
                      ) : null}
                      {sincePrevious !== null ? (
                        <span
                          className="text-xs tabular-nums text-muted-foreground"
                          title={t('returns.timeline.sincePrev')}
                        >
                          +{formatDuration(sincePrevious, t)}
                        </span>
                      ) : null}
                    </div>

                    <div className="mt-1 text-xs text-muted-foreground">
                      {new Date(event.occurredAt).toLocaleString(dateLocale(language))} ·{' '}
                      {event.actorName ?? t('returns.timeline.system')}
                    </div>

                    {event.comment ? (
                      <p className="mt-1 break-words text-xs text-foreground">{event.comment}</p>
                    ) : null}
                  </div>
                </li>
              );
            })}
          </ol>
        )}

        {last && !terminal ? (
          <p className="mt-1 text-xs text-muted-foreground">
            {t('returns.timeline.inStatus', {
              duration: formatDuration(Math.max(0, Date.now() - Date.parse(last.occurredAt)), t),
            })}
          </p>
        ) : null}
      </div>
    </section>
  );
}
