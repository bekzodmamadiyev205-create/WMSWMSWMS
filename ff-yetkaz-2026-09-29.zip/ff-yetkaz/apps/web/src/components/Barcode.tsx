import * as React from 'react';

/**
 * Штрихкод Code 128 (набор B) как SVG — без зависимостей. Кодирует наш код
 * заказа `FF-YES0000001` в реальный сканируемый штрихкод: печатается на этикетке
 * и читается тем же ручным сканером, что и товары.
 *
 * Таблица из 107 паттернов ширин (индексы 0..106). Каждый символ — 6 полос
 * (кроме стоп-символа 106 — 7 полос). Полосы чередуются «чёрная/белая», начиная
 * с чёрной.
 */
const PATTERNS = [
  '212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212',
  '221213', '221312', '231212', '112232', '122132', '122231', '113222', '123122', '123221',
  '223211', '221132', '221231', '213212', '223112', '312131', '311222', '321122', '321221',
  '312212', '322112', '322211', '212123', '212321', '232121', '111323', '131123', '131321',
  '112313', '132113', '132311', '211313', '231113', '231311', '112133', '112331', '132131',
  '113123', '113321', '133121', '313121', '211331', '231131', '213113', '213311', '213131',
  '311123', '311321', '331121', '312113', '312311', '332111', '314111', '221411', '431111',
  '111224', '111422', '121124', '121421', '141122', '141221', '112214', '112412', '122114',
  '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111', '111242',
  '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141',
  '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311',
  '113141', '114131', '311141', '411131', '211412', '211214', '211232', '2331112',
];

const START_B = 104;
const STOP = 106;

function encode(text: string): number[] {
  const codes = [START_B];
  let checksum = START_B;
  let position = 1;
  for (const ch of text) {
    const value = ch.charCodeAt(0) - 32; // набор B: печатные ASCII 32..126
    if (value < 0 || value > 94) continue;
    codes.push(value);
    checksum += value * position;
    position += 1;
  }
  codes.push(checksum % 103);
  codes.push(STOP);
  return codes;
}

export function Barcode({
  value,
  height = 60,
  module = 2,
  className,
}: {
  value: string;
  height?: number;
  module?: number;
  className?: string;
}): React.ReactElement {
  const { bars, width } = React.useMemo(() => {
    const rects: Array<{ x: number; w: number }> = [];
    let x = 0;
    for (const code of encode(value)) {
      const pattern = PATTERNS[code];
      for (let i = 0; i < pattern.length; i += 1) {
        const w = Number(pattern[i]) * module;
        if (i % 2 === 0) rects.push({ x, w }); // чётный индекс — чёрная полоса
        x += w;
      }
    }
    return { bars: rects, width: x };
  }, [value, module]);

  return (
    <svg
      className={className}
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      role="img"
      aria-label={value}
      shapeRendering="crispEdges"
    >
      <rect width={width} height={height} fill="#ffffff" />
      {bars.map((b, i) => (
        <rect key={i} x={b.x} y={0} width={b.w} height={height} fill="#000000" />
      ))}
    </svg>
  );
}
