import * as React from 'react';

type Flash = { kind: 'ok' | 'err'; text: string; key: number } | null;

/** Короткий звук результата: успех — высокий «пик», ошибка — низкий «бз-з». */
function beep(kind: 'ok' | 'err'): void {
  try {
    const Ctx =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = kind === 'ok' ? 'sine' : 'square';
    osc.frequency.value = kind === 'ok' ? 880 : 180;
    gain.gain.value = 0.09;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + (kind === 'ok' ? 0.12 : 0.3));
    osc.onended = () => {
      ctx.close();
    };
  } catch {
    /* звук не критичен — тихо пропускаем */
  }
}

/**
 * Обратная связь сканера для склада (ТСД): зелёная вспышка ✓ при приёме
 * штрихкода, красная ✗ при отказе, плюс короткий звук и вибрация. Работник
 * видит и слышит результат, не вчитываясь в текст на экране.
 */
export function useScanFeedback(holdMs = 900): {
  flash: Flash;
  signalOk: (text: string) => void;
  signalErr: (text: string) => void;
} {
  const [flash, setFlash] = React.useState<Flash>(null);
  const seq = React.useRef(0);
  const timer = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const signal = React.useCallback(
    (kind: 'ok' | 'err', text: string) => {
      seq.current += 1;
      setFlash({ kind, text, key: seq.current });
      beep(kind);
      // Вибрация, если устройство умеет: успех — короткая, ошибка — тройная.
      if ('vibrate' in navigator) navigator.vibrate(kind === 'ok' ? 60 : [70, 50, 70]);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setFlash(null), holdMs);
    },
    [holdMs],
  );

  React.useEffect(() => () => clearTimeout(timer.current), []);

  return {
    flash,
    signalOk: (text: string) => signal('ok', text),
    signalErr: (text: string) => signal('err', text),
  };
}

const OK = '#16a34a';
const ERR = '#dc2626';

/**
 * Полноэкранная вспышка результата скана. Не перехватывает клики
 * (pointer-events:none) — фокус остаётся в поле штрихкода, следующий скан
 * проходит сразу. Гаснет сама (~0.9с, анимация `scan-flash` в index.css).
 */
export function ScanFlash({ flash }: { flash: Flash }): React.ReactElement | null {
  if (!flash) return null;
  const ok = flash.kind === 'ok';
  const color = ok ? OK : ERR;
  return (
    <div
      key={flash.key}
      aria-live="assertive"
      className="scan-flash pointer-events-none fixed inset-0 z-[60] flex flex-col items-center justify-center gap-5 p-6"
      style={{ backgroundColor: ok ? 'rgba(22,163,74,0.22)' : 'rgba(220,38,38,0.26)' }}
    >
      <div
        className="flex h-32 w-32 items-center justify-center rounded-full text-7xl font-black text-white shadow-2xl"
        style={{ backgroundColor: color }}
      >
        {ok ? '✓' : '✗'}
      </div>
      <div
        className="max-w-[90%] rounded-xl px-5 py-3 text-center text-xl font-bold text-white shadow-lg"
        style={{ backgroundColor: color }}
      >
        {flash.text}
      </div>
    </div>
  );
}
