import * as React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { STAFF_ROLES, type Role } from '@ff/shared';
import { useAuth } from '@/lib/auth';
import { LANGUAGES, useI18n, type MessageKey } from '@/lib/i18n';
import { useTheme } from '@/lib/theme';
import { cn } from '@/lib/utils';
import { Flag } from '@/components/flags';
import { Icon, type IconName } from '@/components/icons';
import { Button } from '@/components/ui/button';

/**
 * Оболочка приложения: слева — колонки-разделы, каждая раскрывается как
 * дропдаун; справа сверху — язык (флаг + слово «язык» на самом языке) и тема.
 *
 * Меню описано данными: пункт появляется только если у пользователя есть
 * нужная роль. Прятать и показывать разделы вёрсткой по месту — прямой путь
 * к кнопке, которая отвечает 403.
 */
interface NavItem {
  to: string;
  label: MessageKey;
  icon: IconName;
  roles?: Role[];
}

interface NavSection {
  key: string;
  label: MessageKey;
  icon: IconName;
  roles?: Role[];
  items: NavItem[];
}

const SECTIONS: NavSection[] = [
  {
    key: 'operations',
    label: 'nav.operations',
    icon: 'packing',
    roles: [...STAFF_ROLES],
    items: [
      { to: '/inbound', label: 'nav.inbound', icon: 'inbound', roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER'] },
      { to: '/picking', label: 'nav.picking', icon: 'picking', roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER'] },
      { to: '/packing', label: 'nav.packing', icon: 'packing', roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'PACKER'] },
    ],
  },
  {
    key: 'warehouse',
    label: 'nav.warehouse',
    icon: 'warehouse',
    roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'FINANCE', 'RECEIVER'],
    items: [
      { to: '/stock', label: 'nav.stock', icon: 'stock' },
      {
        to: '/returns',
        label: 'nav.returns',
        icon: 'truck',
        // Приёмщик физически принимает возврат — без него роль не может
        // оформить то, что уже стоит у него на столе.
        roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER'],
      },
      { to: '/dashboard', label: 'nav.summary', icon: 'chart', roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'FINANCE'] },
      { to: '/analytics', label: 'nav.analytics', icon: 'chart', roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'FINANCE'] },
    ],
  },
  {
    key: 'orders',
    label: 'nav.orders',
    icon: 'orders',
    roles: ['ADMIN', 'WAREHOUSE_OPERATOR'],
    items: [
      { to: '/orders', label: 'nav.orders.list', icon: 'orders' },
      { to: '/orders/new', label: 'nav.orders.new', icon: 'plus' },
    ],
  },
  {
    key: 'directories',
    label: 'nav.directories',
    icon: 'catalog',
    roles: ['ADMIN', 'WAREHOUSE_OPERATOR'],
    items: [
      { to: '/catalog', label: 'nav.catalog', icon: 'catalog' },
      { to: '/sellers', label: 'nav.sellers', icon: 'store', roles: ['ADMIN'] },
      { to: '/order-categories', label: 'categories.title', icon: 'catalog', roles: ['ADMIN'] },
    ],
  },
  {
    key: 'finance',
    label: 'nav.finance',
    icon: 'chart',
    roles: ['ADMIN', 'FINANCE'],
    items: [{ to: '/tariffs', label: 'nav.tariffs', icon: 'catalog' }],
  },
  {
    key: 'settings',
    label: 'nav.settings',
    icon: 'settings',
    roles: ['ADMIN'],
    items: [
      { to: '/users', label: 'nav.access', icon: 'users' },
      { to: '/departments', label: 'nav.departments', icon: 'building' },
      { to: '/field-permissions', label: 'acl.title', icon: 'settings' },
    ],
  },
  {
    key: 'seller',
    label: 'nav.seller',
    icon: 'store',
    roles: ['SELLER'],
    items: [{ to: '/seller', label: 'nav.seller', icon: 'store' }],
  },
];

function hasAccess(userRoles: Role[], required?: Role[]): boolean {
  if (!required || required.length === 0) return true;
  return required.some((role) => userRoles.includes(role));
}

function isItemActive(to: string, currentPath: string): boolean {
  if (to === '/orders') return currentPath === '/orders' || /^\/orders\/(?!new)/.test(currentPath);
  return currentPath.startsWith(to);
}

/** Закрывает дропдаун по клику мимо — стандартное поведение меню. */
function useClickOutside(onOutside: () => void): React.RefObject<HTMLDivElement> {
  const ref = React.useRef<HTMLDivElement>(null);
  React.useEffect(() => {
    const handler = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) onOutside();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [onOutside]);
  return ref;
}

function LanguageMenu(): React.ReactElement {
  const { language, setLanguage } = useI18n();
  const [open, setOpen] = React.useState(false);
  const ref = useClickOutside(() => setOpen(false));
  const current = LANGUAGES.find((lang) => lang.code === language) ?? LANGUAGES[0];

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
        className={cn(
          'flex h-9 items-center gap-2 rounded-lg border border-input bg-card px-3 text-sm',
          'shadow-sm hover:bg-accent hover:text-accent-foreground',
        )}
      >
        <Flag code={current.code} />
        <span>{current.word}</span>
        <span aria-hidden className="text-xs text-muted-foreground">▾</span>
      </button>

      {open && (
        <div
          role="listbox"
          className="absolute right-0 z-50 mt-1 w-44 overflow-hidden rounded-lg border bg-card shadow-xl"
        >
          {LANGUAGES.map((lang) => (
            <button
              key={lang.code}
              type="button"
              role="option"
              aria-selected={lang.code === language}
              onClick={() => {
                setLanguage(lang.code);
                setOpen(false);
              }}
              className={cn(
                'flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-accent',
                lang.code === language && 'bg-muted font-medium',
              )}
            >
              <Flag code={lang.code} />
              <span>{lang.native}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * Окно профиля. Открывается по клику на карточку пользователя внизу колонки —
 * оператор может свериться, под кем он вошёл и какие у него роли, не выходя из
 * системы. Данные берутся из уже загруженного профиля, отдельного запроса нет.
 */
function ProfileDialog({ onClose }: { onClose: () => void }): React.ReactElement {
  const { user, logout } = useAuth();
  const { t } = useI18n();
  const roles = (user?.roles ?? []) as Role[];

  // Escape закрывает — привычное поведение модального окна.
  React.useEffect(() => {
    const onKey = (event: KeyboardEvent) => event.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} aria-hidden />
      <div role="dialog" aria-modal className="premium-card relative w-full max-w-sm p-5">
        <div className="mb-4 flex items-center gap-3">
          <span className="brand-gradient flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-base font-semibold text-white">
            {initialsOf(user?.fullName ?? '')}
          </span>
          <div className="min-w-0">
            <div className="truncate text-base font-semibold">{user?.fullName}</div>
            <div className="truncate text-sm text-muted-foreground">{user?.email}</div>
          </div>
        </div>

        <dl className="space-y-2 border-t pt-3 text-sm">
          <div className="flex items-start justify-between gap-3">
            <dt className="shrink-0 text-muted-foreground">{t('users.roles')}</dt>
            <dd className="flex flex-wrap justify-end gap-1">
              {roles.length ? (
                roles.map((role) => (
                  <span
                    key={role}
                    className="rounded-md bg-accent px-2 py-0.5 text-xs text-accent-foreground"
                  >
                    {t(`users.role.${role}` as MessageKey)}
                  </span>
                ))
              ) : (
                <span className="text-muted-foreground">—</span>
              )}
            </dd>
          </div>
          {user?.sellerId && (
            <div className="flex items-center justify-between gap-3">
              <dt className="text-muted-foreground">{t('users.seller')}</dt>
              <dd className="font-mono text-xs">{user.sellerId}</dd>
            </div>
          )}
        </dl>

        <div className="mt-5 flex gap-2">
          <Button variant="outline" className="flex-1" onClick={onClose}>
            {t('common.close')}
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-destructive/40 text-destructive hover:bg-destructive/10"
            onClick={logout}
          >
            {t('nav.logout')}
          </Button>
        </div>
      </div>
    </div>
  );
}

function ThemeToggle(): React.ReactElement {
  const { theme, toggle } = useTheme();
  const { t } = useI18n();
  return (
    <button
      type="button"
      onClick={toggle}
      title={theme === 'dark' ? t('common.theme.light') : t('common.theme.dark')}
      className={cn(
        'flex h-9 w-9 items-center justify-center rounded-lg border border-input bg-card text-base',
        'shadow-sm hover:bg-accent',
      )}
    >
      <span aria-hidden>{theme === 'dark' ? '☀️' : '🌙'}</span>
    </button>
  );
}

/** Инициалы для аватара: «Санжар Сборщик» → «СС». */
function initialsOf(name: string): string {
  return (
    name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() ?? '')
      .join('') || '·'
  );
}

function Logo(): React.ReactElement {
  return (
    <Link to="/" className="flex items-center gap-2.5 px-4 py-4">
      <span className="brand-gradient flex h-9 w-9 shrink-0 rotate-3 items-center justify-center rounded-xl text-sm font-bold text-white shadow-md">
        FF
      </span>
      <span className="min-w-0 leading-tight">
        <span className="block truncate text-[15px] font-semibold tracking-tight">Yetkaz Express</span>
        <span className="block truncate text-[11px] text-muted-foreground">Fulfillment Platform</span>
      </span>
    </Link>
  );
}

function SidebarSection({
  section,
  currentPath,
}: {
  section: NavSection;
  currentPath: string;
}): React.ReactElement {
  // Раздел с активной страницей открыт при заходе — человек видит, где он.
  const containsCurrent = section.items.some((item) => isItemActive(item.to, currentPath));
  const [open, setOpen] = React.useState(containsCurrent);
  const { t } = useI18n();

  return (
    <div>
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
        className={cn(
          'flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium',
          'text-muted-foreground hover:bg-accent hover:text-accent-foreground',
          containsCurrent && 'text-foreground',
        )}
      >
        <span className="text-muted-foreground/80">{Icon[section.icon]('h-4 w-4')}</span>
        <span className="flex-1 text-left">{t(section.label)}</span>
        <span aria-hidden className={cn('text-xs transition-transform', open && 'rotate-180')}>
          ▾
        </span>
      </button>

      {open && (
        <div className="mt-0.5 space-y-0.5 pl-4">
          {section.items.map((item) => {
            const active = isItemActive(item.to, currentPath);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  'flex items-center gap-2.5 rounded-lg px-3 py-1.5 text-sm',
                  active
                    ? 'brand-gradient font-medium text-white shadow-sm'
                    : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground',
                )}
              >
                <span className={active ? 'text-white/90' : 'text-muted-foreground/70'}>
                  {Icon[item.icon]('h-4 w-4')}
                </span>
                {t(item.label)}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function AppShell({ children }: { children: React.ReactNode }): React.ReactElement {
  const { user } = useAuth();
  const { t } = useI18n();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [profileOpen, setProfileOpen] = React.useState(false);

  const roles = (user?.roles ?? []) as Role[];
  const sections = SECTIONS.filter(
    (section) =>
      hasAccess(roles, section.roles) &&
      section.items.some((item) => hasAccess(roles, item.roles)),
  ).map((section) => ({
    ...section,
    items: section.items.filter((item) => hasAccess(roles, item.roles)),
  }));

  // Заголовок в шапке — название текущей страницы из меню.
  const currentTitle =
    location.pathname === '/'
      ? t('home.title')
      : (() => {
          for (const section of sections)
            for (const item of section.items)
              if (isItemActive(item.to, location.pathname)) return t(item.label);
          return t('home.title');
        })();

  const roleTitle = roles.length
    ? t(`users.role.${roles[0]}` as MessageKey)
    : '';

  // Смена маршрута закрывает мобильное меню: иначе оно висит поверх экрана.
  React.useEffect(() => setMobileOpen(false), [location.pathname]);

  const sidebar = (
    <div className="flex h-full flex-col">
      <Logo />
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 pb-3">
        <Link
          to="/"
          className={cn(
            'mb-1 flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname === '/'
              ? 'brand-gradient text-white shadow-sm'
              : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground',
          )}
        >
          <span className={location.pathname === '/' ? 'text-white/90' : 'text-muted-foreground/70'}>
            {Icon.home('h-4 w-4')}
          </span>
          {t('nav.home')}
        </Link>
        {sections.map((section) => (
          <SidebarSection key={section.key} section={section} currentPath={location.pathname} />
        ))}
      </nav>

      {/* Карточка пользователя — как в макете, внизу колонки. Клик открывает профиль. */}
      <div className="border-t p-3">
        <button
          type="button"
          onClick={() => setProfileOpen(true)}
          className="flex w-full items-center gap-2.5 rounded-lg border bg-background/60 px-3 py-2.5 text-left transition-colors hover:bg-accent"
        >
          <span className="brand-gradient flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold text-white">
            {initialsOf(user?.fullName ?? '')}
          </span>
          <span className="min-w-0 flex-1 leading-tight">
            <span className="block truncate text-sm font-medium">{user?.fullName}</span>
            <span className="block truncate text-[11px] text-muted-foreground">{roleTitle}</span>
          </span>
          <span aria-hidden className="text-xs text-muted-foreground">▸</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen">
      {/* Боковая колонка. На телефоне — по кнопке, поверх содержимого. */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 border-r bg-card/80 backdrop-blur md:block">
        {sidebar}
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setMobileOpen(false)}
            aria-hidden
          />
          <aside className="absolute inset-y-0 left-0 w-72 overflow-y-auto border-r bg-card shadow-xl">
            {sidebar}
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b bg-card/80 px-3 backdrop-blur sm:px-5">
          <button
            type="button"
            className="rounded-lg border border-input px-2.5 py-1.5 text-sm md:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="menu"
          >
            ☰
          </button>

          <h1 className="min-w-0 flex-1 truncate text-[15px] font-semibold tracking-tight">
            {currentTitle}
          </h1>

          <LanguageMenu />
          <ThemeToggle />
          {/* Аватар админа: клик открывает окно профиля, «Выйти» — внутри него. */}
          <button
            type="button"
            onClick={() => setProfileOpen(true)}
            title={user?.fullName}
            aria-label={t('profile.title')}
            className="brand-gradient flex h-9 w-9 items-center justify-center rounded-full text-xs font-semibold text-white shadow-sm ring-offset-background hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            {initialsOf(user?.fullName ?? '')}
          </button>
        </header>

        <main className="min-w-0 flex-1">{children}</main>
      </div>

      {profileOpen && <ProfileDialog onClose={() => setProfileOpen(false)} />}
    </div>
  );
}
