import * as React from 'react';
import { downloadFile } from '@/lib/download';
import { useI18n } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/toast';

export interface ExportButtonProps {
  /** Путь выгрузки от api-клиента: `ordersApi.exportPath(filters)`. */
  path: string;
  label?: string;
  className?: string;
  disabled?: boolean;
  variant?: 'default' | 'outline' | 'ghost';
}

function DownloadIcon(): React.ReactElement {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      className="h-4 w-4"
    >
      <path d="M12 3v11" />
      <path d="m7.5 10 4.5 4.5 4.5-4.5" />
      <path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" />
    </svg>
  );
}

function Spinner(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden className="h-4 w-4 animate-spin">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" opacity="0.25" />
      <path
        d="M21 12a9 9 0 0 0-9-9"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

/**
 * Кнопка выгрузки в Excel.
 *
 * Занятость держится в самой кнопке, а не в мутации TanStack Query: выгрузка
 * ничего не меняет на сервере и не должна попадать в кэш — иначе повторный
 * клик отдал бы тот же blob вместо свежего файла по текущим фильтрам.
 * На время формирования кнопка блокируется: серверная сборка xlsx занимает
 * секунды, и второй клик по нетерпению стоил бы второго тяжёлого запроса.
 */
export function ExportButton({
  path,
  label,
  className,
  disabled,
  variant = 'outline',
}: ExportButtonProps): React.ReactElement {
  const { t } = useI18n();
  const toast = useToast();
  const [busy, setBusy] = React.useState(false);

  const run = async (): Promise<void> => {
    if (busy) return;
    setBusy(true);
    try {
      await downloadFile(path);
      toast.success(t('ui.export.done'));
    } catch (error) {
      // У ApiError в message уже лежит текст из конверта бэкенда.
      toast.error(t('ui.export.failed'), error instanceof Error ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Button
      type="button"
      variant={variant}
      className={cn('gap-2', className)}
      disabled={disabled === true || busy}
      aria-busy={busy}
      onClick={() => {
        void run();
      }}
    >
      {busy ? <Spinner /> : <DownloadIcon />}
      {busy ? t('ui.export.busy') : (label ?? t('ui.export.excel'))}
    </Button>
  );
}
