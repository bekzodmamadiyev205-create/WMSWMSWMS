import * as React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { PageContainer } from '@/components/ui/page-header';
import { Skeleton } from '@/components/ui/skeleton';
import { DashboardPage } from '@/pages/DashboardPage';
import { LoginPage } from '@/pages/LoginPage';

/**
 * Экраны грузятся по требованию.
 *
 * Одним куском бандл вырос до ~830 КБ: аналитика тянет графики, тарифы —
 * редакторы, матрица прав — свою таблицу, и всё это скачивал сборщик, которому
 * доступен один экран приёмки. На складском терминале это лишние секунды
 * ожидания при каждом холодном заходе.
 *
 * Не ленивые здесь только двое: логин (он и есть первый экран) и главная
 * (на неё попадают сразу после входа) — ленивая загрузка добавила бы им
 * лишний круг запроса ровно там, где его видно.
 */
const lazyPage = <T extends Record<string, unknown>, K extends keyof T & string>(
  loader: () => Promise<T>,
  name: K,
): React.LazyExoticComponent<React.ComponentType> =>
  React.lazy(() =>
    loader().then((module) => ({ default: module[name] as unknown as React.ComponentType })),
  );

const CatalogPage = lazyPage(() => import('@/pages/CatalogPage'), 'CatalogPage');
const SellersPage = lazyPage(() => import('@/pages/SellersPage'), 'SellersPage');
const InboundListPage = lazyPage(() => import('@/pages/InboundListPage'), 'InboundListPage');
const InboundReceiptPage = lazyPage(
  () => import('@/pages/InboundReceiptPage'),
  'InboundReceiptPage',
);
const StockPage = lazyPage(() => import('@/pages/StockPage'), 'StockPage');
const ReturnsPage = lazyPage(() => import('@/pages/ReturnsPage'), 'ReturnsPage');
const ReturnDetailPage = lazyPage(() => import('@/pages/ReturnDetailPage'), 'ReturnDetailPage');
const OrdersPage = lazyPage(() => import('@/pages/OrdersPage'), 'OrdersPage');
const OrderCreatePage = lazyPage(() => import('@/pages/OrderCreatePage'), 'OrderCreatePage');
const OrderDetailPage = lazyPage(() => import('@/pages/OrderDetailPage'), 'OrderDetailPage');
const PickingListPage = lazyPage(() => import('@/pages/PickingListPage'), 'PickingListPage');
const PickingTaskPage = lazyPage(() => import('@/pages/PickingTaskPage'), 'PickingTaskPage');
const PackingQueuePage = lazyPage(() => import('@/pages/PackingQueuePage'), 'PackingQueuePage');
const PackingStationPage = lazyPage(
  () => import('@/pages/PackingStationPage'),
  'PackingStationPage',
);
const OpsDashboardPage = lazyPage(() => import('@/pages/OpsDashboardPage'), 'OpsDashboardPage');
const AnalyticsPage = lazyPage(() => import('@/pages/AnalyticsPage'), 'AnalyticsPage');
const UsersPage = lazyPage(() => import('@/pages/UsersPage'), 'UsersPage');
const DepartmentsPage = lazyPage(() => import('@/pages/DepartmentsPage'), 'DepartmentsPage');
const OrderCategoriesPage = lazyPage(
  () => import('@/pages/OrderCategoriesPage'),
  'OrderCategoriesPage',
);
const FieldPermissionsPage = lazyPage(
  () => import('@/pages/FieldPermissionsPage'),
  'FieldPermissionsPage',
);
const TariffsPage = lazyPage(() => import('@/pages/TariffsPage'), 'TariffsPage');
const SellerPortalPage = lazyPage(() => import('@/pages/SellerPortalPage'), 'SellerPortalPage');

/**
 * Заглушка на время загрузки куска. Форма повторяет каркас страницы, а не
 * крутилку по центру: подмена скелетона на реальный экран не двигает вёрстку.
 */
function RouteFallback(): React.ReactElement {
  return (
    <PageContainer>
      <div className="space-y-2">
        <Skeleton className="h-7 w-56" />
        <Skeleton className="h-4 w-80" />
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[0, 1, 2, 3].map((index) => (
          <Skeleton key={index} className="h-24 w-full rounded-xl" />
        ))}
      </div>
      <Skeleton className="h-96 w-full rounded-xl" />
    </PageContainer>
  );
}

export function App(): React.ReactElement {
  return (
    <React.Suspense fallback={<RouteFallback />}>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route element={<ProtectedRoute />}>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/catalog" element={<CatalogPage />} />
          <Route path="/sellers" element={<SellersPage />} />
          <Route path="/inbound" element={<InboundListPage />} />
          <Route path="/inbound/:id" element={<InboundReceiptPage />} />
          <Route path="/stock" element={<StockPage />} />
          <Route path="/returns" element={<ReturnsPage />} />
          <Route path="/returns/:id" element={<ReturnDetailPage />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/orders/new" element={<OrderCreatePage />} />
          <Route path="/orders/:id" element={<OrderDetailPage />} />
          <Route path="/picking" element={<PickingListPage />} />
          <Route path="/picking/:id" element={<PickingTaskPage />} />
          <Route path="/packing" element={<PackingQueuePage />} />
          <Route path="/packing/:id" element={<PackingStationPage />} />
          <Route path="/dashboard" element={<OpsDashboardPage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
          <Route path="/users" element={<UsersPage />} />
          <Route path="/departments" element={<DepartmentsPage />} />
          <Route path="/order-categories" element={<OrderCategoriesPage />} />
          <Route path="/field-permissions" element={<FieldPermissionsPage />} />
          <Route path="/tariffs" element={<TariffsPage />} />
          <Route path="/seller" element={<SellerPortalPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </React.Suspense>
  );
}
