import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams } from 'react-router-dom';
import type {
  EffectiveFieldAclDto,
  OrderCategoryDto,
  OrderDto,
  OrderIntakeResultDto,
  UpdateOrderPayload,
} from '@ff/shared';
import { canEditField, canViewField } from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';
import { useI18n, type Language } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { cn } from '@/lib/utils';
import { Barcode } from '@/components/Barcode';
import { OrderStatusBadge, isOrderCancellable } from '@/components/OrderStatusBadge';
import { OrderTimeline } from '@/components/OrderTimeline';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ConfirmDialog, Dialog } from '@/components/ui/dialog';
import { InlineNumber, InlineSelect, InlineText } from '@/components/ui/inline-edit';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Skeleton, SkeletonText } from '@/components/ui/skeleton';
import { TBody, TD, TH, THead, TR, Table } from '@/components/ui/table';
import { useToast } from '@/components/ui/toast';

const LOCALE: Record<Language, string> = { ru: 'ru-RU', uz: 'uz-UZ', en: 'en-GB', zh: 'zh-CN' };

/* ────────────────────────────── права на колонки ─────────────────────────── */

interface FieldAcl {
  canView: (entity: string, field: string) => boolean;
  canEdit: (entity: string, field: string) => boolean;
}

/**
 * Права уровня поля для текущего пользователя.
 *
 * Пока матрица не приехала (или ручка недоступна) — разрешено всё: сервер и так
 * вырезает закрытые поля из ответа, а мигающая карточка, где половина строк
 * появляется через полсекунды, выглядит как поломка. Клиентская проверка здесь
 * — оформление, а не защита.
 */
function useFieldAcl(): FieldAcl {
  const query = useQuery({
    queryKey: ['field-permissions', 'effective'],
    queryFn: () => apiFetch<EffectiveFieldAclDto>('/field-permissions/effective'),
    staleTime: 5 * 60_000,
    retry: false,
  });

  return React.useMemo<FieldAcl>(() => {
    const data = query.data;
    if (!data || data.unrestricted) {
      return { canView: () => true, canEdit: () => true };
    }
    return {
      canView: (entity, field) => canViewField(data.acl, entity, field),
      canEdit: (entity, field) => canEditField(data.acl, entity, field),
    };
  }, [query.data]);
}

/* ─────────────────────────────────── мелочи ──────────────────────────────── */

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}): React.ReactElement {
  return (
    <div className={cn('min-w-0 space-y-1', className)}>
      <span className="block text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      <div className="text-sm text-foreground">{children}</div>
    </div>
  );
}

function ReadOnly({ value }: { value: React.ReactNode }): React.ReactElement {
  const empty = value === null || value === undefined || value === '';
  return <span className={empty ? 'text-muted-foreground' : undefined}>{empty ? '—' : value}</span>;
}

function Section({
  title,
  children,
  actions,
  className,
}: {
  title: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}): React.ReactElement {
  return (
    <section className={cn('premium-card p-4 sm:p-5', className)}>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-semibold tracking-tight text-foreground">{title}</h2>
        {actions}
      </div>
      {children}
    </section>
  );
}

function CategoryDot({ color }: { color: string | null }): React.ReactElement {
  return (
    <span
      aria-hidden="true"
      className="h-2 w-2 shrink-0 rounded-full ring-1 ring-inset ring-black/10"
      // Цвет метки — данные справочника, а не токен темы: его нельзя подменить палитрой.
      style={{ backgroundColor: color ?? 'hsl(var(--muted-foreground))' }}
    />
  );
}

/* ────────────────────────────────── действия ─────────────────────────────── */

interface ActionsProps {
  order: OrderDto;
  busy: boolean;
  onReserve: () => void;
  onDispatch: () => void;
  onCancel: () => void;
}

function OrderActions({ order, busy, onReserve, onDispatch, onCancel }: ActionsProps): React.ReactElement {
  const { t } = useI18n();

  const reserveAllowed =
    order.hasShortage || order.status === 'NEW' || order.status === 'VALIDATED' || order.status === 'RESERVED';
  const dispatchAllowed = order.status === 'READY_TO_SHIP';
  const cancelAllowed = isOrderCancellable(order.status);

  // Недоступное действие остаётся на экране заблокированным, а не исчезает:
  // пропавшая кнопка не отвечает на вопрос «почему нельзя выдать заказ».
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button
        variant="outline"
        size="sm"
        disabled={busy || !reserveAllowed}
        title={reserveAllowed ? undefined : t('orderDetail.reserveBlocked')}
        onClick={onReserve}
      >
        {t('orders.action.reserve')}
      </Button>
      <Button
        size="sm"
        disabled={busy || !dispatchAllowed}
        title={dispatchAllowed ? undefined : t('orderDetail.dispatchBlocked')}
        onClick={onDispatch}
      >
        {t('orders.action.dispatch')}
      </Button>
      <Button
        variant="ghost"
        size="sm"
        className="text-destructive hover:bg-destructive/10 hover:text-destructive"
        disabled={busy || !cancelAllowed}
        title={cancelAllowed ? undefined : t('orderDetail.cancelBlocked')}
        onClick={onCancel}
      >
        {t('orders.action.cancel')}
      </Button>
    </div>
  );
}

/* ──────────────────────────────────── карточка ───────────────────────────── */

export function OrderDetailView({
  id,
  compact = false,
}: {
  id: string;
  compact?: boolean;
}): React.ReactElement {
  const { t, language } = useI18n();
  const locale = LOCALE[language];
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const toast = useToast();
  const acl = useFieldAcl();

  const [dispatchOpen, setDispatchOpen] = React.useState(false);
  const [cancelOpen, setCancelOpen] = React.useState(false);
  const [cancelReason, setCancelReason] = React.useState('');

  const order = useQuery({
    queryKey: ['order', id],
    queryFn: () => apiFetch<OrderDto>(`/orders/${id}`),
    enabled: Boolean(id),
  });
  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const warehouses = useQuery({ queryKey: ['mdm', 'warehouses'], queryFn: mdmApi.warehouses });
  const categories = useQuery({
    queryKey: ['order-categories'],
    queryFn: () => apiFetch<OrderCategoryDto[]>('/order-categories'),
  });

  const settle = React.useCallback((): void => {
    void queryClient.invalidateQueries({ queryKey: ['order', id] });
    void queryClient.invalidateQueries({ queryKey: ['orders'] });
  }, [queryClient, id]);

  const update = useMutation({
    mutationFn: (payload: UpdateOrderPayload) =>
      apiFetch<OrderDto>(`/orders/${id}`, { method: 'PATCH', body: payload }),
    onSuccess: (next) => {
      // Ответ сервера кладём в кэш сразу: правка по месту не должна мигать
      // старым значением, пока идёт инвалидация.
      queryClient.setQueryData(['order', id], next);
      toast.success(t('orderDetail.saved'));
    },
    onError: (error) =>
      toast.error(t('orderDetail.saveFailed'), error instanceof ApiError ? error.message : undefined),
    onSettled: settle,
  });

  const reserve = useMutation({
    mutationFn: () => apiFetch<OrderIntakeResultDto>(`/orders/${id}/reserve`, { method: 'POST', body: {} }),
    onSuccess: (result) => {
      if (result.shortages.length > 0) toast.error(t('orders.toast.reserveShortage'));
      else toast.success(t('orders.toast.reserveOk'));
    },
    onError: (error) =>
      toast.error(t('orders.toast.reserveFailed'), error instanceof ApiError ? error.message : undefined),
    onSettled: settle,
  });

  const dispatchOrder = useMutation({
    mutationFn: () => apiFetch<OrderDto>(`/orders/${id}/dispatch`, { method: 'POST', body: {} }),
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ['order', id] });
      const previous = queryClient.getQueryData<OrderDto>(['order', id]);
      if (previous) {
        queryClient.setQueryData<OrderDto>(['order', id], {
          ...previous,
          status: 'DISPATCHED',
          dispatchedAt: new Date().toISOString(),
        });
      }
      return { previous };
    },
    onError: (error, _vars, context) => {
      if (context?.previous) queryClient.setQueryData(['order', id], context.previous);
      toast.error(t('orders.toast.dispatchFailed'), error instanceof ApiError ? error.message : undefined);
    },
    onSuccess: () => {
      toast.success(t('orders.toast.dispatchOk'));
      setDispatchOpen(false);
    },
    onSettled: settle,
  });

  const cancelOrder = useMutation({
    mutationFn: (reason: string) =>
      apiFetch<OrderDto>(`/orders/${id}/cancel`, { method: 'POST', body: { reason } }),
    onSuccess: () => {
      toast.success(t('orders.toast.cancelOk'));
      setCancelOpen(false);
      setCancelReason('');
    },
    onError: (error) =>
      toast.error(t('orders.toast.cancelFailed'), error instanceof ApiError ? error.message : undefined),
    onSettled: settle,
  });

  if (order.isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 w-full rounded-xl" />
        <Skeleton className="h-40 w-full rounded-xl" />
        <SkeletonText lines={5} />
      </div>
    );
  }

  const o = order.data;
  if (order.isError || !o) {
    return (
      <div className="premium-card flex flex-wrap items-center justify-between gap-3 p-4">
        <span className="text-sm text-destructive">{t('orderDetail.notFound')}</span>
        <Button variant="outline" size="sm" onClick={() => void order.refetch()}>
          {t('ui.retry')}
        </Button>
      </div>
    );
  }

  const busy = update.isPending || reserve.isPending || dispatchOrder.isPending || cancelOrder.isPending;
  const sellerCode = sellers.data?.find((seller) => seller.id === o.sellerId)?.code ?? o.sellerId;
  const warehouseCode = o.warehouseId
    ? (warehouses.data?.find((warehouse) => warehouse.id === o.warehouseId)?.code ?? o.warehouseId)
    : null;
  const category = categories.data?.find((item) => item.id === o.categoryId) ?? null;

  const categoryOptions = [
    { value: '', label: t('orderDetail.noCategory') },
    ...(categories.data ?? []).map((item) => ({ value: item.id, label: item.name })),
  ];

  const actions = (
    <OrderActions
      order={o}
      busy={busy}
      onReserve={() => reserve.mutate()}
      onDispatch={() => setDispatchOpen(true)}
      onCancel={() => {
        setCancelReason('');
        setCancelOpen(true);
      }}
    />
  );

  return (
    <div className="space-y-5">
      {compact ? null : (
        <PageHeader
          breadcrumbs={[
            { label: t('orders.title'), to: '/orders' },
            { label: o.orderCode },
          ]}
          title={<span className="font-mono tracking-wide">{o.orderCode}</span>}
          description={t('orderDetail.subtitle', { external: o.externalId, channel: o.channel })}
          actions={actions}
        />
      )}

      {/* Код + штрихкод + статус: то, ради чего карточку открывают у стола упаковки. */}
      <section className="premium-card flex flex-wrap items-center justify-between gap-4 p-4 sm:p-5">
        <div className="min-w-0 space-y-2">
          <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {t('order.ourCode')}
          </p>
          <p className="font-mono text-2xl font-bold tracking-wider text-foreground">{o.orderCode}</p>
          <div className="flex flex-wrap items-center gap-2">
            <OrderStatusBadge status={o.status} />
            {o.hasShortage ? (
              <Badge variant="destructive" size="sm">
                {t('orders.shortage')}
              </Badge>
            ) : null}
            {o.isSplit ? (
              <Badge variant="warning" size="sm">
                {t('orderDetail.splitNote', { n: o.children.length })}
              </Badge>
            ) : null}
          </div>
          <p className="text-xs text-muted-foreground">
            {t('order.clientNumber')}: <span className="tabular-nums">{o.externalId}</span>
          </p>
        </div>
        <Barcode value={o.orderCode} height={56} />
      </section>

      {compact ? <div className="flex justify-end">{actions}</div> : null}

      <OrderTimeline orderId={o.id} currentStatus={o.status} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Section title={t('orderDetail.recipientTitle')}>
          <div className="grid gap-4 sm:grid-cols-2">
            {acl.canView('order', 'recipientName') ? (
              <Field label={t('orderDetail.recipient')}>
                <InlineText
                  value={o.recipientName}
                  ariaLabel={t('orderDetail.recipient')}
                  disabled={!acl.canEdit('order', 'recipientName')}
                  emptyLabel="—"
                  onSubmit={async (next) => {
                    await update.mutateAsync({ recipientName: next });
                  }}
                />
              </Field>
            ) : null}

            {acl.canView('order', 'recipientPhone') ? (
              <Field label={t('orderDetail.phone')}>
                <InlineText
                  value={o.recipientPhone}
                  ariaLabel={t('orderDetail.phone')}
                  disabled={!acl.canEdit('order', 'recipientPhone')}
                  emptyLabel="—"
                  onSubmit={async (next) => {
                    await update.mutateAsync({ recipientPhone: next });
                  }}
                />
              </Field>
            ) : null}

            {acl.canView('order', 'address') ? (
              <Field label={t('orderDetail.address')} className="sm:col-span-2">
                <InlineText
                  value={o.address}
                  multiline
                  ariaLabel={t('orderDetail.address')}
                  disabled={!acl.canEdit('order', 'address')}
                  emptyLabel="—"
                  onSubmit={async (next) => {
                    await update.mutateAsync({ address: next });
                  }}
                />
              </Field>
            ) : null}

            {acl.canView('order', 'region') ? (
              <Field label={t('orderDetail.region')}>
                <InlineText
                  value={o.region ?? ''}
                  ariaLabel={t('orderDetail.region')}
                  disabled={!acl.canEdit('order', 'region')}
                  emptyLabel="—"
                  onSubmit={async (next) => {
                    await update.mutateAsync({ region: next || null });
                  }}
                />
              </Field>
            ) : null}

            {acl.canView('order', 'weightKg') ? (
              <Field label={t('orderDetail.weight')}>
                <InlineNumber
                  value={o.weightKg}
                  min={0}
                  step={0.001}
                  suffix={t('orderDetail.kg')}
                  ariaLabel={t('orderDetail.weight')}
                  disabled={!acl.canEdit('order', 'weightKg')}
                  emptyLabel="—"
                  onSubmit={async (next) => {
                    await update.mutateAsync({ weightKg: next || null });
                  }}
                />
              </Field>
            ) : null}
          </div>
        </Section>

        <Section title={t('orderDetail.moneyTitle')}>
          <div className="grid gap-4 sm:grid-cols-2">
            {acl.canView('order', 'codAmount') ? (
              <Field label={t('orderDetail.cod')}>
                <ReadOnly
                  value={
                    o.codAmount
                      ? `${new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(Number(o.codAmount))} ${o.currency ?? ''}`.trim()
                      : ''
                  }
                />
              </Field>
            ) : null}

            {acl.canView('order', 'categoryId') ? (
              <Field label={t('orderDetail.category')}>
                <span className="flex items-center gap-2">
                  <CategoryDot color={category?.color ?? o.categoryColor} />
                  <InlineSelect
                    value={o.categoryId ?? ''}
                    options={categoryOptions}
                    ariaLabel={t('orderDetail.category')}
                    disabled={!acl.canEdit('order', 'categoryId')}
                    emptyLabel={t('orderDetail.noCategory')}
                    onSubmit={async (next) => {
                      await update.mutateAsync({ categoryId: next || null });
                    }}
                  />
                </span>
              </Field>
            ) : null}

            {acl.canView('order', 'sellerId') ? (
              <Field label={t('orderDetail.seller')}>
                <ReadOnly value={sellerCode} />
              </Field>
            ) : null}

            {acl.canView('order', 'warehouseId') ? (
              <Field label={t('orderDetail.warehouse')}>
                <ReadOnly value={warehouseCode} />
              </Field>
            ) : null}

            {acl.canView('order', 'channel') ? (
              <Field label={t('orderDetail.channel')}>
                <ReadOnly value={o.channel} />
              </Field>
            ) : null}

            {acl.canView('order', 'createdAt') ? (
              <Field label={t('orderDetail.createdAt')}>
                <ReadOnly value={new Date(o.createdAt).toLocaleString(locale)} />
              </Field>
            ) : null}

            {acl.canView('order', 'dispatchedAt') ? (
              <Field label={t('orderDetail.dispatchedAt')}>
                <ReadOnly value={o.dispatchedAt ? new Date(o.dispatchedAt).toLocaleString(locale) : ''} />
              </Field>
            ) : null}
          </div>
        </Section>
      </div>

      {acl.canView('order', 'lines') ? (
        <Section title={t('orderDetail.linesTitle')}>
          <div className="overflow-x-auto">
            <Table>
              <THead>
                <tr>
                  <TH scope="col">{t('orderDetail.sku')}</TH>
                  <TH scope="col">{t('orderDetail.item')}</TH>
                  <TH scope="col" align="right">
                    {t('orderDetail.quantity')}
                  </TH>
                </tr>
              </THead>
              <TBody>
                {o.lines.map((line) => (
                  <TR key={line.id}>
                    <TD className="font-mono text-xs">{line.skuCode}</TD>
                    <TD>{line.skuName}</TD>
                    <TD align="right" className="tabular-nums">
                      {line.quantity}
                    </TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          </div>
        </Section>
      ) : null}

      {o.children.length > 0 ? (
        <Section title={t('orderDetail.splitParts')}>
          <ul className="divide-y divide-border">
            {o.children.map((child) => (
              <li key={child.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 first:pt-0 last:pb-0">
                <div className="min-w-0">
                  <button
                    type="button"
                    onClick={() => navigate(`/orders/${child.id}`)}
                    className="font-mono text-xs font-semibold text-primary underline-offset-2 hover:underline"
                  >
                    {child.orderCode}
                  </button>
                  <p className="mt-0.5 truncate text-xs text-muted-foreground">
                    {child.lines.map((line) => `${line.skuCode} × ${line.quantity}`).join(', ')}
                  </p>
                </div>
                <OrderStatusBadge status={child.status} size="sm" />
              </li>
            ))}
          </ul>
        </Section>
      ) : null}

      <ConfirmDialog
        open={dispatchOpen}
        onClose={() => setDispatchOpen(false)}
        onConfirm={() => dispatchOrder.mutate()}
        title={t('orders.dispatch.title')}
        description={t('orders.dispatch.description', { code: o.orderCode })}
        confirmLabel={t('orders.action.dispatch')}
        busy={dispatchOrder.isPending}
      />

      <Dialog
        open={cancelOpen}
        onClose={() => setCancelOpen(false)}
        title={t('orders.cancel.title')}
        description={t('orders.cancel.description', { code: o.orderCode })}
        size="sm"
        closeOnOverlay={!cancelOrder.isPending}
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              disabled={cancelOrder.isPending}
              onClick={() => setCancelOpen(false)}
            >
              {t('orders.cancel.keep')}
            </Button>
            <Button
              variant="destructive"
              size="sm"
              // Причина обязательна: отмену через неделю разбирают по журналу,
              // и пустое поле там ничего не объясняет.
              disabled={cancelOrder.isPending || cancelReason.trim().length < 3}
              onClick={() => cancelOrder.mutate(cancelReason.trim())}
            >
              {t('orders.action.cancel')}
            </Button>
          </>
        }
      >
        <div className="space-y-1.5">
          <Label htmlFor="order-cancel-reason">{t('orders.cancel.reason')}</Label>
          <Input
            id="order-cancel-reason"
            autoFocus
            value={cancelReason}
            placeholder={t('orders.cancel.reasonPlaceholder')}
            onChange={(event) => setCancelReason(event.target.value)}
          />
          <p className="text-xs text-muted-foreground">{t('orders.cancel.reasonHint')}</p>
        </div>
      </Dialog>
    </div>
  );
}

/**
 * Модалка карточки заказа: открывается поверх списка, не теряя фильтров и
 * страницы. Тот же контент, что и на /orders/:id, — второй вёрстки нет.
 */
export function OrderDetailModal({ id, onClose }: { id: string; onClose: () => void }): React.ReactElement {
  const { t } = useI18n();
  return (
    <Dialog open onClose={onClose} title={t('orderDetail.cardTitle')} size="xl">
      <OrderDetailView id={id} compact />
    </Dialog>
  );
}

/** Страница карточки заказа — прямой переход по адресу /orders/:id. */
export function OrderDetailPage(): React.ReactElement {
  const { id = '' } = useParams();
  return (
    <PageContainer>
      <OrderDetailView id={id} />
    </PageContainer>
  );
}
