import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ORDER_CATEGORY_COLORS,
  type CreateOrderCategoryPayload,
  type OrderCategoryDto,
  type UpdateOrderCategoryPayload,
} from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { DataTable, type DataTableColumn, type DataTableSort } from '@/components/ui/data-table';
import { ConfirmDialog, Dialog } from '@/components/ui/dialog';
import { InlineNumber, InlineText } from '@/components/ui/inline-edit';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Pagination } from '@/components/ui/pagination';
import { Popover } from '@/components/ui/popover';
import { Select } from '@/components/ui/select';
import { useToast } from '@/components/ui/toast';
import { Toolbar, ToolbarGroup, ToolbarSearch, ToolbarSpacer } from '@/components/ui/toolbar';

/**
 * Клиент справочника живёт здесь, а не в `lib/`: у страницы ровно четыре ручки,
 * и ни один другой экран их не зовёт — выносить ради этого отдельный модуль
 * значит завести файл, который никогда не откроют.
 */
const orderCategoriesApi = {
  list: (): Promise<OrderCategoryDto[]> =>
    apiFetch<OrderCategoryDto[]>('/order-categories?includeInactive=true'),

  create: (payload: CreateOrderCategoryPayload): Promise<OrderCategoryDto> =>
    apiFetch<OrderCategoryDto>('/order-categories', { method: 'POST', body: payload }),

  update: (id: string, payload: UpdateOrderCategoryPayload): Promise<OrderCategoryDto> =>
    apiFetch<OrderCategoryDto>(`/order-categories/${id}`, { method: 'PATCH', body: payload }),

  remove: (id: string): Promise<{ deleted: boolean }> =>
    apiFetch<{ deleted: boolean }>(`/order-categories/${id}`, { method: 'DELETE' }),
};

const QUERY_KEY = ['order-categories'] as const;

/** Код — машинный ключ выгрузок, поэтому набор символов узкий и проверяется до отправки. */
const CODE_PATTERN = /^[A-Z][A-Z0-9_]*$/;

const FALLBACK_COLOR: string = ORDER_CATEGORY_COLORS[0];

/** То же умолчание, что и на сервере: справочник должен сортироваться одинаково. */
const DEFAULT_SORT_ORDER = 100;

type StateFilter = 'all' | 'active' | 'inactive';

interface UpdateVars {
  id: string;
  patch: UpdateOrderCategoryPayload;
  /** Своя формулировка успеха: «отключено» и «сохранено» — разные события для человека. */
  successText?: string;
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function isStatus(error: unknown, status: number): boolean {
  return error instanceof ApiError && error.status === status;
}

/* ─────────────────────────────── мелкие детали ──────────────────────────── */

function TagsIcon(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M7 7h.01" />
      <path d="M12.5 3H7a4 4 0 0 0-4 4v5.5a2 2 0 0 0 .6 1.4l7 7a2 2 0 0 0 2.8 0l5.5-5.5a2 2 0 0 0 0-2.8l-7-7A2 2 0 0 0 12.5 3Z" />
    </svg>
  );
}

function LightbulbIcon(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className="h-4 w-4">
      <path d="M9 18h6" />
      <path d="M10 21h4" />
      <path d="M12 3a6 6 0 0 0-3.5 10.9c.5.4.8 1 .9 1.6h5.2c.1-.6.4-1.2.9-1.6A6 6 0 0 0 12 3Z" />
    </svg>
  );
}

function LockIcon(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className="h-5 w-5">
      <rect x="4" y="10" width="16" height="10" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </svg>
  );
}

function TrashIcon(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className="h-3.5 w-3.5">
      <path d="M4 7h16M10 11v6M14 11v6" />
      <path d="M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12" />
      <path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2" />
    </svg>
  );
}

function Switch({
  checked,
  onChange,
  label,
  disabled = false,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  disabled?: boolean;
}): React.ReactElement {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        'relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        'disabled:cursor-not-allowed disabled:opacity-50',
        checked ? 'bg-success' : 'bg-muted ring-1 ring-inset ring-border',
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          'inline-block h-3.5 w-3.5 rounded-full bg-background shadow ring-1 ring-border transition-transform',
          checked ? 'translate-x-[1.15rem]' : 'translate-x-[0.15rem]',
        )}
      />
    </button>
  );
}

/**
 * Выбор цвета метки. Значения — реальные hex'ы из справочника: это данные
 * категории, а не оформление интерфейса, поэтому они и живут в инлайновом
 * стиле, а не в токене темы.
 */
function ColorPicker({
  color,
  label,
  onPick,
  openUp = false,
}: {
  color: string | null;
  label: string;
  onPick: (next: string) => void;
  /**
   * Раскрывать вверх. Панель абсолютная, а таблица и тело диалога — контейнеры
   * со скроллом: у нижних строк выпадение вниз упирается в их край. Направление
   * выбирает вызывающий код — он один знает, где строка находится в списке.
   */
  openUp?: boolean;
}): React.ReactElement {
  const { t } = useI18n();
  const current = color ?? FALLBACK_COLOR;

  return (
    <Popover
      align="start"
      triggerClassName="h-7 w-7 rounded-md hover:bg-accent"
      contentClassName={cn('w-56', openUp && 'bottom-full mb-2 mt-0')}
      trigger={
        <>
          <span
            aria-hidden="true"
            className="h-4 w-4 rounded-full ring-1 ring-inset ring-border"
            style={{ backgroundColor: current }}
          />
          <span className="sr-only">{label}</span>
        </>
      }
    >
      {(close) => (
        <div className="space-y-3">
          <p className="text-xs font-medium text-muted-foreground">{t('categories.colorPick')}</p>
          <div className="grid grid-cols-4 gap-2">
            {ORDER_CATEGORY_COLORS.map((swatch) => (
              <button
                key={swatch}
                type="button"
                aria-label={swatch}
                aria-pressed={current === swatch}
                onClick={() => {
                  onPick(swatch);
                  close();
                }}
                className={cn(
                  'h-7 w-7 rounded-md ring-1 ring-inset ring-border transition-transform',
                  'hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                  current === swatch && 'ring-2 ring-foreground',
                )}
                style={{ backgroundColor: swatch }}
              />
            ))}
          </div>
          <label className="flex items-center gap-2 text-xs text-muted-foreground">
            <input
              type="color"
              value={current}
              onChange={(event) => onPick(event.target.value)}
              className="h-7 w-10 cursor-pointer rounded border border-input bg-background p-0.5"
            />
            {t('categories.colorCustom')}
          </label>
        </div>
      )}
    </Popover>
  );
}

function ForbiddenCard({ title, body }: { title: string; body: string }): React.ReactElement {
  return (
    <Card className="border-warning/40 bg-warning/5">
      <CardContent className="flex items-start gap-3 p-5">
        <span className="mt-0.5 shrink-0 text-warning">
          <LockIcon />
        </span>
        <div className="space-y-1">
          <p className="text-sm font-medium text-foreground">{title}</p>
          <p className="text-sm leading-relaxed text-muted-foreground">{body}</p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ──────────────────────────────── создание ──────────────────────────────── */

interface CategoryDraft {
  code: string;
  name: string;
  description: string;
  color: string;
  sortOrder: string;
}

const EMPTY_DRAFT: CategoryDraft = {
  code: '',
  name: '',
  description: '',
  color: FALLBACK_COLOR,
  sortOrder: String(DEFAULT_SORT_ORDER),
};

function CreateCategoryDialog({
  open,
  onClose,
  busy,
  onSubmit,
}: {
  open: boolean;
  onClose: () => void;
  busy: boolean;
  onSubmit: (payload: CreateOrderCategoryPayload) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [draft, setDraft] = React.useState<CategoryDraft>(EMPTY_DRAFT);
  const codeId = React.useId();
  const nameId = React.useId();
  const descriptionId = React.useId();
  const sortId = React.useId();

  React.useEffect(() => {
    if (open) setDraft(EMPTY_DRAFT);
  }, [open]);

  const codeValid = CODE_PATTERN.test(draft.code);
  const nameValid = draft.name.trim().length > 0;
  const canSubmit = codeValid && nameValid && !busy;

  const submit = (): void => {
    if (!canSubmit) return;
    const raw = draft.sortOrder.trim().replace(',', '.');
    const sortOrder = Number(raw);
    onSubmit({
      code: draft.code,
      name: draft.name.trim(),
      description: draft.description.trim() || null,
      color: draft.color,
      // Пустое поле — это «не задавал», а не ноль: серверное умолчание честнее.
      sortOrder: raw !== '' && Number.isFinite(sortOrder) ? sortOrder : DEFAULT_SORT_ORDER,
    });
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={t('categories.create.title')}
      description={t('categories.hint.reporting')}
      size="md"
      closeOnOverlay={!busy}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={busy}>
            {t('ui.cancel')}
          </Button>
          <Button size="sm" onClick={submit} disabled={!canSubmit} className="gap-2">
            {busy ? (
              <span aria-hidden className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" />
            ) : null}
            {t('common.create')}
          </Button>
        </>
      }
    >
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <div className="space-y-1.5">
          <Label htmlFor={codeId}>{t('categories.code')}</Label>
          <Input
            id={codeId}
            value={draft.code}
            autoFocus
            spellCheck={false}
            autoComplete="off"
            aria-invalid={draft.code !== '' && !codeValid}
            aria-describedby={`${codeId}-hint`}
            placeholder="MARKETPLACE"
            // Верхний регистр наводится сразу при вводе: сервер всё равно приведёт
            // код к нему, и поле не должно показывать не то, что уедет в базу.
            onChange={(event) => setDraft((prev) => ({ ...prev, code: event.target.value.toUpperCase() }))}
            className="font-mono uppercase"
          />
          <p
            id={`${codeId}-hint`}
            className={cn(
              'text-xs leading-relaxed',
              draft.code === '' ? 'text-muted-foreground' : codeValid ? 'text-success' : 'text-destructive',
            )}
          >
            {draft.code === ''
              ? t('categories.create.codeHint')
              : codeValid
                ? t('categories.create.codeOk')
                : t('categories.create.codeInvalid')}
          </p>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor={nameId}>{t('categories.name')}</Label>
          <Input
            id={nameId}
            value={draft.name}
            placeholder={t('categories.create.namePlaceholder')}
            onChange={(event) => setDraft((prev) => ({ ...prev, name: event.target.value }))}
          />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor={descriptionId}>{t('categories.description')}</Label>
          <textarea
            id={descriptionId}
            rows={2}
            value={draft.description}
            placeholder={t('categories.create.descriptionPlaceholder')}
            onChange={(event) => setDraft((prev) => ({ ...prev, description: event.target.value }))}
            className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          />
        </div>

        <div className="flex flex-wrap items-end gap-4">
          <div className="space-y-1.5">
            <Label>{t('categories.color')}</Label>
            <div className="flex h-10 items-center">
              <ColorPicker
                color={draft.color}
                label={t('categories.colorPick')}
                openUp
                onPick={(next) => setDraft((prev) => ({ ...prev, color: next }))}
              />
            </div>
          </div>

          <div className="min-w-[8rem] flex-1 space-y-1.5">
            <Label htmlFor={sortId}>{t('categories.sortOrder')}</Label>
            <Input
              id={sortId}
              value={draft.sortOrder}
              inputMode="numeric"
              onChange={(event) => setDraft((prev) => ({ ...prev, sortOrder: event.target.value }))}
            />
            <p className="text-xs text-muted-foreground">{t('categories.sortHint')}</p>
          </div>
        </div>
      </form>
    </Dialog>
  );
}

/* ──────────────────────────────── страница ──────────────────────────────── */

function compareCategories(a: OrderCategoryDto, b: OrderCategoryDto, key: string): number {
  switch (key) {
    case 'code':
      return a.code.localeCompare(b.code);
    case 'name':
      return a.name.localeCompare(b.name);
    case 'sortOrder':
      return a.sortOrder - b.sortOrder;
    case 'ordersCount':
      return (a.ordersCount ?? 0) - (b.ordersCount ?? 0);
    case 'isActive':
      return Number(a.isActive) - Number(b.isActive);
    default:
      return 0;
  }
}

export function OrderCategoriesPage(): React.ReactElement {
  const { t } = useI18n();
  const toast = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const [search, setSearch] = React.useState('');
  const [stateFilter, setStateFilter] = React.useState<StateFilter>('all');
  const [sort, setSort] = React.useState<DataTableSort | null>(null);
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(20);
  const [createOpen, setCreateOpen] = React.useState(false);
  const [deleting, setDeleting] = React.useState<OrderCategoryDto | null>(null);

  const categories = useQuery({
    queryKey: [...QUERY_KEY, 'all'],
    queryFn: orderCategoriesApi.list,
    retry: (attempt, error) => !isStatus(error, 403) && attempt < 2,
  });

  const invalidate = React.useCallback((): void => {
    void queryClient.invalidateQueries({ queryKey: QUERY_KEY });
  }, [queryClient]);

  /** Оптимистичная правка всех кэшей справочника + снимок для отката. */
  const patchCaches = React.useCallback(
    async (id: string, patch: UpdateOrderCategoryPayload) => {
      await queryClient.cancelQueries({ queryKey: QUERY_KEY });
      const previous = queryClient.getQueriesData<OrderCategoryDto[]>({ queryKey: QUERY_KEY });
      queryClient.setQueriesData<OrderCategoryDto[]>({ queryKey: QUERY_KEY }, (rows) =>
        rows?.map((row) => (row.id === id ? { ...row, ...patch } : row)),
      );
      return { previous };
    },
    [queryClient],
  );

  const update = useMutation({
    mutationFn: (vars: UpdateVars) => orderCategoriesApi.update(vars.id, vars.patch),
    onMutate: (vars) => patchCaches(vars.id, vars.patch),
    onSuccess: (_data, vars) => toast.success(vars.successText ?? t('categories.saved')),
    onError: (error, _vars, context) => {
      for (const [key, data] of context?.previous ?? []) queryClient.setQueryData(key, data);
      toast.error(t('categories.saveFailed'), errorText(error));
    },
    onSettled: invalidate,
  });

  const create = useMutation({
    mutationFn: (payload: CreateOrderCategoryPayload) => orderCategoriesApi.create(payload),
    onSuccess: (created) => {
      setCreateOpen(false);
      toast.success(t('categories.created', { name: created.name }));
    },
    onError: (error) => toast.error(t('categories.createFailed'), errorText(error)),
    onSettled: invalidate,
  });

  const remove = useMutation({
    mutationFn: (id: string) => orderCategoriesApi.remove(id),
    onSuccess: () => toast.success(t('categories.deleted')),
    onError: (error, id) => {
      // 409 — это не сбой, а ответ по существу: категория уже стоит в заказах.
      // Гасить его нельзя, поэтому показываем текст сервера и сразу предлагаем
      // единственное осмысленное действие вместо удаления.
      if (isStatus(error, 409)) {
        toast.toast({
          title: t('categories.deleteFailed'),
          description: errorText(error),
          variant: 'error',
          duration: 0,
          action: {
            label: t('categories.disableInstead'),
            onClick: () =>
              update.mutate({
                id,
                patch: { isActive: false },
                successText: t('categories.disabled'),
              }),
          },
        });
        return;
      }
      toast.error(t('categories.deleteFailed'), errorText(error));
    },
    onSettled: () => {
      setDeleting(null);
      invalidate();
    },
  });

  const rows = categories.data ?? [];

  /**
   * Справочник приходит одним ответом целиком (пагинации у ручки нет вовсе),
   * поэтому поиск, сортировка и разбивка на страницы здесь ничего не скрывают:
   * они работают над полным набором, а не над куском, присланным сервером.
   */
  const filtered = React.useMemo(() => {
    const needle = search.trim().toLowerCase();
    return rows.filter((row) => {
      if (stateFilter === 'active' && !row.isActive) return false;
      if (stateFilter === 'inactive' && row.isActive) return false;
      if (!needle) return true;
      return (
        row.code.toLowerCase().includes(needle) ||
        row.name.toLowerCase().includes(needle) ||
        (row.description ?? '').toLowerCase().includes(needle)
      );
    });
  }, [rows, search, stateFilter]);

  const sorted = React.useMemo(() => {
    if (!sort) return filtered;
    const factor = sort.direction === 'asc' ? 1 : -1;
    return [...filtered].sort((a, b) => compareCategories(a, b, sort.key) * factor);
  }, [filtered, sort]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
  const currentPage = Math.min(page, pageCount);
  const pageRows = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const activeCount = rows.filter((row) => row.isActive).length;
  const busyRow = update.isPending || remove.isPending;

  const columns: Array<DataTableColumn<OrderCategoryDto>> = [
    {
      key: 'color',
      header: t('categories.color'),
      width: '4rem',
      align: 'center',
      cell: (row, index) => (
        <div className="flex justify-center">
          <ColorPicker
            color={row.color}
            label={t('categories.colorAria', { name: row.name })}
            openUp={index >= pageRows.length / 2}
            onPick={(next) => update.mutate({ id: row.id, patch: { color: next } })}
          />
        </div>
      ),
    },
    {
      key: 'code',
      header: t('categories.code'),
      sortable: true,
      width: '11rem',
      cell: (row) => (
        <span className="font-mono text-xs font-medium text-foreground" title={t('categories.codeImmutable')}>
          {row.code}
        </span>
      ),
    },
    {
      key: 'name',
      header: t('categories.name'),
      sortable: true,
      width: '16rem',
      cell: (row) => (
        <InlineText
          value={row.name}
          ariaLabel={t('categories.name')}
          onSubmit={async (next) => {
            const name = next.trim();
            if (!name) throw new Error(t('categories.nameRequired'));
            await update.mutateAsync({ id: row.id, patch: { name } });
          }}
        />
      ),
    },
    {
      key: 'description',
      header: t('categories.description'),
      hideable: true,
      cell: (row) => (
        <InlineText
          value={row.description ?? ''}
          multiline
          ariaLabel={t('categories.description')}
          placeholder={t('categories.create.descriptionPlaceholder')}
          onSubmit={async (next) => {
            await update.mutateAsync({ id: row.id, patch: { description: next.trim() || null } });
          }}
        />
      ),
    },
    {
      key: 'sortOrder',
      header: t('categories.sortOrder'),
      sortable: true,
      align: 'right',
      width: '7rem',
      hideable: true,
      cell: (row) => (
        <InlineNumber
          value={row.sortOrder}
          min={0}
          max={9999}
          ariaLabel={t('categories.sortOrder')}
          onSubmit={async (next) => {
            // Пустое поле InlineNumber пропускает как «нет значения»; для порядка
            // это молча означало бы 0 и переставило бы категорию в начало списка.
            const value = Number(next);
            if (next === '' || !Number.isFinite(value)) throw new Error(t('categories.sortRequired'));
            await update.mutateAsync({ id: row.id, patch: { sortOrder: value } });
          }}
        />
      ),
    },
    {
      key: 'ordersCount',
      header: t('categories.ordersCount'),
      sortable: true,
      align: 'right',
      width: '7rem',
      hideable: true,
      cell: (row) => (
        <Badge variant={row.ordersCount ? 'secondary' : 'muted'} size="sm">
          {row.ordersCount ?? 0}
        </Badge>
      ),
    },
    {
      key: 'isActive',
      header: t('categories.isActive'),
      sortable: true,
      align: 'center',
      width: '7rem',
      cell: (row) => (
        <div className="flex justify-center">
          <Switch
            checked={row.isActive}
            label={t('categories.activeAria', { name: row.name })}
            onChange={(next) =>
              update.mutate({
                id: row.id,
                patch: { isActive: next },
                successText: next ? t('categories.saved') : t('categories.disabled'),
              })
            }
          />
        </div>
      ),
    },
    {
      key: 'actions',
      header: <span className="sr-only">{t('categories.actions')}</span>,
      align: 'right',
      width: '5rem',
      cell: (row) => (
        <Button
          variant="ghost"
          size="sm"
          className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
          aria-label={`${t('ui.delete')}: ${row.name}`}
          title={t('ui.delete')}
          disabled={busyRow}
          onClick={() => setDeleting(row)}
        >
          <TrashIcon />
        </Button>
      ),
    },
  ];

  const forbidden = isStatus(categories.error, 403) || (user !== null && !user.roles.includes('ADMIN'));

  return (
    <PageContainer>
      <PageHeader
        icon={<TagsIcon />}
        title={t('categories.title')}
        description={
          forbidden
            ? t('categories.subtitle')
            : t('categories.summary', { total: rows.length, active: activeCount })
        }
        actions={
          forbidden ? null : (
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              {t('categories.add')}
            </Button>
          )
        }
      />

      {forbidden ? (
        <ForbiddenCard title={t('categories.forbidden.title')} body={t('categories.forbidden.body')} />
      ) : (
        <>
          <Card className="border-info/30 bg-info/5">
            <CardContent className="flex items-start gap-3 p-4">
              <span className="mt-0.5 shrink-0 text-info">
                <LightbulbIcon />
              </span>
              <div className="space-y-1">
                <p className="text-sm font-medium text-foreground">{t('categories.hint.title')}</p>
                <p className="text-sm leading-relaxed text-muted-foreground">{t('categories.hint.body')}</p>
                <p className="text-xs leading-relaxed text-muted-foreground">{t('categories.hint.reporting')}</p>
              </div>
            </CardContent>
          </Card>

          {categories.isError && !forbidden ? (
            <Card>
              <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                <span className="text-sm text-destructive">{t('categories.loadError')}</span>
                <Button variant="outline" size="sm" onClick={() => void categories.refetch()}>
                  {t('ui.retry')}
                </Button>
              </CardContent>
            </Card>
          ) : null}

          <DataTable<OrderCategoryDto>
            columns={columns}
            rows={pageRows}
            getRowKey={(row) => row.id}
            loading={categories.isLoading}
            sort={sort}
            onSortChange={(next) => {
              setSort(next);
              setPage(1);
            }}
            columnVisibility
            emptyTitle={search || stateFilter !== 'all' ? t('categories.nothingFound') : t('categories.empty.title')}
            emptyDescription={
              search || stateFilter !== 'all' ? t('categories.nothingFoundHint') : t('categories.empty.hint')
            }
            emptyAction={
              search || stateFilter !== 'all' ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSearch('');
                    setStateFilter('all');
                    setPage(1);
                  }}
                >
                  {t('ui.reset')}
                </Button>
              ) : (
                <Button size="sm" onClick={() => setCreateOpen(true)}>
                  {t('categories.add')}
                </Button>
              )
            }
            toolbar={
              <Toolbar>
                <ToolbarGroup className="w-full sm:w-64">
                  <ToolbarSearch
                    value={search}
                    onChange={(next) => {
                      setSearch(next);
                      setPage(1);
                    }}
                    placeholder={t('categories.searchPlaceholder')}
                  />
                </ToolbarGroup>
                <ToolbarGroup label={t('categories.filter.status')}>
                  <Select
                    value={stateFilter}
                    onChange={(event) => {
                      setStateFilter(event.target.value as StateFilter);
                      setPage(1);
                    }}
                    className="h-9 w-auto py-0 text-sm"
                  >
                    <option value="all">{t('ui.all')}</option>
                    <option value="active">{t('categories.filter.active')}</option>
                    <option value="inactive">{t('categories.filter.inactive')}</option>
                  </Select>
                </ToolbarGroup>
                <ToolbarSpacer />
              </Toolbar>
            }
            footer={
              <Pagination
                page={currentPage}
                pageSize={pageSize}
                total={sorted.length}
                onPageChange={setPage}
                onPageSizeChange={(size) => {
                  setPageSize(size);
                  setPage(1);
                }}
              />
            }
          />
        </>
      )}

      <CreateCategoryDialog
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        busy={create.isPending}
        onSubmit={(payload) => create.mutate(payload)}
      />

      <ConfirmDialog
        open={deleting !== null}
        onClose={() => setDeleting(null)}
        onConfirm={() => {
          if (deleting) remove.mutate(deleting.id);
        }}
        busy={remove.isPending}
        danger
        title={t('categories.delete.title')}
        description={t('categories.delete.body', { name: deleting?.name ?? '' })}
        confirmLabel={t('ui.delete')}
      />
    </PageContainer>
  );
}
