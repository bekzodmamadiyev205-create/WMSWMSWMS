import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  INVENTORY_UNIT_STATUSES,
  STOCK_SORT_FIELDS,
  type InventoryUnitStatus,
  type PageDto,
  type StockBinRowDto,
  type StockSortField,
  type StockTableQuery,
  type StockTableRowDto,
  type StockTableTotalsDto,
} from '@ff/shared';
import { useFieldAcl } from '@/lib/acl';
import { inventoryApi } from '@/lib/inventory';
import { mdmApi } from '@/lib/mdm';
import { useUrlFilters } from '@/lib/use-url-filters';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { formatRangeLabel, rangeToQuery, type DateRange } from '@/lib/date-range';
import { ExportButton } from '@/components/ExportButton';
import { Icon } from '@/components/icons';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { DataTable, type DataTableColumn, type DataTableSort } from '@/components/ui/data-table';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { KpiCard, KpiGrid } from '@/components/ui/kpi-card';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Pagination } from '@/components/ui/pagination';
import { Popover } from '@/components/ui/popover';
import { SearchableSelect, type SearchableOption } from '@/components/ui/searchable-select';
import { Select } from '@/components/ui/select';
import {
  FilterChip,
  Toolbar,
  ToolbarGroup,
  ToolbarSearch,
  ToolbarSpacer,
} from '@/components/ui/toolbar';

/**
 * «Остатки склада» — витрина товара глазами кладовщика.
 *
 * Строка витрины — срез SKU × склад × статус, а не «товар»: доступное к продаже
 * и лежащее в браке это разные числа, и складывать их в одну ячейку значит
 * врать. Фильтрует, сортирует и листает сервер; клиентский фильтр поверх
 * выданной страницы показывал бы «ничего не найдено» там, где строки просто
 * лежат на следующей странице.
 */

// -------------------------------------------------------------- состояние фильтров

/**
 * Тип-алиас, а не интерфейс: `useUrlFilters` требует совместимости с
 * `Record<string, string>`, а неявная индексная сигнатура есть только у
 * алиасов. Значения все строковые — они живут в адресной строке.
 */
type StockFilters = {
  sellerId: string;
  warehouseId: string;
  status: string;
  search: string;
  dateFrom: string;
  dateTo: string;
  sort: StockSortField;
  direction: 'asc' | 'desc';
  page: string;
  pageSize: string;
};

const DEFAULT_FILTERS: StockFilters = {
  sellerId: '',
  warehouseId: '',
  status: '',
  search: '',
  dateFrom: '',
  dateTo: '',
  sort: 'skuCode',
  direction: 'asc',
  page: '1',
  pageSize: '50',
};

/** Задержка перед тем, как ввод поиска попадёт в ключ запроса. */
const SEARCH_DEBOUNCE_MS = 300;

/**
 * Значения приезжают из адресной строки, а её правят руками и присылают
 * ссылками. Поэтому всё, что уходит на сервер, сверяется со списком
 * допустимых, а не приводится типом: `?sort=drop%20table` должен превратиться
 * в сортировку по умолчанию, а не в 400 на каждом открытии страницы.
 */
function toSortField(key: string): StockSortField | null {
  return (STOCK_SORT_FIELDS as readonly string[]).includes(key) ? (key as StockSortField) : null;
}

function toStatus(value: string): InventoryUnitStatus | null {
  return (INVENTORY_UNIT_STATUSES as readonly string[]).includes(value)
    ? (value as InventoryUnitStatus)
    : null;
}

/**
 * Цвет статуса задаётся таблицей, а не выводится из имени: смысл «брак —
 * красный, карантин — жёлтый» знает только предметная область. Плюс Tailwind
 * вырезает классы, которых не видит в исходнике целиком.
 */
const STATUS_TONE: Record<
  InventoryUnitStatus,
  'success' | 'info' | 'warning' | 'destructive' | 'secondary' | 'muted'
> = {
  EXPECTED: 'muted',
  RECEIVED: 'secondary',
  INSPECTED: 'secondary',
  AVAILABLE: 'success',
  RESERVED: 'info',
  PICKED: 'info',
  PACKED: 'info',
  SHIPPED: 'muted',
  DAMAGED: 'destructive',
  QUARANTINE: 'warning',
};

/** Сколько ячеек показывается в строке до того, как хвост уедет в поповер. */
const BINS_INLINE = 3;

// -------------------------------------------------------------------- ячейки строк

function BinBadge({ bin, label }: { bin: StockBinRowDto; label: string }): React.ReactElement {
  return (
    <Badge variant="outline" size="sm" title={label} className="font-mono">
      {bin.binCode}
      <span className="text-muted-foreground">×</span>
      <span className="tabular-nums">{bin.quantity}</span>
    </Badge>
  );
}

/**
 * Раскладка по ячейкам прямо в строке. Вопрос кладовщика звучит не «сколько
 * всего», а «где взять» — ответ обязан быть виден без клика. Хвост прячется
 * только чтобы строка с двадцатью ячейками не растянула таблицу.
 */
function BinsCell({ bins }: { bins: StockBinRowDto[] }): React.ReactElement {
  const { t } = useI18n();

  if (bins.length === 0) return <span className="text-muted-foreground">—</span>;

  const head = bins.slice(0, BINS_INLINE);
  const rest = bins.length - head.length;
  const binLabel = (bin: StockBinRowDto): string =>
    `${bin.binCode} · ${t(`stock.binStatus.${bin.status}` as MessageKey)} · ${bin.quantity}`;

  return (
    <div className="flex flex-wrap items-center gap-1">
      {head.map((bin) => (
        <BinBadge key={`${bin.binId}:${bin.status}`} bin={bin} label={binLabel(bin)} />
      ))}

      {rest > 0 ? (
        <Popover
          align="end"
          trigger={<span className="tabular-nums">+{rest}</span>}
          triggerClassName="h-[22px] rounded-md border border-border bg-muted px-1.5 text-[11px] font-medium text-muted-foreground hover:bg-accent hover:text-foreground"
          contentClassName="w-64"
        >
          <p className="mb-2 text-xs font-medium text-foreground">{t('stock.bins.title')}</p>
          <ul className="max-h-64 space-y-1 overflow-auto">
            {bins.map((bin) => (
              <li
                key={`${bin.binId}:${bin.status}`}
                className="flex items-baseline justify-between gap-2 rounded-md border border-border/60 px-2 py-1 text-xs"
              >
                <span className="font-mono">{bin.binCode}</span>
                <span className="truncate text-muted-foreground">
                  {t(`stock.binStatus.${bin.status}` as MessageKey)}
                </span>
                <span className="font-medium tabular-nums">{bin.quantity}</span>
              </li>
            ))}
          </ul>
        </Popover>
      ) : null}
    </div>
  );
}

/**
 * Количественный остаток складывается из нескольких поставок, поэтому дат две.
 * Главная — последний приход (когда пополняли), первая уходит вниз серой
 * строкой: она отвечает на другой вопрос — сколько уже лежит самый старый товар.
 */
function ReceivedCell({
  row,
  format,
}: {
  row: StockTableRowDto;
  format: (iso: string | null) => string;
}): React.ReactElement {
  const { t } = useI18n();
  const showFirst = row.firstReceivedAt !== null && row.firstReceivedAt !== row.lastReceivedAt;

  return (
    <div className="min-w-0" title={t('stock.received.hint')}>
      <div className="tabular-nums">{format(row.lastReceivedAt)}</div>
      {showFirst ? (
        <div className="text-xs tabular-nums text-muted-foreground">
          {t('stock.received.first', { date: format(row.firstReceivedAt) })}
        </div>
      ) : null}
    </div>
  );
}

// -------------------------------------------------------------------------- экран

export function StockPage(): React.ReactElement {
  const { t, language } = useI18n();
  const { canView } = useFieldAcl();
  const { values: filters, set, reset } = useUrlFilters<StockFilters>(DEFAULT_FILTERS);

  // Всё, что уходит на сервер, нормализуется здесь: в адресной строке может
  // лежать что угодно, а невалидная сортировка или статус — это 400 на каждом
  // открытии ссылки, а не «фильтр не применился».
  const page = Math.max(1, Number(filters.page) || 1);
  const pageSize = Math.max(1, Number(filters.pageSize) || Number(DEFAULT_FILTERS.pageSize));
  const sortField = toSortField(filters.sort) ?? DEFAULT_FILTERS.sort;
  const direction: 'asc' | 'desc' = filters.direction === 'desc' ? 'desc' : 'asc';
  const status = toStatus(filters.status);
  const search = filters.search.trim();

  // ------------------------------------------------------------- поиск с задержкой

  const [searchDraft, setSearchDraft] = React.useState(filters.search);

  React.useEffect(() => {
    if (searchDraft === filters.search) return;
    // Каждая буква в ключе запроса — отдельный поход на сервер и мигающий
    // скелет. Полсекунды раздумий дешевле, чем десять запросов на слово.
    const timer = window.setTimeout(() => set({ search: searchDraft }), SEARCH_DEBOUNCE_MS);
    return () => window.clearTimeout(timer);
  }, [searchDraft, filters.search, set]);

  // Сброс фильтров приходит извне (кнопка, чип, ссылка) — поле обязано опустеть
  // вместе с ними, иначе в нём остаётся текст, который уже ни на что не влияет.
  React.useEffect(() => {
    setSearchDraft(filters.search);
  }, [filters.search]);

  // -------------------------------------------------------------------- справочники

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const warehouses = useQuery({ queryKey: ['mdm', 'warehouses'], queryFn: mdmApi.warehouses });

  const sellerOptions = React.useMemo<SearchableOption[]>(
    () =>
      (sellers.data ?? []).map((seller) => ({
        value: seller.id,
        label: `${seller.code} — ${seller.legalName}`,
        triggerLabel: seller.code,
        keywords: `${seller.code} ${seller.legalName}`,
      })),
    [sellers.data],
  );

  // -------------------------------------------------------------------- запрос данных

  const range: DateRange = React.useMemo(
    () => ({ from: filters.dateFrom || null, to: filters.dateTo || null }),
    [filters.dateFrom, filters.dateTo],
  );

  /** Фильтр без листания: им же считаются итоги и им же уходит выгрузка. */
  const filterQuery = React.useMemo<StockTableQuery>(
    () => ({
      sellerId: filters.sellerId || undefined,
      warehouseId: filters.warehouseId || undefined,
      status: status ?? undefined,
      search: search || undefined,
      ...rangeToQuery(range),
    }),
    [filters.sellerId, filters.warehouseId, status, search, range],
  );

  const listQuery = React.useMemo<StockTableQuery>(
    () => ({ ...filterQuery, page, pageSize, sort: sortField, direction }),
    [filterQuery, page, pageSize, sortField, direction],
  );

  const stock = useQuery<PageDto<StockTableRowDto>>({
    queryKey: ['inventory', 'stock', 'table', listQuery],
    queryFn: () => inventoryApi.table(listQuery),
  });

  const totals = useQuery<StockTableTotalsDto>({
    // Итоги считаются по фильтру без страницы — иначе они менялись бы при
    // листании, хотя обещают сумму по всей выборке.
    queryKey: ['inventory', 'stock', 'table', 'totals', filterQuery],
    queryFn: () => inventoryApi.tableTotals(filterQuery),
  });

  // ------------------------------------------------------------------- форматирование

  const numberFormat = React.useMemo(() => new Intl.NumberFormat(language), [language]);
  const dateFormat = React.useMemo(
    () => new Intl.DateTimeFormat(language, { day: '2-digit', month: '2-digit', year: 'numeric' }),
    [language],
  );

  const num = React.useCallback(
    (value: number): string => numberFormat.format(value),
    [numberFormat],
  );
  const formatDate = React.useCallback(
    (iso: string | null): string => (iso ? dateFormat.format(new Date(iso)) : '—'),
    [dateFormat],
  );
  const monthName = React.useCallback((m: number): string => t(`ui.month.${m}` as MessageKey), [t]);
  const statusTitle = React.useCallback(
    (value: InventoryUnitStatus): string => t(`stock.binStatus.${value}` as MessageKey),
    [t],
  );

  // ------------------------------------------------------------------------ колонки

  const columns = React.useMemo<Array<DataTableColumn<StockTableRowDto>>>(() => {
    const list: Array<DataTableColumn<StockTableRowDto>> = [];
    const showCode = canView('stock', 'skuCode');
    const showName = canView('stock', 'skuName');

    // Колонка исчезает целиком, только если закрыты ОБА поля: артикул без
    // названия (и наоборот) читается, а пустой столбец — нет.
    if (showCode || showName) {
      list.push({
        key: 'skuCode',
        header: t('stock.col.sku'),
        sortable: true,
        width: '24%',
        cell: (row) => (
          <div className="min-w-0">
            {showCode ? <div className="truncate font-mono text-xs">{row.skuCode}</div> : null}
            {showName ? (
              <div className="truncate text-sm text-muted-foreground">{row.skuName}</div>
            ) : null}
          </div>
        ),
      });
    }

    if (canView('stock', 'sellerName')) {
      list.push({
        key: 'sellerName',
        header: t('stock.col.seller'),
        sortable: true,
        hideable: true,
        width: '14%',
        cell: (row) => (
          <div className="min-w-0" title={row.sellerName}>
            <div className="truncate text-sm">{row.sellerName}</div>
            <div className="truncate font-mono text-[11px] text-muted-foreground">
              {row.sellerCode}
            </div>
          </div>
        ),
      });
    }

    if (canView('stock', 'warehouseCode')) {
      list.push({
        key: 'warehouseCode',
        header: t('stock.col.warehouse'),
        sortable: true,
        width: '9%',
        cell: (row) => <span className="font-mono text-xs">{row.warehouseCode}</span>,
      });
    }

    if (canView('stock', 'status')) {
      list.push({
        key: 'status',
        header: t('stock.col.status'),
        sortable: true,
        width: '11%',
        cell: (row) => (
          <Badge variant={STATUS_TONE[row.status]} size="sm" dot>
            {statusTitle(row.status)}
          </Badge>
        ),
      });
    }

    if (canView('stock', 'quantity')) {
      list.push({
        key: 'quantity',
        header: t('stock.col.quantity'),
        sortable: true,
        align: 'right',
        width: '8%',
        cell: (row) => <span className="font-medium">{num(row.quantity)}</span>,
      });
    }

    if (canView('stock', 'available')) {
      list.push({
        key: 'available',
        header: t('stock.col.available'),
        align: 'right',
        width: '8%',
        cell: (row) => (
          <span className={row.available > 0 ? 'text-success' : 'text-muted-foreground'}>
            {num(row.available)}
          </span>
        ),
      });
    }

    if (canView('stock', 'reserved')) {
      list.push({
        key: 'reserved',
        header: t('stock.col.reserved'),
        align: 'right',
        hideable: true,
        width: '8%',
        cell: (row) => (
          <span className={row.reserved > 0 ? 'text-warning' : 'text-muted-foreground'}>
            {num(row.reserved)}
          </span>
        ),
      });
    }

    if (canView('stock', 'damaged')) {
      list.push({
        key: 'damaged',
        header: t('stock.col.damaged'),
        align: 'right',
        hideable: true,
        width: '8%',
        cell: (row) => (
          <span className={row.damaged > 0 ? 'text-destructive' : 'text-muted-foreground'}>
            {num(row.damaged)}
          </span>
        ),
      });
    }

    if (canView('stock', 'firstReceivedAt') || canView('stock', 'lastReceivedAt')) {
      list.push({
        key: 'receivedAt',
        header: t('stock.col.received'),
        sortable: true,
        width: '12%',
        cell: (row) => <ReceivedCell row={row} format={formatDate} />,
      });
    }

    if (canView('stock', 'bins')) {
      list.push({
        key: 'bins',
        header: t('stock.col.bins'),
        hideable: true,
        cell: (row) => <BinsCell bins={row.bins} />,
      });
    }

    return list;
  }, [canView, t, num, formatDate, statusTitle]);

  // ----------------------------------------------------------------- активные фильтры

  const chips = React.useMemo(() => {
    const list: Array<{ key: string; label: string; value: string; clear: () => void }> = [];

    if (filters.sellerId) {
      const seller = sellers.data?.find((item) => item.id === filters.sellerId);
      list.push({
        key: 'seller',
        label: t('stock.seller'),
        value: seller ? seller.code : filters.sellerId,
        clear: () => set({ sellerId: '' }),
      });
    }
    if (filters.warehouseId) {
      const warehouse = warehouses.data?.find((item) => item.id === filters.warehouseId);
      list.push({
        key: 'warehouse',
        label: t('stock.warehouse'),
        value: warehouse ? warehouse.code : filters.warehouseId,
        clear: () => set({ warehouseId: '' }),
      });
    }
    if (status) {
      list.push({
        key: 'status',
        label: t('stock.filters.status'),
        value: statusTitle(status),
        clear: () => set({ status: '' }),
      });
    }
    if (range.from || range.to) {
      list.push({
        key: 'period',
        label: t('ui.date.range'),
        value: formatRangeLabel(range, monthName),
        clear: () => set({ dateFrom: '', dateTo: '' }),
      });
    }
    if (search) {
      list.push({
        key: 'search',
        label: t('ui.search'),
        value: search,
        clear: () => {
          setSearchDraft('');
          set({ search: '' });
        },
      });
    }
    return list;
  }, [
    filters.sellerId,
    filters.warehouseId,
    status,
    search,
    range,
    sellers.data,
    warehouses.data,
    t,
    statusTitle,
    monthName,
    set,
  ]);

  const filtered = chips.length > 0;

  const resetAll = React.useCallback((): void => {
    setSearchDraft('');
    reset();
  }, [reset]);

  // ---------------------------------------------------------------------- сортировка

  const sort: DataTableSort = { key: sortField, direction };

  const handleSort = React.useCallback(
    (next: DataTableSort | null): void => {
      const field = next ? toSortField(next.key) : null;
      // Снятие сортировки не оставляет список в произвольном порядке: сервер
      // всё равно чем-то упорядочивает страницу, и это должен быть тот же
      // порядок, что и при первом открытии, иначе листание «прыгает».
      if (!next || !field) {
        set({ sort: DEFAULT_FILTERS.sort, direction: DEFAULT_FILTERS.direction });
        return;
      }
      set({ sort: field, direction: next.direction });
    },
    [set],
  );

  // -------------------------------------------------------------------------- вывод

  const rows = stock.data?.rows ?? [];
  const total = stock.data?.total ?? 0;
  const totalsData = totals.data;

  return (
    <PageContainer>
      <PageHeader
        icon={Icon.stock()}
        title={t('stock.title')}
        description={t('stock.subtitle')}
        actions={
          <ExportButton
            // Выгрузка идёт по ТЕКУЩЕМУ фильтру, а не по видимой странице:
            // «экспорт» из отфильтрованного списка обязан содержать всё, что
            // под фильтр попало, иначе им нельзя пользоваться для сверки.
            path={inventoryApi.exportPath({ ...filterQuery, sort: sortField, direction })}
          />
        }
      />

      <KpiGrid className="lg:grid-cols-5">
        <KpiCard
          label={t('stock.kpi.rows')}
          value={totalsData ? num(totalsData.rows) : '—'}
          hint={totalsData ? t('stock.kpi.skusHint', { count: num(totalsData.skus) }) : undefined}
          icon={Icon.catalog()}
          loading={totals.isLoading}
        />
        <KpiCard
          label={t('stock.kpi.units')}
          value={totalsData ? num(totalsData.units) : '—'}
          icon={Icon.stock()}
          loading={totals.isLoading}
        />
        <KpiCard
          label={t('stock.kpi.available')}
          value={totalsData ? num(totalsData.available) : '—'}
          tone="success"
          icon={Icon.check()}
          loading={totals.isLoading}
        />
        <KpiCard
          label={t('stock.kpi.reserved')}
          value={totalsData ? num(totalsData.reserved) : '—'}
          tone="warning"
          icon={Icon.orders()}
          loading={totals.isLoading}
        />
        <KpiCard
          label={t('stock.kpi.damaged')}
          value={totalsData ? num(totalsData.damaged) : '—'}
          tone="destructive"
          icon={Icon.alert()}
          loading={totals.isLoading}
        />
      </KpiGrid>

      <Toolbar>
        <ToolbarGroup label={t('ui.date.range')}>
          <DateRangePicker
            value={range}
            onChange={(next) => set({ dateFrom: next.from ?? '', dateTo: next.to ?? '' })}
          />
        </ToolbarGroup>

        <ToolbarGroup label={t('stock.seller')} className="w-48">
          <SearchableSelect
            value={filters.sellerId}
            onChange={(value) => set({ sellerId: value })}
            options={sellerOptions}
            clearLabel={t('stock.allSellers')}
            searchPlaceholder={t('ui.search')}
          />
        </ToolbarGroup>

        <ToolbarGroup label={t('stock.warehouse')} className="w-40">
          <Select
            value={filters.warehouseId}
            onChange={(event) => set({ warehouseId: event.target.value })}
          >
            <option value="">{t('stock.allWarehouses')}</option>
            {(warehouses.data ?? []).map((warehouse) => (
              <option key={warehouse.id} value={warehouse.id}>
                {warehouse.code}
              </option>
            ))}
          </Select>
        </ToolbarGroup>

        <ToolbarGroup label={t('stock.filters.status')} className="w-40">
          <Select value={filters.status} onChange={(event) => set({ status: event.target.value })}>
            <option value="">{t('stock.allStatuses')}</option>
            {INVENTORY_UNIT_STATUSES.map((value) => (
              <option key={value} value={value}>
                {statusTitle(value)}
              </option>
            ))}
          </Select>
        </ToolbarGroup>

        <ToolbarGroup label={t('ui.search')} className="w-full sm:w-72">
          <ToolbarSearch
            value={searchDraft}
            onChange={setSearchDraft}
            placeholder={t('stock.search.placeholder')}
          />
        </ToolbarGroup>

        <ToolbarSpacer />

        {filtered ? (
          <Button variant="ghost" size="sm" onClick={resetAll}>
            {t('stock.resetFilters')}
          </Button>
        ) : null}
      </Toolbar>

      {stock.isError ? (
        <Card>
          <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
            <span className="text-sm text-destructive">{t('stock.loadError')}</span>
            <Button variant="outline" size="sm" onClick={() => void stock.refetch()}>
              {t('ui.retry')}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <DataTable
          columns={columns}
          rows={rows}
          getRowKey={(row) => row.key}
          loading={stock.isLoading}
          skeletonRows={Math.min(pageSize, 10)}
          sort={sort}
          onSortChange={handleSort}
          columnVisibility
          // Пустой склад и пустая выборка — разные новости. Первое означает
          // «работать не с чем», второе — «сними фильтр»; одинаковый текст
          // заставляет искать поломку там, где её нет.
          emptyTitle={filtered ? t('stock.noMatchTitle') : t('stock.emptyTitle')}
          emptyDescription={filtered ? t('stock.noMatchHint') : t('stock.emptyHint')}
          emptyAction={
            filtered ? (
              <Button variant="outline" size="sm" onClick={resetAll}>
                {t('stock.resetFilters')}
              </Button>
            ) : undefined
          }
          toolbar={
            chips.length > 0 ? (
              <div className="flex flex-wrap items-center gap-1.5">
                {chips.map((chip) => (
                  <FilterChip
                    key={chip.key}
                    label={chip.label}
                    value={chip.value}
                    onClear={chip.clear}
                  />
                ))}
              </div>
            ) : null
          }
          footer={
            <Pagination
              page={page}
              pageSize={pageSize}
              total={total}
              onPageChange={(next) => set({ page: String(next) })}
              onPageSizeChange={(size) => set({ pageSize: String(size), page: '1' })}
            />
          }
        />
      )}
    </PageContainer>
  );
}
