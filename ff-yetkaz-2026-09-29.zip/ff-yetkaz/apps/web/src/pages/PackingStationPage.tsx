import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import { ApiError } from '@/lib/api';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { packingApi } from '@/lib/packing';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function PackingStationPage(): React.ReactElement {
  const { id = '' } = useParams();
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const kg = (grams: number): string => t('packing.kg', { value: (grams / 1000).toFixed(3) });

  const [weight, setWeight] = React.useState('');
  const [dims, setDims] = React.useState({ length: '', width: '', height: '' });
  const [comment, setComment] = React.useState('');
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [labelUrl, setLabelUrl] = React.useState<string | null>(null);

  const pkg = useQuery({ queryKey: ['packing', 'package', id], queryFn: () => packingApi.package(id) });
  const shipment = useQuery({
    queryKey: ['packing', 'shipment', id],
    queryFn: () => packingApi.shipment(id),
    enabled: pkg.data?.status === 'PACKED',
  });

  // Blob-ссылку надо освобождать: иначе вкладка удерживает PDF в памяти.
  React.useEffect(() => () => {
    if (labelUrl) URL.revokeObjectURL(labelUrl);
  }, [labelUrl]);

  const complete = useMutation({
    mutationFn: () =>
      packingApi.complete(pkg.data!.orderId, {
        weightG: Number(weight),
        lengthMm: dims.length ? Number(dims.length) : undefined,
        widthMm: dims.width ? Number(dims.width) : undefined,
        heightMm: dims.height ? Number(dims.height) : undefined,
        comment: comment.trim() ? comment.trim() : undefined,
      }),
    onSuccess: (result) => {
      setMessage({
        kind: result.weightMismatch ? 'error' : 'ok',
        text: result.weightMismatch
          ? t('packing.completeMismatch', { pct: String(result.deviationPct) })
          : t('packing.completeOk'),
      });
      queryClient.invalidateQueries({ queryKey: ['packing'] });
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : t('common.error.network'),
      }),
  });

  const issue = useMutation({
    mutationFn: async () => {
      await packingApi.issueLabel(id);
      return packingApi.labelUrl(id);
    },
    onSuccess: (url) => {
      setLabelUrl(url);
      window.open(url, '_blank', 'noopener');
      setMessage({ kind: 'ok', text: t('packing.labelIssued') });
      queryClient.invalidateQueries({ queryKey: ['packing'] });
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : t('packing.labelError'),
      }),
  });

  if (pkg.isLoading) {
    return <div className="p-6 text-sm text-muted-foreground">{t('packing.loadingPackage')}</div>;
  }
  if (pkg.isError || !pkg.data) {
    return (
      <div className="space-y-3 p-6">
        <p className="text-sm text-destructive">{t('packing.packageNotFound')}</p>
        <Link to="/packing" className="text-sm underline">
          {t('packing.toQueue')}
        </Link>
      </div>
    );
  }

  const data = pkg.data;
  const expected = data.expectedWeightG;
  const entered = Number(weight);
  // Допуск приезжает с сервера вместе с упаковкой: он живёт в app_settings,
  // и подсказка упаковщику не должна разъехаться с проверкой на бэкенде.
  const tolerance = data.weightTolerancePct;
  const deviation =
    expected && Number.isFinite(entered) && entered > 0
      ? ((entered - expected) / expected) * 100
      : null;
  const outOfTolerance = deviation !== null && Math.abs(deviation) > tolerance;
  const isOpen = data.status === 'OPEN';

  return (
    <div className="mx-auto max-w-xl space-y-4 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('packing.orderTitle')}</h1>
        <Link to="/packing" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>

      {message && (
        <p
          role="status"
          className={
            message.kind === 'ok'
              ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
              : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
          }
        >
          {message.text}
        </p>
      )}

      <Card>
        <CardContent className="space-y-2 p-4">
          <div className="text-sm font-medium">{t('packing.contents')}</div>
          {data.items.map((item) => (
            <div key={item.id} className="flex items-baseline justify-between gap-2 text-sm">
              <span className="min-w-0 truncate">
                <span className="font-medium">{item.skuCode}</span>
                <span className="text-muted-foreground"> · {item.skuName}</span>
              </span>
              <span className="shrink-0 tabular-nums">× {item.quantity}</span>
            </div>
          ))}
          <div className="pt-2 text-sm text-muted-foreground">
            {t('packing.expectedWeight')}{' '}
            {expected === null ? (
              <span className="text-destructive">{t('packing.weightUnknown')}</span>
            ) : (
              <span className="tabular-nums text-foreground">{kg(expected)}</span>
            )}
          </div>
        </CardContent>
      </Card>

      {isOpen && (
        <Card>
          <CardContent className="space-y-4 p-4">
            <div className="space-y-2">
              <Label htmlFor="weight">{t('packing.actualWeightInput')}</Label>
              <Input
                id="weight"
                inputMode="numeric"
                autoFocus
                value={weight}
                onChange={(event) => setWeight(event.target.value.replace(/[^\d]/g, ''))}
                placeholder={t('packing.fromScale')}
              />
              {entered > 0 && (
                <p className={`text-sm ${outOfTolerance ? 'text-destructive' : 'text-muted-foreground'}`}>
                  {kg(entered)}
                  {deviation !== null &&
                    ` · ${t('packing.deviation', {
                      sign: deviation > 0 ? '+' : '',
                      pct: deviation.toFixed(1),
                      tol: tolerance,
                    })}`}
                </p>
              )}
            </div>

            <div className="grid grid-cols-3 gap-2">
              {(['length', 'width', 'height'] as const).map((side) => (
                <div key={side} className="space-y-1">
                  <Label htmlFor={side}>{t(`packing.dim.${side}` as MessageKey)}</Label>
                  <Input
                    id={side}
                    inputMode="numeric"
                    value={dims[side]}
                    onChange={(event) =>
                      setDims({ ...dims, [side]: event.target.value.replace(/[^\d]/g, '') })
                    }
                  />
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <Label htmlFor="comment">
                {outOfTolerance ? t('packing.comment.explain') : t('packing.comment.optional')}
              </Label>
              <Input
                id="comment"
                value={comment}
                onChange={(event) => setComment(event.target.value)}
                placeholder={outOfTolerance ? t('packing.comment.placeholder') : ''}
              />
            </div>

            <Button
              className="w-full"
              disabled={!(entered > 0) || complete.isPending}
              onClick={() => complete.mutate()}
            >
              {t('packing.complete')}
            </Button>
          </CardContent>
        </Card>
      )}

      {!isOpen && (
        <Card>
          <CardContent className="space-y-3 p-4">
            <div className="flex items-baseline justify-between gap-2 text-sm">
              <span className="text-muted-foreground">{t('packing.actualWeight')}</span>
              <span className="tabular-nums">{data.actualWeightG ? kg(data.actualWeightG) : '—'}</span>
            </div>
            {data.weightMismatch && (
              <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {t('packing.weightMismatchNote', { tol: tolerance })}
              </p>
            )}

            {shipment.data ? (
              <div className="space-y-2 text-sm">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-muted-foreground">{t('packing.shipment')}</span>
                  <span className="font-medium tabular-nums">{shipment.data.shipmentNo}</span>
                </div>
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-muted-foreground">{t('packing.tracking')}</span>
                  <span className="tabular-nums">
                    {shipment.data.trackingNo ?? t('packing.trackingPending')}
                  </span>
                </div>
                <Button
                  variant="outline"
                  className="w-full"
                  disabled={issue.isPending}
                  onClick={() => issue.mutate()}
                >
                  {t('packing.reprintLabel')}
                </Button>
              </div>
            ) : (
              <Button className="w-full" disabled={issue.isPending} onClick={() => issue.mutate()}>
                {t('packing.issueLabel')}
              </Button>
            )}

            {labelUrl && (
              <a href={labelUrl} target="_blank" rel="noopener" className="block text-sm underline">
                {t('packing.openLabel')}
              </a>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
