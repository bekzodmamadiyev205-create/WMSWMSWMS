import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate, useParams } from 'react-router-dom';
import type {
  BinLocationDto,
  MoveReturnPayload,
  ReturnDto,
  ReturnItemDto,
  StoreReturnPayload,
} from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ConfirmDialog, Dialog } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Select } from '@/components/ui/select';
import { Skeleton, SkeletonText } from '@/components/ui/skeleton';
import { Table, TBody, TD, TFoot, TH, THead, TR } from '@/components/ui/table';
import { useToast } from '@/components/ui/toast';
import {
  dateLocale,
  ReturnTimeline,
  RETURN_STATUS_TONE,
  returnStatusKey,
} from '@/components/ReturnTimeline';

function errorText(error: unknown): string {
  return error instanceof ApiError ? error.message : (error as Error).message;
}

function Field({ label, children }: { label: string; children: React.ReactNode }): React.ReactElement {
  return (
    <div className="flex min-w-0 flex-col gap-0.5">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="break-words text-sm text-foreground">{children}</span>
    </div>
  );
}

/**
 * Кнопка действия, которая НЕ прячется, когда действие невозможно.
 *
 * Оператор, не нашедший кнопку, считает систему сломанной и идёт звонить; кнопка
 * с подсказкой «почему нельзя» отвечает на вопрос сама. Подсказка висит на
 * обёртке: у отключённой кнопки `pointer-events: none`, и её собственный `title`
 * браузер не покажет.
 */
function ActionButton({
  label,
  hint,
  disabled,
  onClick,
  variant = 'outline',
}: {
  label: string;
  hint?: string;
  disabled: boolean;
  onClick: () => void;
  variant?: 'default' | 'outline' | 'ghost' | 'destructive';
}): React.ReactElement {
  return (
    <span className="inline-flex" title={disabled ? hint : undefined}>
      <Button variant={variant} size="sm" disabled={disabled} onClick={onClick}>
        {label}
      </Button>
    </span>
  );
}

export function ReturnDetailPage(): React.ReactElement {
  const { id = '' } = useParams();
  const { t, language } = useI18n();
  const toast = useToast();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [storeOpen, setStoreOpen] = React.useState(false);
  const [moveOpen, setMoveOpen] = React.useState(false);
  const [completeOpen, setCompleteOpen] = React.useState(false);
  const [cancelOpen, setCancelOpen] = React.useState(false);

  const detail = useQuery({
    queryKey: ['returns', 'detail', id],
    queryFn: () => apiFetch<ReturnDto>(`/returns/${id}`),
    enabled: id !== '',
  });

  const data = detail.data;

  const bins = useQuery({
    queryKey: ['mdm', 'bins', data?.warehouseId ?? ''],
    queryFn: () => mdmApi.bins(data?.warehouseId ?? ''),
    enabled: Boolean(data?.warehouseId),
  });

  /**
   * Ответ сервера кладём в кэш сразу: он и есть новое состояние документа.
   * Оптимистичных правок статуса здесь нет намеренно — переход проверяет FSM на
   * бэкенде, и «завершено» на экране до ответа было бы обещанием, которое может
   * не сбыться 409-м.
   */
  const applyResult = React.useCallback(
    (updated: ReturnDto): void => {
      queryClient.setQueryData(['returns', 'detail', id], updated);
    },
    [queryClient, id],
  );

  const settle = React.useCallback((): void => {
    void queryClient.invalidateQueries({ queryKey: ['returns'] });
    // Раскладка возврата двигает остаток — сводка склада без этого врёт.
    void queryClient.invalidateQueries({ queryKey: ['inventory'] });
  }, [queryClient]);

  const store = useMutation({
    mutationFn: (payload: StoreReturnPayload) =>
      apiFetch<ReturnDto>(`/returns/${id}/store`, { method: 'POST', body: payload }),
    onSuccess: (updated) => {
      applyResult(updated);
      setStoreOpen(false);
      toast.success(t('returns.store.ok'));
    },
    onError: (error) => toast.error(t('returns.actionFailed'), errorText(error)),
    onSettled: settle,
  });

  const move = useMutation({
    mutationFn: (payload: MoveReturnPayload) =>
      apiFetch<ReturnDto>(`/returns/${id}/move`, { method: 'POST', body: payload }),
    onSuccess: (updated) => {
      applyResult(updated);
      setMoveOpen(false);
      toast.success(t('returns.move.ok'));
    },
    onError: (error) => toast.error(t('returns.actionFailed'), errorText(error)),
    onSettled: settle,
  });

  const complete = useMutation({
    mutationFn: () => apiFetch<ReturnDto>(`/returns/${id}/complete`, { method: 'POST', body: {} }),
    onSuccess: (updated) => {
      applyResult(updated);
      setCompleteOpen(false);
      toast.success(t('returns.complete.ok'));
    },
    onError: (error) => toast.error(t('returns.actionFailed'), errorText(error)),
    onSettled: settle,
  });

  const cancel = useMutation({
    mutationFn: (comment: string) =>
      apiFetch<ReturnDto>(`/returns/${id}/cancel`, { method: 'POST', body: { comment } }),
    onSuccess: (updated) => {
      applyResult(updated);
      setCancelOpen(false);
      toast.success(t('returns.cancel.ok'));
    },
    onError: (error) => toast.error(t('returns.actionFailed'), errorText(error)),
    onSettled: settle,
  });

  if (detail.isLoading) {
    return (
      <PageContainer>
        <Skeleton className="h-8 w-64" />
        <div className="premium-card p-4">
          <SkeletonText lines={4} />
        </div>
        <div className="premium-card p-4">
          <SkeletonText lines={6} />
        </div>
      </PageContainer>
    );
  }

  if (detail.isError || !data) {
    return (
      <PageContainer>
        <PageHeader
          title={t('returns.detail.notFound')}
          breadcrumbs={[{ label: t('returns.title'), to: '/returns' }]}
        />
        <div className="premium-card flex flex-wrap items-center justify-between gap-3 p-4">
          <span className="text-sm text-destructive">{t('returns.detail.notFoundHint')}</span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => void detail.refetch()}>
              {t('ui.retry')}
            </Button>
            <Button size="sm" onClick={() => navigate('/returns')}>
              {t('returns.detail.back')}
            </Button>
          </div>
        </div>
      </PageContainer>
    );
  }

  const terminal = data.status === 'COMPLETED' || data.status === 'CANCELLED';
  const pendingTotal = data.items.reduce(
    (sum, item) => sum + Math.max(0, item.quantity - item.restockedQuantity),
    0,
  );
  const storageBins = (bins.data ?? []).filter((bin) => bin.isActive && bin.kind === 'STORAGE');
  const activeBins = (bins.data ?? []).filter((bin) => bin.isActive);

  const canStore = (data.status === 'ACCEPTED' || data.status === 'MOVING') && pendingTotal > 0;
  const storeHint = terminal
    ? t('returns.action.disabled.terminal')
    : pendingTotal === 0
      ? t('returns.action.disabled.storeDone')
      : t('returns.action.disabled.store');

  const busy = store.isPending || move.isPending || complete.isPending || cancel.isPending;

  return (
    <PageContainer>
      <PageHeader
        breadcrumbs={[{ label: t('returns.title'), to: '/returns' }, { label: data.returnNo }]}
        title={<span className="font-mono">{data.returnNo}</span>}
        description={t('returns.detail.subtitle', {
          reason: t(`returns.reason.${data.reason}` as MessageKey),
          created: new Date(data.createdAt).toLocaleString(dateLocale(language)),
        })}
        actions={
          <>
            <Badge variant={RETURN_STATUS_TONE[data.status]} dot>
              {t(returnStatusKey(data.status))}
            </Badge>
            <ActionButton
              label={t('returns.action.store')}
              hint={storeHint}
              disabled={!canStore || busy}
              onClick={() => setStoreOpen(true)}
              variant="default"
            />
            <ActionButton
              label={t('returns.action.move')}
              hint={
                terminal
                  ? t('returns.action.disabled.terminal')
                  : bins.isLoading
                    ? t('ui.loading')
                    : t('returns.action.disabled.noBins')
              }
              // Пока список ячеек едет, кнопка заблокирована, но подсказка честная:
              // «у склада нет ячеек» на полпути к ответу — это ложное обвинение.
              disabled={terminal || busy || bins.isLoading || activeBins.length === 0}
              onClick={() => setMoveOpen(true)}
            />
            <ActionButton
              label={t('returns.action.complete')}
              hint={
                terminal
                  ? t('returns.action.disabled.terminal')
                  : t('returns.action.disabled.complete')
              }
              disabled={!(data.status === 'IN_STORAGE' || data.status === 'MOVING') || busy}
              onClick={() => setCompleteOpen(true)}
            />
            <ActionButton
              label={t('returns.action.cancel')}
              hint={t('returns.action.disabled.terminal')}
              disabled={terminal || busy}
              onClick={() => setCancelOpen(true)}
              variant="ghost"
            />
          </>
        }
      />

      <section className="premium-card grid gap-4 p-4 sm:grid-cols-2 lg:grid-cols-4">
        <Field label={t('returns.detail.seller')}>{data.sellerName ?? data.sellerId}</Field>
        <Field label={t('returns.detail.warehouse')}>{data.warehouseCode ?? data.warehouseId}</Field>
        <Field label={t('returns.detail.order')}>
          {data.orderId ? (
            <Link
              to={`/orders/${data.orderId}`}
              className="rounded font-mono text-sm text-primary underline-offset-2 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {data.orderCode ?? data.orderExternalId ?? data.orderId}
            </Link>
          ) : (
            <span className="text-muted-foreground">{t('returns.detail.noOrder')}</span>
          )}
        </Field>
        <Field label={t('returns.detail.reason')}>
          {t(`returns.reason.${data.reason}` as MessageKey)}
        </Field>
        <Field label={t('returns.detail.createdAt')}>
          {new Date(data.createdAt).toLocaleString(dateLocale(language))}
        </Field>
        <Field label={t('returns.detail.createdBy')}>
          {data.createdBy ?? <span className="text-muted-foreground">—</span>}
        </Field>
        <Field label={t('returns.detail.completedAt')}>
          {data.completedAt ? (
            new Date(data.completedAt).toLocaleString(dateLocale(language))
          ) : (
            <span className="text-muted-foreground">—</span>
          )}
        </Field>
        <Field label={t('returns.detail.progress')}>
          <span className="tabular-nums">
            {data.totalRestocked} / {data.totalQuantity}
          </span>
        </Field>
        {data.comment ? (
          <div className="sm:col-span-2 lg:col-span-4">
            <Field label={t('returns.detail.comment')}>{data.comment}</Field>
          </div>
        ) : null}
      </section>

      <section className="premium-card overflow-hidden">
        <div className="border-b border-border px-4 py-3">
          <h2 className="text-sm font-medium text-card-foreground">{t('returns.detail.items')}</h2>
        </div>
        <div className="overflow-x-auto">
          <Table>
            <THead>
              <tr>
                <TH className="bg-card">{t('returns.detail.col.sku')}</TH>
                <TH className="bg-card">{t('returns.detail.col.item')}</TH>
                <TH align="right" className="bg-card">
                  {t('returns.detail.col.accepted')}
                </TH>
                <TH className="bg-card">{t('returns.detail.col.condition')}</TH>
                <TH align="right" className="bg-card">
                  {t('returns.detail.col.restocked')}
                </TH>
                <TH className="bg-card">{t('returns.detail.col.bin')}</TH>
              </tr>
            </THead>
            <TBody>
              {data.items.map((item) => (
                <TR key={item.id}>
                  <TD className="font-mono text-xs">{item.skuCode}</TD>
                  <TD className="min-w-[12rem]">{item.skuName}</TD>
                  <TD align="right" className="tabular-nums">
                    {item.quantity}
                  </TD>
                  <TD>
                    <Badge variant={item.condition === 'DAMAGED' ? 'destructive' : 'secondary'} size="sm">
                      {t(`returns.condition.${item.condition}` as MessageKey)}
                    </Badge>
                  </TD>
                  <TD align="right" className="tabular-nums">
                    <span
                      className={cn(
                        item.restockedQuantity >= item.quantity ? 'text-success' : undefined,
                      )}
                    >
                      {item.restockedQuantity}
                    </span>
                  </TD>
                  <TD className="font-mono text-xs text-muted-foreground">{item.binCode ?? '—'}</TD>
                </TR>
              ))}
            </TBody>
            <TFoot>
              <tr>
                <TD colSpan={2} className="text-xs font-medium">
                  {t('returns.detail.totals')}
                </TD>
                <TD align="right" className="font-medium tabular-nums">
                  {data.totalQuantity}
                </TD>
                <TD />
                <TD align="right" className="font-medium tabular-nums">
                  {data.totalRestocked}
                </TD>
                <TD />
              </tr>
            </TFoot>
          </Table>
        </div>
      </section>

      <ReturnTimeline events={data.events ?? []} status={data.status} />

      <StoreDialog
        open={storeOpen}
        items={data.items}
        bins={storageBins}
        busy={store.isPending}
        onClose={() => setStoreOpen(false)}
        onSubmit={(payload) => store.mutate(payload)}
      />

      <MoveDialog
        open={moveOpen}
        bins={activeBins}
        busy={move.isPending}
        onClose={() => setMoveOpen(false)}
        onSubmit={(payload) => move.mutate(payload)}
      />

      <ConfirmDialog
        open={completeOpen}
        onClose={() => setCompleteOpen(false)}
        onConfirm={() => complete.mutate()}
        title={t('returns.complete.title')}
        description={t('returns.complete.description', { no: data.returnNo })}
        confirmLabel={t('returns.action.complete')}
        busy={complete.isPending}
      />

      <CancelDialog
        open={cancelOpen}
        busy={cancel.isPending}
        onClose={() => setCancelOpen(false)}
        onSubmit={(comment) => cancel.mutate(comment)}
      />
    </PageContainer>
  );
}

// ---------------------------------------------------------------- раскладка

interface StoreRow {
  itemId: string;
  good: string;
  damaged: string;
  binId: string;
}

function toCount(raw: string): number {
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 0;
}

function StoreDialog({
  open,
  items,
  bins,
  busy,
  onClose,
  onSubmit,
}: {
  open: boolean;
  items: ReturnItemDto[];
  bins: BinLocationDto[];
  busy: boolean;
  onClose: () => void;
  onSubmit: (payload: StoreReturnPayload) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [rows, setRows] = React.useState<StoreRow[]>([]);
  const [comment, setComment] = React.useState('');

  /**
   * «Уже разложено» считаем по `restockedQuantity`. Брак в него не попадает, то
   * есть остаток здесь — оценка СВЕРХУ: сервер всё равно пересчитает и отобьёт
   * лишнее. Показать оператору хоть какой-то остаток важнее, чем не показать
   * никакого.
   */
  const remainderOf = React.useCallback(
    (item: ReturnItemDto): number => Math.max(0, item.quantity - item.restockedQuantity),
    [],
  );

  // Состав нужен эффекту только в момент открытия. Через ref, а не через список
  // зависимостей: фоновый рефетч карточки даёт НОВЫЙ массив позиций, и форма
  // сбросила бы уже набранные оператором количества прямо под руками.
  const itemsRef = React.useRef(items);
  itemsRef.current = items;

  React.useEffect(() => {
    if (!open) return;
    setRows(
      itemsRef.current.map((item) => ({
        itemId: item.id,
        // Годным считается всё непристроенное: брак — исключение, и его оператор
        // проставляет руками, а не наоборот.
        good: item.condition === 'DAMAGED' ? '0' : String(remainderOf(item)),
        damaged: item.condition === 'DAMAGED' ? String(remainderOf(item)) : '0',
        binId: '',
      })),
    );
    setComment('');
  }, [open, remainderOf]);

  const patchRow = (itemId: string, patch: Partial<StoreRow>): void =>
    setRows((prev) => prev.map((row) => (row.itemId === itemId ? { ...row, ...patch } : row)));

  const rowOf = (itemId: string): StoreRow =>
    rows.find((row) => row.itemId === itemId) ?? { itemId, good: '0', damaged: '0', binId: '' };

  const overflow = items.some((item) => {
    const row = rowOf(item.id);
    return toCount(row.good) + toCount(row.damaged) > remainderOf(item);
  });
  const anything = rows.some((row) => toCount(row.good) + toCount(row.damaged) > 0);

  const submit = (): void => {
    onSubmit({
      lines: rows
        .filter((row) => toCount(row.good) + toCount(row.damaged) > 0)
        .map((row) => ({
          itemId: row.itemId,
          goodQuantity: toCount(row.good),
          damagedQuantity: toCount(row.damaged),
          // Пустая ячейка — не ошибка: сервер положит годное в STORAGE склада сам.
          binId: row.binId || null,
        })),
      comment: comment.trim() || null,
    });
  };

  return (
    <Dialog
      open={open}
      onClose={busy ? () => undefined : onClose}
      title={t('returns.store.title')}
      description={t('returns.store.description')}
      size="xl"
      closeOnOverlay={!busy}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={busy}>
            {t('ui.cancel')}
          </Button>
          <Button size="sm" onClick={submit} disabled={busy || overflow || !anything}>
            {t('returns.store.submit')}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        {items.map((item) => {
          const row = rowOf(item.id);
          const remainder = remainderOf(item) - toCount(row.good) - toCount(row.damaged);

          return (
            <div key={item.id} className="rounded-lg border border-border p-3">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <div className="min-w-0">
                  <span className="font-mono text-xs text-muted-foreground">{item.skuCode}</span>
                  <span className="ml-2 text-sm font-medium">{item.skuName}</span>
                </div>
                <span
                  className={cn(
                    'text-xs tabular-nums',
                    remainder < 0 ? 'font-medium text-destructive' : 'text-muted-foreground',
                  )}
                >
                  {remainder < 0
                    ? t('returns.store.overflow')
                    : t('returns.store.remainder', { n: remainder })}
                </span>
              </div>

              <div className="mt-2 grid gap-2 sm:grid-cols-[6rem_6rem_minmax(0,1fr)]">
                <div className="space-y-1">
                  <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                    {t('returns.store.good')}
                  </span>
                  <Input
                    inputMode="numeric"
                    value={row.good}
                    className="h-9 text-right tabular-nums"
                    onChange={(event) =>
                      patchRow(item.id, { good: event.target.value.replace(/[^\d]/g, '') })
                    }
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                    {t('returns.store.damaged')}
                  </span>
                  <Input
                    inputMode="numeric"
                    value={row.damaged}
                    className="h-9 text-right tabular-nums"
                    onChange={(event) =>
                      patchRow(item.id, { damaged: event.target.value.replace(/[^\d]/g, '') })
                    }
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                    {t('returns.store.bin')}
                  </span>
                  <Select
                    value={row.binId}
                    className="h-9"
                    onChange={(event) => patchRow(item.id, { binId: event.target.value })}
                  >
                    <option value="">{t('returns.store.defaultBin')}</option>
                    {bins.map((bin) => (
                      <option key={bin.id} value={bin.id}>
                        {bin.code}
                      </option>
                    ))}
                  </Select>
                </div>
              </div>
            </div>
          );
        })}

        <div className="space-y-1">
          <Label htmlFor="return-store-comment">{t('returns.store.comment')}</Label>
          <Input
            id="return-store-comment"
            value={comment}
            onChange={(event) => setComment(event.target.value)}
          />
        </div>

        {!anything ? (
          <p className="text-xs text-muted-foreground">{t('returns.store.nothing')}</p>
        ) : null}
      </div>
    </Dialog>
  );
}

// -------------------------------------------------------------- перемещение

function MoveDialog({
  open,
  bins,
  busy,
  onClose,
  onSubmit,
}: {
  open: boolean;
  bins: BinLocationDto[];
  busy: boolean;
  onClose: () => void;
  onSubmit: (payload: MoveReturnPayload) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [binId, setBinId] = React.useState('');
  const [comment, setComment] = React.useState('');

  React.useEffect(() => {
    if (!open) return;
    setBinId('');
    setComment('');
  }, [open]);

  return (
    <Dialog
      open={open}
      onClose={busy ? () => undefined : onClose}
      title={t('returns.move.title')}
      description={t('returns.move.description')}
      size="md"
      closeOnOverlay={!busy}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={busy}>
            {t('ui.cancel')}
          </Button>
          <Button
            size="sm"
            disabled={busy || !binId}
            onClick={() => onSubmit({ binId, comment: comment.trim() || null })}
          >
            {t('returns.move.submit')}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <div className="space-y-1">
          <Label htmlFor="return-move-bin">{t('returns.move.bin')}</Label>
          <Select id="return-move-bin" value={binId} onChange={(event) => setBinId(event.target.value)}>
            <option value="">{t('returns.move.needBin')}</option>
            {bins.map((bin) => (
              <option key={bin.id} value={bin.id}>
                {bin.code} · {t(`catalog.binKind.${bin.kind}` as MessageKey)}
              </option>
            ))}
          </Select>
        </div>
        <div className="space-y-1">
          <Label htmlFor="return-move-comment">{t('returns.move.comment')}</Label>
          <Input
            id="return-move-comment"
            value={comment}
            onChange={(event) => setComment(event.target.value)}
          />
        </div>
      </div>
    </Dialog>
  );
}

// ------------------------------------------------------------------ отмена

function CancelDialog({
  open,
  busy,
  onClose,
  onSubmit,
}: {
  open: boolean;
  busy: boolean;
  onClose: () => void;
  onSubmit: (comment: string) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [comment, setComment] = React.useState('');

  React.useEffect(() => {
    if (open) setComment('');
  }, [open]);

  return (
    <Dialog
      open={open}
      onClose={busy ? () => undefined : onClose}
      title={t('returns.cancel.title')}
      description={t('returns.cancel.description')}
      size="md"
      closeOnOverlay={!busy}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={busy}>
            {t('returns.cancel.keep')}
          </Button>
          <Button
            variant="destructive"
            size="sm"
            disabled={busy || comment.trim().length === 0}
            onClick={() => onSubmit(comment.trim())}
          >
            {t('returns.cancel.submit')}
          </Button>
        </>
      }
    >
      <div className="space-y-1">
        <Label htmlFor="return-cancel-comment">{t('returns.cancel.comment')}</Label>
        <Input
          id="return-cancel-comment"
          autoFocus
          value={comment}
          placeholder={t('returns.cancel.commentPlaceholder')}
          onChange={(event) => setComment(event.target.value)}
        />
        <p className="text-xs text-muted-foreground">{t('returns.cancel.commentRequired')}</p>
      </div>
    </Dialog>
  );
}
