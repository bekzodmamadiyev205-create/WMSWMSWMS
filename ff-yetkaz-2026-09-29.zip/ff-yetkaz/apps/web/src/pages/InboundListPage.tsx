import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import type { AsnDto } from '@ff/shared';
import { ApiError } from '@/lib/api';
import { inboundApi } from '@/lib/inbound';
import { mdmApi } from '@/lib/mdm';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ConfirmDialog } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';

interface DraftLine {
  skuId: string;
  expectedQty: string;
}

/** Что подтверждаем: закрытие заявки с недовозом или её отмену целиком. */
type AsnDecision = { asn: AsnDto; action: 'close' | 'cancel' };

export function InboundListPage(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const [sellerId, setSellerId] = React.useState('');
  const [warehouseId, setWarehouseId] = React.useState('');
  const [externalRef, setExternalRef] = React.useState('');
  const [lines, setLines] = React.useState<DraftLine[]>([{ skuId: '', expectedQty: '' }]);
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [creating, setCreating] = React.useState(false);
  const [decision, setDecision] = React.useState<AsnDecision | null>(null);

  const asns = useQuery({ queryKey: ['inbound', 'asns'], queryFn: () => inboundApi.asns() });
  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const warehouses = useQuery({ queryKey: ['mdm', 'warehouses'], queryFn: mdmApi.warehouses });

  const seller = sellerId || sellers.data?.[0]?.id || '';
  const warehouse = warehouseId || warehouses.data?.[0]?.id || '';

  const skus = useQuery({
    queryKey: ['mdm', 'skus', seller, ''],
    queryFn: () => mdmApi.skus({ sellerId: seller }),
    enabled: Boolean(seller) && creating,
  });
  const skuById = React.useMemo(
    () => new Map((skus.data ?? []).map((sku) => [sku.id, sku])),
    [skus.data],
  );

  const fail = (error: unknown) =>
    setMessage({
      kind: 'error',
      text: error instanceof ApiError ? error.message : t('common.error.network'),
    });

  const create = useMutation({
    mutationFn: async () => {
      const payload = lines
        .filter((line) => line.skuId && Number(line.expectedQty) > 0)
        .map((line) => ({ skuId: line.skuId, expectedQty: Number(line.expectedQty) }));
      if (payload.length === 0) throw new Error(t('inbound.error.noLines'));

      const asn = await inboundApi.createAsn({
        sellerId: seller,
        warehouseId: warehouse,
        externalRef: externalRef.trim() || undefined,
        lines: payload,
      });
      // Заявка сразу отправляется: черновик на складе никому не нужен, приёмку
      // по нему всё равно не открыть.
      return inboundApi.submitAsn(asn.id);
    },
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('inbound.created') });
      setLines([{ skuId: '', expectedQty: '' }]);
      setExternalRef('');
      setCreating(false);
      queryClient.invalidateQueries({ queryKey: ['inbound', 'asns'] });
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : (error as Error).message,
      }),
  });

  /**
   * Закрытие с недовозом и отмена — единственный способ убрать заявку из очереди
   * склада: сама она закрывается только при полном выполнении плана (решение PM
   * «расхождения не блокируют приёмку»), и недовоз иначе висит в RECEIVING вечно.
   */
  const decide = useMutation({
    mutationFn: ({ asn, action }: AsnDecision) =>
      action === 'close' ? inboundApi.closeAsn(asn.id) : inboundApi.cancelAsn(asn.id),
    onSuccess: (_asn, variables) => {
      setDecision(null);
      setMessage({
        kind: 'ok',
        text: variables.action === 'close' ? t('inbound.closedShort') : t('inbound.cancelledShort'),
      });
      queryClient.invalidateQueries({ queryKey: ['inbound'] });
    },
    onError: (error) => {
      setDecision(null);
      fail(error);
    },
  });

  const startReceipt = useMutation({
    mutationFn: (asnId: string) => inboundApi.createReceipt(asnId),
    onSuccess: (receipt) => {
      queryClient.invalidateQueries({ queryKey: ['inbound'] });
      navigate(`/inbound/${receipt.id}`);
    },
    onError: fail,
  });

  const open = (asns.data ?? []).filter(
    (asn) => asn.status === 'SUBMITTED' || asn.status === 'RECEIVING',
  );
  const closed = (asns.data ?? []).filter(
    (asn) => asn.status === 'COMPLETED' || asn.status === 'CANCELLED',
  );

  return (
    <div className="mx-auto max-w-3xl space-y-5 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('inbound.title')}</h1>
        <Link to="/" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>

      {message && (
        <p
          role="status"
          className={
            message.kind === 'ok'
              ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
              : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
          }
        >
          {message.text}
        </p>
      )}

      {!creating && (
        <Button onClick={() => setCreating(true)}>{t('inbound.newAsn')}</Button>
      )}

      {creating && (
        <Card>
          <CardContent className="space-y-3 p-4">
            <div className="text-sm font-medium">{t('inbound.newAsn')}</div>
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1">
                <Label htmlFor="asn-seller">{t('inbound.seller')}</Label>
                <Select id="asn-seller" value={seller} onChange={(e) => setSellerId(e.target.value)}>
                  {(sellers.data ?? []).map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.code}
                    </option>
                  ))}
                </Select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="asn-wh">{t('inbound.warehouse')}</Label>
                <Select id="asn-wh" value={warehouse} onChange={(e) => setWarehouseId(e.target.value)}>
                  {(warehouses.data ?? []).map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.code}
                    </option>
                  ))}
                </Select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="asn-ref">{t('inbound.externalRef')}</Label>
                <Input
                  id="asn-ref"
                  value={externalRef}
                  onChange={(event) => setExternalRef(event.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              {lines.map((line, index) => {
                // Товар без штрихкода принимается по строке заявки — это предупреждение,
                // а не запрет: заводить код ради поставки приёмщика не заставляем.
                const withoutBarcode = skuById.get(line.skuId)?.barcodes.length === 0;
                return (
                  <div key={index} className="space-y-1">
                    <div className="flex gap-2">
                      <Select
                        className="flex-1"
                        value={line.skuId}
                        onChange={(event) => {
                          const next = [...lines];
                          next[index] = { ...line, skuId: event.target.value };
                          setLines(next);
                        }}
                      >
                        <option value="">{t('inbound.selectSku')}</option>
                        {(skus.data ?? []).map((sku) => (
                          <option key={sku.id} value={sku.id}>
                            {sku.skuCode} — {sku.name}
                            {sku.barcodes.length === 0 ? ` · ${t('inbound.form.noBarcodeShort')}` : ''}
                          </option>
                        ))}
                      </Select>
                      <Input
                        className="w-24"
                        inputMode="numeric"
                        placeholder={t('inbound.qtyShort')}
                        value={line.expectedQty}
                        onChange={(event) => {
                          const next = [...lines];
                          next[index] = {
                            ...line,
                            expectedQty: event.target.value.replace(/[^\d]/g, ''),
                          };
                          setLines(next);
                        }}
                      />
                      {lines.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setLines(lines.filter((_, i) => i !== index))}
                        >
                          ✕
                        </Button>
                      )}
                    </div>
                    {withoutBarcode && (
                      <p className="text-xs text-muted-foreground">
                        {t('inbound.form.noBarcodeWarning')}
                      </p>
                    )}
                  </div>
                );
              })}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLines([...lines, { skuId: '', expectedQty: '' }])}
              >
                {t('inbound.addLine')}
              </Button>
            </div>

            <div className="flex gap-2">
              <Button disabled={create.isPending} onClick={() => create.mutate()}>
                {t('inbound.createAsn')}
              </Button>
              <Button variant="ghost" onClick={() => setCreating(false)}>
                {t('common.cancel')}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <section className="space-y-2">
        <h2 className="text-sm font-medium text-muted-foreground">{t('inbound.awaiting')}</h2>
        {open.length === 0 && <p className="text-sm text-muted-foreground">{t('inbound.noAsns')}</p>}
        {open.map((asn) => {
          const expected = asn.lines.reduce((sum, line) => sum + line.expectedQty, 0);
          const received = asn.lines.reduce((sum, line) => sum + line.receivedQty, 0);
          return (
            <Card key={asn.id}>
              <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div className="min-w-0">
                  <div className="font-medium">
                    {asn.externalRef ?? t('inbound.asnFallback', { id: asn.id.slice(0, 8) })}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {t(`inbound.asnStatus.${asn.status}` as MessageKey)} ·{' '}
                    {t('inbound.asnSummary', { lines: asn.lines.length, received, expected })}
                    {asn.hasDiscrepancy && (
                      <span className="text-destructive"> · {t('inbound.discrepancy')}</span>
                    )}
                  </div>
                </div>
                <div className="flex shrink-0 flex-wrap gap-2">
                  <Button
                    disabled={startReceipt.isPending}
                    onClick={() => startReceipt.mutate(asn.id)}
                  >
                    {t('inbound.receive')}
                  </Button>
                  {/* Закрыть можно только начатую приёмку: из «ожидается» заявка
                      переходит лишь в приёмку или в отмену. */}
                  {asn.status === 'RECEIVING' && (
                    <Button
                      variant="outline"
                      onClick={() => setDecision({ asn, action: 'close' })}
                    >
                      {t('inbound.closeShort')}
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    className="text-destructive"
                    onClick={() => setDecision({ asn, action: 'cancel' })}
                  >
                    {t('inbound.cancelAsn')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </section>

      {closed.length > 0 && (
        <section className="space-y-2">
          <h2 className="text-sm font-medium text-muted-foreground">{t('inbound.closed')}</h2>
          {closed.slice(0, 10).map((asn) => (
            <Card key={asn.id}>
              <CardContent className="flex items-center justify-between gap-3 p-4 text-sm">
                <span>{asn.externalRef ?? asn.id.slice(0, 8)}</span>
                <span className="text-muted-foreground">
                  {t(`inbound.asnStatus.${asn.status}` as MessageKey)}
                  {asn.hasDiscrepancy && (
                    <span className="text-destructive"> · {t('inbound.discrepancy')}</span>
                  )}
                </span>
              </CardContent>
            </Card>
          ))}
        </section>
      )}

      <ConfirmDialog
        open={decision !== null}
        onClose={() => setDecision(null)}
        onConfirm={() => {
          if (decision) decide.mutate(decision);
        }}
        title={
          decision?.action === 'cancel' ? t('inbound.cancelAsn') : t('inbound.closeShort')
        }
        description={
          decision
            ? decision.action === 'cancel'
              ? t('inbound.cancelAsnConfirm', {
                  ref: decision.asn.externalRef ?? decision.asn.id.slice(0, 8),
                })
              : t('inbound.closeAsnConfirm', {
                  ref: decision.asn.externalRef ?? decision.asn.id.slice(0, 8),
                })
            : undefined
        }
        confirmLabel={
          decision?.action === 'cancel' ? t('inbound.cancelAsn') : t('inbound.closeShort')
        }
        cancelLabel={t('common.cancel')}
        danger={decision?.action === 'cancel'}
        busy={decide.isPending}
      />
    </div>
  );
}
