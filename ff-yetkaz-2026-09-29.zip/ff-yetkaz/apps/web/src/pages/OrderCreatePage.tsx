import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import type { OrderCategoryDto, OrderIntakeResultDto } from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { OrderStatusBadge } from '@/components/OrderStatusBadge';
import { OrderDetailModal } from '@/pages/OrderDetailPage';
import { UZ_REGIONS, districtsOf } from '@/lib/uzbekistan';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Barcode } from '@/components/Barcode';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';

interface DraftLine {
  skuId: string;
  quantity: string;
}

/**
 * Номер для заказа, принятого по телефону: у такого заказа нет номера в канале,
 * а естественный ключ (селлер + канал + номер) требует чего-то уникального.
 * Поле остаётся редактируемым — если номер у клиента есть, оператор его впишет.
 */
function suggestExternalId(): string {
  const now = new Date();
  const pad = (value: number) => String(value).padStart(2, '0');
  return [
    'M',
    `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`,
    `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`,
  ].join('-');
}

export function OrderCreatePage(): React.ReactElement {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { t } = useI18n();

  const [sellerId, setSellerId] = React.useState('');
  const [categoryId, setCategoryId] = React.useState('');
  const [form, setForm] = React.useState({
    channel: 'MANUAL',
    externalId: suggestExternalId(),
    recipientName: '',
    recipientPhone: '',
    address: '',
    region: '',
    district: '',
    weightKg: '',
    codAmount: '',
    currency: 'UZS',
  });
  const [search, setSearch] = React.useState('');
  const [lines, setLines] = React.useState<DraftLine[]>([{ skuId: '', quantity: '1' }]);
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [result, setResult] = React.useState<OrderIntakeResultDto | null>(null);
  const [detailOpen, setDetailOpen] = React.useState(false);

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const selected = sellerId || sellers.data?.[0]?.id || '';

  const categories = useQuery({
    queryKey: ['order-categories'],
    queryFn: () => apiFetch<OrderCategoryDto[]>('/order-categories'),
  });
  const category = (categories.data ?? []).find((item) => item.id === categoryId) ?? null;

  const skus = useQuery({
    queryKey: ['mdm', 'skus', selected, search],
    queryFn: () => mdmApi.skus({ sellerId: selected, q: search || undefined }),
    enabled: Boolean(selected),
  });

  const skuName = (id: string) => {
    const sku = skus.data?.find((item) => item.id === id);
    return sku ? `${sku.skuCode} — ${sku.name}` : id;
  };

  const create = useMutation({
    mutationFn: () => {
      const payload = lines
        .filter((line) => line.skuId && Number(line.quantity) > 0)
        .map((line) => ({ skuId: line.skuId, quantity: Number(line.quantity) }));
      if (payload.length === 0) throw new Error(t('orderCreate.errorNoLines'));
      if (new Set(payload.map((line) => line.skuId)).size !== payload.length) {
        throw new Error(t('orderCreate.errorDupSku'));
      }
      // Валюта имеет смысл только вместе с суммой COD: без суммы её не отправляем.
      const codAmount = form.codAmount.trim();
      const currency = form.currency.trim().toUpperCase();
      if (codAmount && !currency) throw new Error(t('orderCreate.errorNoCurrency'));

      return apiFetch<OrderIntakeResultDto>('/orders', {
        method: 'POST',
        body: {
          sellerId: selected,
          channel: form.channel.trim() || 'MANUAL',
          externalId: form.externalId.trim(),
          recipientName: form.recipientName.trim(),
          recipientPhone: form.recipientPhone.trim(),
          address: form.address.trim(),
          // Область и район храним вместе в свободнотекстовом `region`: «Область, Район».
          region: [form.region.trim(), form.district.trim()].filter(Boolean).join(', ') || undefined,
          codAmount: codAmount || undefined,
          currency: codAmount ? currency || undefined : undefined,
          weightKg: form.weightKg.trim() || undefined,
          // Категория необязательна: пустую строку отправлять нельзя — сервер
          // ждёт либо идентификатор, либо отсутствие поля.
          categoryId: categoryId || undefined,
          lines: payload,
        },
      });
    },
    onSuccess: (intake) => {
      setResult(intake);
      setMessage(
        intake.duplicate
          ? { kind: 'error', text: t('orderCreate.duplicate') }
          : { kind: 'ok', text: t('orderCreate.accepted') },
      );
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : (error as Error).message,
      }),
  });

  const startAnother = () => {
    setResult(null);
    setMessage(null);
    setForm({ ...form, externalId: suggestExternalId(), recipientName: '', recipientPhone: '', address: '', weightKg: '', codAmount: '' });
    setLines([{ skuId: '', quantity: '1' }]);
  };

  if (result) {
    const order = result.order;
    return (
      <div className="mx-auto max-w-2xl space-y-4 p-4">
        <h1 className="text-xl font-semibold tracking-tight">
          {t('orderCreate.orderTitle')}{' '}
          <button
            type="button"
            onClick={() => setDetailOpen(true)}
            className="text-primary underline-offset-2 hover:underline"
          >
            {order.externalId}
          </button>
        </h1>
        <Card>
          <CardContent className="flex flex-col items-center gap-2 p-4">
            <div className="text-sm text-muted-foreground">{t('order.codeAssigned')}</div>
            <div className="font-mono text-2xl font-bold tracking-wider">{order.orderCode}</div>
            <Barcode value={order.orderCode} />
            <div className="text-xs text-muted-foreground">
              {t('order.clientNumber')}: {order.externalId}
            </div>
          </CardContent>
        </Card>
        {message && (
          <p
            className={
              message.kind === 'ok'
                ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
                : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
            }
          >
            {message.text}
          </p>
        )}
        <Card>
          <CardContent className="space-y-2 p-4 text-sm">
            <div className="flex items-center gap-2">
              <span>{t('orderCreate.statusLabel')}:</span>
              <OrderStatusBadge status={order.status} size="sm" />
            </div>
            <div>
              {order.recipientName} · {order.recipientPhone} · {order.address}
            </div>
            <div className="text-muted-foreground">
              {order.lines.map((line) => `${line.skuCode} × ${line.quantity}`).join(', ')}
            </div>
            {order.isSplit && (
              <div>{t('orderCreate.splitInfo', { n: order.children.length })}</div>
            )}
            {result.shortages.length > 0 && (
              <div className="text-destructive">
                {t('orderCreate.shortageTitle')}{' '}
                {result.shortages
                  .map((shortage) =>
                    t('orderCreate.shortageItem', {
                      name: skuName(shortage.skuId),
                      requested: shortage.requested,
                      available: shortage.available,
                    }),
                  )
                  .join('; ')}
                {t('orderCreate.shortageHint')}
              </div>
            )}
          </CardContent>
        </Card>
        <div className="flex gap-2">
          <Button onClick={startAnother}>{t('orderCreate.createAnother')}</Button>
          <Button variant="outline" onClick={() => navigate('/orders')}>
            {t('orderCreate.toOrderList')}
          </Button>
        </div>

        {detailOpen && <OrderDetailModal id={order.id} onClose={() => setDetailOpen(false)} />}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl space-y-4 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('orderCreate.title')}</h1>
        <Link to="/orders" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>

      {message && (
        <p
          role="status"
          className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive"
        >
          {message.text}
        </p>
      )}

      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="new-seller">{t('orderCreate.seller')}</Label>
              <Select
                id="new-seller"
                value={selected}
                onChange={(event) => setSellerId(event.target.value)}
              >
                {(sellers.data ?? []).map((seller) => (
                  <option key={seller.id} value={seller.id}>
                    {seller.code} — {seller.legalName}
                  </option>
                ))}
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="new-channel">{t('orderCreate.channel')}</Label>
              <Input
                id="new-channel"
                value={form.channel}
                onChange={(event) => setForm({ ...form, channel: event.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="new-external">{t('orderCreate.externalId')}</Label>
              <Input
                id="new-external"
                value={form.externalId}
                onChange={(event) => setForm({ ...form, externalId: event.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="new-category">{t('orderCreate.category')}</Label>
              <div className="flex items-center gap-2">
                {/* Точка показывает цвет метки из справочника — в нативном
                    <option> его нарисовать нечем, а по цвету категорию и узнают. */}
                <span
                  aria-hidden="true"
                  className="h-2.5 w-2.5 shrink-0 rounded-full ring-1 ring-inset ring-black/10"
                  style={{ backgroundColor: category?.color ?? 'hsl(var(--muted-foreground))' }}
                />
                <Select
                  id="new-category"
                  className="flex-1"
                  value={categoryId}
                  onChange={(event) => setCategoryId(event.target.value)}
                >
                  <option value="">{t('orderCreate.categoryNone')}</option>
                  {(categories.data ?? []).map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                    </option>
                  ))}
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="text-sm font-medium">{t('orderCreate.recipient')}</div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="new-name">{t('orderCreate.name')}</Label>
              <Input
                id="new-name"
                value={form.recipientName}
                onChange={(event) => setForm({ ...form, recipientName: event.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="new-phone">{t('orderCreate.phone')}</Label>
              <Input
                id="new-phone"
                value={form.recipientPhone}
                placeholder="+998901112233"
                onChange={(event) => setForm({ ...form, recipientPhone: event.target.value })}
              />
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="new-address">{t('orderCreate.address')}</Label>
            <Input
              id="new-address"
              value={form.address}
              onChange={(event) => setForm({ ...form, address: event.target.value })}
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="new-region">{t('orderCreate.region')}</Label>
              <Select
                id="new-region"
                value={form.region}
                onChange={(event) =>
                  // Сменили область — район сбрасываем: прежний к новой области не относится.
                  setForm({ ...form, region: event.target.value, district: '' })
                }
              >
                <option value="">{t('orderCreate.regionPlaceholder')}</option>
                {UZ_REGIONS.map((region) => (
                  <option key={region.name} value={region.name}>
                    {region.name}
                  </option>
                ))}
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="new-district">{t('orderCreate.district')}</Label>
              <Select
                id="new-district"
                value={form.district}
                disabled={!form.region}
                onChange={(event) => setForm({ ...form, district: event.target.value })}
              >
                <option value="">{form.region ? t('orderCreate.districtPlaceholder') : t('orderCreate.districtFirstRegion')}</option>
                {districtsOf(form.region).map((district) => (
                  <option key={district} value={district}>
                    {district}
                  </option>
                ))}
              </Select>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label htmlFor="new-weight">{t('orderCreate.weight')}</Label>
              <Input
                id="new-weight"
                inputMode="decimal"
                placeholder="0.000"
                value={form.weightKg}
                onChange={(event) =>
                  setForm({ ...form, weightKg: event.target.value.replace(/[^\d.,]/g, '').replace(',', '.') })
                }
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="new-cod">{t('orderCreate.cod')}</Label>
              <Input
                id="new-cod"
                inputMode="decimal"
                value={form.codAmount}
                onChange={(event) =>
                  setForm({ ...form, codAmount: event.target.value.replace(/[^\d.,]/g, '').replace(',', '.') })
                }
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="new-currency">{t('orderCreate.currency')}</Label>
              <Select
                id="new-currency"
                value={form.currency}
                onChange={(event) => setForm({ ...form, currency: event.target.value })}
              >
                <option value="UZS">{t('orderCreate.currencyUZS')}</option>
                <option value="USD">{t('orderCreate.currencyUSD')}</option>
                <option value="EUR">{t('orderCreate.currencyEUR')}</option>
                <option value="RUB">{t('orderCreate.currencyRUB')}</option>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="flex items-center justify-between gap-2">
            <div className="text-sm font-medium">{t('orderCreate.linesTitle')}</div>
            <Input
              className="w-56"
              value={search}
              placeholder={t('orderCreate.searchBySku')}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>

          {lines.map((line, index) => (
            <div key={index} className="flex gap-2">
              <Select
                className="flex-1"
                value={line.skuId}
                onChange={(event) => {
                  const next = [...lines];
                  next[index] = { ...line, skuId: event.target.value };
                  setLines(next);
                }}
              >
                <option value="">{t('orderCreate.skuPlaceholder')}</option>
                {(skus.data ?? []).map((sku) => (
                  <option key={sku.id} value={sku.id}>
                    {sku.skuCode} — {sku.name}
                  </option>
                ))}
              </Select>
              <Input
                className="w-24"
                inputMode="numeric"
                value={line.quantity}
                onChange={(event) => {
                  const next = [...lines];
                  next[index] = { ...line, quantity: event.target.value.replace(/[^\d]/g, '') };
                  setLines(next);
                }}
              />
              {lines.length > 1 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setLines(lines.filter((_, i) => i !== index))}
                >
                  ✕
                </Button>
              )}
            </div>
          ))}

          <Button
            variant="outline"
            size="sm"
            onClick={() => setLines([...lines, { skuId: '', quantity: '1' }])}
          >
            {t('orderCreate.addLine')}
          </Button>
        </CardContent>
      </Card>

      <Button className="w-full" disabled={create.isPending} onClick={() => create.mutate()}>
        {t('orderCreate.submit')}
      </Button>
    </div>
  );
}
