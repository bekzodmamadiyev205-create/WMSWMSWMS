import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import { ApiError } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { packingApi } from '@/lib/packing';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export function PackingQueuePage(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [error, setError] = React.useState<string | null>(null);

  const queue = useQuery({ queryKey: ['packing', 'queue'], queryFn: packingApi.queue });

  const take = useMutation({
    mutationFn: (orderId: string) => packingApi.start(orderId),
    onSuccess: (pkg) => {
      queryClient.invalidateQueries({ queryKey: ['packing'] });
      navigate(`/packing/${pkg.id}`);
    },
    onError: (err) =>
      setError(err instanceof ApiError ? err.message : t('common.error.network')),
  });

  const items = queue.data ?? [];

  return (
    <div className="mx-auto max-w-xl space-y-6 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('packing.title')}</h1>
        <Link to="/" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>

      {error && (
        <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {error}
        </p>
      )}

      {queue.isLoading && <p className="text-sm text-muted-foreground">{t('packing.loadingQueue')}</p>}
      {queue.isError && (
        <div className="space-y-2">
          <p className="text-sm text-destructive">{t('packing.loadError')}</p>
          <Button variant="outline" size="sm" onClick={() => queue.refetch()}>
            {t('common.retry')}
          </Button>
        </div>
      )}
      {!queue.isLoading && !queue.isError && items.length === 0 && (
        <p className="text-sm text-muted-foreground">{t('packing.empty')}</p>
      )}

      <div className="space-y-3">
        {items.map((item) => (
          <Card key={item.orderId}>
            <CardContent className="flex items-center justify-between gap-3 p-4">
              <div className="min-w-0">
                <div className="font-medium">
                  {item.externalId}
                  <span className="text-muted-foreground"> · {item.channel}</span>
                </div>
                <div className="truncate text-sm text-muted-foreground">{item.recipientName}</div>
                <div className="text-sm text-muted-foreground">
                  {t('packing.queue.counts', { items: item.itemsCount, units: item.unitsCount })}
                  {item.hasShortage && (
                    <span className="text-destructive"> · {t('packing.shortage')}</span>
                  )}
                </div>
              </div>
              {item.packageId ? (
                <Button className="shrink-0" onClick={() => navigate(`/packing/${item.packageId}`)}>
                  {t('packing.continue')}
                </Button>
              ) : (
                <Button
                  variant="outline"
                  className="shrink-0"
                  disabled={take.isPending}
                  onClick={() => {
                    setError(null);
                    take.mutate(item.orderId);
                  }}
                >
                  {t('packing.pack')}
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
