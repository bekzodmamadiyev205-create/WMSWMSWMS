import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import type {
  AnalyticsGranularity,
  AnalyticsMetricDto,
  AnalyticsOverviewDto,
  MetricDto,
  OrderStatus,
  PageDto,
  Role,
  StockTableRowDto,
} from '@ff/shared';
import { ORDER_STATUSES } from '@ff/shared';
import { apiFetch } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { dashboardApi } from '@/lib/dashboard';
import { daysInRange, parseIso, presetRange, rangeToQuery, type DateRange } from '@/lib/date-range';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import { Icon, type IconName } from '@/components/icons';
import { Button } from '@/components/ui/button';
import { CHART_COLORS, DonutChart, LineChart, type DonutSlice } from '@/components/ui/charts';
import { DataTable, type DataTableColumn } from '@/components/ui/data-table';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { EmptyState } from '@/components/ui/empty-state';
import { KpiCard, KpiGrid, type KpiTone } from '@/components/ui/kpi-card';
import { PageContainer, PageHeader } from '@/components/ui/page-header';

/**
 * Главная панель. Все агрегаты приходят готовыми с сервера.
 *
 * Прежняя версия строила «динамику за 7 дней» на клиенте из `GET /orders`,
 * который отдаёт максимум одну страницу заказов: на 101-м заказе график
 * начинал показывать не динамику склада, а динамику первой сотни строк —
 * молча и без единой ошибки в консоли. Ровно так же сортировался «топ
 * остатков». Обе витрины теперь берутся из BI-ручек, где считает SQL.
 */

type Translate = (key: MessageKey, params?: Record<string, string | number>) => string;

/** Роли, которым бэкенд отдаёт сводку склада и BI-обзор. */
const OPS_ROLES: readonly Role[] = ['ADMIN', 'WAREHOUSE_OPERATOR', 'FINANCE'];

interface KpiSpec {
  metric: string;
  label: MessageKey;
  icon: IconName;
  tone: KpiTone;
  /** Ключ ряда в `series` для спарклайна; без него плитка остаётся плоской. */
  series?: string;
}

const KPI_SPECS: readonly KpiSpec[] = [
  { metric: 'orders', label: 'dash.kpi.orders', icon: 'orders', tone: 'default', series: 'orders' },
  { metric: 'delivered', label: 'dash.kpi.delivered', icon: 'check', tone: 'success', series: 'delivered' },
  { metric: 'revenue', label: 'dash.kpi.revenue', icon: 'chart', tone: 'info', series: 'revenue' },
  // У доли возвратов и передач перевозчику своего ряда в `series` нет, а
  // считать процент по дням на клиенте — та же ошибка, из-за которой
  // переписывалась эта страница. Плитки живут без спарклайна.
  { metric: 'returnRatePct', label: 'dash.kpi.returnRate', icon: 'alert', tone: 'warning' },
  { metric: 'dispatchedCount', label: 'dash.kpi.dispatched', icon: 'truck', tone: 'default' },
];

/** Куда ведёт очередь передела. */
const QUEUE_TARGET: Record<string, string> = {
  asn_receiving: '/inbound',
  orders_to_pick: '/picking',
  tasks_in_progress: '/picking',
  orders_to_pack: '/packing',
  shipments_to_handover: '/packing',
};

const QUEUE_ICON: Record<string, IconName> = {
  asn_receiving: 'inbound',
  orders_to_pick: 'picking',
  tasks_in_progress: 'picking',
  orders_to_pack: 'packing',
  shipments_to_handover: 'truck',
};

/** Куда идти разбирать проблему. Плитка без адреса бесполезна. */
const PROBLEM_TARGET: Record<string, string> = {
  orders_shortage: '/orders',
  weight_mismatch: '/packing',
  quarantine_units: '/stock',
  outbox_failed: '/orders',
  webhooks_rejected: '/orders',
  billing_problems: '/tariffs',
  storage_snapshot_gaps: '/tariffs',
  cod_short: '/tariffs',
};

interface QuickAction {
  to: string;
  label: MessageKey;
  icon: IconName;
  /** Пусто — видно всем. */
  roles?: readonly Role[];
}

const QUICK_ACTIONS: readonly QuickAction[] = [
  { to: '/inbound', label: 'dash.quick.inbound', icon: 'inbound', roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'RECEIVER'] },
  { to: '/picking', label: 'dash.quick.picking', icon: 'picking', roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'PICKER'] },
  { to: '/packing', label: 'dash.quick.packing', icon: 'packing', roles: ['ADMIN', 'WAREHOUSE_OPERATOR', 'PACKER'] },
  { to: '/orders/new', label: 'dash.quick.newOrder', icon: 'plus', roles: ['ADMIN', 'WAREHOUSE_OPERATOR'] },
  { to: '/returns', label: 'dash.quick.returns', icon: 'truck', roles: ['ADMIN', 'WAREHOUSE_OPERATOR'] },
  { to: '/analytics', label: 'dash.quick.analytics', icon: 'chart', roles: ['ADMIN', 'FINANCE'] },
];

/* ─────────────────────────────── вспомогательное ─────────────────────────── */

/** Название метрики: перевод по ключу, незнакомый ключ — заголовок бэкенда. */
function metricTitle(t: Translate, metric: MetricDto): string {
  const key = `metric.${metric.key}` as MessageKey;
  const translated = t(key);
  return translated === key ? metric.title : translated;
}

/** Статус заказа: словарь, а если статуса в нём нет — сырое значение, не ключ. */
function statusLabel(t: Translate, status: string): string {
  const key = `status.${status}` as MessageKey;
  const translated = t(key);
  return translated === key ? status : translated;
}

/**
 * Палитра из шести токенов, статусов двенадцать: цвет закреплён за позицией в
 * каноническом списке. Иначе он «прыгал» бы между рендерами, стоило одному
 * статусу исчезнуть из выборки.
 */
function statusColor(status: string): string {
  const index = ORDER_STATUSES.indexOf(status as OrderStatus);
  return CHART_COLORS[(index < 0 ? 0 : index) % CHART_COLORS.length];
}

/**
 * Шаг ряда по длине периода. Сервер отказывается строить больше 400 интервалов,
 * да и 365 точек в 600 пикселей всё равно не читаются.
 */
function pickGranularity(range: DateRange): AnalyticsGranularity {
  const days = daysInRange(range);
  if (days === null || days > 180) return 'month';
  if (days > 45) return 'week';
  return 'day';
}

function numberFormat(language: string, digits = 0): Intl.NumberFormat {
  return new Intl.NumberFormat(language, { maximumFractionDigits: digits });
}

function formatMoney(value: number, currency: string | null, language: string): string {
  if (!currency) return numberFormat(language).format(value);
  try {
    return new Intl.NumberFormat(language, {
      style: 'currency',
      currency,
      maximumFractionDigits: 0,
    }).format(value);
  } catch {
    // Неизвестный код валюты роняет Intl целиком — плитка не должна исчезать из-за подписи.
    return `${numberFormat(language).format(value)} ${currency}`;
  }
}

/** Метрика приходит строкой (деньги через float недопустимы) — разбираем здесь. */
function metricNumber(metric: AnalyticsMetricDto | undefined): number {
  const parsed = Number(metric?.value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function formatMetric(metric: AnalyticsMetricDto | undefined, language: string): string {
  if (!metric) return '—';
  const value = metricNumber(metric);
  switch (metric.format) {
    case 'money':
      return formatMoney(value, metric.currency ?? null, language);
    case 'percent':
      return `${numberFormat(language, 1).format(value)}%`;
    case 'weight':
      return numberFormat(language, 1).format(value);
    default:
      return numberFormat(language).format(value);
  }
}

function metricDelta(
  metric: AnalyticsMetricDto | undefined,
): { value: number; suffix: string; positiveIsGood: boolean } | undefined {
  if (!metric || metric.changePct === null) return undefined;
  const change = Number(metric.changePct);
  if (!Number.isFinite(change)) return undefined;
  return { value: change, suffix: '%', positiveIsGood: metric.positiveIsGood };
}

/** Подпись точки ряда: день и месяц, а для месячного шага — месяц и год. */
function bucketLabel(bucket: string, granularity: AnalyticsGranularity, t: Translate): string {
  const date = parseIso(bucket.slice(0, 10));
  const month = t(`ui.month.${date.getMonth() + 1}` as MessageKey);
  if (granularity === 'month') return `${month} ${String(date.getFullYear()).slice(2)}`;
  return `${date.getDate()} ${month}`;
}

function seriesValues(overview: AnalyticsOverviewDto | undefined, key: string): number[] {
  if (!overview) return [];
  return overview.series.map((point) => {
    const parsed = Number(point.values[key]);
    return Number.isFinite(parsed) ? parsed : 0;
  });
}

function greetingKey(hour: number): MessageKey {
  if (hour < 5) return 'dash.greeting.night';
  if (hour < 12) return 'dash.greeting.morning';
  if (hour < 18) return 'dash.greeting.day';
  return 'dash.greeting.evening';
}

/** Запрос BI-обзора. Обёртки в `lib/` для этих ручек пока нет — зовём напрямую. */
function fetchOverview(
  path: 'overview' | 'seller-summary',
  range: DateRange,
  granularity: AnalyticsGranularity,
): Promise<AnalyticsOverviewDto> {
  const query = new URLSearchParams({ ...rangeToQuery(range), granularity });
  return apiFetch<AnalyticsOverviewDto>(`/analytics/${path}?${query.toString()}`);
}

/** Топ остатков сортирует сервер: сортировка выданной страницы врала бы. */
function fetchTopStock(limit: number): Promise<PageDto<StockTableRowDto>> {
  const query = new URLSearchParams({
    status: 'AVAILABLE',
    sort: 'quantity',
    direction: 'desc',
    page: '1',
    pageSize: String(limit),
  });
  return apiFetch<PageDto<StockTableRowDto>>(`/inventory/stock/table?${query.toString()}`);
}

/* ─────────────────────────────── мелкие блоки ────────────────────────────── */

function Section({
  title,
  hint,
  action,
  children,
  className,
}: {
  title: string;
  hint?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}): React.ReactElement {
  return (
    <section className={cn('space-y-3', className)}>
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <div className="min-w-0">
          <h2 className="text-sm font-semibold text-foreground">{title}</h2>
          {hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

/** Сбой запроса не должен оставлять пустое место: видно, что сломалось и как повторить. */
function ErrorCard({
  message,
  onRetry,
  className,
}: {
  message: string;
  onRetry: () => void;
  className?: string;
}): React.ReactElement {
  const { t } = useI18n();
  return (
    <div
      role="alert"
      className={cn(
        'premium-card flex flex-wrap items-center gap-3 border-destructive/30 bg-destructive/5 p-4',
        className,
      )}
    >
      <span className="text-destructive">{Icon.alert('h-5 w-5')}</span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-foreground">{t('dash.error.title')}</p>
        {/* Сообщение сервера бывает пустым — тогда хотя бы объясняем, что делать. */}
        <p className="truncate text-xs text-muted-foreground">{message || t('dash.error.text')}</p>
      </div>
      <Button variant="outline" size="sm" onClick={onRetry}>
        {t('ui.retry')}
      </Button>
    </div>
  );
}

function QuickActionsGrid({ actions }: { actions: readonly QuickAction[] }): React.ReactElement {
  const { t } = useI18n();
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
      {actions.map((action) => (
        <Link
          key={action.to}
          to={action.to}
          className={cn(
            'premium-card flex items-center gap-3 p-4 transition-all duration-150',
            'hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md',
            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
          )}
        >
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
            {Icon[action.icon]('h-4 w-4')}
          </span>
          <span className="truncate text-sm font-medium">{t(action.label)}</span>
        </Link>
      ))}
    </div>
  );
}

/* ──────────────────────────────── страница ───────────────────────────────── */

export function DashboardPage(): React.ReactElement {
  const { user } = useAuth();
  const { t, language } = useI18n();
  const navigate = useNavigate();

  const roles = React.useMemo<readonly Role[]>(() => user?.roles ?? [], [user]);
  const canOps = roles.some((role) => OPS_ROLES.includes(role));
  const isSeller = Boolean(user?.sellerId);

  const [range, setRange] = React.useState<DateRange>(() => presetRange('last7'));
  const granularity = pickGranularity(range);

  // Селлеру та же витрина отдаётся отдельной ручкой — со скоупом из токена.
  const overviewPath: 'overview' | 'seller-summary' = canOps ? 'overview' : 'seller-summary';
  const overview = useQuery({
    queryKey: ['dashboard', 'overview', overviewPath, range.from, range.to, granularity],
    queryFn: () => fetchOverview(overviewPath, range, granularity),
    enabled: canOps || isSeller,
  });

  const ops = useQuery({
    queryKey: ['dashboard', 'ops'],
    queryFn: dashboardApi.ops,
    enabled: canOps,
    refetchInterval: 60_000,
  });

  const topStock = useQuery({
    queryKey: ['dashboard', 'topStock'],
    queryFn: () => fetchTopStock(5),
    enabled: canOps,
  });

  const quickActions = React.useMemo(() => {
    const visible = QUICK_ACTIONS.filter(
      (action) => !action.roles || action.roles.some((role) => roles.includes(role)),
    );
    return isSeller
      ? [...visible, { to: '/seller', label: 'nav.seller' as MessageKey, icon: 'store' as IconName }]
      : visible;
  }, [roles, isSeller]);

  // Имя из профиля, а если его нет — почта: приветствие с пустым местом после
  // запятой выглядит как незагрузившийся экран.
  const greeting = t(greetingKey(new Date().getHours()), {
    name: user?.fullName?.trim() || user?.email || '',
  });

  const metricsByKey = React.useMemo(() => {
    const map = new Map<string, AnalyticsMetricDto>();
    for (const metric of overview.data?.metrics ?? []) map.set(metric.key, metric);
    return map;
  }, [overview.data]);

  const kpiCards = KPI_SPECS.map((spec) => {
    const metric = metricsByKey.get(spec.metric);
    const spark = spec.series ? seriesValues(overview.data, spec.series) : undefined;
    return (
      <KpiCard
        key={spec.metric}
        label={t(spec.label)}
        value={formatMetric(metric, language)}
        delta={metricDelta(metric)}
        hint={metric?.changePct ? t('dash.kpi.prevPeriod') : undefined}
        icon={Icon[spec.icon]()}
        tone={spec.tone}
        spark={spark && spark.length > 1 ? spark : undefined}
        loading={overview.isLoading}
      />
    );
  });

  const datePicker = <DateRangePicker value={range} onChange={setRange} align="end" compact />;

  /* ── Ветка без права на сводку: сборщик, упаковщик, приёмщик, селлер ── */
  if (!canOps) {
    return (
      <PageContainer>
        <PageHeader
          title={greeting}
          description={t('dash.tasks.hint')}
          icon={Icon.home()}
          actions={isSeller ? datePicker : undefined}
        />

        {isSeller ? (
          <Section title={t('dash.seller.title')}>
            {overview.isError ? (
              <ErrorCard
                message={(overview.error as Error).message}
                onRetry={() => void overview.refetch()}
              />
            ) : (
              <KpiGrid className="lg:grid-cols-5">{kpiCards}</KpiGrid>
            )}
          </Section>
        ) : null}

        <Section title={t('dash.tasks.title')}>
          <QuickActionsGrid actions={quickActions} />
        </Section>
      </PageContainer>
    );
  }

  /* ── Полная сводка ── */
  const queues = ops.data?.queues ?? [];
  const problems = (ops.data?.problems ?? []).filter((metric) => metric.value > 0);

  const statusRows = (overview.data?.ordersByStatus ?? []).filter((row) => row.count > 0);
  const statusTotal = statusRows.reduce((sum, row) => sum + row.count, 0);
  const slices: DonutSlice[] = statusRows.map((row) => ({
    key: row.status,
    name: statusLabel(t, row.status),
    value: row.count,
    color: statusColor(row.status),
  }));

  const points = (overview.data?.series ?? []).map((point) => ({
    label: bucketLabel(point.bucket, granularity, t),
    values: {
      orders: Number(point.values.orders) || 0,
      delivered: Number(point.values.delivered) || 0,
    },
  }));

  const stockColumns: Array<DataTableColumn<StockTableRowDto>> = [
    {
      key: 'skuCode',
      header: t('dash.col.sku'),
      cell: (row) => <span className="font-medium">{row.skuCode}</span>,
      width: '30%',
    },
    {
      key: 'skuName',
      header: t('dash.col.name'),
      cell: (row) => <span className="block truncate text-muted-foreground">{row.skuName}</span>,
    },
    {
      key: 'warehouseCode',
      header: t('dash.col.warehouse'),
      cell: (row) => <span className="text-muted-foreground">{row.warehouseCode}</span>,
      width: '18%',
      hideable: true,
    },
    {
      key: 'available',
      header: t('dash.col.available'),
      align: 'right',
      width: '18%',
      cell: (row) => (
        <span className="font-semibold tabular-nums">
          {numberFormat(language).format(row.available)}
        </span>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title={greeting}
        description={t('dash.subtitle')}
        icon={Icon.home()}
        actions={datePicker}
      />

      {overview.isError ? (
        <ErrorCard
          message={(overview.error as Error).message}
          onRetry={() => void overview.refetch()}
        />
      ) : (
        <KpiGrid className="lg:grid-cols-5">{kpiCards}</KpiGrid>
      )}

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <Section title={t('dash.dynamics.title')} hint={t('dash.dynamics.hint')}>
            {overview.isError ? (
              <ErrorCard
                message={(overview.error as Error).message}
                onRetry={() => void overview.refetch()}
              />
            ) : (
              <div className="premium-card p-4">
                {overview.isLoading ? (
                  <div className="h-[260px] animate-pulse rounded-lg bg-muted/60" />
                ) : (
                  <LineChart
                    points={points}
                    series={[
                      { key: 'orders', name: t('dash.series.orders'), color: CHART_COLORS[0] },
                      { key: 'delivered', name: t('dash.series.delivered'), color: CHART_COLORS[3] },
                    ]}
                    height={260}
                    area
                    curved
                    legend
                    formatValue={(value) => numberFormat(language).format(value)}
                  />
                )}
              </div>
            )}
          </Section>

          <Section
            title={t('dash.topStock.title')}
            hint={t('dash.topStock.hint')}
            action={
              <Link
                to="/stock"
                className="rounded text-xs font-medium text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                {t('dash.topStock.all')} →
              </Link>
            }
          >
            {topStock.isError ? (
              <ErrorCard
                message={(topStock.error as Error).message}
                onRetry={() => void topStock.refetch()}
              />
            ) : (
              <DataTable
                columns={stockColumns}
                rows={topStock.data?.rows ?? []}
                getRowKey={(row) => row.key}
                loading={topStock.isLoading}
                skeletonRows={5}
                dense
                emptyTitle={t('dash.topStock.empty')}
                emptyDescription={t('ui.noDataHint')}
                onRowClick={() => navigate('/stock')}
              />
            )}
          </Section>

          <Section title={t('dash.queues.title')} hint={t('dash.queues.hint')}>
            {ops.isError ? (
              <ErrorCard message={(ops.error as Error).message} onRetry={() => void ops.refetch()} />
            ) : (
              <KpiGrid className="sm:grid-cols-3 lg:grid-cols-5">
                {ops.isLoading
                  ? Array.from({ length: 5 }).map((_, index) => (
                      <KpiCard key={index} label="" value="" loading />
                    ))
                  : queues.map((metric) => (
                      <KpiCard
                        key={metric.key}
                        label={metricTitle(t, metric)}
                        value={numberFormat(language).format(metric.value)}
                        icon={Icon[QUEUE_ICON[metric.key] ?? 'orders']()}
                        tone={metric.attention ? 'warning' : 'default'}
                        onClick={() => navigate(QUEUE_TARGET[metric.key] ?? '/orders')}
                      />
                    ))}
              </KpiGrid>
            )}
          </Section>
        </div>

        <div className="space-y-5">
          <Section title={t('dash.status.title')}>
            {overview.isError ? (
              <ErrorCard
                message={(overview.error as Error).message}
                onRetry={() => void overview.refetch()}
              />
            ) : (
              <div className="premium-card p-4">
                {overview.isLoading ? (
                  <div className="mx-auto h-44 w-44 animate-pulse rounded-full bg-muted/60" />
                ) : slices.length === 0 ? (
                  <EmptyState title={t('dash.status.empty')} description={t('ui.noDataHint')} />
                ) : (
                  <DonutChart
                    slices={slices}
                    centerLabel={t('ui.chart.total')}
                    centerValue={numberFormat(language).format(statusTotal)}
                    formatValue={(value) => numberFormat(language).format(value)}
                  />
                )}
              </div>
            )}
          </Section>

          <Section title={t('dash.problems.title')}>
            {ops.isError ? (
              <ErrorCard message={(ops.error as Error).message} onRetry={() => void ops.refetch()} />
            ) : ops.isLoading ? (
              // «Всё в порядке» на недогруженной сводке — обещание, которого никто
              // не давал: пока ответа нет, показываем заглушку, а не спокойствие.
              <div className="premium-card h-24 animate-pulse" />
            ) : problems.length === 0 ? (
              // Блок проблем, который виден всегда, перестают замечать — поэтому
              // при пустом списке здесь спокойное подтверждение, а не пустая рамка.
              <div className="premium-card border-success/30 bg-success/5">
                <EmptyState
                  icon={<span className="text-success">{Icon.check('h-5 w-5')}</span>}
                  title={t('dash.problems.okTitle')}
                  description={t('dash.problems.okText')}
                  className="py-8"
                />
              </div>
            ) : (
              <div className="space-y-2">
                {problems.map((metric) => (
                  <button
                    key={metric.key}
                    type="button"
                    onClick={() => navigate(PROBLEM_TARGET[metric.key] ?? '/dashboard')}
                    className={cn(
                      'premium-card flex w-full items-center gap-3 border-destructive/30 bg-destructive/5 p-3 text-left',
                      'transition-all duration-150 hover:-translate-y-0.5 hover:shadow-md',
                      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
                    )}
                  >
                    <span className="text-destructive">{Icon.alert('h-4 w-4')}</span>
                    <span className="min-w-0 flex-1 truncate text-sm">{metricTitle(t, metric)}</span>
                    <span className="text-xl font-semibold tabular-nums text-destructive">
                      {numberFormat(language).format(metric.value)}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </Section>

          <Section title={t('dash.quick.title')}>
            <QuickActionsGrid actions={quickActions} />
          </Section>

          {ops.data ? (
            <p className="text-right text-[11px] text-muted-foreground">
              {t('dash.updated', {
                time: new Intl.DateTimeFormat(language, {
                  hour: '2-digit',
                  minute: '2-digit',
                }).format(new Date(ops.data.generatedAt)),
              })}
            </p>
          ) : null}
        </div>
      </div>
    </PageContainer>
  );
}
