import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import type { MetricDto, OrderStatus } from '@ff/shared';
import { ORDER_STATUSES } from '@ff/shared';
import { dashboardApi } from '@/lib/dashboard';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import { Icon } from '@/components/icons';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BarChart, CHART_COLORS, type ChartSeries } from '@/components/ui/charts';
import { EmptyState } from '@/components/ui/empty-state';
import { KpiCard, KpiGrid } from '@/components/ui/kpi-card';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { useToast } from '@/components/ui/toast';

/**
 * Табло цеха. На него смотрят через помещение, поэтому числа крупные, тон
 * задаётся цветом, а не подсказкой при наведении: на стене мыши нет.
 */

type Translate = (key: MessageKey, params?: Record<string, string | number>) => string;

/** Название метрики: перевод по ключу, незнакомый ключ — заголовок бэкенда. */
function metricTitle(t: Translate, metric: MetricDto): string {
  const key = `metric.${metric.key}` as MessageKey;
  const translated = t(key);
  return translated === key ? metric.title : translated;
}

function statusLabel(t: Translate, status: string): string {
  const key = `status.${status}` as MessageKey;
  const translated = t(key);
  return translated === key ? status : translated;
}

/** Цвет закреплён за позицией статуса в каноническом списке — см. главную панель. */
function statusColor(status: string): string {
  const index = ORDER_STATUSES.indexOf(status as OrderStatus);
  return CHART_COLORS[(index < 0 ? 0 : index) % CHART_COLORS.length];
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}): React.ReactElement {
  return (
    <section className="space-y-3">
      <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
        {title}
      </h2>
      {children}
    </section>
  );
}

/** Сбой запроса не должен оставлять пустое место: видно, что сломалось и как повторить. */
function ErrorCard({
  message,
  onRetry,
}: {
  message: string;
  onRetry: () => void;
}): React.ReactElement {
  const { t } = useI18n();
  return (
    <div
      role="alert"
      className="premium-card flex flex-wrap items-center gap-3 border-destructive/30 bg-destructive/5 p-4"
    >
      <span className="text-destructive">{Icon.alert('h-5 w-5')}</span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-foreground">{t('ops.unavailable')}</p>
        <p className="truncate text-xs text-muted-foreground">{message || t('dash.error.text')}</p>
      </div>
      <Button variant="outline" size="sm" onClick={onRetry}>
        {t('ui.retry')}
      </Button>
    </div>
  );
}

/** Плитка табло: число крупнее обычного KPI, требующее внимания — красным с пульсом. */
function WallTile({
  metric,
  format,
}: {
  metric: MetricDto;
  format: (value: number) => string;
}): React.ReactElement {
  const { t } = useI18n();
  return (
    <KpiCard
      label={metricTitle(t, metric)}
      value={
        <span className="block text-3xl leading-tight sm:text-4xl">{format(metric.value)}</span>
      }
      tone={metric.attention ? 'destructive' : 'default'}
      hint={
        metric.attention ? (
          <span className="inline-flex items-center gap-1.5 text-destructive">
            <span aria-hidden="true" className="h-2 w-2 animate-pulse rounded-full bg-destructive" />
            {t('dash.ops.attention')}
          </span>
        ) : undefined
      }
      className={metric.attention ? 'border-destructive/40 bg-destructive/5' : undefined}
    />
  );
}

function LoadingTiles({ count }: { count: number }): React.ReactElement {
  return (
    <>
      {Array.from({ length: count }).map((_, index) => (
        <KpiCard key={index} label="" value="" loading />
      ))}
    </>
  );
}

export function OpsDashboardPage(): React.ReactElement {
  const { t, language } = useI18n();
  const toast = useToast();

  // Сводка живёт секунды: склад меняется, пока оператор на неё смотрит.
  const ops = useQuery({
    queryKey: ['dashboard', 'ops'],
    queryFn: dashboardApi.ops,
    refetchInterval: 15_000,
  });

  const [refreshing, setRefreshing] = React.useState(false);

  const numberFormat = React.useMemo(() => new Intl.NumberFormat(language), [language]);
  const format = React.useCallback((value: number) => numberFormat.format(value), [numberFormat]);

  const refresh = async (): Promise<void> => {
    setRefreshing(true);
    try {
      const result = await ops.refetch();
      if (result.error) toast.error(t('dash.refreshFailed'), result.error.message);
      else toast.success(t('dash.refreshed'));
    } finally {
      setRefreshing(false);
    }
  };

  const data = ops.data;
  const statusRows = (data?.ordersByStatus ?? []).filter((row) => row.count > 0);
  const statusTotal = statusRows.reduce((sum, row) => sum + row.count, 0);
  const problems = (data?.problems ?? []).filter((metric) => metric.value > 0);

  // Воронка — ОДИН накопительный столбик во всю ширину: доли статусов видны
  // сразу, а не через сравнение высот, как в прежних вручную масштабированных div.
  const funnelSeries: ChartSeries[] = statusRows.map((row) => ({
    key: row.status,
    name: statusLabel(t, row.status),
    color: statusColor(row.status),
  }));
  const funnelPoints = [
    {
      label: t('dash.ops.totalOrders'),
      values: Object.fromEntries(statusRows.map((row) => [row.status, row.count])),
    },
  ];

  const updatedAt = data
    ? new Intl.DateTimeFormat(language, {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      }).format(new Date(data.generatedAt))
    : null;

  // Пока данных нет вовсе, секции не рисуются: пустая сетка и зелёное «проблем
  // нет» на упавшем запросе — это не отсутствие проблем, а их незнание.
  // Устаревшие данные, наоборот, остаются на экране рядом с ошибкой: на табло
  // они полезнее пустоты.
  const showBoard = ops.isLoading || Boolean(data);

  return (
    <PageContainer>
      <PageHeader
        breadcrumbs={[{ label: t('nav.home'), to: '/' }, { label: t('ops.title') }]}
        title={t('ops.title')}
        description={t('dash.ops.subtitle')}
        icon={Icon.warehouse()}
        actions={
          <>
            <Badge variant={ops.isError ? 'destructive' : 'success'} dot>
              {t('dash.ops.live')}
            </Badge>
            <Button variant="outline" size="sm" onClick={() => void refresh()} disabled={refreshing}>
              {t('dash.ops.refresh')}
            </Button>
          </>
        }
      />

      {ops.isError ? (
        <ErrorCard message={(ops.error as Error).message} onRetry={() => void ops.refetch()} />
      ) : null}

      {showBoard ? (
        <>
          <Section title={t('ops.queues')}>
            <KpiGrid className="sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
              {ops.isLoading ? (
                <LoadingTiles count={5} />
              ) : (
                (data?.queues ?? []).map((metric) => (
                  <WallTile key={metric.key} metric={metric} format={format} />
                ))
              )}
            </KpiGrid>
          </Section>

          <Section title={t('ops.problems')}>
            {ops.isLoading ? (
              <KpiGrid className="sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                <LoadingTiles count={4} />
              </KpiGrid>
            ) : problems.length > 0 ? (
              <KpiGrid className="sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {problems.map((metric) => (
                  <WallTile key={metric.key} metric={metric} format={format} />
                ))}
              </KpiGrid>
            ) : (
              // Всегда видимый блок проблем перестают замечать — при пустом
              // списке здесь спокойное подтверждение, а не сетка нулей.
              <div className="premium-card border-success/30 bg-success/5">
                <EmptyState
                  icon={<span className="text-success">{Icon.check('h-5 w-5')}</span>}
                  title={t('dash.ops.allClear')}
                  description={t('dash.ops.allClearText')}
                  className="py-8"
                />
              </div>
            )}
          </Section>

          <Section title={t('ops.today')}>
            <KpiGrid className="sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
              {ops.isLoading ? (
                <LoadingTiles count={5} />
              ) : (
                (data?.today ?? []).map((metric) => (
                  <WallTile key={metric.key} metric={metric} format={format} />
                ))
              )}
            </KpiGrid>
          </Section>

          <Section title={t('dash.ops.funnel')}>
            <div className="premium-card p-4">
              {ops.isLoading ? (
                <div className="h-28 animate-pulse rounded-lg bg-muted/60" />
              ) : statusRows.length === 0 ? (
                <EmptyState title={t('ops.noOrders')} description={t('ui.noDataHint')} />
              ) : (
                <>
                  <BarChart
                    points={funnelPoints}
                    series={funnelSeries}
                    height={110}
                    horizontal
                    stacked
                    legend={false}
                    formatValue={format}
                  />
                  {/* Подписи вынесены под график: на табло значение, которое
                      видно только при наведении, не существует. */}
                  <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-3 xl:grid-cols-6">
                    {statusRows.map((row) => (
                      <li key={row.status} className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span
                            aria-hidden="true"
                            className="h-2.5 w-2.5 shrink-0 rounded-full"
                            style={{ backgroundColor: statusColor(row.status) }}
                          />
                          <span className="truncate text-xs uppercase tracking-wide text-muted-foreground">
                            {statusLabel(t, row.status)}
                          </span>
                        </div>
                        <div className="mt-0.5 flex items-baseline gap-2 pl-[18px]">
                          <span className="text-2xl font-semibold tabular-nums">
                            {format(row.count)}
                          </span>
                          <span className="text-xs tabular-nums text-muted-foreground">
                            {Math.round((row.count / Math.max(statusTotal, 1)) * 100)}%
                          </span>
                        </div>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </Section>
        </>
      ) : null}

      <p className={cn('text-xs text-muted-foreground', refreshing && 'animate-pulse')}>
        {updatedAt ? t('ops.updated', { time: updatedAt }) : t('ui.loading')}
      </p>
    </PageContainer>
  );
}
