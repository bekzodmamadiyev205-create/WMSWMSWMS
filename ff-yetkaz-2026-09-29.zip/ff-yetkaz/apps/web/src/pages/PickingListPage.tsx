import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import type { OrderDto, PickTaskDto } from '@ff/shared';
import { ApiError } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { ordersApi } from '@/lib/orders';
import { pickingApi } from '@/lib/picking';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';

function TaskCard({
  task,
  action,
}: {
  task: PickTaskDto;
  action: React.ReactNode;
}): React.ReactElement {
  const { t } = useI18n();
  const done = task.lines.filter((line) => line.status !== 'PENDING').length;
  return (
    <Card>
      <CardContent className="flex items-center justify-between gap-3 p-4">
        <div className="min-w-0">
          <div className="font-medium">
            {task.kind === 'BATCH' ? 'Batch' : t('picking.taskKind.order')} ·{' '}
            {t('picking.taskCard.orderCount', { n: task.orderIds.length })}
          </div>
          <div className="text-sm text-muted-foreground">
            {t('picking.taskCard.positions', { done, total: task.lines.length })} ·{' '}
            {t(`picking.taskStatus.${task.status}` as MessageKey)}
          </div>
        </div>
        {action}
      </CardContent>
    </Card>
  );
}

/**
 * Формирование задания — работа оператора, а не сборщика: он решает, какие
 * заказы поедут одним маршрутом. Блок скрыт по ролям, иначе сборщик получал бы
 * 403 от кнопки, которую ему показали.
 *
 * Все заказы задания обязаны быть с одного склада (маршрут сборщика не бывает
 * межскладским), поэтому выбор идёт внутри выбранного склада, а не вперемешку.
 */
function CreateTaskSection(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [open, setOpen] = React.useState(false);
  const [warehouseId, setWarehouseId] = React.useState('');
  const [selected, setSelected] = React.useState<Record<string, boolean>>({});
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  const warehouses = useQuery({ queryKey: ['mdm', 'warehouses'], queryFn: mdmApi.warehouses });
  const orders = useQuery({
    queryKey: ['orders', '', ''],
    // Сюда нужны ВСЕ заказы под резервом, а не первая страница: список
    // самоочищается (создание задания уводит заказы в PICKING), и урезанная
    // выборка молча пряталa бы часть работы от сборщика.
    queryFn: () => ordersApi.listAll({ status: 'RESERVED' }),
    enabled: open,
  });

  // Исполняет заказ его дочерняя часть, если он разделён между складами:
  // у контейнера склада нет, собирать по нему нечего.
  const candidates: OrderDto[] = (orders.data ?? ([] as OrderDto[]))
    .flatMap((order: OrderDto) => (order.isSplit ? order.children : [order]))
    .filter((order: OrderDto) => order.status === 'RESERVED' && order.warehouseId);

  const warehouseIds = [...new Set(candidates.map((order) => order.warehouseId as string))];
  const activeWarehouse = warehouseId || warehouseIds[0] || '';
  const visible = candidates.filter((order) => order.warehouseId === activeWarehouse);
  const chosen = visible.filter((order) => selected[order.id]).map((order) => order.id);

  const create = useMutation({
    mutationFn: () => pickingApi.create(chosen),
    onSuccess: (task) => {
      setMessage({
        kind: 'ok',
        text: t('picking.create.success', {
          orders: task.orderIds.length,
          lines: task.lines.length,
        }),
      });
      setSelected({});
      queryClient.invalidateQueries({ queryKey: ['picking'] });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : t('picking.create.error'),
      }),
  });

  const warehouseCode = (id: string) =>
    warehouses.data?.find((warehouse) => warehouse.id === id)?.code ?? id.slice(0, 8);

  if (!open) {
    return (
      <Button variant="outline" onClick={() => setOpen(true)}>
        {t('picking.create.open')}
      </Button>
    );
  }

  return (
    <Card>
      <CardContent className="space-y-3 p-4">
        <div className="flex items-center justify-between gap-2">
          <div className="text-sm font-medium">{t('picking.create.open')}</div>
          <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
            {t('picking.create.collapse')}
          </Button>
        </div>

        {message && (
          <p
            role="status"
            className={
              message.kind === 'ok'
                ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
                : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
            }
          >
            {message.text}
          </p>
        )}

        {orders.isLoading && (
          <p className="text-sm text-muted-foreground">{t('picking.create.loadingOrders')}</p>
        )}

        {!orders.isLoading && candidates.length === 0 && (
          <p className="text-sm text-muted-foreground">{t('picking.create.noReserved')}</p>
        )}

        {warehouseIds.length > 1 && (
          <div className="space-y-1">
            <Label htmlFor="task-warehouse">{t('picking.create.warehouse')}</Label>
            <Select
              id="task-warehouse"
              value={activeWarehouse}
              onChange={(event) => {
                setWarehouseId(event.target.value);
                // Выбор сбрасывается: заказы разных складов в одно задание не идут.
                setSelected({});
              }}
            >
              {warehouseIds.map((id) => (
                <option key={id} value={id}>
                  {warehouseCode(id)}
                </option>
              ))}
            </Select>
          </div>
        )}

        <div className="space-y-1">
          {visible.map((order) => (
            <label
              key={order.id}
              className="flex cursor-pointer items-center gap-3 rounded border px-3 py-2 text-sm"
            >
              <input
                type="checkbox"
                className="h-4 w-4"
                checked={Boolean(selected[order.id])}
                onChange={(event) =>
                  setSelected({ ...selected, [order.id]: event.target.checked })
                }
              />
              <span className="min-w-0 flex-1">
                <span className="font-medium">{order.externalId}</span>
                <span className="ml-2 text-muted-foreground">
                  {order.lines.map((line) => `${line.skuCode} × ${line.quantity}`).join(', ')}
                </span>
              </span>
            </label>
          ))}
        </div>

        {visible.length > 0 && (
          <div className="flex items-center gap-2">
            <Button disabled={chosen.length === 0 || create.isPending} onClick={() => create.mutate()}>
              {t('picking.create.submit')}
              {chosen.length > 0 ? ` (${chosen.length})` : ''}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() =>
                setSelected(Object.fromEntries(visible.map((order) => [order.id, true])))
              }
            >
              {t('picking.create.selectAll')}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function PickingListPage(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { user } = useAuth();
  const canCreate = (user?.roles ?? []).some(
    (role) => role === 'ADMIN' || role === 'WAREHOUSE_OPERATOR',
  );

  const mine = useQuery({ queryKey: ['picking', 'mine'], queryFn: pickingApi.myTasks });
  const open = useQuery({ queryKey: ['picking', 'open'], queryFn: pickingApi.openTasks });

  const take = useMutation({
    mutationFn: (id: string) => pickingApi.assign(id),
    onSuccess: (task) => {
      queryClient.invalidateQueries({ queryKey: ['picking'] });
      navigate(`/picking/${task.id}`);
    },
  });

  const active = (mine.data ?? []).filter((task) => task.status !== 'COMPLETED');
  const free = open.data ?? [];

  return (
    <div className="mx-auto max-w-xl space-y-6 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('picking.title')}</h1>
        <Link to="/" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>

      {canCreate && <CreateTaskSection />}

      <section className="space-y-3">
        <h2 className="text-sm font-medium text-muted-foreground">{t('picking.myTasks')}</h2>
        {mine.isLoading && <p className="text-sm text-muted-foreground">{t('common.loading')}</p>}
        {!mine.isLoading && active.length === 0 && (
          <p className="text-sm text-muted-foreground">{t('picking.noActive')}</p>
        )}
        {active.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            action={
              <Button onClick={() => navigate(`/picking/${task.id}`)} className="shrink-0">
                {t('picking.open')}
              </Button>
            }
          />
        ))}
      </section>

      <section className="space-y-3">
        <h2 className="text-sm font-medium text-muted-foreground">{t('picking.freeTasks')}</h2>
        {free.length === 0 && <p className="text-sm text-muted-foreground">{t('picking.noFree')}</p>}
        {free.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            action={
              <Button
                variant="outline"
                className="shrink-0"
                disabled={take.isPending}
                onClick={() => take.mutate(task.id)}
              >
                {t('picking.take')}
              </Button>
            }
          />
        ))}
      </section>
    </div>
  );
}
