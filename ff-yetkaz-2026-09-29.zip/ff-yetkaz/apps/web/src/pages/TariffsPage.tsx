import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { ChargeKind, SkuDto, TariffPlanDto, TariffRuleDto, TariffUnit } from '@ff/shared';
import {
  ALLOWED_UNITS,
  CHARGE_KINDS,
  DEFAULT_TARIFF_COMPONENT,
  TARIFF_COMPONENTS,
} from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';
import { chargeKindLabel, tariffUnitLabel } from '@/lib/billing';
import { isoDate } from '@/lib/date-range';
import { useI18n } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { DataTable, type DataTableColumn } from '@/components/ui/data-table';
import { ConfirmDialog, Dialog } from '@/components/ui/dialog';
import { EmptyState } from '@/components/ui/empty-state';
import { InlineNumber, InlineText } from '@/components/ui/inline-edit';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { Select } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/components/ui/toast';
import { Toolbar, ToolbarGroup, ToolbarSearch } from '@/components/ui/toolbar';

/* ────────────────────────────── ручки экрана ─────────────────────────────── */

interface CreatePlanBody {
  code: string;
  name: string;
  currency: string;
  isDefault: boolean;
  isActive: boolean;
}

interface UpdatePlanBody {
  name?: string;
  currency?: string;
  isDefault?: boolean;
  isActive?: boolean;
}

interface CreateRuleBody {
  kind: ChargeKind;
  unit: TariffUnit;
  component?: string;
  price: string;
  minQty?: string;
  effectiveFrom?: string;
  effectiveTo?: string;
}

interface UpdateRuleBody {
  price?: string;
  minQty?: string;
  /** `null` снимает дату окончания — правило снова бессрочное. */
  effectiveTo?: string | null;
}

interface PackingNormsBody {
  unitsPerBox?: number | null;
  unitsPerPallet?: number | null;
}

interface PackingNormsResultDto {
  skuId: string;
  unitsPerBox: number | null;
  unitsPerPallet: number | null;
}

/**
 * Ручки держим рядом с экраном, а не в общем `lib/billing.ts`: там есть только
 * чтение планов и добавление правила, а всё остальное (правка плана, правка и
 * удаление правила, нормы упаковки) нужно ровно этому экрану.
 */
const tariffsApi = {
  plans: (): Promise<TariffPlanDto[]> => apiFetch<TariffPlanDto[]>('/billing/tariff-plans'),
  createPlan: (body: CreatePlanBody): Promise<TariffPlanDto> =>
    apiFetch<TariffPlanDto>('/billing/tariff-plans', { method: 'POST', body }),
  updatePlan: (id: string, body: UpdatePlanBody): Promise<TariffPlanDto> =>
    apiFetch<TariffPlanDto>(`/billing/tariff-plans/${id}`, { method: 'PATCH', body }),
  addRule: (planId: string, body: CreateRuleBody): Promise<TariffRuleDto> =>
    apiFetch<TariffRuleDto>(`/billing/tariff-plans/${planId}/rules`, { method: 'POST', body }),
  updateRule: (id: string, body: UpdateRuleBody): Promise<TariffRuleDto> =>
    apiFetch<TariffRuleDto>(`/billing/tariff-rules/${id}`, { method: 'PATCH', body }),
  deleteRule: (id: string): Promise<void> =>
    apiFetch<void>(`/billing/tariff-rules/${id}`, { method: 'DELETE' }),
  setPackingNorms: (skuId: string, body: PackingNormsBody): Promise<PackingNormsResultDto> =>
    apiFetch<PackingNormsResultDto>(`/billing/skus/${skuId}/packing-norms`, {
      method: 'PATCH',
      body,
    }),
};

const PLANS_KEY = ['billing', 'tariff-plans'] as const;

/** Деньги — строкой: float в цене недопустим даже на клиенте. */
const MONEY_RE = /^\d+(\.\d{1,4})?$/;
const QTY_RE = /^\d+(\.\d{1,3})?$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const COMPONENT_RE = /^[A-Z][A-Z0-9_]*$/;
const CURRENCY_RE = /^[A-Za-z]{3}$/;

const scrubNumeric = (raw: string): string => raw.replace(/[^\d.]/g, '');

const errorText = (error: unknown): string =>
  error instanceof ApiError
    ? error.message
    : error instanceof Error
      ? error.message
      : String(error);

/** Свободный ввод составляющей: значение-маркер вместо пункта списка. */
const CUSTOM_COMPONENT = '__custom__';

/* ─────────────────────────── группировка правил ──────────────────────────── */

interface ComponentGroup {
  component: string;
  rules: TariffRuleDto[];
}

interface KindGroup {
  kind: ChargeKind;
  components: ComponentGroup[];
}

const KIND_ORDER = new Map<string, number>(CHARGE_KINDS.map((kind, index) => [kind, index]));

/**
 * Группировка и есть смысл экрана: услуга «паллета + перевес по кг» — это ДВЕ
 * составляющие, и увидеть их надо сразу, а не вычитать из плоского списка.
 * Составляющие складываются между собой, строки внутри составляющей — ступени
 * по объёму, поэтому внутри сортируем по `minQty`, а не по дате создания.
 */
function groupRules(rules: TariffRuleDto[]): KindGroup[] {
  const byKind = new Map<ChargeKind, Map<string, TariffRuleDto[]>>();

  for (const rule of rules) {
    const component = rule.component || DEFAULT_TARIFF_COMPONENT;
    let components = byKind.get(rule.kind);
    if (!components) {
      components = new Map<string, TariffRuleDto[]>();
      byKind.set(rule.kind, components);
    }
    const bucket = components.get(component);
    if (bucket) bucket.push(rule);
    else components.set(component, [rule]);
  }

  return Array.from(byKind.entries())
    .sort((a, b) => (KIND_ORDER.get(a[0]) ?? 99) - (KIND_ORDER.get(b[0]) ?? 99))
    .map(([kind, components]) => ({
      kind,
      components: Array.from(components.entries())
        .sort((a, b) => {
          if (a[0] === b[0]) return 0;
          if (a[0] === DEFAULT_TARIFF_COMPONENT) return -1;
          if (b[0] === DEFAULT_TARIFF_COMPONENT) return 1;
          return a[0].localeCompare(b[0]);
        })
        .map(([component, list]) => ({
          component,
          rules: [...list].sort(
            (a, b) =>
              Number(a.minQty) - Number(b.minQty) || a.effectiveFrom.localeCompare(b.effectiveFrom),
          ),
        })),
    }));
}

type RuleState = 'active' | 'planned' | 'expired';

function ruleState(rule: TariffRuleDto, today: string): RuleState {
  if (rule.effectiveTo && rule.effectiveTo < today) return 'expired';
  if (rule.effectiveFrom > today) return 'planned';
  return 'active';
}

/* ──────────────────────────── мелкие примитивы ───────────────────────────── */

function Switch({
  checked,
  onChange,
  label,
  disabled,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  disabled?: boolean;
}): React.ReactElement {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        'inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
        checked ? 'border-primary bg-primary' : 'border-input bg-muted',
        disabled && 'cursor-not-allowed opacity-50',
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          'h-4 w-4 rounded-full bg-background shadow transition-transform',
          checked ? 'translate-x-6' : 'translate-x-1',
        )}
      />
    </button>
  );
}

function FieldRow({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}): React.ReactElement {
  return (
    <div className="space-y-1">
      <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div className="text-sm">{children}</div>
      {hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}
    </div>
  );
}

function TrashIcon(): React.ReactElement {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className="h-4 w-4"
    >
      <path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" />
    </svg>
  );
}

function TariffIcon(): React.ReactElement {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M20.6 13.4 12 22l-9-9V4h9l8.6 8.6a1.4 1.4 0 0 1 0 2Z" />
      <circle cx="7.5" cy="7.5" r="1.4" />
    </svg>
  );
}

/* ──────────────────────────────── страница ───────────────────────────────── */

export function TariffsPage(): React.ReactElement {
  const { t } = useI18n();
  const plans = useQuery({ queryKey: PLANS_KEY, queryFn: tariffsApi.plans });
  const [selectedId, setSelectedId] = React.useState<string | null>(null);
  const [creating, setCreating] = React.useState(false);

  const list = React.useMemo<TariffPlanDto[]>(() => plans.data ?? [], [plans.data]);

  // Экран без выбранного плана показывает пустоту, хотя данные уже загружены:
  // выбираем план по умолчанию, а если его нет — первый.
  React.useEffect(() => {
    if (list.length === 0) {
      if (selectedId !== null) setSelectedId(null);
      return;
    }
    if (!selectedId || !list.some((plan) => plan.id === selectedId)) {
      setSelectedId(list.find((plan) => plan.isDefault)?.id ?? list[0].id);
    }
  }, [list, selectedId]);

  const selected = list.find((plan) => plan.id === selectedId) ?? null;

  return (
    <PageContainer>
      <PageHeader
        icon={<TariffIcon />}
        title={t('tariffs.title')}
        description={t('tariffs.subtitle')}
        actions={<Button onClick={() => setCreating(true)}>{t('tariffs.createPlan')}</Button>}
      />

      {plans.isError ? (
        <Card>
          <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
            <p className="text-sm text-destructive">{errorText(plans.error)}</p>
            <Button variant="outline" size="sm" onClick={() => void plans.refetch()}>
              {t('ui.retry')}
            </Button>
          </CardContent>
        </Card>
      ) : null}

      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,17rem)_minmax(0,1fr)]">
        <PlanRail
          plans={list}
          loading={plans.isLoading}
          selectedId={selectedId}
          onSelect={setSelectedId}
          onCreate={() => setCreating(true)}
        />

        <div className="min-w-0 space-y-4">
          {selected ? (
            <>
              <PlanEditor plan={selected} otherDefault={list.some((p) => p.isDefault && p.id !== selected.id)} />
              <RulesSection plan={selected} />
            </>
          ) : (
            <Card>
              <CardContent className="p-6">
                <EmptyState
                  title={plans.isLoading ? t('ui.loading') : t('tariffs.noPlanSelected')}
                  description={plans.isLoading ? undefined : t('tariffs.noPlanSelectedHint')}
                  action={
                    plans.isLoading ? undefined : (
                      <Button size="sm" onClick={() => setCreating(true)}>
                        {t('tariffs.createPlan')}
                      </Button>
                    )
                  }
                />
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <PackingNormsSection />

      <CreatePlanDialog
        open={creating}
        hasDefault={list.some((plan) => plan.isDefault)}
        onClose={() => setCreating(false)}
        onCreated={(plan) => {
          setSelectedId(plan.id);
          setCreating(false);
        }}
      />
    </PageContainer>
  );
}

/* ─────────────────────────────── список планов ───────────────────────────── */

function PlanRail({
  plans,
  loading,
  selectedId,
  onSelect,
  onCreate,
}: {
  plans: TariffPlanDto[];
  loading: boolean;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onCreate: () => void;
}): React.ReactElement {
  const { t } = useI18n();

  return (
    <Card className="lg:sticky lg:top-4">
      <CardContent className="space-y-2 p-3">
        <div className="px-1 pb-1">
          <div className="text-sm font-semibold">{t('tariffs.plans')}</div>
          <p className="mt-0.5 text-xs text-muted-foreground">{t('tariffs.plansHint')}</p>
        </div>

        {loading ? (
          <div className="space-y-2" aria-busy="true" aria-label={t('ui.loading')}>
            {[0, 1, 2].map((row) => (
              <Skeleton key={row} className="h-16 w-full" />
            ))}
          </div>
        ) : plans.length === 0 ? (
          <EmptyState
            title={t('tariffs.noPlans')}
            description={t('tariffs.noPlansHint')}
            action={
              <Button size="sm" onClick={onCreate}>
                {t('tariffs.createPlan')}
              </Button>
            }
          />
        ) : (
          <ul className="space-y-1">
            {plans.map((plan) => {
              const active = plan.id === selectedId;
              return (
                <li key={plan.id}>
                  <button
                    type="button"
                    aria-current={active ? 'true' : undefined}
                    onClick={() => onSelect(plan.id)}
                    className={cn(
                      'w-full rounded-lg border px-3 py-2.5 text-left transition-colors',
                      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1',
                      active
                        ? 'border-primary/50 bg-primary/5'
                        : 'border-transparent hover:bg-muted/60',
                    )}
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="truncate font-mono text-sm font-medium">{plan.code}</span>
                      <span className="shrink-0 text-xs text-muted-foreground">{plan.currency}</span>
                    </div>
                    <div className="mt-0.5 truncate text-sm text-muted-foreground">{plan.name}</div>
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {plan.isDefault ? (
                        <Badge variant="info" size="sm">
                          {t('tariffs.default')}
                        </Badge>
                      ) : null}
                      <Badge variant={plan.isActive ? 'success' : 'muted'} size="sm" dot>
                        {plan.isActive ? t('tariffs.active') : t('tariffs.inactive')}
                      </Badge>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

/* ─────────────────────────────── правка плана ────────────────────────────── */

function PlanEditor({
  plan,
  otherDefault,
}: {
  plan: TariffPlanDto;
  otherDefault: boolean;
}): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const toast = useToast();
  const [confirmDefault, setConfirmDefault] = React.useState(false);

  const update = useMutation({
    mutationFn: (body: UpdatePlanBody) => tariffsApi.updatePlan(plan.id, body),
    onMutate: async (body) => {
      await queryClient.cancelQueries({ queryKey: PLANS_KEY });
      const previous = queryClient.getQueryData<TariffPlanDto[]>(PLANS_KEY);
      queryClient.setQueryData<TariffPlanDto[]>(PLANS_KEY, (rows) =>
        rows?.map((row) => {
          if (row.id === plan.id) {
            return {
              ...row,
              name: body.name ?? row.name,
              currency: body.currency ?? row.currency,
              isDefault: body.isDefault ?? row.isDefault,
              isActive: body.isActive ?? row.isActive,
            };
          }
          // Флаг «по умолчанию» в системе ровно один (частичный уникальный
          // индекс), поэтому снимаем его с прежнего плана сразу — иначе до
          // ответа сервера в списке видно два плана по умолчанию.
          return body.isDefault === true && row.isDefault ? { ...row, isDefault: false } : row;
        }),
      );
      return { previous };
    },
    onError: (error, _body, context) => {
      if (context?.previous) queryClient.setQueryData(PLANS_KEY, context.previous);
      toast.error(t('tariffs.planSaveFailed'), errorText(error));
    },
    onSuccess: () => {
      toast.success(t('tariffs.planSaved'));
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: PLANS_KEY });
    },
  });

  const saveName = async (next: string): Promise<void> => {
    const value = next.trim();
    if (value.length < 2) throw new Error(t('tariffs.validation.name'));
    await update.mutateAsync({ name: value });
  };

  const saveCurrency = async (next: string): Promise<void> => {
    const value = next.trim().toUpperCase();
    if (!CURRENCY_RE.test(value)) throw new Error(t('tariffs.validation.currency'));
    await update.mutateAsync({ currency: value });
  };

  const toggleDefault = (next: boolean): void => {
    if (next && otherDefault) {
      setConfirmDefault(true);
      return;
    }
    update.mutate({ isDefault: next });
  };

  return (
    <Card>
      <CardContent className="space-y-4 p-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-base font-semibold">{plan.code}</span>
          {plan.isDefault ? <Badge variant="info">{t('tariffs.default')}</Badge> : null}
          <Badge variant={plan.isActive ? 'success' : 'muted'} dot>
            {plan.isActive ? t('tariffs.active') : t('tariffs.inactive')}
          </Badge>
        </div>

        {!plan.isActive ? (
          <p
            role="status"
            className="rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-sm"
          >
            {t('tariffs.inactiveWarning')}
          </p>
        ) : null}

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <FieldRow label={t('tariffs.name')}>
            <InlineText
              value={plan.name}
              maxLength={120}
              ariaLabel={t('tariffs.name')}
              onSubmit={saveName}
            />
          </FieldRow>

          <FieldRow label={t('tariffs.currency')} hint={t('tariffs.currencyHint')}>
            <InlineText
              value={plan.currency}
              maxLength={3}
              ariaLabel={t('tariffs.currency')}
              onSubmit={saveCurrency}
            />
          </FieldRow>

          <FieldRow label={t('tariffs.default')} hint={t('tariffs.defaultHint')}>
            <Switch
              checked={plan.isDefault}
              label={t('tariffs.default')}
              disabled={update.isPending}
              onChange={toggleDefault}
            />
          </FieldRow>

          <FieldRow label={t('tariffs.isActive')} hint={t('tariffs.isActiveHint')}>
            <Switch
              checked={plan.isActive}
              label={t('tariffs.isActive')}
              disabled={update.isPending}
              onChange={(next) => update.mutate({ isActive: next })}
            />
          </FieldRow>
        </div>
      </CardContent>

      <ConfirmDialog
        open={confirmDefault}
        busy={update.isPending}
        title={t('tariffs.defaultSwitchTitle')}
        description={t('tariffs.defaultSwitchBody')}
        confirmLabel={t('tariffs.defaultSwitchConfirm')}
        onClose={() => setConfirmDefault(false)}
        onConfirm={() => {
          setConfirmDefault(false);
          update.mutate({ isDefault: true });
        }}
      />
    </Card>
  );
}

/* ──────────────────────────── правила: таблицы ───────────────────────────── */

function RulesSection({ plan }: { plan: TariffPlanDto }): React.ReactElement {
  const { t, language } = useI18n();
  const queryClient = useQueryClient();
  const toast = useToast();
  const today = React.useMemo(() => isoDate(new Date()), []);
  const [adding, setAdding] = React.useState(false);
  const [pendingDelete, setPendingDelete] = React.useState<TariffRuleDto | null>(null);

  const groups = React.useMemo(() => groupRules(plan.rules), [plan.rules]);

  const patchRule = useMutation({
    mutationFn: ({ id, body }: { id: string; body: UpdateRuleBody }) =>
      tariffsApi.updateRule(id, body),
    onMutate: async ({ id, body }) => {
      await queryClient.cancelQueries({ queryKey: PLANS_KEY });
      const previous = queryClient.getQueryData<TariffPlanDto[]>(PLANS_KEY);
      queryClient.setQueryData<TariffPlanDto[]>(PLANS_KEY, (rows) =>
        rows?.map((row) => ({
          ...row,
          rules: row.rules.map((rule) =>
            rule.id === id
              ? {
                  ...rule,
                  price: body.price ?? rule.price,
                  minQty: body.minQty ?? rule.minQty,
                  effectiveTo: body.effectiveTo === undefined ? rule.effectiveTo : body.effectiveTo,
                }
              : rule,
          ),
        })),
      );
      return { previous };
    },
    onError: (error, _vars, context) => {
      if (context?.previous) queryClient.setQueryData(PLANS_KEY, context.previous);
      toast.error(t('tariffs.ruleSaveFailed'), errorText(error));
    },
    onSuccess: () => {
      toast.success(t('tariffs.ruleSaved'));
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: PLANS_KEY });
    },
  });

  const closeToday = useMutation({
    mutationFn: (ruleId: string) => tariffsApi.updateRule(ruleId, { effectiveTo: today }),
    onSuccess: () => {
      toast.success(t('tariffs.ruleClosed'), t('tariffs.ruleClosedHint', { date: today }));
    },
    onError: (error) => {
      toast.error(t('tariffs.ruleSaveFailed'), errorText(error));
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: PLANS_KEY });
    },
  });

  const removeRule = useMutation({
    mutationFn: (rule: TariffRuleDto) => tariffsApi.deleteRule(rule.id),
    onSuccess: () => {
      setPendingDelete(null);
      toast.success(t('tariffs.ruleDeleted'));
    },
    onError: (error, rule) => {
      setPendingDelete(null);
      // 409 тут — не «что-то пошло не так»: правило уже применено в начислениях,
      // и удалить его значит оставить в счёте сумму без цены, по которой она
      // посчитана. Законный выход один — закрыть правило датой окончания.
      if (error instanceof ApiError && error.status === 409) {
        toast.toast({
          title: t('tariffs.deleteBlocked'),
          description: errorText(error),
          variant: 'warning',
          duration: 0,
          action: {
            label: t('tariffs.closeWithDate'),
            onClick: () => closeToday.mutate(rule.id),
          },
        });
        return;
      }
      toast.error(t('tariffs.deleteFailed'), errorText(error));
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: PLANS_KEY });
    },
  });

  const savePrice = async (rule: TariffRuleDto, next: string): Promise<void> => {
    const value = scrubNumeric(next);
    if (!MONEY_RE.test(value)) throw new Error(t('tariffs.validation.price'));
    await patchRule.mutateAsync({ id: rule.id, body: { price: value } });
  };

  const saveMinQty = async (rule: TariffRuleDto, next: string): Promise<void> => {
    const value = scrubNumeric(next);
    if (!QTY_RE.test(value)) throw new Error(t('tariffs.validation.minQty'));
    await patchRule.mutateAsync({ id: rule.id, body: { minQty: value } });
  };

  const saveEffectiveTo = async (rule: TariffRuleDto, next: string): Promise<void> => {
    const value = next.trim();
    if (value === '') {
      await patchRule.mutateAsync({ id: rule.id, body: { effectiveTo: null } });
      return;
    }
    if (!DATE_RE.test(value)) throw new Error(t('tariffs.validation.date'));
    if (value < rule.effectiveFrom) throw new Error(t('tariffs.validation.dateOrder'));
    await patchRule.mutateAsync({ id: rule.id, body: { effectiveTo: value } });
  };

  // Колонки собираются на каждый рендер намеренно: в ячейках живут обработчики
  // правки, и мемоизация законсервировала бы замыкание первого рендера.
  const columns: Array<DataTableColumn<TariffRuleDto>> = [
    {
      key: 'component',
      header: t('tariffs.component'),
      width: '9rem',
      cell: (rule) => (
        <span className="font-mono text-xs text-muted-foreground">
          {rule.component || DEFAULT_TARIFF_COMPONENT}
        </span>
      ),
    },
    {
      key: 'unit',
      header: t('tariffs.unit'),
      width: '11rem',
      cell: (rule) => <span className="text-muted-foreground">{tariffUnitLabel(language, rule.unit)}</span>,
    },
    {
      key: 'price',
      header: t('tariffs.price'),
      align: 'right',
      width: '11rem',
      cell: (rule) => (
        <InlineText
          value={rule.price}
          align="right"
          ariaLabel={t('tariffs.price')}
          onSubmit={(next) => savePrice(rule, next)}
        />
      ),
    },
    {
      key: 'minQty',
      header: t('tariffs.minQty'),
      align: 'right',
      width: '9rem',
      cell: (rule) => (
        <InlineText
          value={rule.minQty}
          align="right"
          ariaLabel={t('tariffs.minQty')}
          onSubmit={(next) => saveMinQty(rule, next)}
        />
      ),
    },
    {
      key: 'effectiveFrom',
      header: t('tariffs.effectiveFrom'),
      width: '9rem',
      cell: (rule) => <span className="tabular-nums">{rule.effectiveFrom}</span>,
    },
    {
      key: 'effectiveTo',
      header: t('tariffs.effectiveTo'),
      width: '10rem',
      cell: (rule) => (
        <InlineText
          value={rule.effectiveTo ?? ''}
          placeholder="2026-12-31"
          emptyLabel={t('tariffs.openEnded')}
          ariaLabel={t('tariffs.effectiveTo')}
          onSubmit={(next) => saveEffectiveTo(rule, next)}
        />
      ),
    },
    {
      key: 'actions',
      header: t('tariffs.actions'),
      align: 'right',
      width: '11rem',
      cell: (rule) => {
        const state = ruleState(rule, today);
        return (
          <div className="flex items-center justify-end gap-2">
            <Badge
              variant={state === 'active' ? 'success' : state === 'planned' ? 'info' : 'muted'}
              size="sm"
            >
              {state === 'active'
                ? t('tariffs.stateActive')
                : state === 'planned'
                  ? t('tariffs.statePlanned')
                  : t('tariffs.stateExpired')}
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              aria-label={t('tariffs.deleteRule')}
              title={t('tariffs.deleteRule')}
              className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
              onClick={() => setPendingDelete(rule)}
            >
              <TrashIcon />
            </Button>
          </div>
        );
      },
    },
  ];

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-semibold tracking-tight">{t('tariffs.rules')}</h2>
          <p className="mt-0.5 text-sm text-muted-foreground">{t('tariffs.rulesHint')}</p>
        </div>
        <Button size="sm" onClick={() => setAdding(true)}>
          {t('tariffs.addRule')}
        </Button>
      </div>

      {groups.length === 0 ? (
        <Card>
          <CardContent className="p-6">
            <EmptyState
              title={t('tariffs.noRules')}
              description={t('tariffs.noRulesHint')}
              action={
                <Button size="sm" onClick={() => setAdding(true)}>
                  {t('tariffs.addRule')}
                </Button>
              }
            />
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {groups.map((group) => (
            <div key={group.kind} className="space-y-3">
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                <h3 className="text-sm font-semibold">{chargeKindLabel(language, group.kind)}</h3>
                <Badge variant="outline" size="sm">
                  {t('tariffs.componentCount', { n: group.components.length })}
                </Badge>
                <p className="text-xs text-muted-foreground">{t('tariffs.groupHint')}</p>
              </div>

              {group.components.map((sub) => (
                <div key={`${group.kind}-${sub.component}`} className="space-y-1.5">
                  <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5 pl-0.5">
                    <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                      {t('tariffs.componentHeading')}
                    </span>
                    <span className="font-mono text-sm font-medium">{sub.component}</span>
                    <span className="text-xs text-muted-foreground">
                      {t('tariffs.componentSteps', { n: sub.rules.length })}
                    </span>
                  </div>
                  <DataTable
                    columns={columns}
                    rows={sub.rules}
                    getRowKey={(rule) => rule.id}
                    stickyHeader={false}
                    dense
                    emptyTitle={t('tariffs.noRules')}
                    rowClassName={(rule) =>
                      ruleState(rule, today) === 'expired' ? 'opacity-60' : undefined
                    }
                  />
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      <AddRuleDialog plan={plan} open={adding} onClose={() => setAdding(false)} />

      <ConfirmDialog
        open={pendingDelete !== null}
        busy={removeRule.isPending}
        danger
        title={t('tariffs.deleteRuleTitle')}
        description={t('tariffs.deleteRuleBody')}
        confirmLabel={t('ui.delete')}
        onClose={() => setPendingDelete(null)}
        onConfirm={() => {
          if (pendingDelete) removeRule.mutate(pendingDelete);
        }}
      />
    </section>
  );
}

/* ────────────────────────────── новое правило ────────────────────────────── */

interface RuleForm {
  kind: ChargeKind;
  unit: TariffUnit;
  componentChoice: string;
  customComponent: string;
  price: string;
  minQty: string;
  effectiveFrom: string;
  effectiveTo: string;
}

function AddRuleDialog({
  plan,
  open,
  onClose,
}: {
  plan: TariffPlanDto;
  open: boolean;
  onClose: () => void;
}): React.ReactElement | null {
  const { t, language } = useI18n();
  const queryClient = useQueryClient();
  const toast = useToast();

  const blank = React.useCallback(
    (): RuleForm => ({
      kind: 'STORAGE',
      unit: ALLOWED_UNITS.STORAGE[0],
      componentChoice: DEFAULT_TARIFF_COMPONENT,
      customComponent: '',
      price: '',
      minQty: '',
      effectiveFrom: isoDate(new Date()),
      effectiveTo: '',
    }),
    [],
  );

  const [form, setForm] = React.useState<RuleForm>(blank);
  const [formError, setFormError] = React.useState<string | null>(null);
  const [unitError, setUnitError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!open) return;
    setForm(blank());
    setFormError(null);
    setUnitError(null);
  }, [open, blank]);

  const component =
    form.componentChoice === CUSTOM_COMPONENT
      ? form.customComponent.trim().toUpperCase()
      : form.componentChoice;

  const add = useMutation({
    mutationFn: (body: CreateRuleBody) => tariffsApi.addRule(plan.id, body),
    onSuccess: () => {
      toast.success(t('tariffs.ruleAdded'));
      onClose();
    },
    onError: (error) => {
      // Вторая единица у той же (услуга, составляющая) отбивается триггером в
      // БД. Это не сбой, а ответ по существу — и относится он к полю единицы,
      // поэтому показываем сообщение сервера там, а не общим тостом.
      if (error instanceof ApiError && error.status === 409) {
        setUnitError(errorText(error));
        return;
      }
      setFormError(errorText(error));
      toast.error(t('tariffs.ruleAddFailed'), errorText(error));
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: PLANS_KEY });
    },
  });

  if (!open) return null;

  const allowedUnits = ALLOWED_UNITS[form.kind];

  const submit = (): void => {
    setFormError(null);
    setUnitError(null);

    const price = scrubNumeric(form.price);
    if (!MONEY_RE.test(price)) {
      setFormError(t('tariffs.validation.price'));
      return;
    }
    const minQty = scrubNumeric(form.minQty);
    if (minQty !== '' && !QTY_RE.test(minQty)) {
      setFormError(t('tariffs.validation.minQty'));
      return;
    }
    if (form.componentChoice === CUSTOM_COMPONENT && !COMPONENT_RE.test(component)) {
      setFormError(t('tariffs.validation.component'));
      return;
    }
    if (form.effectiveFrom !== '' && !DATE_RE.test(form.effectiveFrom)) {
      setFormError(t('tariffs.validation.date'));
      return;
    }
    if (form.effectiveTo !== '') {
      if (!DATE_RE.test(form.effectiveTo)) {
        setFormError(t('tariffs.validation.date'));
        return;
      }
      if (form.effectiveFrom !== '' && form.effectiveTo < form.effectiveFrom) {
        setFormError(t('tariffs.validation.dateOrder'));
        return;
      }
    }

    add.mutate({
      kind: form.kind,
      unit: form.unit,
      component,
      price,
      minQty: minQty === '' ? undefined : minQty,
      effectiveFrom: form.effectiveFrom === '' ? undefined : form.effectiveFrom,
      effectiveTo: form.effectiveTo === '' ? undefined : form.effectiveTo,
    });
  };

  const preview = t('tariffs.previewLine', {
    kind: chargeKindLabel(language, form.kind),
    component: component || DEFAULT_TARIFF_COMPONENT,
    price: scrubNumeric(form.price) || '0',
    currency: plan.currency,
    unit: tariffUnitLabel(language, form.unit),
    min: scrubNumeric(form.minQty) || '0',
  });

  return (
    <Dialog
      open={open}
      onClose={onClose}
      size="lg"
      title={t('tariffs.addRuleTitle')}
      description={t('tariffs.addRuleHint', { plan: plan.code })}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={add.isPending}>
            {t('ui.cancel')}
          </Button>
          <Button size="sm" onClick={submit} disabled={add.isPending}>
            {t('tariffs.addRule')}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label htmlFor="rule-kind">{t('tariffs.kind')}</Label>
            <Select
              id="rule-kind"
              value={form.kind}
              onChange={(event) => {
                const kind = event.target.value as ChargeKind;
                // Единица зависит от услуги: «хранение за заказ» — ошибка ввода,
                // а не тариф, поэтому при смене услуги берём первую допустимую.
                setUnitError(null);
                setForm((prev) => ({ ...prev, kind, unit: ALLOWED_UNITS[kind][0] }));
              }}
            >
              {CHARGE_KINDS.map((kind) => (
                <option key={kind} value={kind}>
                  {chargeKindLabel(language, kind)}
                </option>
              ))}
            </Select>
          </div>

          <div className="space-y-1">
            <Label htmlFor="rule-component">{t('tariffs.component')}</Label>
            <Select
              id="rule-component"
              value={form.componentChoice}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, componentChoice: event.target.value }))
              }
            >
              {TARIFF_COMPONENTS.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
              <option value={CUSTOM_COMPONENT}>{t('tariffs.componentCustom')}</option>
            </Select>
            {form.componentChoice === CUSTOM_COMPONENT ? (
              <Input
                aria-label={t('tariffs.componentCustom')}
                placeholder="OVERWEIGHT"
                value={form.customComponent}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    customComponent: event.target.value.toUpperCase(),
                  }))
                }
              />
            ) : null}
            <p className="text-xs text-muted-foreground">{t('tariffs.componentFieldHint')}</p>
          </div>

          <div className="space-y-1">
            <Label htmlFor="rule-unit">{t('tariffs.unit')}</Label>
            <Select
              id="rule-unit"
              value={form.unit}
              aria-invalid={unitError ? true : undefined}
              aria-describedby={unitError ? 'rule-unit-error' : undefined}
              onChange={(event) => {
                setUnitError(null);
                setForm((prev) => ({ ...prev, unit: event.target.value as TariffUnit }));
              }}
            >
              {allowedUnits.map((unit) => (
                <option key={unit} value={unit}>
                  {tariffUnitLabel(language, unit)}
                </option>
              ))}
            </Select>
            {unitError ? (
              <p
                id="rule-unit-error"
                role="alert"
                className="rounded-md border border-destructive/40 bg-destructive/10 px-2 py-1.5 text-xs text-destructive"
              >
                {unitError}
              </p>
            ) : (
              <p className="text-xs text-muted-foreground">{t('tariffs.unitFieldHint')}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label htmlFor="rule-price">{t('tariffs.price')}</Label>
              <Input
                id="rule-price"
                inputMode="decimal"
                placeholder="1500"
                value={form.price}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, price: scrubNumeric(event.target.value) }))
                }
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="rule-min">{t('tariffs.minQty')}</Label>
              <Input
                id="rule-min"
                inputMode="decimal"
                placeholder="0"
                value={form.minQty}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, minQty: scrubNumeric(event.target.value) }))
                }
              />
            </div>
          </div>

          <div className="space-y-1">
            <Label htmlFor="rule-from">{t('tariffs.effectiveFrom')}</Label>
            <Input
              id="rule-from"
              type="date"
              value={form.effectiveFrom}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, effectiveFrom: event.target.value }))
              }
            />
          </div>

          <div className="space-y-1">
            <Label htmlFor="rule-to">{t('tariffs.effectiveTo')}</Label>
            <Input
              id="rule-to"
              type="date"
              value={form.effectiveTo}
              onChange={(event) => setForm((prev) => ({ ...prev, effectiveTo: event.target.value }))}
            />
            <p className="text-xs text-muted-foreground">{t('tariffs.effectiveToHint')}</p>
          </div>
        </div>

        {/* Оператор должен прочитать вслух то, что сохраняет: цена, единица и
            ступень вместе значат не то же, что каждое поле по отдельности. */}
        <div className="rounded-md border border-border bg-muted/40 px-3 py-2">
          <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {t('tariffs.preview')}
          </div>
          <p className="mt-0.5 text-sm">{preview}</p>
        </div>

        {formError ? (
          <p
            role="alert"
            className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive"
          >
            {formError}
          </p>
        ) : null}
      </div>
    </Dialog>
  );
}

/* ──────────────────────────────── новый план ─────────────────────────────── */

function CreatePlanDialog({
  open,
  hasDefault,
  onClose,
  onCreated,
}: {
  open: boolean;
  hasDefault: boolean;
  onClose: () => void;
  onCreated: (plan: TariffPlanDto) => void;
}): React.ReactElement | null {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const toast = useToast();

  const [form, setForm] = React.useState<CreatePlanBody>({
    code: '',
    name: '',
    currency: 'UZS',
    isDefault: false,
    // Неактивный план не применяется ни к одному начислению, и заведённый через
    // интерфейс тариф молча уходил в проблемы биллинга. Значение по умолчанию —
    // «активен», иначе экран создаёт заведомо мёртвый план.
    isActive: true,
  });
  const [formError, setFormError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!open) return;
    setForm({ code: '', name: '', currency: 'UZS', isDefault: false, isActive: true });
    setFormError(null);
  }, [open]);

  const create = useMutation({
    mutationFn: (body: CreatePlanBody) => tariffsApi.createPlan(body),
    onSuccess: (plan) => {
      toast.success(t('tariffs.planCreated'), plan.code);
      onCreated(plan);
    },
    onError: (error) => {
      setFormError(errorText(error));
      toast.error(t('tariffs.planCreateFailed'), errorText(error));
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: PLANS_KEY });
    },
  });

  if (!open) return null;

  const submit = (): void => {
    setFormError(null);
    const code = form.code.trim();
    const name = form.name.trim();
    const currency = form.currency.trim().toUpperCase();
    if (code.length < 2 || name.length < 2) {
      setFormError(t('tariffs.validation.codeName'));
      return;
    }
    if (!CURRENCY_RE.test(currency)) {
      setFormError(t('tariffs.validation.currency'));
      return;
    }
    create.mutate({ code, name, currency, isDefault: form.isDefault, isActive: form.isActive });
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      size="md"
      title={t('tariffs.newPlan')}
      description={t('tariffs.newPlanHint')}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={create.isPending}>
            {t('ui.cancel')}
          </Button>
          <Button size="sm" onClick={submit} disabled={create.isPending}>
            {t('common.create')}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label htmlFor="plan-code">{t('tariffs.code')}</Label>
            <Input
              id="plan-code"
              placeholder="STD-2026"
              value={form.code}
              onChange={(event) => setForm((prev) => ({ ...prev, code: event.target.value }))}
            />
            <p className="text-xs text-muted-foreground">{t('tariffs.codeHint')}</p>
          </div>
          <div className="space-y-1">
            <Label htmlFor="plan-currency">{t('tariffs.currency')}</Label>
            <Input
              id="plan-currency"
              maxLength={3}
              value={form.currency}
              onChange={(event) =>
                setForm((prev) => ({ ...prev, currency: event.target.value.toUpperCase() }))
              }
            />
            <p className="text-xs text-muted-foreground">{t('tariffs.currencyHint')}</p>
          </div>
          <div className="space-y-1 sm:col-span-2">
            <Label htmlFor="plan-name">{t('tariffs.name')}</Label>
            <Input
              id="plan-name"
              value={form.name}
              onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
            />
          </div>
        </div>

        <div className="space-y-3 rounded-md border border-border p-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-sm font-medium">{t('tariffs.isActive')}</div>
              <p className="mt-0.5 text-xs text-muted-foreground">{t('tariffs.isActiveHint')}</p>
            </div>
            <Switch
              checked={form.isActive}
              label={t('tariffs.isActive')}
              onChange={(next) => setForm((prev) => ({ ...prev, isActive: next }))}
            />
          </div>

          <div className="flex items-start justify-between gap-3 border-t border-border pt-3">
            <div className="min-w-0">
              <div className="text-sm font-medium">{t('tariffs.default')}</div>
              <p className="mt-0.5 text-xs text-muted-foreground">{t('tariffs.defaultHint')}</p>
            </div>
            <Switch
              checked={form.isDefault}
              label={t('tariffs.default')}
              onChange={(next) => setForm((prev) => ({ ...prev, isDefault: next }))}
            />
          </div>

          {form.isDefault && hasDefault ? (
            <p
              role="status"
              className="rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-xs"
            >
              {t('tariffs.defaultSwitchBody')}
            </p>
          ) : null}

          {!form.isActive ? (
            <p
              role="status"
              className="rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-xs"
            >
              {t('tariffs.inactiveWarning')}
            </p>
          ) : null}
        </div>

        {formError ? (
          <p
            role="alert"
            className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive"
          >
            {formError}
          </p>
        ) : null}
      </div>
    </Dialog>
  );
}

/* ───────────────────────── нормы упаковки товаров ────────────────────────── */

/**
 * Нормы упаковки в каталоге пока не типизированы (`SkuDto` их не отдаёт),
 * поэтому читаем их мягко: экран не должен падать на старом ответе API.
 */
type SkuWithNorms = SkuDto & { unitsPerBox?: number | null; unitsPerPallet?: number | null };

/** Столько строк отдаёт `/skus` максимум — дальше нужен фильтр, а не прокрутка. */
const SKU_LIMIT = 500;

function PackingNormsSection(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const toast = useToast();

  const [sellerId, setSellerId] = React.useState('');
  const [search, setSearch] = React.useState('');
  const [query, setQuery] = React.useState('');

  // Поиск фильтрует на СЕРВЕРЕ, поэтому не на каждый символ: иначе на каждую
  // букву летит запрос, а список всё равно перерисуется последним ответом.
  React.useEffect(() => {
    const timer = window.setTimeout(() => setQuery(search.trim()), 300);
    return () => window.clearTimeout(timer);
  }, [search]);

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });

  const skusKey = ['mdm', 'skus', 'packing-norms', sellerId, query] as const;
  const skus = useQuery({
    queryKey: skusKey,
    queryFn: (): Promise<SkuWithNorms[]> =>
      mdmApi.skus({ sellerId: sellerId || undefined, q: query || undefined }),
  });

  const setNorms = useMutation({
    mutationFn: ({ skuId, body }: { skuId: string; body: PackingNormsBody }) =>
      tariffsApi.setPackingNorms(skuId, body),
    onMutate: async ({ skuId, body }) => {
      await queryClient.cancelQueries({ queryKey: skusKey });
      const previous = queryClient.getQueryData<SkuWithNorms[]>(skusKey);
      queryClient.setQueryData<SkuWithNorms[]>(skusKey, (rows) =>
        rows?.map((row) => (row.id === skuId ? { ...row, ...body } : row)),
      );
      return { previous };
    },
    onError: (error, _vars, context) => {
      if (context?.previous) queryClient.setQueryData(skusKey, context.previous);
      toast.error(t('tariffs.normsSaveFailed'), errorText(error));
    },
    onSuccess: () => {
      toast.success(t('tariffs.normsSaved'));
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ['mdm', 'skus'] });
    },
  });

  const submitNorm = async (
    sku: SkuWithNorms,
    field: 'unitsPerBox' | 'unitsPerPallet',
    raw: string,
  ): Promise<void> => {
    const trimmed = raw.trim();
    let value: number | null = null;
    if (trimmed !== '') {
      const parsed = Number(trimmed);
      if (!Number.isInteger(parsed) || parsed < 1) throw new Error(t('tariffs.validation.norm'));
      value = parsed;
    }
    const body: PackingNormsBody =
      field === 'unitsPerBox' ? { unitsPerBox: value } : { unitsPerPallet: value };
    await setNorms.mutateAsync({ skuId: sku.id, body });
  };

  const sellerOptions = React.useMemo(
    () =>
      (sellers.data ?? []).map((seller) => ({
        value: seller.id,
        label: `${seller.code} — ${seller.legalName}`,
        triggerLabel: seller.code,
        keywords: `${seller.code} ${seller.legalName}`,
      })),
    [sellers.data],
  );

  const columns: Array<DataTableColumn<SkuWithNorms>> = [
    {
      key: 'skuCode',
      header: t('tariffs.skuCode'),
      width: '12rem',
      cell: (row) => <span className="font-mono text-xs">{row.skuCode}</span>,
    },
    {
      key: 'name',
      header: t('tariffs.skuName'),
      cell: (row) => <span className="block truncate">{row.name}</span>,
    },
    {
      key: 'unitsPerBox',
      header: t('tariffs.unitsPerBox'),
      align: 'right',
      width: '11rem',
      cell: (row) => (
        <InlineNumber
          value={row.unitsPerBox ?? null}
          min={1}
          step={1}
          emptyLabel={t('tariffs.normNotSet')}
          ariaLabel={`${t('tariffs.unitsPerBox')} — ${row.skuCode}`}
          onSubmit={(next) => submitNorm(row, 'unitsPerBox', next)}
        />
      ),
    },
    {
      key: 'unitsPerPallet',
      header: t('tariffs.unitsPerPallet'),
      align: 'right',
      width: '11rem',
      cell: (row) => (
        <InlineNumber
          value={row.unitsPerPallet ?? null}
          min={1}
          step={1}
          emptyLabel={t('tariffs.normNotSet')}
          ariaLabel={`${t('tariffs.unitsPerPallet')} — ${row.skuCode}`}
          onSubmit={(next) => submitNorm(row, 'unitsPerPallet', next)}
        />
      ),
    },
    {
      key: 'state',
      header: t('tariffs.normsState'),
      align: 'right',
      width: '12rem',
      cell: (row) =>
        row.unitsPerBox == null && row.unitsPerPallet == null ? (
          <Badge variant="warning" size="sm">
            {t('tariffs.normMissing')}
          </Badge>
        ) : null,
    },
  ];

  const rows = skus.data ?? [];
  const filtered = sellerId !== '' || query !== '';

  return (
    <section className="space-y-3">
      <div>
        <h2 className="text-base font-semibold tracking-tight">{t('tariffs.norms')}</h2>
        <p className="mt-0.5 max-w-3xl text-sm text-muted-foreground">{t('tariffs.normsHint')}</p>
      </div>

      {skus.isError ? (
        <Card>
          <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
            <p className="text-sm text-destructive">{errorText(skus.error)}</p>
            <Button variant="outline" size="sm" onClick={() => void skus.refetch()}>
              {t('ui.retry')}
            </Button>
          </CardContent>
        </Card>
      ) : null}

      <DataTable
        columns={columns}
        rows={rows}
        getRowKey={(row) => row.id}
        loading={skus.isLoading}
        dense
        maxHeight="32rem"
        emptyTitle={t('tariffs.normsEmpty')}
        emptyDescription={t('tariffs.normsEmptyHint')}
        toolbar={
          <Toolbar>
            <ToolbarGroup label={t('tariffs.seller')} className="w-56">
              <SearchableSelect
                value={sellerId}
                onChange={setSellerId}
                options={sellerOptions}
                clearLabel={t('ui.all')}
                searchPlaceholder={t('ui.search')}
              />
            </ToolbarGroup>
            <ToolbarGroup label={t('ui.search')} className="w-64">
              <ToolbarSearch
                value={search}
                onChange={setSearch}
                placeholder={t('tariffs.skuSearchHint')}
              />
            </ToolbarGroup>
            {filtered ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setSellerId('');
                  setSearch('');
                }}
              >
                {t('ui.reset')}
              </Button>
            ) : null}
          </Toolbar>
        }
        footer={
          rows.length >= SKU_LIMIT ? (
            <p className="text-xs text-muted-foreground">
              {t('tariffs.normsLimit', { n: SKU_LIMIT })}
            </p>
          ) : undefined
        }
      />
    </section>
  );
}
