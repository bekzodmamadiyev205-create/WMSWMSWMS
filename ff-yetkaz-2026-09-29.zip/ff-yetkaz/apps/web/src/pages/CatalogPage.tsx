import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { BARCODE_KINDS } from '@ff/shared';
import type { BarcodeKind, SkuDto, SkuImportResultDto, SkuImportRowDto } from '@ff/shared';
import { ApiError } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { cellNumber, mapHeaders, parseCsv } from '@/lib/csv';
import { mdmApi } from '@/lib/mdm';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';

type Tab = 'sellers' | 'warehouses' | 'skus';

const BIN_KINDS = [
  'RECEIVING',
  'STORAGE',
  'PICKING',
  'PACKING',
  'QUARANTINE',
  'DAMAGED',
  'SHIPPING',
] as const;

/**
 * Ячейки, без которых склад не поедет: без RECEIVING не открыть приёмку,
 * без PACKING не создать задание на сборку. Заводим их одной кнопкой, чтобы
 * запуск не спотыкался на этом в первый же день.
 */
const REQUIRED_BINS = [
  { code: 'R-01-01-01', kind: 'RECEIVING' },
  { code: 'S-01-01-01', kind: 'STORAGE' },
  { code: 'P-01-01-01', kind: 'PACKING' },
  { code: 'X-01-01-01', kind: 'SHIPPING' },
  { code: 'D-01-01-01', kind: 'DAMAGED' },
];

const SKU_HEADER_ALIASES = {
  skuCode: ['артикул', 'sku', 'sku_code', 'skucode', 'код'],
  name: ['название', 'наименование', 'name', 'товар'],
  barcode: ['штрихкод', 'штрих-код', 'barcode', 'ean', 'ean13'],
  weightG: ['вес', 'вес,г', 'вес, г', 'weight', 'weightg', 'вес_г'],
  lengthMm: ['длина', 'length', 'lengthmm', 'длина,мм', 'длина, мм'],
  widthMm: ['ширина', 'width', 'widthmm', 'ширина,мм', 'ширина, мм'],
  heightMm: ['высота', 'height', 'heightmm', 'высота,мм', 'высота, мм'],
};

/**
 * Отказ сервера показываем его словами (там сказано, за каким SKU уже закреплён
 * штрихкод), а на обрыве связи — общий текст: голое «Failed to fetch» оператору
 * ничего не объясняет.
 */
function useErrorText(): (error: unknown) => string {
  const { t } = useI18n();
  return React.useCallback(
    (error: unknown) => (error instanceof ApiError ? error.message : t('common.error.network')),
    [t],
  );
}

function Message({ message }: { message: { kind: 'ok' | 'error'; text: string } | null }) {
  if (!message) return null;
  return (
    <p
      role="status"
      className={
        message.kind === 'ok'
          ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
          : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
      }
    >
      {message.text}
    </p>
  );
}

export function CatalogPage(): React.ReactElement {
  const { t } = useI18n();
  const [tab, setTab] = React.useState<Tab>('sellers');

  return (
    <div className="mx-auto max-w-4xl space-y-6 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('catalog.title')}</h1>
        <Link to="/" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>

      <div className="flex flex-wrap gap-2">
        {(
          [
            ['sellers', t('catalog.tab.sellers')],
            ['warehouses', t('catalog.tab.warehouses')],
            ['skus', t('catalog.tab.skus')],
          ] as Array<[Tab, string]>
        ).map(([key, title]) => (
          <Button
            key={key}
            variant={tab === key ? 'default' : 'outline'}
            size="sm"
            onClick={() => setTab(key)}
          >
            {title}
          </Button>
        ))}
      </div>

      {tab === 'sellers' && <SellersSection />}
      {tab === 'warehouses' && <WarehousesSection />}
      {tab === 'skus' && <SkusSection />}
    </div>
  );
}

// ---------------------------------------------------------------- селлеры

function SellersSection(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [form, setForm] = React.useState({ code: '', legalName: '', contactPhone: '' });
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });

  const create = useMutation({
    mutationFn: () =>
      mdmApi.createSeller({
        code: form.code.trim().toUpperCase(),
        legalName: form.legalName.trim(),
        contactPhone: form.contactPhone.trim() || undefined,
      }),
    onSuccess: (seller) => {
      setMessage({ kind: 'ok', text: t('catalog.sellers.created', { code: seller.code }) });
      setForm({ code: '', legalName: '', contactPhone: '' });
      queryClient.invalidateQueries({ queryKey: ['mdm', 'sellers'] });
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : t('common.error.network'),
      }),
  });

  return (
    <div className="space-y-4">
      <Message message={message} />

      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="text-sm font-medium">{t('catalog.sellers.new')}</div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label htmlFor="seller-code">{t('catalog.field.code')}</Label>
              <Input
                id="seller-code"
                value={form.code}
                placeholder="ACME"
                onChange={(event) => setForm({ ...form, code: event.target.value })}
              />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="seller-name">{t('catalog.sellers.legalName')}</Label>
              <Input
                id="seller-name"
                value={form.legalName}
                placeholder={t('catalog.sellers.legalNamePlaceholder')}
                onChange={(event) => setForm({ ...form, legalName: event.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="seller-phone">{t('catalog.sellers.phone')}</Label>
              <Input
                id="seller-phone"
                value={form.contactPhone}
                onChange={(event) => setForm({ ...form, contactPhone: event.target.value })}
              />
            </div>
          </div>
          <Button
            disabled={form.code.trim().length < 2 || form.legalName.trim().length < 2 || create.isPending}
            onClick={() => create.mutate()}
          >
            {t('catalog.sellers.submit')}
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {(sellers.data ?? []).map((seller) => (
          <Card key={seller.id}>
            <CardContent className="flex flex-wrap items-baseline justify-between gap-2 p-4 text-sm">
              <div>
                <span className="font-medium">{seller.code}</span>
                <span className="text-muted-foreground"> · {seller.legalName}</span>
              </div>
              <div className="text-muted-foreground">
                {seller.contactPhone ?? '—'}
                {!seller.isActive && (
                  <span className="text-destructive"> · {t('catalog.sellers.disabled')}</span>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
        {sellers.data?.length === 0 && (
          <p className="text-sm text-muted-foreground">{t('catalog.sellers.empty')}</p>
        )}
      </div>
    </div>
  );
}

// ------------------------------------------------------- склады и ячейки

function WarehousesSection(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [warehouseId, setWarehouseId] = React.useState('');
  const [warehouseForm, setWarehouseForm] = React.useState({ code: '', name: '' });
  const [binForm, setBinForm] = React.useState({ code: '', kind: 'STORAGE' });
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  const warehouses = useQuery({ queryKey: ['mdm', 'warehouses'], queryFn: mdmApi.warehouses });
  const selected = warehouseId || warehouses.data?.[0]?.id || '';

  const bins = useQuery({
    queryKey: ['mdm', 'bins', selected],
    queryFn: () => mdmApi.bins(selected),
    enabled: Boolean(selected),
  });

  const fail = (error: unknown) =>
    setMessage({
      kind: 'error',
      text: error instanceof ApiError ? error.message : t('common.error.network'),
    });

  const createWarehouse = useMutation({
    mutationFn: () =>
      mdmApi.createWarehouse({
        code: warehouseForm.code.trim().toUpperCase(),
        name: warehouseForm.name.trim(),
      }),
    onSuccess: (warehouse) => {
      setMessage({ kind: 'ok', text: t('catalog.warehouses.created', { code: warehouse.code }) });
      setWarehouseForm({ code: '', name: '' });
      queryClient.invalidateQueries({ queryKey: ['mdm', 'warehouses'] });
    },
    onError: fail,
  });

  const createBin = useMutation({
    mutationFn: () =>
      mdmApi.createBin({
        warehouseId: selected,
        code: binForm.code.trim().toUpperCase(),
        kind: binForm.kind,
      }),
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('catalog.warehouses.binAdded') });
      setBinForm({ code: '', kind: 'STORAGE' });
      queryClient.invalidateQueries({ queryKey: ['mdm', 'bins', selected] });
    },
    onError: fail,
  });

  const createRequired = useMutation({
    mutationFn: async () => {
      const existing = new Set((bins.data ?? []).map((bin) => bin.kind));
      let added = 0;
      for (const bin of REQUIRED_BINS) {
        if (existing.has(bin.kind as never)) continue;
        await mdmApi.createBin({ warehouseId: selected, ...bin });
        added += 1;
      }
      return added;
    },
    onSuccess: (added) => {
      setMessage({
        kind: 'ok',
        text:
          added > 0
            ? t('catalog.warehouses.binsAdded', { n: added })
            : t('catalog.warehouses.binsAllPresent'),
      });
      queryClient.invalidateQueries({ queryKey: ['mdm', 'bins', selected] });
    },
    onError: fail,
  });

  const missing = REQUIRED_BINS.filter(
    (required) => !(bins.data ?? []).some((bin) => bin.kind === required.kind),
  );

  return (
    <div className="space-y-4">
      <Message message={message} />

      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="text-sm font-medium">{t('catalog.warehouses.new')}</div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label htmlFor="wh-code">{t('catalog.field.code')}</Label>
              <Input
                id="wh-code"
                value={warehouseForm.code}
                placeholder="TAS-1"
                onChange={(event) => setWarehouseForm({ ...warehouseForm, code: event.target.value })}
              />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="wh-name">{t('catalog.field.name')}</Label>
              <Input
                id="wh-name"
                value={warehouseForm.name}
                placeholder={t('catalog.warehouses.warehousePlaceholder')}
                onChange={(event) => setWarehouseForm({ ...warehouseForm, name: event.target.value })}
              />
            </div>
          </div>
          <Button
            disabled={warehouseForm.code.trim().length < 2 || createWarehouse.isPending}
            onClick={() => createWarehouse.mutate()}
          >
            {t('catalog.warehouses.submitWarehouse')}
          </Button>
        </CardContent>
      </Card>

      {(warehouses.data ?? []).length > 0 && (
        <Card>
          <CardContent className="space-y-4 p-4">
            <div className="space-y-1">
              <Label htmlFor="wh-pick">{t('catalog.warehouses.binsOfWarehouse')}</Label>
              <Select
                id="wh-pick"
                value={selected}
                onChange={(event) => setWarehouseId(event.target.value)}
              >
                {(warehouses.data ?? []).map((warehouse) => (
                  <option key={warehouse.id} value={warehouse.id}>
                    {warehouse.code} — {warehouse.name}
                  </option>
                ))}
              </Select>
            </div>

            {missing.length > 0 && (
              <div className="space-y-2 rounded-md border border-destructive/40 bg-destructive/5 p-3">
                <p className="text-sm text-destructive">
                  {t('catalog.warehouses.missing', {
                    kinds: missing
                      .map((bin) => t(`catalog.binKind.${bin.kind}` as MessageKey))
                      .join(', '),
                  })}
                </p>
                <Button size="sm" disabled={createRequired.isPending} onClick={() => createRequired.mutate()}>
                  {t('catalog.warehouses.createRequired')}
                </Button>
              </div>
            )}

            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1 sm:col-span-2">
                <Label htmlFor="bin-code">{t('catalog.warehouses.binCode')}</Label>
                <Input
                  id="bin-code"
                  value={binForm.code}
                  placeholder="S-01-03-02"
                  onChange={(event) => setBinForm({ ...binForm, code: event.target.value })}
                />
                {/* Маршрут сборки — это сортировка по коду, поэтому нули важны. */}
                <p className="text-xs text-muted-foreground">
                  {t('catalog.warehouses.binCodeHint')}
                </p>
              </div>
              <div className="space-y-1">
                <Label htmlFor="bin-kind">{t('catalog.warehouses.binKindLabel')}</Label>
                <Select
                  id="bin-kind"
                  value={binForm.kind}
                  onChange={(event) => setBinForm({ ...binForm, kind: event.target.value })}
                >
                  {BIN_KINDS.map((kind) => (
                    <option key={kind} value={kind}>
                      {t(`catalog.binKind.${kind}` as MessageKey)}
                    </option>
                  ))}
                </Select>
              </div>
            </div>
            <Button
              variant="outline"
              disabled={binForm.code.trim().length < 3 || createBin.isPending}
              onClick={() => createBin.mutate()}
            >
              {t('catalog.warehouses.addBin')}
            </Button>

            <div className="flex flex-wrap gap-2 pt-2">
              {(bins.data ?? []).map((bin) => (
                <span
                  key={bin.id}
                  className="rounded border px-2 py-1 text-xs tabular-nums"
                  title={t(`catalog.binKind.${bin.kind}` as MessageKey)}
                >
                  {bin.code}
                  <span className="text-muted-foreground">
                    {' '}
                    · {t(`catalog.binKind.${bin.kind}` as MessageKey)}
                  </span>
                </span>
              ))}
              {bins.data?.length === 0 && (
                <p className="text-sm text-muted-foreground">{t('catalog.warehouses.binsEmpty')}</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ----------------------------------------------------------------- товары

function SkusSection(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const errorText = useErrorText();
  const { user } = useAuth();
  // Ручки штрихкодов разрешены ADMIN и WAREHOUSE_OPERATOR. Кнопку, которая
  // гарантированно ответит 403, не показываем: у сборщика её быть не должно.
  const canManageBarcodes = (user?.roles ?? []).some(
    (role) => role === 'ADMIN' || role === 'WAREHOUSE_OPERATOR',
  );

  const [sellerId, setSellerId] = React.useState('');
  const [search, setSearch] = React.useState('');
  const [form, setForm] = React.useState<{
    skuCode: string;
    name: string;
    barcode: string;
    barcodeKind: BarcodeKind;
    weightG: string;
  }>({ skuCode: '', name: '', barcode: '', barcodeKind: 'EAN13', weightG: '' });
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [importResult, setImportResult] = React.useState<SkuImportResultDto | null>(null);
  const [barcodeTarget, setBarcodeTarget] = React.useState<SkuDto | null>(null);
  // Товар создан, а код к нему не привязался: держим код под рукой, чтобы
  // оператор не набирал его заново и не пытался «повторить создание».
  const [barcodePending, setBarcodePending] = React.useState<{ sku: SkuDto; barcode: string } | null>(
    null,
  );
  const fileRef = React.useRef<HTMLInputElement>(null);

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const selected = sellerId || sellers.data?.[0]?.id || '';

  const skus = useQuery({
    queryKey: ['mdm', 'skus', selected, search],
    queryFn: () => mdmApi.skus({ sellerId: selected, q: search || undefined }),
    enabled: Boolean(selected),
  });

  const fail = (error: unknown) => setMessage({ kind: 'error', text: errorText(error) });

  const create = useMutation({
    /**
     * Создание товара и привязка кода — два разных факта, и отвечать за них надо
     * порознь. Раньше занятый штрихкод отменял весь результат в глазах оператора:
     * товар уже лежал в справочнике без кода, а форма показывала ошибку — на
     * повторе он получал «у селлера уже есть такой артикул» и заходил в тупик.
     */
    mutationFn: async (): Promise<{ sku: SkuDto; barcodeError: unknown }> => {
      const sku = await mdmApi.createSku({
        sellerId: selected,
        skuCode: form.skuCode.trim(),
        name: form.name.trim(),
        weightG: form.weightG ? Number(form.weightG) : undefined,
      });

      const barcode = form.barcode.trim();
      if (!barcode) return { sku, barcodeError: null };
      try {
        // Первый код товара — основной: по нему он подставляется в документы.
        const withBarcode = await mdmApi.addBarcode(sku.id, {
          barcode,
          kind: form.barcodeKind,
          isPrimary: true,
        });
        return { sku: withBarcode, barcodeError: null };
      } catch (error) {
        return { sku, barcodeError: error };
      }
    },
    onSuccess: ({ sku, barcodeError }) => {
      const attempted = form.barcode.trim();
      setForm({ skuCode: '', name: '', barcode: '', barcodeKind: form.barcodeKind, weightG: '' });
      queryClient.invalidateQueries({ queryKey: ['mdm', 'skus'] });

      if (barcodeError) {
        setBarcodePending({ sku, barcode: attempted });
        setMessage({
          kind: 'error',
          text: t('catalog.skus.createdNoBarcode', {
            code: sku.skuCode,
            reason: errorText(barcodeError),
          }),
        });
        return;
      }

      setBarcodePending(null);
      setMessage({ kind: 'ok', text: t('catalog.skus.created', { code: sku.skuCode }) });
    },
    onError: fail,
  });

  const importFile = useMutation({
    mutationFn: async (file: File) => {
      const rows = parseCsv(await file.text());
      if (rows.length < 2) throw new Error(t('catalog.skus.importNoRows'));

      const columns = mapHeaders(rows[0], SKU_HEADER_ALIASES);
      if (columns.skuCode === undefined || columns.name === undefined) {
        throw new Error(t('catalog.skus.importNoColumns'));
      }

      // Номер строки ФАЙЛА, а не позиция в отправленном массиве: оператор ищет
      // ошибку в своём Excel, и «строка 4» должна означать четвёртую строку
      // файла, а не четвёртую из тех, что дошли до сервера.
      const prepared = rows.slice(1).map((cells, index) => ({
        fileLine: index + 2,
        row: {
          skuCode: (cells[columns.skuCode] ?? '').trim(),
          name: (cells[columns.name] ?? '').trim(),
          barcode:
            columns.barcode === undefined ? undefined : cells[columns.barcode]?.trim() || undefined,
          weightG: columns.weightG === undefined ? undefined : cellNumber(cells[columns.weightG]),
          lengthMm: columns.lengthMm === undefined ? undefined : cellNumber(cells[columns.lengthMm]),
          widthMm: columns.widthMm === undefined ? undefined : cellNumber(cells[columns.widthMm]),
          heightMm: columns.heightMm === undefined ? undefined : cellNumber(cells[columns.heightMm]),
        } satisfies SkuImportRowDto,
      }));

      // Негодные строки НЕ выбрасываются молча: пропавшая позиция каталога
      // обнаружится через месяц, когда её не найдёт сканер на приёмке.
      const rejected = prepared.filter((item) => !item.row.skuCode || !item.row.name);
      const valid = prepared.filter((item) => item.row.skuCode && item.row.name);
      if (valid.length === 0) throw new Error(t('catalog.skus.importNoValid'));

      const result = await mdmApi.importSkus(
        selected,
        valid.map((item) => item.row),
      );

      const merged: SkuImportResultDto = {
        created: result.created,
        updated: result.updated,
        failed: result.failed + rejected.length,
        rows: [
          ...result.rows.map((row) => ({
            ...row,
            row: valid[row.row - 1]?.fileLine ?? row.row,
          })),
          ...rejected.map((item) => ({
            row: item.fileLine,
            skuCode: item.row.skuCode || '—',
            outcome: 'FAILED' as const,
            message: t('catalog.skus.importRowRejected'),
          })),
        ].sort((left, right) => left.row - right.row),
      };
      return merged;
    },
    onSuccess: (result) => {
      setImportResult(result);
      setMessage({
        kind: result.failed > 0 ? 'error' : 'ok',
        text: t('catalog.skus.importSummary', {
          created: result.created,
          updated: result.updated,
          failed: result.failed,
        }),
      });
      queryClient.invalidateQueries({ queryKey: ['mdm', 'skus'] });
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : (error as Error).message,
      }),
  });

  return (
    <div className="space-y-4">
      <Message message={message} />

      {barcodePending && (
        <div className="flex flex-wrap items-center gap-3 rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm">
          <span>
            {t('catalog.skus.barcodePending', {
              code: barcodePending.sku.skuCode,
              barcode: barcodePending.barcode,
            })}
          </span>
          <Button size="sm" onClick={() => setBarcodeTarget(barcodePending.sku)}>
            {t('catalog.skus.retryBarcode')}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setBarcodePending(null)}>
            {t('catalog.skus.barcodePendingDismiss')}
          </Button>
        </div>
      )}

      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label htmlFor="sku-seller">{t('catalog.skus.seller')}</Label>
              <Select
                id="sku-seller"
                value={selected}
                onChange={(event) => setSellerId(event.target.value)}
              >
                {(sellers.data ?? []).map((seller) => (
                  <option key={seller.id} value={seller.id}>
                    {seller.code} — {seller.legalName}
                  </option>
                ))}
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="sku-search">{t('common.search')}</Label>
              <Input
                id="sku-search"
                value={search}
                placeholder={t('catalog.skus.searchPlaceholder')}
                onChange={(event) => setSearch(event.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="text-sm font-medium">{t('catalog.skus.importTitle')}</div>
          <p className="text-xs text-muted-foreground">{t('catalog.skus.importHint')}</p>
          <input
            ref={fileRef}
            type="file"
            accept=".csv,text/csv,text/plain"
            className="block w-full text-sm file:mr-3 file:rounded-md file:border file:bg-background file:px-3 file:py-1.5 file:text-sm"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) importFile.mutate(file);
              // Сбрасываем значение: иначе повторный выбор того же файла не
              // вызовет onChange, и «загрузить ещё раз» перестанет работать.
              if (fileRef.current) fileRef.current.value = '';
            }}
          />

          {importResult && importResult.rows.some((row) => row.outcome === 'FAILED') && (
            <div className="max-h-48 overflow-y-auto rounded border">
              <table className="w-full text-xs">
                <tbody>
                  {importResult.rows
                    .filter((row) => row.outcome === 'FAILED')
                    .map((row) => (
                      <tr key={row.row} className="border-b last:border-0">
                        <td className="p-2 tabular-nums text-muted-foreground">
                          {t('catalog.skus.rowLabel', { n: row.row })}
                        </td>
                        <td className="p-2 font-medium">{row.skuCode}</td>
                        <td className="p-2 text-destructive">{row.message}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="text-sm font-medium">{t('catalog.skus.new')}</div>
          <div className="grid gap-3 sm:grid-cols-4">
            <div className="space-y-1">
              <Label htmlFor="sku-code">{t('catalog.field.skuCode')}</Label>
              <Input
                id="sku-code"
                value={form.skuCode}
                onChange={(event) => setForm({ ...form, skuCode: event.target.value })}
              />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="sku-name">{t('catalog.field.name')}</Label>
              <Input
                id="sku-name"
                value={form.name}
                onChange={(event) => setForm({ ...form, name: event.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="sku-weight">{t('catalog.field.weightG')}</Label>
              <Input
                id="sku-weight"
                inputMode="numeric"
                value={form.weightG}
                onChange={(event) =>
                  setForm({ ...form, weightG: event.target.value.replace(/[^\d]/g, '') })
                }
              />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="sku-barcode">{t('catalog.field.barcode')}</Label>
              <Input
                id="sku-barcode"
                value={form.barcode}
                onChange={(event) => setForm({ ...form, barcode: event.target.value })}
              />
              {/* Код можно не вводить сейчас — товар примут по строке заявки, а
                  код привяжут из таблицы, когда коробка окажется в руках. */}
              <p className="text-xs text-muted-foreground">{t('catalog.skus.barcodeOptional')}</p>
            </div>
            <div className="space-y-1">
              <Label htmlFor="sku-barcode-kind">{t('catalog.field.barcodeKind')}</Label>
              <Select
                id="sku-barcode-kind"
                value={form.barcodeKind}
                onChange={(event) =>
                  setForm({ ...form, barcodeKind: event.target.value as BarcodeKind })
                }
              >
                {BARCODE_KINDS.map((kind) => (
                  <option key={kind} value={kind}>
                    {t(`catalog.barcodeKind.${kind}` as MessageKey)}
                  </option>
                ))}
              </Select>
            </div>
          </div>
          <Button
            disabled={!selected || form.skuCode.trim() === '' || form.name.trim() === '' || create.isPending}
            onClick={() => create.mutate()}
          >
            {t('catalog.skus.submit')}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b text-muted-foreground">
                <tr>
                  <th className="p-3 text-left font-medium">{t('catalog.field.skuCode')}</th>
                  <th className="p-3 text-left font-medium">{t('catalog.field.barcode')}</th>
                  <th className="p-3 text-right font-medium">{t('catalog.field.weightG')}</th>
                </tr>
              </thead>
              <tbody>
                {(skus.data ?? []).map((sku) => (
                  <tr key={sku.id} className="border-b last:border-0">
                    <td className="p-3">
                      <div className="font-medium">{sku.skuCode}</div>
                      <div className="text-xs text-muted-foreground">{sku.name}</div>
                    </td>
                    <td className="p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="tabular-nums">
                          {sku.barcodes.find((code) => code.isPrimary)?.barcode ??
                            sku.barcodes[0]?.barcode ?? (
                              <span className="text-destructive">{t('catalog.skus.noBarcode')}</span>
                            )}
                        </span>
                        {sku.barcodes.length > 1 && (
                          <span className="text-xs text-muted-foreground">
                            {t('catalog.barcodes.more', { n: sku.barcodes.length - 1 })}
                          </span>
                        )}
                        {canManageBarcodes && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setBarcodeTarget(sku)}
                          >
                            {sku.barcodes.length === 0
                              ? t('catalog.barcodes.bind')
                              : t('catalog.barcodes.manage')}
                          </Button>
                        )}
                      </div>
                    </td>
                    <td className="p-3 text-right tabular-nums">
                      {sku.weightG ?? <span className="text-destructive">{t('catalog.skus.noWeight')}</span>}
                    </td>
                  </tr>
                ))}
                {skus.data?.length === 0 && (
                  <tr>
                    <td className="p-3 text-muted-foreground" colSpan={3}>
                      {t('catalog.skus.empty')}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {barcodeTarget && (
        <BarcodesDialog
          // Ключ по товару: диалог держит свой список кодов, и при переходе на
          // другой товар состояние обязано начаться заново, а не донестись от предыдущего.
          key={barcodeTarget.id}
          sku={barcodeTarget}
          initialBarcode={
            barcodePending?.sku.id === barcodeTarget.id ? barcodePending.barcode : ''
          }
          onClose={() => setBarcodeTarget(null)}
          onChanged={(updated) => {
            setBarcodeTarget(updated);
            if (barcodePending?.sku.id === updated.id && updated.barcodes.length > 0) {
              setBarcodePending(null);
            }
            queryClient.invalidateQueries({ queryKey: ['mdm', 'skus'] });
          }}
        />
      )}
    </div>
  );
}

// ------------------------------------------------------ штрихкоды товара

interface BarcodesDialogProps {
  sku: SkuDto;
  /** Код, который не привязался при создании товара — чтобы не набирать заново. */
  initialBarcode: string;
  onClose: () => void;
  onChanged: (sku: SkuDto) => void;
}

/**
 * Привязка и отвязка штрихкодов. Без неё товар, заведённый без кода, чинить было
 * нечем: ручки на бэкенде есть, а вызвать их из интерфейса не мог даже админ.
 */
function BarcodesDialog({
  sku,
  initialBarcode,
  onClose,
  onChanged,
}: BarcodesDialogProps): React.ReactElement {
  const { t } = useI18n();
  const errorText = useErrorText();
  // Список кодов ведём по ответам сервера: обе ручки возвращают обновлённый SKU,
  // поэтому диалог не гадает, что получилось, и не ждёт перезагрузки списка.
  const [current, setCurrent] = React.useState(sku);
  const [barcode, setBarcode] = React.useState(initialBarcode);
  const [kind, setKind] = React.useState<BarcodeKind>('EAN13');
  const [isPrimary, setIsPrimary] = React.useState(sku.barcodes.length === 0);
  const [pendingRemoval, setPendingRemoval] = React.useState<string | null>(null);
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  const primary = current.barcodes.find((code) => code.isPrimary) ?? null;

  const applied = (updated: SkuDto): void => {
    setCurrent(updated);
    onChanged(updated);
  };

  const add = useMutation({
    mutationFn: () =>
      mdmApi.addBarcode(current.id, { barcode: barcode.trim(), kind, isPrimary }),
    onSuccess: (updated) => {
      const added = barcode.trim();
      applied(updated);
      setBarcode('');
      // Второй код по умолчанию уже не основной: основной у товара ровно один,
      // и менять его молча при каждой привязке нельзя.
      setIsPrimary(false);
      setMessage({ kind: 'ok', text: t('catalog.barcodes.added', { barcode: added }) });
    },
    onError: (error) => setMessage({ kind: 'error', text: errorText(error) }),
  });

  const remove = useMutation({
    mutationFn: (barcodeId: string) => mdmApi.removeBarcode(current.id, barcodeId),
    onSuccess: (updated, barcodeId) => {
      const removed = current.barcodes.find((code) => code.id === barcodeId)?.barcode ?? '';
      applied(updated);
      setPendingRemoval(null);
      setMessage({ kind: 'ok', text: t('catalog.barcodes.removed', { barcode: removed }) });
    },
    onError: (error) => setMessage({ kind: 'error', text: errorText(error) }),
  });

  const busy = add.isPending || remove.isPending;

  const primaryHint = (): string => {
    if (current.barcodes.length === 0) return t('catalog.barcodes.firstHint');
    if (isPrimary && primary) return t('catalog.barcodes.primaryReplaces', { barcode: primary.barcode });
    return t('catalog.barcodes.primaryHint');
  };

  return (
    <Dialog
      open
      onClose={onClose}
      size="md"
      title={t('catalog.barcodes.title', { code: current.skuCode })}
      description={t('catalog.barcodes.description')}
      footer={
        <Button variant="outline" size="sm" onClick={onClose}>
          {t('ui.close')}
        </Button>
      }
    >
      <div className="space-y-4">
        <Message message={message} />

        <div className="space-y-2">
          {current.barcodes.map((code) => (
            <div
              key={code.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-md border p-2"
            >
              <div>
                <span className="font-medium tabular-nums">{code.barcode}</span>
                <span className="text-xs text-muted-foreground">
                  {' '}
                  · {t(`catalog.barcodeKind.${code.kind}` as MessageKey)}
                </span>
                {code.isPrimary && (
                  <span className="text-xs font-medium"> · {t('catalog.barcodes.primary')}</span>
                )}
              </div>

              {/* Подтверждение прямо в строке, а не вторым модальным окном:
                  вложенные диалоги дерутся за фокус, и выйти из них некуда. */}
              {pendingRemoval === code.id ? (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-destructive">
                    {t('catalog.barcodes.confirmRemove')}
                  </span>
                  <Button
                    variant="destructive"
                    size="sm"
                    disabled={busy}
                    onClick={() => remove.mutate(code.id)}
                  >
                    {t('catalog.barcodes.remove')}
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setPendingRemoval(null)}>
                    {t('ui.cancel')}
                  </Button>
                </div>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  disabled={busy}
                  onClick={() => setPendingRemoval(code.id)}
                >
                  {t('catalog.barcodes.remove')}
                </Button>
              )}
            </div>
          ))}

          {current.barcodes.length === 0 && (
            <p className="text-sm text-muted-foreground">{t('catalog.barcodes.empty')}</p>
          )}
        </div>

        <div className="space-y-3 border-t pt-3">
          <div className="text-sm font-medium">{t('catalog.barcodes.newCode')}</div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="barcode-value">{t('catalog.field.barcode')}</Label>
              <Input
                id="barcode-value"
                value={barcode}
                onChange={(event) => setBarcode(event.target.value)}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="barcode-kind">{t('catalog.field.barcodeKind')}</Label>
              <Select
                id="barcode-kind"
                value={kind}
                onChange={(event) => setKind(event.target.value as BarcodeKind)}
              >
                {BARCODE_KINDS.map((option) => (
                  <option key={option} value={option}>
                    {t(`catalog.barcodeKind.${option}` as MessageKey)}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              className="h-4 w-4"
              checked={isPrimary}
              onChange={(event) => setIsPrimary(event.target.checked)}
            />
            {t('catalog.barcodes.isPrimary')}
          </label>
          <p className="text-xs text-muted-foreground">{primaryHint()}</p>

          <Button disabled={barcode.trim() === '' || busy} onClick={() => add.mutate()}>
            {t('catalog.barcodes.add')}
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
