import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import type { DepartmentDto } from '@ff/shared';
import { DEPARTMENT_CODE_RE } from '@ff/shared';
import { ApiError } from '@/lib/api';
import { departmentsApi } from '@/lib/departments';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

function Message({ message }: { message: { kind: 'ok' | 'error'; text: string } | null }) {
  if (!message) return null;
  return (
    <p
      role="status"
      className={
        message.kind === 'ok'
          ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
          : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
      }
    >
      {message.text}
    </p>
  );
}

/**
 * Отделы (подразделения) оператора. Экран административный, живёт в «Параметрах».
 * Отдел — организационная метка над учётной записью; привязка сотрудника к
 * отделу делается на экране «Доступы».
 */
export function DepartmentsPage(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [form, setForm] = React.useState({ code: '', name: '', description: '' });

  const departments = useQuery({ queryKey: ['departments'], queryFn: departmentsApi.list });

  const fail = (error: unknown) =>
    setMessage({
      kind: 'error',
      text: error instanceof ApiError ? error.message : t('common.error.network'),
    });
  const refresh = () => queryClient.invalidateQueries({ queryKey: ['departments'] });

  const create = useMutation({
    mutationFn: () =>
      departmentsApi.create({
        code: form.code.trim().toUpperCase(),
        name: form.name.trim(),
        description: form.description.trim() || undefined,
      }),
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('departments.created') });
      setForm({ code: '', name: '', description: '' });
      refresh();
    },
    onError: fail,
  });

  const codeValid = DEPARTMENT_CODE_RE.test(form.code.trim().toUpperCase());
  const list = departments.data ?? [];

  return (
    <div className="mx-auto max-w-3xl space-y-4 p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">{t('departments.title')}</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{t('departments.subtitle')}</p>
        </div>
        <Link to="/" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>

      <Message message={message} />

      {/* Новый отдел */}
      <Card>
        <CardContent className="space-y-3 p-4">
          <div className="text-sm font-medium">{t('departments.new')}</div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label htmlFor="dep-code">{t('departments.code')}</Label>
              <Input
                id="dep-code"
                value={form.code}
                placeholder="WAREHOUSE"
                onChange={(event) =>
                  setForm({ ...form, code: event.target.value.toUpperCase().replace(/[^A-Z0-9_]/g, '') })
                }
              />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="dep-name">{t('departments.name')}</Label>
              <Input
                id="dep-name"
                value={form.name}
                onChange={(event) => setForm({ ...form, name: event.target.value })}
              />
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="dep-desc">{t('departments.description')}</Label>
            <Input
              id="dep-desc"
              value={form.description}
              onChange={(event) => setForm({ ...form, description: event.target.value })}
            />
            <p className="text-xs text-muted-foreground">{t('departments.codeHint')}</p>
          </div>
          <Button
            disabled={create.isPending || !codeValid || form.name.trim().length < 1}
            onClick={() => create.mutate()}
          >
            {t('common.create')}
          </Button>
        </CardContent>
      </Card>

      {/* Список отделов */}
      {departments.isLoading && (
        <p className="text-sm text-muted-foreground">{t('common.loading')}</p>
      )}
      {departments.isError && (
        <Card>
          <CardContent className="flex items-center justify-between gap-3 p-4">
            <span className="text-sm text-destructive">{t('common.error.network')}</span>
            <Button variant="outline" size="sm" onClick={() => departments.refetch()}>
              {t('common.retry')}
            </Button>
          </CardContent>
        </Card>
      )}
      {!departments.isLoading && list.length === 0 && (
        <p className="text-sm text-muted-foreground">{t('departments.noItems')}</p>
      )}

      <div className="space-y-2">
        {list.map((department) => (
          <DepartmentCard
            key={department.id}
            department={department}
            onDone={(text) => {
              setMessage({ kind: 'ok', text });
              refresh();
            }}
            onError={fail}
          />
        ))}
      </div>
    </div>
  );
}

function DepartmentCard({
  department,
  onDone,
  onError,
}: {
  department: DepartmentDto;
  onDone: (text: string) => void;
  onError: (error: unknown) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [editing, setEditing] = React.useState(false);
  const [draft, setDraft] = React.useState({ name: department.name, description: department.description ?? '' });

  const save = useMutation({
    mutationFn: () =>
      departmentsApi.update(department.id, {
        name: draft.name.trim(),
        description: draft.description.trim(),
      }),
    onSuccess: () => {
      setEditing(false);
      onDone(t('departments.saved'));
    },
    onError,
  });

  const toggle = useMutation({
    mutationFn: () => departmentsApi.update(department.id, { isActive: !department.isActive }),
    onSuccess: () => onDone(t('departments.saved')),
    onError,
  });

  return (
    <Card className={department.isActive ? undefined : 'opacity-60'}>
      <CardContent className="space-y-2 p-4">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <div className="min-w-0">
            <span className="font-medium">{department.name}</span>
            <span className="ml-2 rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{department.code}</span>
          </div>
          <span
            className={department.isActive ? 'text-sm text-muted-foreground' : 'text-sm text-destructive'}
          >
            {department.isActive ? t('departments.active') : t('departments.disabled')}
          </span>
        </div>

        {department.description && !editing && (
          <p className="text-sm text-muted-foreground">{department.description}</p>
        )}
        <p className="text-xs text-muted-foreground">
          {department.memberCount} {t('departments.members')}
        </p>

        {editing ? (
          <div className="space-y-2 border-t pt-3">
            <div className="space-y-1">
              <Label htmlFor={`d-name-${department.id}`}>{t('departments.name')}</Label>
              <Input
                id={`d-name-${department.id}`}
                value={draft.name}
                onChange={(event) => setDraft({ ...draft, name: event.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor={`d-desc-${department.id}`}>{t('departments.description')}</Label>
              <Input
                id={`d-desc-${department.id}`}
                value={draft.description}
                onChange={(event) => setDraft({ ...draft, description: event.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                disabled={save.isPending || draft.name.trim().length < 1}
                onClick={() => save.mutate()}
              >
                {t('common.save')}
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setEditing(false);
                  setDraft({ name: department.name, description: department.description ?? '' });
                }}
              >
                {t('common.cancel')}
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => setEditing(true)}>
              {t('departments.rename')}
            </Button>
            <Button size="sm" variant="ghost" disabled={toggle.isPending} onClick={() => toggle.mutate()}>
              {department.isActive ? t('departments.disable') : t('departments.enable')}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
