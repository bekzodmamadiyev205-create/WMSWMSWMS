import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { Role, UserSummaryDto } from '@ff/shared';
import { PASSWORD_MIN_LENGTH, ROLES, SELLER_ROLE } from '@ff/shared';
import { ApiError } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { departmentsApi } from '@/lib/departments';
import { useI18n } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { usersApi } from '@/lib/users';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';

function Message({ message }: { message: { kind: 'ok' | 'error'; text: string } | null }) {
  if (!message) return null;
  return (
    <p
      role="status"
      className={
        message.kind === 'ok'
          ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
          : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
      }
    >
      {message.text}
    </p>
  );
}

/** Выдача доступа сотрудникам и клиентам — целиком из интерфейса. */
export function UsersPage(): React.ReactElement {
  const { t } = useI18n();
  const { user: me } = useAuth();
  const queryClient = useQueryClient();

  const [creating, setCreating] = React.useState(false);
  const [form, setForm] = React.useState({
    email: '',
    fullName: '',
    password: '',
    roles: [] as Role[],
    sellerId: '',
    departmentId: '',
  });
  const [passwordFor, setPasswordFor] = React.useState<UserSummaryDto | null>(null);
  const [newPassword, setNewPassword] = React.useState('');
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);

  const users = useQuery({ queryKey: ['users'], queryFn: usersApi.list });
  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const departments = useQuery({ queryKey: ['departments'], queryFn: departmentsApi.list });

  const fail = (error: unknown) =>
    setMessage({
      kind: 'error',
      text: error instanceof ApiError ? error.message : t('common.error.network'),
    });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ['users'] });

  const create = useMutation({
    mutationFn: () =>
      usersApi.create({
        email: form.email.trim(),
        fullName: form.fullName.trim(),
        password: form.password,
        roles: form.roles,
        sellerId: form.roles.includes(SELLER_ROLE) ? form.sellerId : undefined,
        departmentId:
          !form.roles.includes(SELLER_ROLE) && form.departmentId ? form.departmentId : undefined,
      }),
    onSuccess: (created) => {
      setMessage({ kind: 'ok', text: t('users.created', { email: created.email }) });
      setForm({ email: '', fullName: '', password: '', roles: [], sellerId: '', departmentId: '' });
      setCreating(false);
      refresh();
    },
    onError: fail,
  });

  const toggleActive = useMutation({
    mutationFn: (target: UserSummaryDto) =>
      usersApi.update(target.id, { isActive: !target.isActive }),
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('users.updated') });
      refresh();
    },
    onError: fail,
  });

  const setDepartment = useMutation({
    mutationFn: (vars: { id: string; departmentId: string | null }) =>
      usersApi.update(vars.id, { departmentId: vars.departmentId }),
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('users.updated') });
      refresh();
    },
    onError: fail,
  });

  const setPassword = useMutation({
    mutationFn: () => usersApi.setPassword(passwordFor!.id, newPassword),
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('users.passwordChanged') });
      setPasswordFor(null);
      setNewPassword('');
    },
    onError: fail,
  });

  const toggleRole = (role: Role) => {
    setForm((current) => {
      const has = current.roles.includes(role);
      let roles = has ? current.roles.filter((r) => r !== role) : [...current.roles, role];
      // SELLER не совмещается с ролями сотрудников — правило бэкенда,
      // но щёлкать по чекбоксам и ловить 400 оператор не должен.
      if (!has && role === SELLER_ROLE) roles = [SELLER_ROLE];
      if (!has && role !== SELLER_ROLE) roles = roles.filter((r) => r !== SELLER_ROLE);
      return { ...current, roles };
    });
  };

  const roleTitle = (role: Role) => t(`users.role.${role}` as Parameters<typeof t>[0]);

  return (
    <div className="mx-auto max-w-3xl space-y-4 p-4">
      <h1 className="text-xl font-semibold tracking-tight">{t('users.title')}</h1>

      <Message message={message} />

      {!creating && <Button onClick={() => setCreating(true)}>{t('users.new')}</Button>}

      {creating && (
        <Card>
          <CardContent className="space-y-3 p-4">
            <div className="text-sm font-medium">{t('users.new')}</div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <Label htmlFor="u-name">{t('users.fullName')}</Label>
                <Input
                  id="u-name"
                  value={form.fullName}
                  onChange={(event) => setForm({ ...form, fullName: event.target.value })}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="u-email">{t('users.email')}</Label>
                <Input
                  id="u-email"
                  type="email"
                  autoComplete="off"
                  value={form.email}
                  onChange={(event) => setForm({ ...form, email: event.target.value })}
                />
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="u-password">{t('users.password')}</Label>
              <Input
                id="u-password"
                type="text"
                autoComplete="new-password"
                value={form.password}
                onChange={(event) => setForm({ ...form, password: event.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                {t('users.passwordHint', { n: PASSWORD_MIN_LENGTH })}
              </p>
            </div>

            <div className="space-y-1">
              <Label>{t('users.roles')}</Label>
              <div className="grid gap-1 sm:grid-cols-2">
                {ROLES.map((role) => (
                  <label
                    key={role}
                    className="flex cursor-pointer items-center gap-2 rounded border px-3 py-2 text-sm"
                  >
                    <input
                      type="checkbox"
                      className="h-4 w-4"
                      checked={form.roles.includes(role)}
                      onChange={() => toggleRole(role)}
                    />
                    {roleTitle(role)}
                  </label>
                ))}
              </div>
            </div>

            {form.roles.includes(SELLER_ROLE) && (
              <div className="space-y-1">
                <Label htmlFor="u-seller">{t('users.seller')}</Label>
                <Select
                  id="u-seller"
                  value={form.sellerId}
                  onChange={(event) => setForm({ ...form, sellerId: event.target.value })}
                >
                  <option value="">—</option>
                  {(sellers.data ?? []).map((seller) => (
                    <option key={seller.id} value={seller.id}>
                      {seller.code} — {seller.legalName}
                    </option>
                  ))}
                </Select>
              </div>
            )}

            {/* Отдел — организационная привязка сотрудника; селлеру не показываем. */}
            {!form.roles.includes(SELLER_ROLE) && (
              <div className="space-y-1">
                <Label htmlFor="u-department">{t('users.department')}</Label>
                <Select
                  id="u-department"
                  value={form.departmentId}
                  onChange={(event) => setForm({ ...form, departmentId: event.target.value })}
                >
                  <option value="">{t('users.noDepartment')}</option>
                  {(departments.data ?? [])
                    .filter((department) => department.isActive)
                    .map((department) => (
                      <option key={department.id} value={department.id}>
                        {department.name}
                      </option>
                    ))}
                </Select>
              </div>
            )}

            <div className="flex gap-2">
              <Button
                disabled={
                  create.isPending ||
                  !form.email.trim() ||
                  !form.fullName.trim() ||
                  form.password.length < PASSWORD_MIN_LENGTH ||
                  form.roles.length === 0 ||
                  (form.roles.includes(SELLER_ROLE) && !form.sellerId)
                }
                onClick={() => create.mutate()}
              >
                {t('common.create')}
              </Button>
              <Button variant="ghost" onClick={() => setCreating(false)}>
                {t('common.cancel')}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {users.isLoading && <p className="text-sm text-muted-foreground">{t('common.loading')}</p>}
      {users.isError && (
        <Card>
          <CardContent className="flex items-center justify-between gap-3 p-4">
            <span className="text-sm text-destructive">{t('common.error.network')}</span>
            <Button variant="outline" size="sm" onClick={() => users.refetch()}>
              {t('common.retry')}
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {(users.data ?? []).map((row) => (
          <Card key={row.id} className={row.isActive ? undefined : 'opacity-60'}>
            <CardContent className="space-y-2 p-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <div className="min-w-0">
                  <span className="font-medium">{row.fullName}</span>
                  <span className="ml-2 text-sm text-muted-foreground">{row.email}</span>
                  {me?.id === row.id && (
                    <span className="ml-2 rounded bg-muted px-1.5 py-0.5 text-xs">
                      {t('users.you')}
                    </span>
                  )}
                </div>
                <span
                  className={
                    row.isActive ? 'text-sm text-muted-foreground' : 'text-sm text-destructive'
                  }
                >
                  {row.isActive ? t('users.active') : t('users.disabled')}
                </span>
              </div>

              <div className="flex flex-wrap gap-1">
                {row.roles.map((role) => (
                  <span key={role} className="rounded bg-muted px-2 py-0.5 text-xs">
                    {roleTitle(role)}
                  </span>
                ))}
              </div>

              {/* Отдел сотрудника — можно переназначить прямо здесь. У селлера отдела нет. */}
              {!row.roles.includes(SELLER_ROLE) && (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-muted-foreground">{t('users.department')}:</span>
                  <Select
                    className="w-auto min-w-[10rem] max-w-full"
                    value={row.departmentId ?? ''}
                    disabled={setDepartment.isPending}
                    onChange={(event) =>
                      setDepartment.mutate({ id: row.id, departmentId: event.target.value || null })
                    }
                  >
                    <option value="">{t('users.noDepartment')}</option>
                    {(departments.data ?? [])
                      .filter((dep) => dep.isActive || dep.id === row.departmentId)
                      .map((dep) => (
                        <option key={dep.id} value={dep.id}>
                          {dep.name}
                        </option>
                      ))}
                  </Select>
                </div>
              )}

              {passwordFor?.id === row.id ? (
                <div className="flex flex-wrap items-end gap-2">
                  <div className="min-w-48 flex-1 space-y-1">
                    <Label htmlFor={`pw-${row.id}`}>{t('users.password')}</Label>
                    <Input
                      id={`pw-${row.id}`}
                      type="text"
                      autoFocus
                      autoComplete="new-password"
                      value={newPassword}
                      onChange={(event) => setNewPassword(event.target.value)}
                    />
                  </div>
                  <Button
                    variant="outline"
                    disabled={setPassword.isPending || newPassword.length < PASSWORD_MIN_LENGTH}
                    onClick={() => setPassword.mutate()}
                  >
                    {t('common.save')}
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      setPasswordFor(null);
                      setNewPassword('');
                    }}
                  >
                    {t('common.cancel')}
                  </Button>
                </div>
              ) : (
                <div className="flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setPasswordFor(row);
                      setNewPassword('');
                    }}
                  >
                    {t('users.resetPassword')}
                  </Button>
                  {/* Себя выключить нельзя — бэкенд всё равно защитит последнего
                      администратора, но кнопка-ловушка тут ни к чему. */}
                  {me?.id !== row.id && (
                    <Button
                      size="sm"
                      variant="ghost"
                      disabled={toggleActive.isPending}
                      onClick={() => toggleActive.mutate(row)}
                    >
                      {row.isActive ? t('users.disable') : t('users.enable')}
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
