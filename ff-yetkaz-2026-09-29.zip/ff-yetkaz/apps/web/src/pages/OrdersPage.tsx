import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import type {
  OrderCategoryDto,
  OrderDto,
  OrderImportOrderDto,
  OrderImportResultDto,
  OrderImportResultRowDto,
  OrderIntakeResultDto,
  OrderListTotalsDto,
  OrderSortField,
  OrderStatus,
  PageDto,
  SortDirection,
} from '@ff/shared';
import { ORDER_SORT_FIELDS, ORDER_STATUSES } from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';
import { cellMoney, cellNumber, mapHeaders, parseCsv } from '@/lib/csv';
import { type DateRange } from '@/lib/date-range';
import { useI18n, type Language, type MessageKey } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { useScannerInput } from '@/lib/use-scanner';
import { cn } from '@/lib/utils';
import {
  ORDER_PIPELINE,
  OrderStatusBadge,
  isOrderCancellable,
  orderStatusKey,
} from '@/components/OrderStatusBadge';
import { OrderDetailModal } from '@/pages/OrderDetailPage';
import { ExportButton } from '@/components/ExportButton';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DataTable, type DataTableColumn, type DataTableSort } from '@/components/ui/data-table';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { Dialog } from '@/components/ui/dialog';
import { DropdownMenu, type DropdownItem } from '@/components/ui/dropdown-menu';
import { EmptyState } from '@/components/ui/empty-state';
import { Input } from '@/components/ui/input';
import { KpiCard, KpiGrid } from '@/components/ui/kpi-card';
import { Label } from '@/components/ui/label';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Pagination } from '@/components/ui/pagination';
import { Popover } from '@/components/ui/popover';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { Select } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/toast';
import {
  FilterChip,
  Toolbar,
  ToolbarGroup,
  ToolbarSearch,
  ToolbarSpacer,
} from '@/components/ui/toolbar';

const LOCALE: Record<Language, string> = { ru: 'ru-RU', uz: 'uz-UZ', en: 'en-GB', zh: 'zh-CN' };

type ViewMode = 'table' | 'kanban';

/** Сколько карточек грузим в одну колонку канбана. Настоящий счётчик берётся из totals. */
const KANBAN_COLUMN_LIMIT = 50;

const DEFAULT_SORT: OrderSortField = 'createdAt';
const DEFAULT_DIRECTION: SortDirection = 'desc';
const DEFAULT_PAGE_SIZE = 50;

/** «В работе» — всё между приёмкой и готовностью к отгрузке. */
const IN_PROGRESS: OrderStatus[] = ['VALIDATED', 'RESERVED', 'PICKING', 'PICKED', 'PACKING', 'PACKED'];

/* ───────────────────────────── фильтры в адресе ───────────────────────────── */

interface OrdersFilters {
  view: ViewMode;
  range: DateRange;
  sellerId: string;
  statuses: OrderStatus[];
  categoryId: string;
  warehouseId: string;
  channel: string;
  search: string;
  page: number;
  pageSize: number;
  sort: OrderSortField;
  direction: SortDirection;
}

function parseStatuses(raw: string): OrderStatus[] {
  const known = new Set<string>(ORDER_STATUSES);
  return raw
    .split(',')
    .map((part) => part.trim())
    .filter((part) => known.has(part)) as OrderStatus[];
}

function parseSort(raw: string): OrderSortField {
  return (ORDER_SORT_FIELDS as readonly string[]).includes(raw)
    ? (raw as OrderSortField)
    : DEFAULT_SORT;
}

/**
 * Состояние списка живёт в адресной строке, а не в React-стейте: ссылку на
 * «отменённые за август по селлеру X» нужно уметь отправить коллеге, а возврат
 * из карточки заказа обязан вернуть тот же экран, а не первую страницу.
 */
function useUrlFilters(): {
  filters: OrdersFilters;
  patch: (next: Partial<OrdersFilters>) => void;
  reset: () => void;
} {
  const [params, setParams] = useSearchParams();

  const filters = React.useMemo<OrdersFilters>(() => {
    const pageSize = Number(params.get('pageSize'));
    const page = Number(params.get('page'));
    return {
      view: params.get('view') === 'kanban' ? 'kanban' : 'table',
      range: { from: params.get('dateFrom'), to: params.get('dateTo') },
      sellerId: params.get('sellerId') ?? '',
      statuses: parseStatuses(params.get('statuses') ?? ''),
      categoryId: params.get('categoryId') ?? '',
      warehouseId: params.get('warehouseId') ?? '',
      channel: params.get('channel') ?? '',
      search: params.get('search') ?? '',
      page: Number.isFinite(page) && page > 0 ? page : 1,
      pageSize: Number.isFinite(pageSize) && pageSize > 0 ? pageSize : DEFAULT_PAGE_SIZE,
      sort: parseSort(params.get('sort') ?? ''),
      direction: params.get('direction') === 'asc' ? 'asc' : DEFAULT_DIRECTION,
    };
  }, [params]);

  const patch = React.useCallback(
    (next: Partial<OrdersFilters>): void => {
      setParams(
        (prev) => {
          const query = new URLSearchParams(prev);
          const put = (key: string, value: string): void => {
            if (value) query.set(key, value);
            else query.delete(key);
          };

          if (next.view !== undefined) put('view', next.view === 'table' ? '' : next.view);
          if (next.range !== undefined) {
            put('dateFrom', next.range.from ?? '');
            put('dateTo', next.range.to ?? '');
          }
          if (next.sellerId !== undefined) put('sellerId', next.sellerId);
          if (next.statuses !== undefined) put('statuses', next.statuses.join(','));
          if (next.categoryId !== undefined) put('categoryId', next.categoryId);
          if (next.warehouseId !== undefined) put('warehouseId', next.warehouseId);
          if (next.channel !== undefined) put('channel', next.channel);
          if (next.search !== undefined) put('search', next.search);
          if (next.pageSize !== undefined)
            put('pageSize', next.pageSize === DEFAULT_PAGE_SIZE ? '' : String(next.pageSize));
          if (next.sort !== undefined) put('sort', next.sort === DEFAULT_SORT ? '' : next.sort);
          if (next.direction !== undefined)
            put('direction', next.direction === DEFAULT_DIRECTION ? '' : next.direction);

          // Смена ЛЮБОГО фильтра возвращает на первую страницу. Иначе после
          // сужения выборки оператор оказывается на несуществующей странице и
          // видит пустой экран вместо результата.
          if (next.page !== undefined) put('page', next.page > 1 ? String(next.page) : '');
          else query.delete('page');

          return query;
        },
        { replace: true },
      );
    },
    [setParams],
  );

  const reset = React.useCallback((): void => {
    setParams((prev) => {
      const query = new URLSearchParams();
      const view = prev.get('view');
      // Вид (таблица/канбан) — не фильтр, сбрасывать его вместе с ними нельзя.
      if (view) query.set('view', view);
      return query;
    });
  }, [setParams]);

  return { filters, patch, reset };
}

/** Строка запроса к /orders. `paging: false` — для totals и выгрузки. */
function buildQuery(
  filters: OrdersFilters,
  options: { paging: boolean; statuses?: OrderStatus[] },
): string {
  const query = new URLSearchParams();
  if (filters.range.from) query.set('dateFrom', filters.range.from);
  if (filters.range.to) query.set('dateTo', filters.range.to);
  if (filters.sellerId) query.set('sellerId', filters.sellerId);

  const statuses = options.statuses ?? filters.statuses;
  if (statuses.length > 0) query.set('statuses', statuses.join(','));

  if (filters.categoryId) query.set('categoryId', filters.categoryId);
  if (filters.warehouseId) query.set('warehouseId', filters.warehouseId);
  if (filters.channel) query.set('channel', filters.channel);
  if (filters.search) query.set('search', filters.search);

  if (options.paging) {
    query.set('page', String(filters.page));
    query.set('pageSize', String(filters.pageSize));
    query.set('sort', filters.sort);
    query.set('direction', filters.direction);
  }
  return query.toString();
}

/* ────────────────────────────────── мелочи ───────────────────────────────── */

function money(amount: string | null, currency: string | null, locale: string): string {
  if (!amount) return '—';
  const value = Number(amount);
  const text = Number.isFinite(value)
    ? new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(value)
    : amount;
  return currency ? `${text} ${currency}` : text;
}

function itemsCount(order: OrderDto): number {
  return order.lines.reduce((sum, line) => sum + line.quantity, 0);
}

function CategoryDot({ color }: { color: string | null }): React.ReactElement {
  return (
    <span
      aria-hidden="true"
      className="h-2 w-2 shrink-0 rounded-full ring-1 ring-inset ring-black/10"
      // Цвет приходит из справочника категорий — это ДАННЫЕ, а не тема оформления,
      // поэтому он и не может быть токеном.
      style={{ backgroundColor: color ?? 'hsl(var(--muted-foreground))' }}
    />
  );
}

function CategoryTag({ order }: { order: OrderDto }): React.ReactElement {
  if (!order.categoryId || !order.categoryName) {
    return <span className="text-muted-foreground">—</span>;
  }
  return (
    <Badge variant="outline" size="sm" className="max-w-[10rem]">
      <CategoryDot color={order.categoryColor} />
      <span className="truncate">{order.categoryName}</span>
    </Badge>
  );
}

/** Возраст заказа: на карточке канбана это главный сигнал «застрял». */
function ageLabel(createdAt: string, now: number, t: (k: MessageKey, p?: Record<string, string | number>) => string): string {
  const started = Date.parse(createdAt);
  if (!Number.isFinite(started)) return '—';
  const minutes = Math.max(0, Math.round((now - started) / 60_000));
  if (minutes < 60) return t('orders.age.minutes', { n: minutes });
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return t('orders.age.hours', { n: hours });
  return t('orders.age.days', { n: Math.floor(hours / 24) });
}

/**
 * Подписанное поле фильтра для контролов, построенных НА КНОПКЕ (поповеры).
 * `ToolbarGroup label=…` оборачивает содержимое в `<label>`, а внутрь `<label>`
 * нельзя класть панель с собственными кнопками и чек-боксами: щелчок по ним
 * браузер норовит переадресовать на первый управляемый элемент — сам триггер.
 * Нативные `<select>`/`<input>` продолжают пользоваться ToolbarGroup с подписью.
 */
function FilterField({
  label,
  className,
  children,
}: {
  label: string;
  className?: string;
  children: React.ReactNode;
}): React.ReactElement {
  return (
    <ToolbarGroup className={className}>
      <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      {children}
    </ToolbarGroup>
  );
}

/* ──────────────────────────────── фильтр статусов ────────────────────────── */

function StatusFilter({
  value,
  onChange,
}: {
  value: OrderStatus[];
  onChange: (next: OrderStatus[]) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const selected = new Set(value);

  const toggle = (status: OrderStatus): void => {
    const next = new Set(selected);
    if (next.has(status)) next.delete(status);
    else next.add(status);
    onChange(ORDER_STATUSES.filter((item) => next.has(item)));
  };

  const label =
    value.length === 0
      ? t('ui.all')
      : value.length === 1 && value[0]
        ? t(orderStatusKey(value[0]))
        : t('orders.filter.statusCount', { n: value.length });

  return (
    <Popover
      align="start"
      triggerClassName={cn(
        'h-10 w-full justify-between border border-input bg-background px-3',
        'hover:bg-accent hover:text-accent-foreground',
      )}
      contentClassName="w-64 max-h-[22rem] overflow-y-auto"
      trigger={
        <>
          <span className="truncate">{label}</span>
          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 shrink-0 opacity-60" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden>
            <path d="m6 8 4 4 4-4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </>
      }
    >
      <div className="space-y-1">
        {ORDER_STATUSES.map((status) => (
          <label
            key={status}
            className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors hover:bg-accent"
          >
            <input
              type="checkbox"
              checked={selected.has(status)}
              onChange={() => toggle(status)}
              className="h-3.5 w-3.5 rounded border-input accent-[hsl(var(--primary))]"
            />
            <OrderStatusBadge status={status} size="sm" />
          </label>
        ))}
        {value.length > 0 ? (
          <button
            type="button"
            onClick={() => onChange([])}
            className="mt-1 w-full rounded-md px-2 py-1.5 text-left text-xs text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            {t('ui.reset')}
          </button>
        ) : null}
      </div>
    </Popover>
  );
}

/* ─────────────────────────────── фильтр категорий ────────────────────────── */

function CategoryFilter({
  value,
  onChange,
  categories,
}: {
  value: string;
  onChange: (next: string) => void;
  categories: OrderCategoryDto[];
}): React.ReactElement {
  const { t } = useI18n();
  const selected = categories.find((category) => category.id === value) ?? null;

  return (
    <Popover
      align="start"
      triggerClassName={cn(
        'h-10 w-full justify-between border border-input bg-background px-3',
        'hover:bg-accent hover:text-accent-foreground',
      )}
      contentClassName="w-60 max-h-[22rem] overflow-y-auto"
      trigger={
        <span className="flex min-w-0 items-center gap-2">
          {selected ? <CategoryDot color={selected.color} /> : null}
          <span className="truncate">{selected ? selected.name : t('ui.all')}</span>
        </span>
      }
    >
      {(close) => (
        <div className="space-y-0.5">
          <button
            type="button"
            onClick={() => {
              onChange('');
              close();
            }}
            className={cn(
              'w-full rounded-md px-2 py-1.5 text-left text-sm transition-colors hover:bg-accent',
              value === '' && 'bg-accent font-medium',
            )}
          >
            {t('ui.all')}
          </button>
          {categories.map((category) => (
            <button
              key={category.id}
              type="button"
              onClick={() => {
                onChange(category.id);
                close();
              }}
              className={cn(
                'flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition-colors hover:bg-accent',
                value === category.id && 'bg-accent font-medium',
              )}
            >
              <CategoryDot color={category.color} />
              <span className="truncate">{category.name}</span>
            </button>
          ))}
          {categories.length === 0 ? (
            <p className="px-2 py-1.5 text-xs text-muted-foreground">{t('orders.filter.noCategories')}</p>
          ) : null}
        </div>
      )}
    </Popover>
  );
}


/* ─────────────────────────────── скан кода заказа ────────────────────────── */

function ScanCard({ onFound }: { onFound: (id: string) => void }): React.ReactElement {
  const { t } = useI18n();
  const toast = useToast();
  const submitRef = React.useRef<(code: string) => void>(() => {});
  const scanner = useScannerInput((code) => submitRef.current(code));

  const openByCode = useMutation({
    mutationFn: (code: string) =>
      apiFetch<OrderDto>(`/orders/by-code?code=${encodeURIComponent(code)}`),
    onSuccess: (order) => {
      onFound(order.id);
      scanner.clear();
      scanner.ref.current?.focus();
    },
    onError: () => {
      toast.error(t('ordersList.scanNotFound'));
      scanner.clear();
      scanner.ref.current?.focus();
    },
  });
  submitRef.current = (code: string) => openByCode.mutate(code);

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        scanner.submit();
      }}
      className="premium-card flex flex-wrap items-end gap-2 p-3"
    >
      <div className="min-w-[14rem] flex-1 space-y-1">
        <Label htmlFor="order-scan">{t('ordersList.scanOpen')}</Label>
        <Input
          id="order-scan"
          ref={scanner.ref}
          autoComplete="off"
          placeholder={t('ordersList.scanPlaceholder2')}
          onChange={() => scanner.onInput()}
        />
      </div>
      <Button type="submit" disabled={openByCode.isPending}>
        {t('ordersList.scanOpenBtn')}
      </Button>
    </form>
  );
}

/* ────────────────────────────────── канбан ───────────────────────────────── */

interface KanbanColumnProps {
  status: OrderStatus;
  /** Счётчик из `/orders/totals`. `null` — счётчик неизвестен: totals ещё едет или не доехал. */
  total: number | null;
  totalsFailed: boolean;
  onRetryTotals: () => void;
  filters: OrdersFilters;
  now: number;
  locale: string;
  onOpen: (id: string) => void;
}

function KanbanColumn({
  status,
  total,
  totalsFailed,
  onRetryTotals,
  filters,
  now,
  locale,
  onOpen,
}: KanbanColumnProps): React.ReactElement {
  const { t } = useI18n();

  const query = React.useMemo(
    () =>
      buildQuery(
        { ...filters, page: 1, pageSize: KANBAN_COLUMN_LIMIT, sort: DEFAULT_SORT, direction: DEFAULT_DIRECTION },
        { paging: true, statuses: [status] },
      ),
    [filters, status],
  );

  // Колонку без заказов не запрашиваем вовсе: настоящий счётчик уже пришёл из
  // totals, и одиннадцать пустых запросов на каждый чих фильтра не нужны.
  const enabled = total !== null && total > 0;
  const page = useQuery({
    queryKey: ['orders', 'kanban', query],
    queryFn: () => apiFetch<PageDto<OrderDto>>(`/orders?${query}`),
    enabled,
  });

  /**
   * Счётчик в шапке и карточки под ним приезжают РАЗНЫМИ запросами, поэтому у
   * колонки есть состояние «счётчик 12, а содержимое неизвестно». Рисовать в нём
   * «Пусто» — значит выдать отказ запроса за факт «заказов нет»: оператор верит
   * экрану и идёт искать поломку не в той стороне.
   */
  const failed = totalsFailed || page.isError;
  const loading = !failed && (total === null || (enabled && page.isPending));

  const rows = failed ? [] : (page.data?.rows ?? []);
  // «Ещё N» имеет смысл только когда обе половины сошлись: иначе ссылка обещает
  // заказы, которых мы не показали и не смогли сосчитать.
  const rest = total !== null && page.data ? total - rows.length : 0;

  const retry = (): void => {
    if (totalsFailed) onRetryTotals();
    if (page.isError) void page.refetch();
  };

  const linkTo = React.useMemo(() => {
    const params = new URLSearchParams(buildQuery(filters, { paging: false, statuses: [status] }));
    return `/orders?${params.toString()}`;
  }, [filters, status]);

  return (
    <section className="flex w-72 shrink-0 flex-col rounded-xl bg-muted/40 ring-1 ring-inset ring-border/60">
      <header className="flex items-center justify-between gap-2 px-3 py-2.5">
        <OrderStatusBadge status={status} size="sm" />
        <span className="text-xs font-semibold tabular-nums text-muted-foreground">
          {total === null ? '—' : total}
        </span>
      </header>

      <div className="flex max-h-[62vh] flex-col gap-2 overflow-y-auto px-2 pb-2">
        {loading
          ? Array.from({ length: Math.min(3, total ?? 3) }, (_unused, index) => (
              <Skeleton key={index} className="h-[4.5rem] w-full rounded-lg" />
            ))
          : null}

        {failed ? (
          <div className="flex flex-col items-center gap-2 px-2 py-6 text-center">
            <p className="text-xs text-destructive">{t('orders.loadError')}</p>
            <Button variant="outline" size="sm" onClick={retry}>
              {t('ui.retry')}
            </Button>
          </div>
        ) : null}

        {rows.map((order) => (
          <article
            key={order.id}
            role="button"
            tabIndex={0}
            onClick={() => onOpen(order.id)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                onOpen(order.id);
              }
            }}
            className={cn(
              'cursor-pointer rounded-lg border border-border bg-card p-2.5 text-left transition-shadow',
              'hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
            )}
          >
            <div className="flex items-baseline justify-between gap-2">
              <span className="truncate font-mono text-xs font-semibold text-primary">
                {order.orderCode}
              </span>
              <span className="shrink-0 text-[11px] tabular-nums text-muted-foreground">
                {ageLabel(order.createdAt, now, t)}
              </span>
            </div>
            <p className="mt-1 truncate text-xs font-medium text-foreground">{order.recipientName}</p>
            <div className="mt-1.5 flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
              <span className="tabular-nums">{t('orders.kanban.items', { n: itemsCount(order) })}</span>
              <span className="truncate tabular-nums">{money(order.codAmount, order.currency, locale)}</span>
            </div>
            {order.hasShortage ? (
              <p className="mt-1.5 text-[11px] font-medium text-destructive">{t('orders.shortage')}</p>
            ) : null}
          </article>
        ))}

        {!loading && !failed && rows.length === 0 ? (
          <p className="px-2 py-6 text-center text-xs text-muted-foreground">{t('orders.kanban.empty')}</p>
        ) : null}
      </div>

      {rest > 0 ? (
        <Link
          to={linkTo}
          className="border-t border-border/60 px-3 py-2 text-center text-xs font-medium text-primary transition-colors hover:bg-accent"
        >
          {t('orders.kanban.more', { n: rest })}
        </Link>
      ) : null}
    </section>
  );
}

/* ──────────────────────────────── импорт файлом ──────────────────────────── */

const HEADER_ALIASES = {
  externalId: ['номер', 'номер заказа', '№', '№ заказа', 'заказ', 'order', 'order_id', 'externalid', 'external_id'],
  recipientName: ['получатель', 'имя', 'фио', 'клиент', 'recipient', 'name'],
  recipientPhone: ['телефон', 'тел', 'phone', 'номер телефона'],
  address: ['адрес', 'address'],
  region: ['регион', 'область', 'region'],
  codAmount: ['сумма cod', 'сумма', 'наложенный платёж', 'наложенный платеж', 'к оплате', 'cod', 'cod_amount'],
  currency: ['валюта', 'currency'],
  skuCode: ['артикул', 'sku', 'sku_code', 'skucode', 'код товара'],
  quantity: ['количество', 'кол-во', 'колво', 'qty', 'quantity', 'шт'],
};

/** Шаблон для клиента: заказ из двух позиций показан второй строкой без повторов. */
const TEMPLATE_CSV = [
  'Номер заказа;Получатель;Телефон;Адрес;Регион;Сумма COD;Валюта;Артикул;Количество',
  'ORD-001;Иванов Иван;+998901112233;г. Ташкент, ул. Амира Темура, 1;Ташкент;150000;UZS;ART-001;2',
  'ORD-001;;;;;;;ART-002;1',
  'ORD-002;Петрова Мария;+998901112244;г. Самарканд, ул. Регистан, 5;Самарканд;;;ART-001;1',
].join('\r\n');

interface PreparedImport {
  orders: OrderImportOrderDto[];
  rejected: OrderImportResultRowDto[];
}

/**
 * Файл → заказы. Строки с одним номером заказа склеиваются в один заказ:
 * выгрузка из маркетплейса устроена именно так — по строке на позицию, реквизиты
 * получателя только в первой.
 */
export function prepareImport(
  text: string,
  fallbackCurrency: string,
  t: (key: MessageKey, params?: Record<string, string | number>) => string,
): PreparedImport {
  const rows = parseCsv(text);
  if (rows.length < 2) throw new Error(t('orders.import.noRows'));

  const columns = mapHeaders(rows[0], HEADER_ALIASES);
  for (const [field, colKey] of [
    ['externalId', 'orders.import.col.orderNo'],
    ['skuCode', 'orders.import.col.sku'],
    ['quantity', 'orders.import.col.qty'],
  ] as Array<[keyof typeof HEADER_ALIASES, string]>) {
    if (columns[field] === undefined) {
      throw new Error(t('orders.import.colMissing', { col: t(colKey as MessageKey) }));
    }
  }

  const cell = (cells: string[], field: keyof typeof HEADER_ALIASES): string | undefined =>
    columns[field] === undefined ? undefined : cells[columns[field]];

  const groups = new Map<string, OrderImportOrderDto>();
  const rejected: OrderImportResultRowDto[] = [];
  const reject = (row: number, externalId: string, message: string): void => {
    rejected.push({
      row,
      externalId: externalId || '—',
      outcome: 'FAILED',
      orderId: null,
      status: null,
      hasShortage: false,
      message,
    });
  };

  rows.slice(1).forEach((cells, index) => {
    const fileLine = index + 2;
    const externalId = (cell(cells, 'externalId') ?? '').trim();
    const skuCode = (cell(cells, 'skuCode') ?? '').trim();
    const quantity = cellNumber(cell(cells, 'quantity'));

    if (!externalId) {
      reject(fileLine, '', t('orders.import.emptyOrderNo'));
      return;
    }
    if (!skuCode) {
      reject(fileLine, externalId, t('orders.import.emptySku'));
      return;
    }
    if (quantity === undefined || quantity < 1) {
      reject(fileLine, externalId, t('orders.import.badQty'));
      return;
    }

    const key = externalId.toLowerCase();
    const existing = groups.get(key);
    if (existing) {
      existing.lines.push({ skuCode, quantity });
      return;
    }

    const amount = cellMoney(cell(cells, 'codAmount'));
    if (amount === null) {
      reject(fileLine, externalId, t('orders.import.badCod'));
      return;
    }
    const rowCurrency = (cell(cells, 'currency') ?? '').trim().toUpperCase();

    groups.set(key, {
      fileLine,
      externalId,
      recipientName: (cell(cells, 'recipientName') ?? '').trim(),
      recipientPhone: (cell(cells, 'recipientPhone') ?? '').trim(),
      address: (cell(cells, 'address') ?? '').trim(),
      region: (cell(cells, 'region') ?? '').trim() || undefined,
      codAmount: amount,
      currency: amount ? rowCurrency || fallbackCurrency || undefined : undefined,
      lines: [{ skuCode, quantity }],
    });
  });

  const orders: OrderImportOrderDto[] = [];
  for (const order of groups.values()) {
    const missing: string[] = [];
    if (!order.recipientName) missing.push(t('orders.import.field.recipient'));
    if (order.recipientPhone.length < 3) missing.push(t('orders.import.field.phone'));
    if (order.address.length < 3) missing.push(t('orders.import.field.address'));
    if (missing.length > 0) {
      reject(
        order.fileLine,
        order.externalId,
        t('orders.import.notFilled', { fields: missing.join(', ') }),
      );
      continue;
    }
    orders.push(order);
  }

  return { orders, rejected: rejected.sort((left, right) => left.row - right.row) };
}

function ImportDialog({
  open,
  onClose,
  onDone,
}: {
  open: boolean;
  onClose: () => void;
  onDone: () => void;
}): React.ReactElement {
  const { t } = useI18n();
  const toast = useToast();
  const [sellerId, setSellerId] = React.useState('');
  const [channel, setChannel] = React.useState('CSV');
  const [currency, setCurrency] = React.useState('');
  const [result, setResult] = React.useState<OrderImportResultDto | null>(null);
  const fileRef = React.useRef<HTMLInputElement>(null);

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const selected = sellerId || sellers.data?.[0]?.id || '';

  const upload = useMutation({
    mutationFn: async (file: File) => {
      const prepared = prepareImport(await file.text(), currency.trim().toUpperCase(), t);
      if (prepared.orders.length === 0) throw new Error(t('orders.import.noOrders'));

      const response = await apiFetch<OrderImportResultDto>('/orders/import', {
        method: 'POST',
        body: { sellerId: selected, channel: channel.trim() || 'CSV', orders: prepared.orders },
      });

      // Строки, отбитые ещё до отправки, попадают в тот же отчёт: пропавший
      // заказ обнаружился бы иначе только звонком клиента.
      return {
        created: response.created,
        duplicates: response.duplicates,
        failed: response.failed + prepared.rejected.length,
        rows: [...response.rows, ...prepared.rejected].sort((left, right) => left.row - right.row),
      } satisfies OrderImportResultDto;
    },
    onSuccess: (data) => {
      setResult(data);
      const text = t('orders.import.result', {
        created: data.created,
        duplicates: data.duplicates,
        failed: data.failed,
      });
      if (data.failed > 0) toast.error(t('orders.import.title'), text);
      else toast.success(t('orders.import.title'), text);
      onDone();
    },
    onError: (error) =>
      toast.error(
        t('orders.import.title'),
        error instanceof ApiError ? error.message : (error as Error).message,
      ),
  });

  const downloadTemplate = (): void => {
    // BOM обязателен: без него Excel открывает кириллицу кракозябрами.
    const blob = new Blob([`﻿${TEMPLATE_CSV}`], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'ff-orders-template.csv';
    link.click();
    URL.revokeObjectURL(url);
  };

  const problems = (result?.rows ?? []).filter(
    (row) => row.outcome === 'FAILED' || row.message !== null,
  );

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={t('orders.import.title')}
      description={t('orders.import.hint')}
      size="lg"
      footer={
        <>
          <Button variant="outline" size="sm" onClick={downloadTemplate}>
            {t('orders.import.downloadTemplate')}
          </Button>
          <Button size="sm" onClick={onClose}>
            {t('ui.close')}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1">
            <Label htmlFor="import-seller">{t('orders.filter.seller')}</Label>
            <Select
              id="import-seller"
              value={selected}
              onChange={(event) => setSellerId(event.target.value)}
            >
              {(sellers.data ?? []).map((seller) => (
                <option key={seller.id} value={seller.id}>
                  {seller.code} — {seller.legalName}
                </option>
              ))}
            </Select>
          </div>
          <div className="space-y-1">
            <Label htmlFor="import-channel">{t('orders.import.channel')}</Label>
            <Input id="import-channel" value={channel} placeholder="CSV" onChange={(event) => setChannel(event.target.value)} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="import-currency">{t('orders.import.codCurrency')}</Label>
            <Input
              id="import-currency"
              value={currency}
              placeholder="UZS"
              maxLength={3}
              onChange={(event) => setCurrency(event.target.value)}
            />
          </div>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept=".csv,text/csv,text/plain"
          disabled={!selected || upload.isPending}
          className="block w-full text-sm file:mr-3 file:rounded-md file:border file:border-input file:bg-background file:px-3 file:py-1.5 file:text-sm"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) upload.mutate(file);
            // Сброс значения: иначе повторный выбор того же файла не даст onChange.
            if (fileRef.current) fileRef.current.value = '';
          }}
        />

        {problems.length > 0 ? (
          <div className="space-y-1.5">
            {/* Здесь не только ошибки: заказ, принятый без остатка, — это не отказ,
                но оператор должен о нём знать, иначе он потеряется в общем списке. */}
            <p className="text-xs font-medium text-muted-foreground">{t('orders.import.problemsTitle')}</p>
            <div className="max-h-64 overflow-y-auto rounded-lg border border-border">
              <table className="w-full text-xs">
                <tbody>
                  {problems.map((row) => (
                    <tr key={`${row.row}-${row.externalId}`} className="border-b border-border/60 last:border-0">
                      <td className="p-2 tabular-nums text-muted-foreground">
                        {t('orders.import.rowLabel', { n: row.row })}
                      </td>
                      <td className="p-2 font-medium">{row.externalId}</td>
                      <td className={row.outcome === 'FAILED' ? 'p-2 text-destructive' : 'p-2'}>{row.message}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : null}
      </div>
    </Dialog>
  );
}

/* ─────────────────────────────────── страница ────────────────────────────── */

export function OrdersPage(): React.ReactElement {
  const { t, language } = useI18n();
  const locale = LOCALE[language];
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { filters, patch, reset } = useUrlFilters();

  const [detailId, setDetailId] = React.useState<string | null>(null);
  const [importOpen, setImportOpen] = React.useState(false);
  const [dispatching, setDispatching] = React.useState<OrderDto | null>(null);
  const [cancelling, setCancelling] = React.useState<OrderDto | null>(null);
  const [cancelReason, setCancelReason] = React.useState('');
  const [now, setNow] = React.useState(() => Date.now());

  React.useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 60_000);
    return () => window.clearInterval(id);
  }, []);

  // Текстовые фильтры печатаются посимвольно, а уходят на сервер раз в 350 мс:
  // иначе каждая буква — отдельный запрос с полной пересборкой выборки.
  const [searchDraft, setSearchDraft] = React.useState(filters.search);
  React.useEffect(() => setSearchDraft(filters.search), [filters.search]);
  React.useEffect(() => {
    if (searchDraft === filters.search) return;
    const id = window.setTimeout(() => patch({ search: searchDraft }), 350);
    return () => window.clearTimeout(id);
  }, [searchDraft, filters.search, patch]);

  const [channelDraft, setChannelDraft] = React.useState(filters.channel);
  React.useEffect(() => setChannelDraft(filters.channel), [filters.channel]);
  React.useEffect(() => {
    if (channelDraft === filters.channel) return;
    const id = window.setTimeout(() => patch({ channel: channelDraft }), 350);
    return () => window.clearTimeout(id);
  }, [channelDraft, filters.channel, patch]);

  const listQuery = React.useMemo(() => buildQuery(filters, { paging: true }), [filters]);
  const scopeQuery = React.useMemo(() => buildQuery(filters, { paging: false }), [filters]);
  const totalsQuery = React.useMemo(
    () => buildQuery({ ...filters, statuses: [] }, { paging: false }),
    [filters],
  );

  const orders = useQuery({
    queryKey: ['orders', 'page', listQuery],
    queryFn: () => apiFetch<PageDto<OrderDto>>(`/orders?${listQuery}`),
    enabled: filters.view === 'table',
    // Прошлая страница остаётся на экране, пока грузится следующая: без этого
    // таблица схлопывается в скелет на каждый клик по пагинации.
    placeholderData: (previous) => previous,
  });

  const totals = useQuery({
    queryKey: ['orders', 'totals', totalsQuery],
    queryFn: () => apiFetch<OrderListTotalsDto>(`/orders/totals?${totalsQuery}`),
  });

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const warehouses = useQuery({ queryKey: ['mdm', 'warehouses'], queryFn: mdmApi.warehouses });
  const categories = useQuery({
    queryKey: ['order-categories'],
    queryFn: () => apiFetch<OrderCategoryDto[]>('/order-categories'),
  });

  const byStatus = React.useMemo(() => {
    const map = new Map<OrderStatus, number>();
    for (const row of totals.data?.byStatus ?? []) map.set(row.status, row.count);
    return map;
  }, [totals.data]);

  const countOf = React.useCallback(
    (statuses: OrderStatus[]): number => statuses.reduce((sum, status) => sum + (byStatus.get(status) ?? 0), 0),
    [byStatus],
  );

  // Канбан показывает только те статусы, которые попадают под ТЕКУЩИЙ фильтр
  // статусов: иначе выбранный «Отменён» выдал бы одиннадцать пустых колонок.
  const kanbanStages = React.useMemo(() => {
    const wanted = new Set(filters.statuses);
    const stages = wanted.size > 0 ? ORDER_STATUSES.filter((s) => wanted.has(s)) : [...ORDER_PIPELINE];
    return stages as OrderStatus[];
  }, [filters.statuses]);

  const sellerCode = React.useCallback(
    (id: string) => sellers.data?.find((seller) => seller.id === id)?.code ?? '—',
    [sellers.data],
  );

  /* ── мутации ── */

  const patchCached = React.useCallback(
    (id: string, next: Partial<OrderDto>): void => {
      queryClient.setQueriesData<PageDto<OrderDto>>({ queryKey: ['orders', 'page'] }, (page) =>
        page
          ? { ...page, rows: page.rows.map((row) => (row.id === id ? { ...row, ...next } : row)) }
          : page,
      );
    },
    [queryClient],
  );

  const invalidateOrders = React.useCallback((): void => {
    void queryClient.invalidateQueries({ queryKey: ['orders'] });
  }, [queryClient]);

  const reserve = useMutation({
    mutationFn: (id: string) =>
      apiFetch<OrderIntakeResultDto>(`/orders/${id}/reserve`, { method: 'POST', body: {} }),
    // Резерв оптимистично не показываем: его исход зависит от остатка на складе,
    // и «зарезервировано» до ответа сервера было бы прямой ложью.
    onSuccess: (result) => {
      if (result.shortages.length > 0) toast.error(t('orders.toast.reserveShortage'));
      else toast.success(t('orders.toast.reserveOk'));
    },
    onError: (error) =>
      toast.error(t('orders.toast.reserveFailed'), error instanceof ApiError ? error.message : undefined),
    onSettled: invalidateOrders,
  });

  const dispatchOrder = useMutation({
    mutationFn: (id: string) => apiFetch<OrderDto>(`/orders/${id}/dispatch`, { method: 'POST', body: {} }),
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ['orders', 'page'] });
      const snapshot = queryClient.getQueriesData<PageDto<OrderDto>>({ queryKey: ['orders', 'page'] });
      patchCached(id, { status: 'DISPATCHED', dispatchedAt: new Date().toISOString() });
      return { snapshot };
    },
    onError: (error, _id, context) => {
      for (const [key, value] of context?.snapshot ?? []) {
        queryClient.setQueryData<PageDto<OrderDto>>(key, value);
      }
      toast.error(t('orders.toast.dispatchFailed'), error instanceof ApiError ? error.message : undefined);
    },
    onSuccess: () => {
      toast.success(t('orders.toast.dispatchOk'));
      setDispatching(null);
    },
    onSettled: invalidateOrders,
  });

  const cancelOrder = useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) =>
      apiFetch<OrderDto>(`/orders/${id}/cancel`, { method: 'POST', body: { reason } }),
    onMutate: async ({ id }) => {
      await queryClient.cancelQueries({ queryKey: ['orders', 'page'] });
      const snapshot = queryClient.getQueriesData<PageDto<OrderDto>>({ queryKey: ['orders', 'page'] });
      patchCached(id, { status: 'CANCELLED' });
      return { snapshot };
    },
    onError: (error, _vars, context) => {
      for (const [key, value] of context?.snapshot ?? []) {
        queryClient.setQueryData<PageDto<OrderDto>>(key, value);
      }
      toast.error(t('orders.toast.cancelFailed'), error instanceof ApiError ? error.message : undefined);
    },
    onSuccess: () => {
      toast.success(t('orders.toast.cancelOk'));
      setCancelling(null);
      setCancelReason('');
    },
    onSettled: invalidateOrders,
  });

  const canReserve = (order: OrderDto): boolean =>
    order.hasShortage || order.status === 'NEW' || order.status === 'VALIDATED';

  const rowActions = React.useCallback(
    (order: OrderDto): DropdownItem[] => [
      { key: 'open', label: t('orders.action.open'), onSelect: () => navigate(`/orders/${order.id}`) },
      {
        key: 'reserve',
        label: t('orders.action.reserve'),
        disabled: !canReserve(order) || reserve.isPending,
        onSelect: () => reserve.mutate(order.id),
      },
      {
        key: 'dispatch',
        label: t('orders.action.dispatch'),
        disabled: order.status !== 'READY_TO_SHIP',
        onSelect: () => setDispatching(order),
      },
      { key: 'sep', separator: true },
      {
        key: 'cancel',
        label: t('orders.action.cancel'),
        danger: true,
        disabled: !isOrderCancellable(order.status),
        onSelect: () => {
          setCancelReason('');
          setCancelling(order);
        },
      },
    ],
    [navigate, reserve, t],
  );

  /* ── колонки ── */

  const columns = React.useMemo<Array<DataTableColumn<OrderDto>>>(
    () => [
      {
        key: 'orderCode',
        header: t('orders.col.code'),
        sortable: true,
        width: '11rem',
        cell: (order) => (
          <Link
            to={`/orders/${order.id}`}
            className="font-mono text-xs font-semibold text-primary underline-offset-2 hover:underline"
          >
            {order.orderCode}
          </Link>
        ),
      },
      {
        key: 'externalId',
        header: t('orders.col.externalId'),
        sortable: true,
        hideable: true,
        cell: (order) => <span className="text-xs">{order.externalId}</span>,
      },
      {
        key: 'status',
        header: t('orders.col.status'),
        sortable: true,
        cell: (order) => (
          <div className="flex flex-wrap items-center gap-1.5">
            <OrderStatusBadge status={order.status} size="sm" />
            {order.hasShortage ? (
              <Badge variant="destructive" size="sm">
                {t('orders.shortage')}
              </Badge>
            ) : null}
          </div>
        ),
      },
      {
        key: 'category',
        header: t('orders.col.category'),
        hideable: true,
        cell: (order) => <CategoryTag order={order} />,
      },
      {
        key: 'seller',
        header: t('orders.col.seller'),
        hideable: true,
        cell: (order) => <span className="text-xs">{sellerCode(order.sellerId)}</span>,
      },
      {
        key: 'recipientName',
        header: t('orders.col.recipient'),
        sortable: true,
        cell: (order) => (
          <div className="min-w-0">
            <p className="truncate text-sm">{order.recipientName}</p>
            <p className="truncate text-xs tabular-nums text-muted-foreground">{order.recipientPhone}</p>
          </div>
        ),
      },
      {
        key: 'region',
        header: t('orders.col.region'),
        hideable: true,
        cell: (order) => <span className="text-xs text-muted-foreground">{order.region ?? '—'}</span>,
      },
      {
        key: 'items',
        header: t('orders.col.items'),
        align: 'right',
        hideable: true,
        width: '5.5rem',
        cell: (order) => <span className="text-xs">{itemsCount(order)}</span>,
      },
      {
        key: 'weightKg',
        header: t('orders.col.weight'),
        sortable: true,
        align: 'right',
        hideable: true,
        width: '6rem',
        cell: (order) => <span className="text-xs">{order.weightKg ?? '—'}</span>,
      },
      {
        key: 'codAmount',
        header: t('orders.col.cod'),
        sortable: true,
        align: 'right',
        width: '9rem',
        cell: (order) => <span className="text-xs">{money(order.codAmount, order.currency, locale)}</span>,
      },
      {
        key: 'createdAt',
        header: t('orders.col.createdAt'),
        sortable: true,
        width: '10rem',
        cell: (order) => (
          <span className="text-xs tabular-nums text-muted-foreground">
            {new Date(order.createdAt).toLocaleString(locale)}
          </span>
        ),
      },
      {
        key: 'dispatchedAt',
        header: t('orders.col.dispatchedAt'),
        sortable: true,
        hideable: true,
        width: '10rem',
        cell: (order) => (
          <span className="text-xs tabular-nums text-muted-foreground">
            {order.dispatchedAt ? new Date(order.dispatchedAt).toLocaleString(locale) : '—'}
          </span>
        ),
      },
      {
        key: 'actions',
        header: <span className="sr-only">{t('ui.more')}</span>,
        align: 'right',
        width: '3.5rem',
        cell: (order) => <DropdownMenu items={rowActions(order)} label={t('ui.more')} />,
      },
    ],
    [locale, rowActions, sellerCode, t],
  );

  const sort: DataTableSort = { key: filters.sort, direction: filters.direction };

  /* ── чипы активных фильтров ── */

  const chips: React.ReactNode[] = [];
  if (filters.sellerId) {
    chips.push(
      <FilterChip
        key="seller"
        label={t('orders.filter.seller')}
        value={sellerCode(filters.sellerId)}
        onClear={() => patch({ sellerId: '' })}
      />,
    );
  }
  if (filters.statuses.length > 0) {
    chips.push(
      <FilterChip
        key="statuses"
        label={t('orders.col.status')}
        value={filters.statuses.map((status) => t(orderStatusKey(status))).join(', ')}
        onClear={() => patch({ statuses: [] })}
      />,
    );
  }
  if (filters.categoryId) {
    chips.push(
      <FilterChip
        key="category"
        label={t('orders.col.category')}
        value={categories.data?.find((item) => item.id === filters.categoryId)?.name ?? filters.categoryId}
        onClear={() => patch({ categoryId: '' })}
      />,
    );
  }
  if (filters.warehouseId) {
    chips.push(
      <FilterChip
        key="warehouse"
        label={t('orders.filter.warehouse')}
        value={warehouses.data?.find((item) => item.id === filters.warehouseId)?.code ?? filters.warehouseId}
        onClear={() => patch({ warehouseId: '' })}
      />,
    );
  }
  if (filters.channel) {
    chips.push(
      <FilterChip
        key="channel"
        label={t('orders.filter.channel')}
        value={filters.channel}
        onClear={() => patch({ channel: '' })}
      />,
    );
  }

  const toolbar = (
    <Toolbar>
      <FilterField label={t('ui.date.range')}>
        <DateRangePicker value={filters.range} onChange={(range) => patch({ range })} allowAllTime />
      </FilterField>

      <FilterField label={t('orders.filter.seller')} className="w-44">
        <SearchableSelect
          value={filters.sellerId}
          onChange={(sellerId) => patch({ sellerId })}
          clearLabel={t('ui.all')}
          placeholder={t('ui.all')}
          searchPlaceholder={t('orders.filter.sellerSearch')}
          options={(sellers.data ?? []).map((seller) => ({
            value: seller.id,
            triggerLabel: seller.code,
            label: `${seller.code} — ${seller.legalName}`,
            keywords: `${seller.code} ${seller.legalName}`,
          }))}
        />
      </FilterField>

      <FilterField label={t('orders.col.status')} className="w-44">
        <StatusFilter value={filters.statuses} onChange={(statuses) => patch({ statuses })} />
      </FilterField>

      <FilterField label={t('orders.col.category')} className="w-40">
        <CategoryFilter
          value={filters.categoryId}
          onChange={(categoryId) => patch({ categoryId })}
          categories={categories.data ?? []}
        />
      </FilterField>

      <ToolbarGroup label={t('orders.filter.warehouse')} className="w-40">
        <Select
          value={filters.warehouseId}
          onChange={(event) => patch({ warehouseId: event.target.value })}
        >
          <option value="">{t('ui.all')}</option>
          {(warehouses.data ?? []).map((warehouse) => (
            <option key={warehouse.id} value={warehouse.id}>
              {warehouse.code}
            </option>
          ))}
        </Select>
      </ToolbarGroup>

      <ToolbarGroup label={t('orders.filter.channel')} className="w-32">
        <Input
          value={channelDraft}
          placeholder={t('ui.all')}
          onChange={(event) => setChannelDraft(event.target.value)}
        />
      </ToolbarGroup>

      <ToolbarGroup label={t('ui.search')} className="w-56">
        <ToolbarSearch
          value={searchDraft}
          onChange={setSearchDraft}
          placeholder={t('orders.filter.searchPlaceholder')}
        />
      </ToolbarGroup>

      <ToolbarSpacer />

      <ToolbarGroup>
        <div className="flex items-center gap-2">
          <ExportButton path={`/orders/export?${scopeQuery}`} disabled={(totals.data?.total ?? 0) === 0} />
          <Button variant="ghost" size="sm" onClick={reset}>
            {t('ui.reset')}
          </Button>
        </div>
      </ToolbarGroup>
    </Toolbar>
  );

  const total = totals.data?.total ?? 0;

  /**
   * Значение плитки: при отказе totals — прочерк, а не ноль. Ноль здесь читается
   * как «заказов нет», и это тот же обман, что и «Пусто» в колонке канбана:
   * рядом с плитками уже висит карточка отказа с повтором, а сами они при этом
   * уверенно докладывают цифры.
   */
  const kpiValue = (value: number): React.ReactNode => (totals.isError ? '—' : value);

  return (
    <PageContainer>
      <PageHeader
        title={t('orders.title')}
        description={t('orders.subtitle')}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => setImportOpen(true)}>
              {t('orders.import.open')}
            </Button>
            <Link to="/orders/new">
              <Button size="sm">{t('orders.new')}</Button>
            </Link>
          </>
        }
      />

      <ScanCard onFound={setDetailId} />

      <KpiGrid>
        <KpiCard
          label={t('orders.kpi.total')}
          value={kpiValue(total)}
          loading={totals.isLoading}
          onClick={() => patch({ statuses: [] })}
        />
        <KpiCard
          label={t('orders.kpi.new')}
          value={kpiValue(countOf(['NEW']))}
          tone="info"
          loading={totals.isLoading}
          onClick={() => patch({ statuses: ['NEW'] })}
        />
        <KpiCard
          label={t('orders.kpi.inProgress')}
          value={kpiValue(countOf(IN_PROGRESS))}
          tone="warning"
          loading={totals.isLoading}
          onClick={() => patch({ statuses: IN_PROGRESS })}
        />
        <KpiCard
          label={t('orders.kpi.readyToShip')}
          value={kpiValue(countOf(['READY_TO_SHIP']))}
          loading={totals.isLoading}
          onClick={() => patch({ statuses: ['READY_TO_SHIP'] })}
        />
        <KpiCard
          label={t('orders.kpi.dispatched')}
          value={kpiValue(countOf(['DISPATCHED']))}
          tone="success"
          loading={totals.isLoading}
          onClick={() => patch({ statuses: ['DISPATCHED'] })}
        />
        <KpiCard
          label={t('orders.kpi.cancelled')}
          value={kpiValue(countOf(['CANCELLED']))}
          tone="destructive"
          loading={totals.isLoading}
          onClick={() => patch({ statuses: ['CANCELLED'] })}
        />
      </KpiGrid>

      <div className="flex flex-wrap items-center gap-3">
        <Tabs
          value={filters.view}
          onValueChange={(view) => patch({ view })}
          items={[
            { value: 'table', label: t('orders.view.table') },
            { value: 'kanban', label: t('orders.view.kanban') },
          ]}
        />
        {chips.length > 0 ? <div className="flex flex-wrap items-center gap-1.5">{chips}</div> : null}
      </div>

      {totals.isError ? (
        <div className="premium-card flex flex-wrap items-center justify-between gap-3 p-4">
          <span className="text-sm text-destructive">{t('orders.loadError')}</span>
          <Button variant="outline" size="sm" onClick={() => void totals.refetch()}>
            {t('ui.retry')}
          </Button>
        </div>
      ) : null}

      {filters.view === 'table' ? (
        orders.isError ? (
          <div className="premium-card flex flex-wrap items-center justify-between gap-3 p-4">
            <span className="text-sm text-destructive">{t('orders.loadError')}</span>
            <Button variant="outline" size="sm" onClick={() => void orders.refetch()}>
              {t('ui.retry')}
            </Button>
          </div>
        ) : (
          <DataTable
            columns={columns}
            rows={orders.data?.rows ?? []}
            getRowKey={(order) => order.id}
            loading={orders.isLoading}
            skeletonRows={10}
            columnVisibility
            toolbar={toolbar}
            sort={sort}
            onSortChange={(next) =>
              patch(
                next
                  ? { sort: parseSort(next.key), direction: next.direction }
                  : { sort: DEFAULT_SORT, direction: DEFAULT_DIRECTION },
              )
            }
            onRowClick={(order) => navigate(`/orders/${order.id}`)}
            emptyTitle={t('orders.empty')}
            emptyDescription={t('orders.emptyHint')}
            emptyAction={
              <Button variant="outline" size="sm" onClick={reset}>
                {t('ui.reset')}
              </Button>
            }
            footer={
              <Pagination
                page={filters.page}
                pageSize={filters.pageSize}
                total={orders.data?.total ?? 0}
                onPageChange={(page) => patch({ page })}
                onPageSizeChange={(pageSize) => patch({ pageSize })}
              />
            }
          />
        )
      ) : (
        <div className="space-y-4">
          <div className="premium-card p-3">{toolbar}</div>
          {kanbanStages.length === 0 ? (
            <EmptyState title={t('orders.empty')} description={t('orders.emptyHint')} />
          ) : (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {kanbanStages.map((status) => (
                <KanbanColumn
                  key={status}
                  status={status}
                  // Пока totals не ответил (или ответил ошибкой), счётчика НЕТ.
                  // Ноль вместо него означал бы «в колонке пусто» — колонка это
                  // покажет, и человек примет неизвестность за факт.
                  total={totals.isSuccess ? (byStatus.get(status) ?? 0) : null}
                  totalsFailed={totals.isError}
                  onRetryTotals={() => void totals.refetch()}
                  filters={filters}
                  now={now}
                  locale={locale}
                  onOpen={setDetailId}
                />
              ))}
            </div>
          )}
        </div>
      )}

      <ImportDialog open={importOpen} onClose={() => setImportOpen(false)} onDone={invalidateOrders} />

      <Dialog
        open={dispatching !== null}
        onClose={() => setDispatching(null)}
        title={t('orders.dispatch.title')}
        description={t('orders.dispatch.description', { code: dispatching?.orderCode ?? '' })}
        size="sm"
        closeOnOverlay={!dispatchOrder.isPending}
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              disabled={dispatchOrder.isPending}
              onClick={() => setDispatching(null)}
            >
              {t('ui.cancel')}
            </Button>
            <Button
              size="sm"
              disabled={dispatchOrder.isPending}
              onClick={() => dispatching && dispatchOrder.mutate(dispatching.id)}
            >
              {t('orders.action.dispatch')}
            </Button>
          </>
        }
      />

      <Dialog
        open={cancelling !== null}
        onClose={() => setCancelling(null)}
        title={t('orders.cancel.title')}
        description={t('orders.cancel.description', { code: cancelling?.orderCode ?? '' })}
        size="sm"
        closeOnOverlay={!cancelOrder.isPending}
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              disabled={cancelOrder.isPending}
              onClick={() => setCancelling(null)}
            >
              {t('orders.cancel.keep')}
            </Button>
            <Button
              variant="destructive"
              size="sm"
              // Причина обязательна: отмена без объяснения — это спор с селлером
              // через неделю, который нечем закрыть.
              disabled={cancelOrder.isPending || cancelReason.trim().length < 3}
              onClick={() =>
                cancelling && cancelOrder.mutate({ id: cancelling.id, reason: cancelReason.trim() })
              }
            >
              {t('orders.action.cancel')}
            </Button>
          </>
        }
      >
        <div className="space-y-1.5">
          <Label htmlFor="cancel-reason">{t('orders.cancel.reason')}</Label>
          <Input
            id="cancel-reason"
            autoFocus
            value={cancelReason}
            placeholder={t('orders.cancel.reasonPlaceholder')}
            onChange={(event) => setCancelReason(event.target.value)}
          />
          <p className="text-xs text-muted-foreground">{t('orders.cancel.reasonHint')}</p>
        </div>
      </Dialog>

      {detailId ? <OrderDetailModal id={detailId} onClose={() => setDetailId(null)} /> : null}
    </PageContainer>
  );
}
