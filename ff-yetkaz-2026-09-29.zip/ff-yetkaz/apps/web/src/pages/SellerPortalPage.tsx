import * as React from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { Link, useSearchParams } from 'react-router-dom';
import type {
  AnalyticsGranularity,
  SellerDashboardDto,
  SellerShipmentRowDto,
  SellerStockRowDto,
} from '@ff/shared';
import { analyticsApi } from '@/lib/analytics';
import { dashboardApi } from '@/lib/dashboard';
import { daysInRange, presetRange, rangeToQuery, type DateRange } from '@/lib/date-range';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import {
  buildSeriesPoints,
  formatDecimalString,
  MetricKpiGrid,
  ORDER_STATUS_CHART_COLOR,
} from '@/pages/AnalyticsPage';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CHART_COLORS, DonutChart, LineChart, type ChartSeries, type DonutSlice } from '@/components/ui/charts';
import { DataTable, type DataTableColumn, type DataTableSort } from '@/components/ui/data-table';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { KpiCard, KpiGrid } from '@/components/ui/kpi-card';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Pagination } from '@/components/ui/pagination';
import { SkeletonText } from '@/components/ui/skeleton';

const NBSP = ' ';
const DASH = '—';

type OrderStatusKey = keyof typeof ORDER_STATUS_CHART_COLOR;

/**
 * Суммы складываются в BigInt по копейкам, а не через `Number()`.
 *
 * Счета приходят строками не для красоты: годовой оборот в сумах выходит за
 * безопасный диапазон double, и обычное сложение чисел тихо теряет младшие
 * разряды — расхождение с бухгалтерией на единицы, которое никто не заметит.
 * Возвращаем тоже строку: дальше по коду она никуда не «оцифровывается».
 */
function sumMoneyStrings(values: Array<string | null>): string | null {
  let total = 0n;
  let seen = false;

  for (const raw of values) {
    if (raw === null) continue;
    const match = /^([+-]?)(\d+)(?:[.,](\d+))?$/.exec(raw.trim());
    if (!match) return null;
    const fraction = (match[3] ?? '').padEnd(2, '0').slice(0, 2);
    const magnitude = BigInt(`${match[2]}${fraction}`);
    total += match[1] === '-' ? -magnitude : magnitude;
    seen = true;
  }

  if (!seen) return null;
  const negative = total < 0n;
  const absolute = negative ? -total : total;
  const whole = (absolute / 100n).toString();
  const cents = (absolute % 100n).toString().padStart(2, '0');
  return `${negative ? '-' : ''}${whole}.${cents}`;
}

function money(raw: string | null | undefined, currency = 'UZS'): string {
  const value = formatDecimalString(raw, 2);
  return value === null ? DASH : `${value}${NBSP}${currency}`;
}

const SHIPMENT_BADGE: Record<string, 'default' | 'success' | 'warning' | 'info' | 'destructive' | 'muted'> = {
  READY: 'muted',
  HANDED_OVER: 'info',
  IN_TRANSIT: 'info',
  DELIVERED: 'success',
  FAILED: 'destructive',
  RETURNING: 'warning',
  CANCELLED: 'muted',
};

/** Локальная секция-карточка: та же рамка у всех блоков кабинета. */
function Section({
  title,
  description,
  actions,
  children,
  className,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}): React.ReactElement {
  return (
    <section className={cn('premium-card p-4', className)}>
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <h2 className="text-sm font-semibold text-card-foreground">{title}</h2>
          {description ? <p className="mt-0.5 text-xs text-muted-foreground">{description}</p> : null}
        </div>
        {actions ? <div className="flex shrink-0 items-center gap-2">{actions}</div> : null}
      </div>
      {children}
    </section>
  );
}

/* ────────────────── сортировка и страницы поверх полного ответа ────────────────── */

interface LocalTable<T> {
  sort: DataTableSort | null;
  setSort: (sort: DataTableSort | null) => void;
  page: number;
  setPage: (page: number) => void;
  pageSize: number;
  setPageSize: (size: number) => void;
  rows: T[];
  total: number;
}

/**
 * `/dashboard/seller` отдаёт остатки и отправления ЦЕЛИКОМ, одним ответом:
 * ни `page`, ни `total` в контракте нет. Поэтому сортировать и листать здесь
 * можно на клиенте, не соврав — в памяти лежит весь набор, а не первая
 * страница. Появится постраничная ручка — обе операции обязаны уехать в запрос.
 */
function useLocalTable<T>(
  all: T[],
  sortValue: (row: T, key: string) => string | number,
  initialSort: DataTableSort | null = null,
  initialPageSize = 10,
): LocalTable<T> {
  const [sort, setSort] = React.useState<DataTableSort | null>(initialSort);
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(initialPageSize);

  const sorted = React.useMemo(() => {
    if (!sort) return all;
    const direction = sort.direction === 'asc' ? 1 : -1;
    return [...all].sort((left, right) => {
      const a = sortValue(left, sort.key);
      const b = sortValue(right, sort.key);
      if (typeof a === 'string' || typeof b === 'string') {
        return direction * String(a).localeCompare(String(b), 'ru');
      }
      return direction * (a - b);
    });
  }, [all, sort, sortValue]);

  React.useEffect(() => {
    setPage(1);
  }, [all, pageSize, sort]);

  const rows = React.useMemo(
    () => sorted.slice((page - 1) * pageSize, page * pageSize),
    [sorted, page, pageSize],
  );

  return { sort, setSort, page, setPage, pageSize, setPageSize, rows, total: sorted.length };
}

/* ═══════════════════════════════ сам кабинет ══════════════════════════════ */

/**
 * Витрина селлера — только чтение. Полный кабинет с созданием поставок и
 * заказов в объём MVP не входит (решение PM).
 */
export function SellerPortalPage(): React.ReactElement {
  const { t } = useI18n();
  const [params] = useSearchParams();
  const sellerId = params.get('sellerId') ?? undefined;

  const [range, setRange] = React.useState<DateRange>(() => presetRange('last30'));

  const view = useQuery({
    queryKey: ['dashboard', 'seller', sellerId ?? 'self'],
    queryFn: () => dashboardApi.seller(sellerId),
  });

  if (view.isLoading) {
    return (
      <PageContainer>
        <PageHeader title={t('ui.loading')} description={t('portal.subtitle')} />
        <KpiGrid>
          {['orders', 'units', 'delivered', 'revenue'].map((key) => (
            <KpiCard key={key} loading label={DASH} value={DASH} />
          ))}
        </KpiGrid>
        <div className="premium-card p-4">
          <SkeletonText lines={5} />
        </div>
      </PageContainer>
    );
  }

  if (view.isError || !view.data) {
    return (
      <PageContainer>
        <PageHeader title={t('portal.subtitle')} />
        <div className="premium-card flex flex-wrap items-center justify-between gap-3 p-4">
          <p className="text-sm text-destructive">{t('portal.dataUnavailable')}</p>
          <Button variant="outline" size="sm" onClick={() => void view.refetch()}>
            {t('ui.retry')}
          </Button>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title={view.data.sellerName}
        description={t('portal.subtitle')}
        actions={
          <Link to="/">
            <Button variant="ghost" size="sm">
              {t('portal.backHome')}
            </Button>
          </Link>
        }
      />

      <PortalKpis data={view.data} />

      <div className="grid gap-4 xl:grid-cols-3">
        <SellerDynamics
          className="xl:col-span-2"
          sellerId={sellerId}
          range={range}
          onRangeChange={setRange}
        />
        <Section title={t('portal.orders')}>
          <OrdersDonut data={view.data} />
        </Section>
      </div>

      <StockTable rows={view.data.stock} />
      <ShipmentsTable rows={view.data.recentShipments} />
      <InvoicesTable invoices={view.data.openInvoices} />
    </PageContainer>
  );
}

/* ───────────────────────────────── плитки ───────────────────────────────── */

function PortalKpis({ data }: { data: SellerDashboardDto }): React.ReactElement {
  const { t } = useI18n();

  const ordersTotal = data.ordersByStatus.reduce((sum, row) => sum + row.count, 0);
  const available = data.stock.reduce((sum, row) => sum + row.available, 0);
  const blocked = data.stock.reduce((sum, row) => sum + row.quarantine + row.damaged, 0);

  // Складывать можно только однородные суммы: два счёта в разных валютах в одну
  // плитку не сводятся, и показать их «итогом» значило бы придумать число.
  const currencies = new Set(data.openInvoices.map((invoice) => invoice.currency));
  const payout =
    currencies.size === 1
      ? sumMoneyStrings(data.openInvoices.map((invoice) => invoice.payoutTotal))
      : null;
  const payoutCurrency = [...currencies][0] ?? 'UZS';

  return (
    <KpiGrid>
      <KpiCard
        label={t('portal.kpi.ordersTotal')}
        value={ordersTotal.toLocaleString('ru-RU')}
        tone="default"
      />
      <KpiCard
        label={t('portal.kpi.available')}
        value={available.toLocaleString('ru-RU')}
        hint={t('portal.kpi.skus') + ': ' + data.stock.length.toLocaleString('ru-RU')}
        tone="success"
      />
      <KpiCard
        label={t('portal.kpi.blocked')}
        value={blocked.toLocaleString('ru-RU')}
        tone={blocked > 0 ? 'destructive' : 'default'}
      />
      <KpiCard
        label={t('portal.kpi.payout')}
        value={payout === null ? DASH : money(payout, payoutCurrency)}
        hint={t('portal.kpi.openInvoices') + ': ' + data.openInvoices.length.toLocaleString('ru-RU')}
        tone="info"
      />
    </KpiGrid>
  );
}

function OrdersDonut({ data }: { data: SellerDashboardDto }): React.ReactElement {
  const { t } = useI18n();

  const slices: DonutSlice[] = data.ordersByStatus.map((row, index) => ({
    key: row.status,
    name: t(`status.${row.status}` as MessageKey),
    value: row.count,
    // Статус в этом DTO объявлен как `string`: цвет берём из общей таблицы,
    // а если бэкенд однажды пришлёт незнакомый — падаем на палитру графиков.
    color: ORDER_STATUS_CHART_COLOR[row.status as OrderStatusKey] ?? CHART_COLORS[index % CHART_COLORS.length],
  }));
  const total = slices.reduce((sum, slice) => sum + slice.value, 0);

  return (
    <DonutChart
      slices={slices}
      size={168}
      centerLabel={t('ui.chart.total')}
      centerValue={total > 0 ? total.toLocaleString('ru-RU') : DASH}
      formatValue={(value) => value.toLocaleString('ru-RU')}
    />
  );
}

/* ─────────────────────────── динамика по селлеру ────────────────────────── */

/**
 * Шаг графика подбирается по длине периода: 400 точек на дневном шаге бэкенд
 * не отдаст (там стоит потолок), а годовой отчёт по дням всё равно нечитаем.
 */
function granularityFor(range: DateRange): AnalyticsGranularity {
  const days = daysInRange(range);
  if (days === null) return 'month';
  if (days <= 45) return 'day';
  if (days <= 200) return 'week';
  return 'month';
}

function SellerDynamics({
  sellerId,
  range,
  onRangeChange,
  className,
}: {
  sellerId: string | undefined;
  range: DateRange;
  onRangeChange: (range: DateRange) => void;
  className?: string;
}): React.ReactElement {
  const { t } = useI18n();
  const monthName = React.useCallback(
    (month: number): string => t(`ui.month.${month}` as MessageKey),
    [t],
  );

  const granularity = granularityFor(range);
  const query = React.useMemo(
    () => ({ ...rangeToQuery(range), sellerId, granularity }),
    [range, sellerId, granularity],
  );

  const summary = useQuery({
    queryKey: ['analytics', 'seller-summary', query],
    queryFn: () => analyticsApi.sellerSummary(query),
    placeholderData: keepPreviousData,
  });

  const points = React.useMemo(
    () => buildSeriesPoints(summary.data?.series ?? [], granularity, monthName),
    [summary.data?.series, granularity, monthName],
  );

  const seriesKeys = summary.data?.seriesKeys ?? [];
  const series: ChartSeries[] = ['orders', 'delivered', 'returned']
    .filter((key) => seriesKeys.includes(key))
    .map((key, index) => ({
      key,
      name: t(`analytics.metric.${key}` as MessageKey),
      color: CHART_COLORS[index % CHART_COLORS.length],
    }));

  return (
    <Section
      className={className}
      title={t('portal.summary')}
      description={t('portal.summaryHint')}
      actions={<DateRangePicker compact value={range} onChange={onRangeChange} align="end" />}
    >
      {summary.isError ? (
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-destructive">{t('analytics.error')}</p>
          <Button variant="outline" size="sm" onClick={() => void summary.refetch()}>
            {t('ui.retry')}
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          <MetricKpiGrid
            metrics={summary.data?.metrics ?? []}
            loading={summary.isLoading}
            keys={['orders', 'delivered', 'returned', 'returnRatePct']}
          />
          <LineChart
            area
            curved
            legend
            height={240}
            points={points}
            series={series}
            formatValue={(value) => Math.round(value).toLocaleString('ru-RU')}
          />
        </div>
      )}
    </Section>
  );
}

/* ──────────────────────────────── остатки ──────────────────────────────── */

function StockTable({ rows }: { rows: SellerStockRowDto[] }): React.ReactElement {
  const { t } = useI18n();

  const sortValue = React.useCallback((row: SellerStockRowDto, key: string): string | number => {
    switch (key) {
      case 'sku':
        return row.skuCode;
      case 'available':
        return row.available;
      case 'reserved':
        return row.reserved;
      case 'inProgress':
        return row.inProgress;
      case 'quarantine':
        return row.quarantine;
      case 'damaged':
        return row.damaged;
      default:
        return 0;
    }
  }, []);

  const table = useLocalTable(rows, sortValue, { key: 'available', direction: 'desc' }, 10);

  const columns: Array<DataTableColumn<SellerStockRowDto>> = [
    {
      key: 'sku',
      header: t('portal.sku'),
      sortable: true,
      width: '18rem',
      className: 'sticky left-0 z-[1] bg-card',
      headerClassName: 'sticky left-0 z-20 bg-card',
      cell: (row) => (
        <div className="min-w-0">
          <div className="truncate font-mono text-xs font-medium text-foreground">{row.skuCode}</div>
          <div className="truncate text-xs text-muted-foreground">{row.name}</div>
        </div>
      ),
    },
    {
      key: 'available',
      header: t('portal.available'),
      sortable: true,
      align: 'right',
      cell: (row) => row.available.toLocaleString('ru-RU'),
    },
    {
      key: 'reserved',
      header: t('portal.reserved'),
      sortable: true,
      align: 'right',
      cell: (row) => row.reserved.toLocaleString('ru-RU'),
    },
    {
      key: 'inProgress',
      header: t('portal.inProgress'),
      sortable: true,
      align: 'right',
      cell: (row) => row.inProgress.toLocaleString('ru-RU'),
    },
    {
      key: 'quarantine',
      header: t('portal.quarantine'),
      sortable: true,
      align: 'right',
      cell: (row) =>
        row.quarantine > 0 ? (
          <Badge variant="warning" size="sm">
            {row.quarantine.toLocaleString('ru-RU')}
          </Badge>
        ) : (
          '0'
        ),
    },
    {
      key: 'damaged',
      header: t('portal.damaged'),
      sortable: true,
      align: 'right',
      cell: (row) =>
        row.damaged > 0 ? (
          <Badge variant="destructive" size="sm">
            {row.damaged.toLocaleString('ru-RU')}
          </Badge>
        ) : (
          '0'
        ),
    },
  ];

  return (
    <section className="space-y-2">
      <h2 className="text-sm font-semibold text-foreground">{t('portal.stock')}</h2>
      <DataTable
        columns={columns}
        rows={table.rows}
        getRowKey={(row) => row.skuId}
        sort={table.sort}
        onSortChange={table.setSort}
        emptyTitle={t('portal.noStock')}
        emptyDescription={t('ui.noDataHint')}
        footer={
          <Pagination
            page={table.page}
            pageSize={table.pageSize}
            total={table.total}
            onPageChange={table.setPage}
            onPageSizeChange={table.setPageSize}
          />
        }
      />
    </section>
  );
}

/* ─────────────────────────────── отправления ────────────────────────────── */

function ShipmentsTable({ rows }: { rows: SellerShipmentRowDto[] }): React.ReactElement {
  const { t } = useI18n();

  const sortValue = React.useCallback((row: SellerShipmentRowDto, key: string): string | number => {
    switch (key) {
      case 'shipmentNo':
        return row.shipmentNo;
      case 'order':
        return row.orderExternalId;
      case 'status':
        return row.status;
      case 'handedOver':
        return row.handedOverAt ?? '';
      case 'delivered':
        return row.deliveredAt ?? '';
      default:
        return 0;
    }
  }, []);

  const table = useLocalTable(rows, sortValue, { key: 'handedOver', direction: 'desc' }, 10);

  const dateCell = (value: string | null): string =>
    value === null ? DASH : new Date(value).toLocaleDateString('ru-RU');

  const columns: Array<DataTableColumn<SellerShipmentRowDto>> = [
    {
      key: 'shipmentNo',
      header: t('portal.shipmentNo'),
      sortable: true,
      width: '12rem',
      className: 'sticky left-0 z-[1] bg-card',
      headerClassName: 'sticky left-0 z-20 bg-card',
      cell: (row) => <span className="font-mono text-xs font-medium">{row.shipmentNo}</span>,
    },
    {
      key: 'order',
      header: t('portal.order'),
      sortable: true,
      cell: (row) => <span className="font-mono text-xs">{row.orderExternalId}</span>,
    },
    {
      key: 'status',
      header: t('portal.status'),
      sortable: true,
      cell: (row) => (
        <Badge dot variant={SHIPMENT_BADGE[row.status] ?? 'muted'} size="sm">
          {t(`portal.shipmentStatus.${row.status}` as MessageKey)}
        </Badge>
      ),
    },
    {
      key: 'tracking',
      header: t('portal.tracking'),
      hideable: true,
      cell: (row) =>
        row.trackingNo ? <span className="font-mono text-xs">{row.trackingNo}</span> : DASH,
    },
    {
      key: 'handedOver',
      header: t('portal.handedOver'),
      sortable: true,
      align: 'right',
      hideable: true,
      cell: (row) => dateCell(row.handedOverAt),
    },
    {
      key: 'delivered',
      header: t('portal.deliveredAt'),
      sortable: true,
      align: 'right',
      hideable: true,
      cell: (row) => dateCell(row.deliveredAt),
    },
    {
      key: 'cod',
      header: t('portal.cod'),
      align: 'right',
      cell: (row) => (
        <div className="whitespace-nowrap">
          <div>{money(row.codAmount)}</div>
          {row.codCollectedAmount ? (
            <div className="text-xs text-muted-foreground">
              {t('portal.codCollected', { amount: money(row.codCollectedAmount) })}
            </div>
          ) : null}
        </div>
      ),
    },
  ];

  return (
    <section className="space-y-2">
      <h2 className="text-sm font-semibold text-foreground">{t('portal.shipments')}</h2>
      <DataTable
        columnVisibility
        columns={columns}
        rows={table.rows}
        getRowKey={(row) => row.shipmentNo}
        sort={table.sort}
        onSortChange={table.setSort}
        emptyTitle={t('portal.noShipments')}
        emptyDescription={t('ui.noDataHint')}
        footer={
          <Pagination
            page={table.page}
            pageSize={table.pageSize}
            total={table.total}
            onPageChange={table.setPage}
            onPageSizeChange={table.setPageSize}
          />
        }
      />
    </section>
  );
}

/* ──────────────────────────────── счета ────────────────────────────────── */

type OpenInvoice = SellerDashboardDto['openInvoices'][number];

function InvoicesTable({ invoices }: { invoices: OpenInvoice[] }): React.ReactElement {
  const { t } = useI18n();

  const sortValue = React.useCallback((row: OpenInvoice, key: string): string | number => {
    switch (key) {
      case 'number':
        return row.number;
      case 'period':
        return row.periodStart;
      case 'status':
        return row.status;
      default:
        return 0;
    }
  }, []);

  const table = useLocalTable(invoices, sortValue, { key: 'period', direction: 'desc' }, 10);

  const columns: Array<DataTableColumn<OpenInvoice>> = [
    {
      key: 'number',
      header: t('portal.invoiceNumber'),
      sortable: true,
      width: '12rem',
      cell: (row) => <span className="font-mono text-xs font-medium">{row.number}</span>,
    },
    {
      key: 'period',
      header: t('portal.period'),
      sortable: true,
      cell: (row) => (
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          {row.periodStart} — {row.periodEnd}
        </span>
      ),
    },
    {
      key: 'status',
      header: t('portal.status'),
      sortable: true,
      cell: (row) => (
        <Badge variant="muted" size="sm">
          {row.status}
        </Badge>
      ),
    },
    {
      key: 'services',
      header: t('portal.services'),
      align: 'right',
      cell: (row) => money(row.servicesTotal, row.currency),
    },
    {
      key: 'payout',
      header: t('portal.payout'),
      align: 'right',
      cell: (row) => <span className="font-medium">{money(row.payoutTotal, row.currency)}</span>,
    },
  ];

  return (
    <section className="space-y-2">
      <h2 className="text-sm font-semibold text-foreground">{t('portal.invoices')}</h2>
      <DataTable
        columns={columns}
        rows={table.rows}
        getRowKey={(row) => row.id}
        sort={table.sort}
        onSortChange={table.setSort}
        emptyTitle={t('portal.noInvoices')}
        emptyDescription={t('ui.noDataHint')}
        footer={
          <Pagination
            page={table.page}
            pageSize={table.pageSize}
            total={table.total}
            onPageChange={table.setPage}
            onPageSizeChange={table.setPageSize}
          />
        }
      />
    </section>
  );
}
