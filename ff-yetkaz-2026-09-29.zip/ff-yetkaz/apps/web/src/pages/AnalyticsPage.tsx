import * as React from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import type {
  AnalyticsGranularity,
  AnalyticsMetricDto,
  AnalyticsOverviewDto,
  AnalyticsQuery,
  AnalyticsSeriesPointDto,
  BiViewDto,
  OrderCategoryDto,
  OrderStatus,
  SellerAnalyticsDto,
  SellerAnalyticsRowDto,
} from '@ff/shared';
import { ANALYTICS_GRANULARITIES } from '@ff/shared';
import { analyticsApi } from '@/lib/analytics';
import { orderCategoriesApi } from '@/lib/order-categories';
import { useAuth } from '@/lib/auth';
import { presetRange, rangeToQuery, type DateRange } from '@/lib/date-range';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  BarChart,
  CHART_COLORS,
  DonutChart,
  LineChart,
  type ChartPoint,
  type ChartSeries,
  type DonutSlice,
} from '@/components/ui/charts';
import { DataTable, type DataTableColumn, type DataTableSort } from '@/components/ui/data-table';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { EmptyState } from '@/components/ui/empty-state';
import { KpiCard, KpiGrid, type KpiCardProps, type KpiTone } from '@/components/ui/kpi-card';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Pagination } from '@/components/ui/pagination';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { Select } from '@/components/ui/select';
import { Table, TBody, TD, TH, THead, TR } from '@/components/ui/table';
import { FilterChip, Toolbar, ToolbarGroup, ToolbarSpacer } from '@/components/ui/toolbar';
import { useToast } from '@/components/ui/toast';

/* ═══════════════════════════════ клиент API ═══════════════════════════════ */

/**
 * Клиент BI-ручек живёт рядом со своим экраном, а не в `src/lib/`: файлы
 * библиотеки сейчас правятся параллельно другими задачами, и ещё один модуль
 * там гарантировал бы конфликт. Переезд в `src/lib/analytics.ts` — механическое
 * перемещение этого блока, ничего в нём для этого менять не нужно.
 */

function toSearch(params: Record<string, string | undefined>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== '') search.set(key, value);
  }
  const query = search.toString();
  return query ? `?${query}` : '';
}

function overviewSearch(query: AnalyticsQuery): string {
  return toSearch({
    dateFrom: query.dateFrom,
    dateTo: query.dateTo,
    sellerId: query.sellerId,
    warehouseId: query.warehouseId,
    categoryId: query.categoryId,
    granularity: query.granularity,
  });
}

/** У списка селлеров и его выгрузки шага графика нет — параметр отбрасываем. */
function sellersSearch(query: AnalyticsQuery): string {
  return toSearch({
    dateFrom: query.dateFrom,
    dateTo: query.dateTo,
    sellerId: query.sellerId,
    warehouseId: query.warehouseId,
    categoryId: query.categoryId,
  });
}

// Клиент BI-ручек и выгрузка живут в lib/: страница их только использует.
// Второй экземпляр того же кода рядом разойдётся с первым на первой же правке.

/** Справочник категорий нужен только как источник фильтра — одним запросом. */
function fetchOrderCategories(): Promise<OrderCategoryDto[]> {
  return orderCategoriesApi.list(true);
}

/* ═════════════════════════════ форматирование ═════════════════════════════ */

const NBSP = ' ';
const DASH = '—';

/**
 * Разряды группируются посимвольно, без `Number()`.
 *
 * Деньги приходят строкой намеренно: сумма в сумах за квартал легко выходит за
 * безопасный диапазон double, и один `Number()` по дороге к экрану тихо съедает
 * младшие разряды. Поэтому строка так и остаётся строкой до самого DOM.
 */
export function formatDecimalString(
  raw: string | null | undefined,
  maxFraction = 2,
): string | null {
  if (raw === null || raw === undefined) return null;
  const trimmed = raw.trim();
  if (trimmed === '') return null;

  const match = /^([+-]?)(\d+)(?:[.,](\d+))?$/.exec(trimmed);
  if (!match) return null;

  const sign = match[1] === '-' ? '-' : '';
  const grouped = match[2].replace(/\B(?=(\d{3})+(?!\d))/g, NBSP);
  const fraction = (match[3] ?? '').slice(0, maxFraction).replace(/0+$/, '');
  return `${sign}${grouped}${fraction ? `,${fraction}` : ''}`;
}

/** Метрики, которые сервер отдаёт форматом `count`, но измеряет часами. */
const HOUR_METRICS = new Set(['avgFulfilmentHours']);

/**
 * Значение плитки. `—` показывается только там, где числа НЕТ (null, пустая
 * строка, мусор): ноль — это факт («за период не было ни одного возврата»),
 * и подменять его прочерком значит скрывать результат.
 */
function fractionDigitsFor(metric: AnalyticsMetricDto): number {
  if (metric.format === 'money') return 2;
  if (metric.format === 'percent' || HOUR_METRICS.has(metric.key)) return 1;
  return 0;
}

export function formatMetricValue(
  metric: AnalyticsMetricDto,
  t: (key: MessageKey, params?: Record<string, string | number>) => string,
): string {
  const value = formatDecimalString(metric.value, fractionDigitsFor(metric));
  if (value === null) return DASH;

  switch (metric.format) {
    case 'money':
      return metric.currency ? `${value}${NBSP}${metric.currency}` : value;
    case 'percent':
      return `${value}${NBSP}%`;
    case 'weight':
      return `${value}${NBSP}${t('analytics.unit.kg')}`;
    case 'count':
      return HOUR_METRICS.has(metric.key) ? `${value}${NBSP}${t('analytics.unit.hours')}` : value;
  }
}

function metricDelta(metric: AnalyticsMetricDto): KpiCardProps['delta'] {
  if (metric.changePct === null) return undefined;
  const value = Number(metric.changePct);
  if (!Number.isFinite(value)) return undefined;
  return { value, suffix: '%', positiveIsGood: metric.positiveIsGood };
}

const METRIC_TONE: Record<string, KpiTone> = {
  delivered: 'success',
  revenue: 'success',
  codCollected: 'info',
  returnRatePct: 'warning',
  avgFulfilmentHours: 'warning',
  returned: 'destructive',
  cancelled: 'destructive',
};

/* ═════════════════════════════════ иконки ═════════════════════════════════ */

/**
 * Иконки нарисованы здесь, а не взяты из общего набора: тот правится соседними
 * задачами, и завязка на его состав добавила бы этому экрану чужую поломку.
 */
function Glyph({ children }: { children: React.ReactNode }): React.ReactElement {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {children}
    </svg>
  );
}

const METRIC_ICON: Record<string, React.ReactElement> = {
  orders: (
    <Glyph>
      <path d="M4 7h16v13H4z" />
      <path d="M8 7V4h8v3" />
    </Glyph>
  ),
  units: (
    <Glyph>
      <path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z" />
      <path d="M4 7.5 12 12l8-4.5M12 12v9" />
    </Glyph>
  ),
  delivered: (
    <Glyph>
      <path d="m4 12.5 5 5L20 6.5" />
    </Glyph>
  ),
  cancelled: (
    <Glyph>
      <circle cx="12" cy="12" r="8.5" />
      <path d="m9 9 6 6M15 9l-6 6" />
    </Glyph>
  ),
  returned: (
    <Glyph>
      <path d="M4 10h11a5 5 0 0 1 0 10H9" />
      <path d="m8 6-4 4 4 4" />
    </Glyph>
  ),
  returnRatePct: (
    <Glyph>
      <path d="m6 18 12-12" />
      <circle cx="8" cy="8" r="2" />
      <circle cx="16" cy="16" r="2" />
    </Glyph>
  ),
  revenue: (
    <Glyph>
      <path d="M4 18 9.5 12l3.5 3.5L20 8" />
      <path d="M15 8h5v5" />
    </Glyph>
  ),
  codCollected: (
    <Glyph>
      <rect x="3" y="6" width="18" height="12" rx="2.5" />
      <circle cx="12" cy="12" r="2.5" />
    </Glyph>
  ),
  avgFulfilmentHours: (
    <Glyph>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </Glyph>
  ),
  dispatchedCount: (
    <Glyph>
      <path d="M3 7h10v9H3z" />
      <path d="M13 10h4l3 3v3h-7z" />
      <circle cx="7" cy="18" r="1.6" />
      <circle cx="17" cy="18" r="1.6" />
    </Glyph>
  ),
};

/* ══════════════════════════════ общие блоки ═══════════════════════════════ */

export interface MetricKpiGridProps {
  metrics: AnalyticsMetricDto[];
  loading?: boolean;
  /** Порядок и состав плиток; без него показываются все метрики ответа. */
  keys?: string[];
  className?: string;
}

/**
 * Плитки рисуются ПО ОТВЕТУ, а не по списку в коде: набор метрик задаёт бэкенд,
 * и захардкоженный перечень означал бы, что новая метрика появляется только
 * с релизом фронта.
 */
export function MetricKpiGrid({
  metrics,
  loading = false,
  keys,
  className,
}: MetricKpiGridProps): React.ReactElement {
  const { t } = useI18n();

  const shown = keys
    ? keys
        .map((key) => metrics.find((metric) => metric.key === key))
        .filter((metric): metric is AnalyticsMetricDto => metric !== undefined)
    : metrics;

  // Пустой ответ (свежая база) — не повод показывать пустоту: каркас плиток
  // с прочерками сообщает «данных за период нет», а не «экран не догрузился».
  if (shown.length === 0) {
    const placeholderKeys = keys ?? ['orders', 'delivered', 'returned', 'revenue'];
    return (
      <KpiGrid className={className}>
        {placeholderKeys.map((key) => (
          <KpiCard
            key={`kpi-placeholder-${key}`}
            loading={loading}
            icon={METRIC_ICON[key]}
            label={t(`analytics.metric.${key}` as MessageKey)}
            value={DASH}
          />
        ))}
      </KpiGrid>
    );
  }

  return (
    <KpiGrid className={className}>
      {shown.map((metric) => {
        const previous = formatDecimalString(
          metric.previous,
          fractionDigitsFor(metric),
        );
        return (
          <KpiCard
            key={metric.key}
            loading={loading}
            tone={METRIC_TONE[metric.key] ?? 'default'}
            icon={METRIC_ICON[metric.key]}
            label={t(`analytics.metric.${metric.key}` as MessageKey)}
            value={formatMetricValue(metric, t)}
            delta={metricDelta(metric)}
            hint={previous === null ? undefined : t('analytics.previous', { value: previous })}
          />
        );
      })}
    </KpiGrid>
  );
}

/**
 * Цвет статуса — только токен темы, включая полупрозрачные производные: тринадцать
 * статусов в шесть графиковых токенов не умещаются, а брать седьмой цвет «из
 * головы» означало бы hex, который не переживёт смену темы.
 */
export const ORDER_STATUS_CHART_COLOR: Record<OrderStatus, string> = {
  NEW: 'hsl(var(--chart-1))',
  VALIDATED: 'hsl(var(--chart-1) / 0.55)',
  RESERVED: 'hsl(var(--chart-3))',
  PICKING: 'hsl(var(--chart-3) / 0.55)',
  PICKED: 'hsl(var(--chart-2))',
  PACKING: 'hsl(var(--chart-2) / 0.55)',
  PACKED: 'hsl(var(--info))',
  READY_TO_SHIP: 'hsl(var(--info) / 0.55)',
  DISPATCHED: 'hsl(var(--warning))',
  SHIPPED: 'hsl(var(--warning) / 0.55)',
  DELIVERED: 'hsl(var(--success))',
  RETURNED: 'hsl(var(--destructive))',
  CANCELLED: 'hsl(var(--muted-foreground) / 0.6)',
};

/** Подпись интервала: «20 авг» по дням и неделям, «авг 2026» по месяцам. */
export function bucketLabel(
  bucket: string,
  granularity: AnalyticsGranularity,
  monthName: (month: number) => string,
): string {
  const parts = bucket.split('-');
  const month = Number(parts[1]);
  const day = Number(parts[2]);
  if (!Number.isFinite(month) || month < 1 || month > 12) return bucket;
  if (granularity === 'month') return `${monthName(month)} ${parts[0]}`;
  return Number.isFinite(day) ? `${day} ${monthName(month)}` : `${monthName(month)} ${parts[0]}`;
}

/**
 * Числа ряда переводятся в float ТОЛЬКО здесь, на входе в график: пиксель всё
 * равно целый, а точная сумма показывается плиткой и таблицей, где она остаётся
 * строкой.
 */
export function buildSeriesPoints(
  series: AnalyticsSeriesPointDto[],
  granularity: AnalyticsGranularity,
  monthName: (month: number) => string,
): ChartPoint[] {
  return series.map((point) => {
    const values: Record<string, number> = {};
    for (const [key, raw] of Object.entries(point.values)) {
      const parsed = Number(raw);
      values[key] = Number.isFinite(parsed) ? parsed : 0;
    }
    return { label: bucketLabel(point.bucket, granularity, monthName), values };
  });
}

/** Секция-карточка с заголовком: одинаковая рамка у всех блоков экрана. */
function Panel({
  title,
  description,
  actions,
  children,
  className,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}): React.ReactElement {
  return (
    <section className={cn('premium-card p-4', className)}>
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <h2 className="text-sm font-semibold text-card-foreground">{title}</h2>
          {description ? (
            <p className="mt-0.5 text-xs text-muted-foreground">{description}</p>
          ) : null}
        </div>
        {actions ? <div className="flex shrink-0 items-center gap-2">{actions}</div> : null}
      </div>
      {children}
    </section>
  );
}

function ErrorPanel({ message, onRetry }: { message: string; onRetry: () => void }): React.ReactElement {
  const { t } = useI18n();
  return (
    <div className="premium-card flex flex-wrap items-center justify-between gap-3 p-4">
      <p className="text-sm text-destructive">{message}</p>
      <Button variant="outline" size="sm" onClick={onRetry}>
        {t('ui.retry')}
      </Button>
    </div>
  );
}

function ExportButton({
  onExport,
  disabled = false,
}: {
  onExport: () => Promise<void>;
  disabled?: boolean;
}): React.ReactElement {
  const { t } = useI18n();
  const toast = useToast();
  const [busy, setBusy] = React.useState(false);

  const run = async (): Promise<void> => {
    setBusy(true);
    try {
      await onExport();
      toast.success(t('ui.export.done'));
    } catch (error) {
      toast.error(t('ui.export.failed'), error instanceof Error ? error.message : undefined);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Button variant="outline" size="sm" disabled={disabled || busy} onClick={() => void run()}>
      {busy ? t('ui.export.busy') : t('ui.export.excel')}
    </Button>
  );
}

/* ═══════════════════════════════ сам экран ════════════════════════════════ */

const SELLER_PAGE_SIZE_DEFAULT = 20;

export function AnalyticsPage(): React.ReactElement {
  const { t } = useI18n();
  const { user } = useAuth();

  const monthName = React.useCallback(
    (month: number): string => t(`ui.month.${month}` as MessageKey),
    [t],
  );

  const [range, setRange] = React.useState<DateRange>(() => presetRange('last30'));
  const [sellerId, setSellerId] = React.useState('');
  const [warehouseId, setWarehouseId] = React.useState('');
  const [categoryId, setCategoryId] = React.useState('');
  const [granularity, setGranularity] = React.useState<AnalyticsGranularity>('day');

  const roles = user?.roles ?? [];
  // Списки селлеров и витрины BI закрыты ролями ADMIN/FINANCE. Запрашивать их
  // складским оператором — значит рисовать ему блок, который отвечает 403.
  const canSeeSellerTable = roles.includes('ADMIN') || roles.includes('FINANCE');

  const query: AnalyticsQuery = React.useMemo(
    () => ({
      ...rangeToQuery(range),
      sellerId: sellerId || undefined,
      warehouseId: warehouseId || undefined,
      categoryId: categoryId || undefined,
      granularity,
    }),
    [range, sellerId, warehouseId, categoryId, granularity],
  );

  const overview = useQuery({
    queryKey: ['analytics', 'overview', query],
    queryFn: () => analyticsApi.overview(query),
    placeholderData: keepPreviousData,
  });

  const sellersTable = useQuery({
    queryKey: ['analytics', 'sellers', sellersSearch(query)],
    queryFn: () => analyticsApi.sellers(query),
    placeholderData: keepPreviousData,
    enabled: canSeeSellerTable,
  });

  const sellerDirectory = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const warehouses = useQuery({ queryKey: ['mdm', 'warehouses'], queryFn: mdmApi.warehouses });
  const categories = useQuery({
    queryKey: ['order-categories', 'all'],
    queryFn: fetchOrderCategories,
  });

  const data = overview.data;
  const loadingOverview = overview.isLoading;

  const seriesPoints = React.useMemo(
    () => buildSeriesPoints(data?.series ?? [], granularity, monthName),
    [data?.series, granularity, monthName],
  );

  const seriesKeys = data?.seriesKeys ?? [];
  const dynamicsSeries: ChartSeries[] = ['orders', 'delivered', 'returned']
    .filter((key) => seriesKeys.includes(key))
    .map((key, index) => ({
      key,
      name: t(`analytics.metric.${key}` as MessageKey),
      color: CHART_COLORS[index % CHART_COLORS.length],
    }));

  const revenueSeries: ChartSeries[] = seriesKeys.includes('revenue')
    ? [{ key: 'revenue', name: t('analytics.metric.revenue'), color: CHART_COLORS[3] }]
    : [];

  const currency = data?.currency ?? null;
  const compact = React.useMemo(
    () => new Intl.NumberFormat('ru-RU', { notation: 'compact', maximumFractionDigits: 1 }),
    [],
  );
  const formatMoneyAxis = React.useCallback(
    (value: number): string => (currency ? `${compact.format(value)}${NBSP}${currency}` : compact.format(value)),
    [compact, currency],
  );

  const statusSlices: DonutSlice[] = (data?.ordersByStatus ?? []).map((row) => ({
    key: row.status,
    name: t(`status.${row.status}` as MessageKey),
    value: row.count,
    color: ORDER_STATUS_CHART_COLOR[row.status],
  }));
  const statusTotal = statusSlices.reduce((sum, slice) => sum + slice.value, 0);

  const categorySlices: DonutSlice[] = (data?.ordersByCategory ?? []).map((row, index) => ({
    key: row.categoryId ?? 'none',
    name: row.name || t('analytics.chart.uncategorised'),
    value: row.count,
    // Цвет из справочника побеждает палитру: категория обязана выглядеть
    // одинаково здесь и в списке заказов.
    color: row.color ?? CHART_COLORS[index % CHART_COLORS.length],
  }));
  const categoryTotal = categorySlices.reduce((sum, slice) => sum + slice.value, 0);

  const intFormatter = React.useMemo(() => new Intl.NumberFormat('ru-RU'), []);
  const formatCount = React.useCallback(
    (value: number): string => intFormatter.format(Math.round(value)),
    [intFormatter],
  );

  const resetFilters = (): void => {
    setSellerId('');
    setWarehouseId('');
    setCategoryId('');
  };

  const sellerLabel = sellerDirectory.data?.find((seller) => seller.id === sellerId);
  const warehouseLabel = warehouses.data?.find((warehouse) => warehouse.id === warehouseId);
  const categoryLabel = categories.data?.find((category) => category.id === categoryId);
  const hasFilters = Boolean(sellerId || warehouseId || categoryId);

  const generatedAt = data
    ? new Date(data.generatedAt).toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' })
    : null;

  return (
    <PageContainer>
      <PageHeader
        title={t('analytics.title')}
        description={t('analytics.subtitle')}
        icon={
          <Glyph>
            <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
          </Glyph>
        }
        actions={
          <>
            <DateRangePicker value={range} onChange={setRange} align="end" />
            {canSeeSellerTable ? (
              <ExportButton
                disabled={sellersTable.isError}
                onExport={() => analyticsApi.exportSellers(query)}
              />
            ) : null}
          </>
        }
      />

      <div className="premium-card p-3">
        <Toolbar>
          <ToolbarGroup label={t('analytics.filters.seller')} className="w-full sm:w-60">
            <SearchableSelect
              value={sellerId}
              onChange={setSellerId}
              clearLabel={t('analytics.filters.allSellers')}
              placeholder={t('analytics.filters.allSellers')}
              searchPlaceholder={t('analytics.filters.searchSeller')}
              options={(sellerDirectory.data ?? []).map((seller) => ({
                value: seller.id,
                triggerLabel: seller.code,
                label: `${seller.code} — ${seller.legalName}`,
                keywords: `${seller.code} ${seller.legalName}`,
              }))}
            />
          </ToolbarGroup>

          <ToolbarGroup label={t('analytics.filters.warehouse')} className="w-full sm:w-48">
            <Select value={warehouseId} onChange={(event) => setWarehouseId(event.target.value)}>
              <option value="">{t('analytics.filters.allWarehouses')}</option>
              {(warehouses.data ?? []).map((warehouse) => (
                <option key={warehouse.id} value={warehouse.id}>
                  {warehouse.code} — {warehouse.name}
                </option>
              ))}
            </Select>
          </ToolbarGroup>

          <ToolbarGroup label={t('analytics.filters.category')} className="w-full sm:w-48">
            <Select value={categoryId} onChange={(event) => setCategoryId(event.target.value)}>
              <option value="">{t('analytics.filters.allCategories')}</option>
              {(categories.data ?? []).map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </Select>
          </ToolbarGroup>

          <ToolbarGroup label={t('analytics.filters.granularity')} className="w-full sm:w-40">
            <Select
              value={granularity}
              onChange={(event) => setGranularity(event.target.value as AnalyticsGranularity)}
            >
              {ANALYTICS_GRANULARITIES.map((key) => (
                <option key={key} value={key}>
                  {t(`analytics.granularity.${key}` as MessageKey)}
                </option>
              ))}
            </Select>
          </ToolbarGroup>

          <ToolbarSpacer />

          {hasFilters ? (
            <Button variant="ghost" size="sm" onClick={resetFilters}>
              {t('ui.reset')}
            </Button>
          ) : null}
        </Toolbar>

        {hasFilters ? (
          <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border pt-3">
            {sellerId ? (
              <FilterChip
                label={t('analytics.filters.seller')}
                value={sellerLabel?.code ?? sellerId}
                onClear={() => setSellerId('')}
              />
            ) : null}
            {warehouseId ? (
              <FilterChip
                label={t('analytics.filters.warehouse')}
                value={warehouseLabel?.code ?? warehouseId}
                onClear={() => setWarehouseId('')}
              />
            ) : null}
            {categoryId ? (
              <FilterChip
                label={t('analytics.filters.category')}
                value={categoryLabel?.name ?? categoryId}
                onClear={() => setCategoryId('')}
              />
            ) : null}
          </div>
        ) : null}
      </div>

      {overview.isError ? (
        <ErrorPanel message={t('analytics.error')} onRetry={() => void overview.refetch()} />
      ) : (
        <MetricKpiGrid metrics={data?.metrics ?? []} loading={loadingOverview} />
      )}

      <div className="grid gap-4 xl:grid-cols-2">
        <Panel
          title={t('analytics.chart.dynamics')}
          description={t('analytics.chart.dynamicsHint')}
          className="xl:col-span-2"
        >
          <LineChart
            area
            curved
            legend
            height={280}
            points={seriesPoints}
            series={dynamicsSeries}
            formatValue={formatCount}
          />
        </Panel>

        <Panel title={t('analytics.chart.revenue')} description={t('analytics.chart.revenueHint')}>
          <BarChart
            height={260}
            points={seriesPoints}
            series={revenueSeries}
            formatValue={formatMoneyAxis}
          />
        </Panel>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-1 2xl:grid-cols-2">
          <Panel title={t('analytics.chart.statuses')}>
            <DonutChart
              slices={statusSlices}
              size={168}
              centerLabel={t('ui.chart.total')}
              centerValue={statusTotal > 0 ? formatCount(statusTotal) : DASH}
              formatValue={formatCount}
            />
          </Panel>

          <Panel title={t('analytics.chart.categories')}>
            <DonutChart
              slices={categorySlices}
              size={168}
              centerLabel={t('ui.chart.total')}
              centerValue={categoryTotal > 0 ? formatCount(categoryTotal) : DASH}
              formatValue={formatCount}
            />
          </Panel>
        </div>
      </div>

      {canSeeSellerTable ? (
        <SellerAnalyticsTable
          data={sellersTable.data ?? null}
          loading={sellersTable.isLoading}
          error={sellersTable.isError}
          onRetry={() => void sellersTable.refetch()}
        />
      ) : null}

      {canSeeSellerTable ? <BiViewsSection /> : null}

      {generatedAt ? (
        <p className="text-right text-xs text-muted-foreground">
          {t('analytics.generatedAt', { time: generatedAt })}
        </p>
      ) : null}
    </PageContainer>
  );
}

/* ═══════════════════════════ таблица селлеров ═════════════════════════════ */

type SellerTotals = SellerAnalyticsDto['totals'];

/** Порог доли возвратов, за которым строка перестаёт быть нормой. */
const RETURN_RATE_OK = 3;
const RETURN_RATE_WATCH = 8;

function returnRateVariant(raw: string): 'success' | 'warning' | 'destructive' | 'muted' {
  const value = Number(raw);
  if (!Number.isFinite(value)) return 'muted';
  if (value <= RETURN_RATE_OK) return 'success';
  if (value <= RETURN_RATE_WATCH) return 'warning';
  return 'destructive';
}

function SellerAnalyticsTable({
  data,
  loading,
  error,
  onRetry,
}: {
  data: SellerAnalyticsDto | null;
  loading: boolean;
  error: boolean;
  onRetry: () => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [sort, setSort] = React.useState<DataTableSort | null>({ key: 'orders', direction: 'desc' });
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(SELLER_PAGE_SIZE_DEFAULT);

  const rows = React.useMemo(() => data?.rows ?? [], [data]);
  const currency = data?.totals.currency ?? null;

  const money = React.useCallback(
    (raw: string): string => {
      const value = formatDecimalString(raw, 2);
      if (value === null) return DASH;
      return currency ? `${value}${NBSP}${currency}` : value;
    },
    [currency],
  );

  /**
   * Сортировка и страницы считаются НА КЛИЕНТЕ, и это осознанно: `/analytics/sellers`
   * отдаёт ВЕСЬ список селлеров одним ответом (там нет ни `page`, ни `total`),
   * то есть в памяти лежит полный набор, а не первая страница. Именно поэтому
   * такая сортировка не врёт: она видит все строки, которые видит сервер.
   * Как только у ручки появится постраничность — обе операции обязаны уехать
   * в запрос.
   */
  const sorted = React.useMemo(() => {
    if (!sort) return rows;
    const direction = sort.direction === 'asc' ? 1 : -1;
    const key = sort.key;

    const copy = [...rows];
    copy.sort((left, right) => {
      if (key === 'seller') {
        return direction * left.sellerName.localeCompare(right.sellerName, 'ru');
      }
      // Деньги сравниваются через Number: порядок — единственное, что от него
      // требуется, а на экран сумма по-прежнему уходит строкой.
      const a = Number(left[key as keyof SellerAnalyticsRowDto] ?? 0);
      const b = Number(right[key as keyof SellerAnalyticsRowDto] ?? 0);
      if (!Number.isFinite(a) || !Number.isFinite(b)) return 0;
      return direction * (a - b);
    });
    return copy;
  }, [rows, sort]);

  React.useEffect(() => {
    setPage(1);
  }, [rows, pageSize, sort]);

  const pageRows = React.useMemo(
    () => sorted.slice((page - 1) * pageSize, page * pageSize),
    [sorted, page, pageSize],
  );

  const columns: Array<DataTableColumn<SellerAnalyticsRowDto>> = [
    {
      key: 'seller',
      header: t('analytics.col.seller'),
      sortable: true,
      width: '15rem',
      // Первая колонка липкая: без неё при горизонтальной прокрутке чисел
      // непонятно, чья это строка.
      className: 'sticky left-0 z-[1] bg-card',
      headerClassName: 'sticky left-0 z-20 bg-card',
      cell: (row) => (
        <div className="min-w-0">
          <div className="truncate font-medium text-foreground">{row.sellerName}</div>
          <div className="truncate font-mono text-xs text-muted-foreground">{row.sellerCode}</div>
        </div>
      ),
    },
    {
      key: 'orders',
      header: t('analytics.col.orders'),
      sortable: true,
      align: 'right',
      cell: (row) => row.orders.toLocaleString('ru-RU'),
    },
    {
      key: 'delivered',
      header: t('analytics.col.delivered'),
      sortable: true,
      align: 'right',
      cell: (row) => row.delivered.toLocaleString('ru-RU'),
    },
    {
      key: 'cancelled',
      header: t('analytics.col.cancelled'),
      sortable: true,
      align: 'right',
      cell: (row) => row.cancelled.toLocaleString('ru-RU'),
    },
    {
      key: 'returned',
      header: t('analytics.col.returned'),
      sortable: true,
      align: 'right',
      cell: (row) => row.returned.toLocaleString('ru-RU'),
    },
    {
      key: 'returnRatePct',
      header: t('analytics.col.returnRate'),
      sortable: true,
      align: 'right',
      cell: (row) => {
        const value = formatDecimalString(row.returnRatePct, 1);
        return (
          <Badge variant={returnRateVariant(row.returnRatePct)} size="sm">
            {value === null ? DASH : `${value}${NBSP}%`}
          </Badge>
        );
      },
    },
    {
      key: 'units',
      header: t('analytics.col.units'),
      sortable: true,
      align: 'right',
      hideable: true,
      cell: (row) => row.units.toLocaleString('ru-RU'),
    },
    {
      key: 'revenue',
      header: t('analytics.col.revenue'),
      sortable: true,
      align: 'right',
      cell: (row) => <span className="font-medium">{money(row.revenue)}</span>,
    },
    {
      key: 'codCollected',
      header: t('analytics.col.cod'),
      sortable: true,
      align: 'right',
      hideable: true,
      cell: (row) => money(row.codCollected),
    },
    {
      key: 'averageOrderValue',
      header: t('analytics.col.aov'),
      sortable: true,
      align: 'right',
      hideable: true,
      cell: (row) => money(row.averageOrderValue),
    },
    {
      key: 'stockUnits',
      header: t('analytics.col.stock'),
      sortable: true,
      align: 'right',
      hideable: true,
      cell: (row) => row.stockUnits.toLocaleString('ru-RU'),
    },
  ];

  if (error) {
    return (
      <Panel title={t('analytics.sellers.title')}>
        <ErrorPanel message={t('analytics.error')} onRetry={onRetry} />
      </Panel>
    );
  }

  return (
    <section className="space-y-2">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-sm font-semibold text-foreground">{t('analytics.sellers.title')}</h2>
        <p className="text-xs text-muted-foreground">{t('analytics.sellers.subtitle')}</p>
      </div>

      <DataTable
        columnVisibility
        columns={columns}
        rows={pageRows}
        loading={loading}
        sort={sort}
        onSortChange={setSort}
        getRowKey={(row) => row.sellerId}
        emptyTitle={t('analytics.sellers.empty')}
        emptyDescription={t('analytics.sellers.emptyHint')}
        maxHeight="32rem"
        footer={
          <div className="space-y-2">
            {data && rows.length > 0 ? <SellerTotalsRow totals={data.totals} money={money} /> : null}
            <Pagination
              page={page}
              pageSize={pageSize}
              total={sorted.length}
              onPageChange={setPage}
              onPageSizeChange={setPageSize}
            />
          </div>
        }
      />
    </section>
  );
}

/**
 * Итоги вынесены в подвал отдельной полосой, а не строкой с колонками таблицы:
 * область строк прокручивается по горизонтали независимо от подвала, и «строка
 * итогов» под ней разъезжалась бы со своими заголовками при первом же сдвиге.
 * Пары «подпись — число» читаются при любой ширине.
 */
function SellerTotalsRow({
  totals,
  money,
}: {
  totals: SellerTotals;
  money: (raw: string) => string;
}): React.ReactElement {
  const { t } = useI18n();

  const cells: Array<{ label: string; value: string }> = [
    { label: t('analytics.col.orders'), value: totals.orders.toLocaleString('ru-RU') },
    { label: t('analytics.col.delivered'), value: totals.delivered.toLocaleString('ru-RU') },
    { label: t('analytics.col.cancelled'), value: totals.cancelled.toLocaleString('ru-RU') },
    { label: t('analytics.col.returned'), value: totals.returned.toLocaleString('ru-RU') },
    {
      label: t('analytics.col.returnRate'),
      value: `${formatDecimalString(totals.returnRatePct, 1) ?? DASH}${NBSP}%`,
    },
    { label: t('analytics.col.units'), value: totals.units.toLocaleString('ru-RU') },
    { label: t('analytics.col.revenue'), value: money(totals.revenue) },
    { label: t('analytics.col.cod'), value: money(totals.codCollected) },
    { label: t('analytics.col.aov'), value: money(totals.averageOrderValue) },
    { label: t('analytics.col.stock'), value: totals.stockUnits.toLocaleString('ru-RU') },
  ];

  return (
    <div className="flex flex-wrap items-center gap-x-5 gap-y-1.5">
      <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {t('analytics.totals')}
      </span>
      {cells.map((cell) => (
        <span key={cell.label} className="text-xs text-muted-foreground">
          {cell.label}:{' '}
          <span className="font-semibold tabular-nums text-foreground">{cell.value}</span>
        </span>
      ))}
    </div>
  );
}

/* ═════════════════════════════ витрины для BI ═════════════════════════════ */

function BiViewsSection(): React.ReactElement {
  const { t } = useI18n();
  const toast = useToast();
  const [open, setOpen] = React.useState(false);
  const panelId = React.useId();

  const views = useQuery({
    queryKey: ['analytics', 'bi-views'],
    queryFn: analyticsApi.biViews,
    enabled: open,
    staleTime: 30 * 60 * 1000,
  });

  const copySelect = async (view: BiViewDto): Promise<void> => {
    const sql = `SELECT * FROM ${view.name} LIMIT 100`;
    try {
      // На http-origin (стенд без TLS) Clipboard API отсутствует целиком —
      // проверяем до вызова, иначе получаем невнятный TypeError.
      if (!navigator.clipboard) throw new Error('clipboard unavailable');
      await navigator.clipboard.writeText(sql);
      toast.success(t('analytics.bi.copied'), sql);
    } catch {
      toast.error(t('analytics.bi.copyFailed'), sql);
    }
  };

  return (
    <section className="premium-card overflow-hidden">
      <button
        type="button"
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => setOpen((value) => !value)}
        className="flex w-full items-center justify-between gap-3 p-4 text-left transition-colors hover:bg-accent/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring"
      >
        <span className="min-w-0">
          <span className="block text-sm font-semibold text-card-foreground">
            {t('analytics.bi.title')}
          </span>
          <span className="mt-0.5 block text-xs text-muted-foreground">
            {t('analytics.bi.subtitle')}
          </span>
        </span>
        <span className="shrink-0 text-xs font-medium text-muted-foreground">
          {open ? t('analytics.bi.hide') : t('analytics.bi.show')}
        </span>
      </button>

      {open ? (
        <div id={panelId} className="space-y-3 border-t border-border p-4">
          {views.isError ? (
            <ErrorPanel message={t('analytics.error')} onRetry={() => void views.refetch()} />
          ) : views.isLoading ? (
            <p className="text-sm text-muted-foreground">{t('ui.loading')}</p>
          ) : (views.data ?? []).length === 0 ? (
            <EmptyState title={t('analytics.bi.empty')} description={t('ui.noDataHint')} />
          ) : (
            (views.data ?? []).map((view) => (
              <article key={view.name} className="rounded-lg border border-border p-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-mono text-sm font-medium text-foreground">
                      {view.name}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {view.title} · {t('analytics.bi.columnsCount', { n: view.columns.length })}
                    </p>
                    {view.description ? (
                      <p className="mt-1.5 max-w-2xl text-xs leading-relaxed text-muted-foreground">
                        {view.description}
                      </p>
                    ) : null}
                  </div>
                  <Button variant="outline" size="sm" onClick={() => void copySelect(view)}>
                    {t('analytics.bi.copySelect')}
                  </Button>
                </div>

                <div className="mt-3 overflow-x-auto rounded-md border border-border">
                  <Table>
                    <THead>
                      <tr>
                        <TH scope="col">{t('analytics.bi.column')}</TH>
                        <TH scope="col">{t('analytics.bi.type')}</TH>
                        <TH scope="col">{t('analytics.bi.description')}</TH>
                      </tr>
                    </THead>
                    <TBody>
                      {view.columns.map((column) => (
                        <TR key={column.name}>
                          <TD className="whitespace-nowrap font-mono text-xs">{column.name}</TD>
                          <TD className="whitespace-nowrap font-mono text-xs text-muted-foreground">
                            {column.type}
                          </TD>
                          <TD className="text-xs text-muted-foreground">{column.description}</TD>
                        </TR>
                      ))}
                    </TBody>
                  </Table>
                </div>
              </article>
            ))
          )}
        </div>
      ) : null}
    </section>
  );
}
