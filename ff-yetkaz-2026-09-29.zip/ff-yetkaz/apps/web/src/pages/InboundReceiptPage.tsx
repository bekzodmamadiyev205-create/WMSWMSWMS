import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate, useParams } from 'react-router-dom';
import type { AsnLineDto, ReceiptLineDto, SkuDto } from '@ff/shared';
import { ApiError } from '@/lib/api';
import { apiErrorCode, inboundApi, type ScanInput } from '@/lib/inbound';
import { mdmApi } from '@/lib/mdm';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';
import { ScanFlash, useScanFeedback } from '@/components/scan-feedback';
import { useScannerInput } from '@/lib/use-scanner';

/** Партия и срок годности: пусто = не передаём (SKU без партионного учёта их отбивает). */
interface LotDraft {
  lotCode: string;
  expiryDate: string;
}

const EMPTY_LOT: LotDraft = { lotCode: '', expiryDate: '' };

/** Пустые строки не отправляем: у SKU без партионного учёта любая партия — 400. */
function lotFields(draft: LotDraft): Pick<ScanInput, 'lotCode' | 'expiryDate'> {
  return {
    lotCode: draft.lotCode.trim() || undefined,
    expiryDate: draft.expiryDate || undefined,
  };
}

/**
 * Поля партии и срока. Показываем их сразу, если у товара включён соответствующий
 * учёт; когда справочник недоступен (признаков нет) — прячем под «дополнительно»,
 * чтобы обычная приёмка не смотрела на два лишних поля.
 */
function LotInputs({
  idPrefix,
  sku,
  value,
  onChange,
}: {
  idPrefix: string;
  sku: SkuDto | undefined;
  value: LotDraft;
  onChange: (next: LotDraft) => void;
}): React.ReactElement {
  const { t } = useI18n();

  const fields = (
    <div className="grid gap-3 sm:grid-cols-2">
      <div className="space-y-1">
        <Label htmlFor={`${idPrefix}-lot`}>{t('inbound.lotCode')}</Label>
        <Input
          id={`${idPrefix}-lot`}
          autoComplete="off"
          placeholder={t('inbound.lotCodePlaceholder')}
          value={value.lotCode}
          onChange={(event) => onChange({ ...value, lotCode: event.target.value })}
        />
      </div>
      <div className="space-y-1">
        <Label htmlFor={`${idPrefix}-expiry`}>{t('inbound.expiryDate')}</Label>
        <Input
          id={`${idPrefix}-expiry`}
          type="date"
          value={value.expiryDate}
          onChange={(event) => onChange({ ...value, expiryDate: event.target.value })}
        />
      </div>
    </div>
  );

  if (sku && (sku.isLotTracked || sku.isExpiryTracked)) {
    return (
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground">{t('inbound.lotRequiredHint')}</p>
        {fields}
      </div>
    );
  }

  return (
    <details className="rounded-md border border-border px-3 py-2">
      <summary className="cursor-pointer text-sm text-muted-foreground">
        {t('inbound.moreFields')}
      </summary>
      <div className="pt-3">{fields}</div>
    </details>
  );
}

/**
 * Приём позиции прямо по строке заявки — без штрихкода. Строка ASN сама по себе
 * разрешает принять именно этот SKU именно в эту поставку, поэтому такой приём
 * строже скана: сканер ищет товар по всему справочнику, строка задаёт его однозначно.
 */
function ReceiveLineDialog({
  line,
  sku,
  busy,
  onClose,
  onSubmit,
}: {
  line: AsnLineDto;
  sku: SkuDto | undefined;
  busy: boolean;
  onClose: () => void;
  onSubmit: (values: { quantity: number } & LotDraft) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const remaining = Math.max(0, line.expectedQty - line.receivedQty);
  const [quantity, setQuantity] = React.useState(String(remaining || 1));
  const [lot, setLot] = React.useState<LotDraft>(EMPTY_LOT);
  const fieldId = React.useId();

  const qty = Number(quantity);
  const canSubmit = Number.isInteger(qty) && qty > 0 && !busy;

  const submit = (): void => {
    if (!canSubmit) return;
    onSubmit({ quantity: qty, ...lot });
  };

  return (
    <Dialog
      open
      onClose={busy ? () => undefined : onClose}
      title={t('inbound.receiveLine.title', { sku: line.skuCode })}
      description={t('inbound.receiveLine.hint', {
        expected: line.expectedQty,
        received: line.receivedQty,
      })}
      size="md"
      closeOnOverlay={!busy}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={busy}>
            {t('common.cancel')}
          </Button>
          <Button size="sm" onClick={submit} disabled={!canSubmit}>
            {t('inbound.receiveLine.submit')}
          </Button>
        </>
      }
    >
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <div className="text-sm text-muted-foreground">{line.skuName}</div>
        <div className="w-32 space-y-1">
          <Label htmlFor={`${fieldId}-qty`}>{t('inbound.qty')}</Label>
          <Input
            id={`${fieldId}-qty`}
            autoFocus
            inputMode="numeric"
            value={quantity}
            onChange={(event) => setQuantity(event.target.value.replace(/[^\d]/g, ''))}
          />
        </div>
        <LotInputs idPrefix={fieldId} sku={sku} value={lot} onChange={setLot} />
        {/* Скрытая кнопка: Enter в поле количества должен отправлять форму. */}
        <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
      </form>
    </Dialog>
  );
}

/**
 * Неизвестный штрихкод — не тупик: чаще всего это первый приход товара, у которого
 * кода в справочнике ещё нет. Привязываем код к позиции заявки и повторяем приём.
 */
function BindBarcodeDialog({
  barcode,
  lines,
  busy,
  onClose,
  onSubmit,
}: {
  barcode: string;
  lines: AsnLineDto[];
  busy: boolean;
  onClose: () => void;
  onSubmit: (asnLineId: string) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [asnLineId, setAsnLineId] = React.useState(lines[0]?.id ?? '');
  const fieldId = React.useId();

  return (
    <Dialog
      open
      onClose={busy ? () => undefined : onClose}
      title={t('inbound.bind.title')}
      description={t('inbound.bind.question', { barcode })}
      size="md"
      closeOnOverlay={!busy}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={busy}>
            {t('common.cancel')}
          </Button>
          <Button size="sm" onClick={() => onSubmit(asnLineId)} disabled={busy || !asnLineId}>
            {t('inbound.bind.submit')}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <div className="space-y-1">
          <Label htmlFor={fieldId}>{t('inbound.bind.line')}</Label>
          <Select
            id={fieldId}
            value={asnLineId}
            onChange={(event) => setAsnLineId(event.target.value)}
          >
            {lines.map((line) => (
              <option key={line.id} value={line.id}>
                {line.skuCode} — {line.skuName}
              </option>
            ))}
          </Select>
        </div>
        <p className="text-xs text-muted-foreground">{t('inbound.bind.hint')}</p>
      </div>
    </Dialog>
  );
}

/**
 * Рабочий экран приёмщика. Сканируем коробку, потом раскладываем по ячейкам.
 * Панель скана прижата к низу — на телефоне до неё дотягивается большой палец,
 * как и на экране сборщика.
 *
 * Рядом со сканом — план заявки: приёмщик должен видеть, чего от него ждут, а не
 * только то, что он уже отсканировал. Из плана же принимается товар без штрихкода.
 */
export function InboundReceiptPage(): React.ReactElement {
  const { t } = useI18n();
  const { id = '' } = useParams();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const [quantity, setQuantity] = React.useState('1');
  const [scanLot, setScanLot] = React.useState<LotDraft>(EMPTY_LOT);
  const [message, setMessage] = React.useState<{
    kind: 'ok' | 'error';
    text: string;
    /** Ошибка «SKU не в заявке» бесполезна без пути к самой заявке. */
    showPlan?: boolean;
  } | null>(null);
  const [putAwayLine, setPutAwayLine] = React.useState<ReceiptLineDto | null>(null);
  const [putAway, setPutAway] = React.useState({ qtyOk: '', qtyDamaged: '0', binId: '' });
  const [receiveLine, setReceiveLine] = React.useState<AsnLineDto | null>(null);
  const [unknownBarcode, setUnknownBarcode] = React.useState<string | null>(null);
  const feedback = useScanFeedback();
  const submitScan = React.useRef<(code: string) => void>(() => {});
  const scanner = useScannerInput((code) => submitScan.current(code));
  const planRef = React.useRef<HTMLElement>(null);

  const receipt = useQuery({
    queryKey: ['inbound', 'receipt', id],
    queryFn: () => inboundApi.receipt(id),
  });

  // Заявка грузится параллельно приёмке: план — половина экрана приёмщика.
  const asn = useQuery({
    queryKey: ['inbound', 'asn', receipt.data?.asnId ?? ''],
    queryFn: () => inboundApi.asn(receipt.data!.asnId),
    enabled: Boolean(receipt.data?.asnId),
  });

  // Справочник товаров селлера — ради признаков партионного учёта и штрихкодов:
  // в строке заявки их нет, а без них поля партии показывать наугад.
  const skus = useQuery({
    queryKey: ['mdm', 'skus', asn.data?.sellerId ?? '', ''],
    queryFn: () => mdmApi.skus({ sellerId: asn.data!.sellerId }),
    enabled: Boolean(asn.data?.sellerId),
  });
  const skuById = React.useMemo(
    () => new Map((skus.data ?? []).map((sku) => [sku.id, sku])),
    [skus.data],
  );

  const bins = useQuery({
    queryKey: ['mdm', 'bins', receipt.data?.warehouseId ?? ''],
    queryFn: () => mdmApi.bins(receipt.data!.warehouseId),
    enabled: Boolean(receipt.data?.warehouseId),
  });

  const storageBins = (bins.data ?? []).filter((bin) => bin.kind === 'STORAGE' && bin.isActive);

  const refresh = () => queryClient.invalidateQueries({ queryKey: ['inbound'] });
  const fail = (error: unknown) =>
    setMessage({
      kind: 'error',
      text: error instanceof ApiError ? error.message : t('common.error.network'),
    });

  const scan = useMutation({
    mutationFn: (input: ScanInput) => inboundApi.scan(id, input),
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('inbound.scan.received') });
      feedback.signalOk(t('inbound.scan.accepted'));
      scanner.clear();
      setQuantity('1');
      setScanLot(EMPTY_LOT);
      setReceiveLine(null);
      setUnknownBarcode(null);
      scanner.ref.current?.focus();
      refresh();
    },
    onError: (error, variables) => {
      const text = error instanceof ApiError ? error.message : t('common.error.network');
      const code = apiErrorCode(error);
      setMessage({ kind: 'error', text, showPlan: code === 'SKU_NOT_IN_ASN' });
      feedback.signalErr(text);

      // Незаведённый код — повод предложить привязку, а не отправлять человека
      // искать товар в справочнике.
      if (code === 'BARCODE_UNKNOWN' && variables.barcode) {
        setUnknownBarcode(variables.barcode);
      }

      // Приём по строке заявки идёт из открытого диалога — забирать у него фокус
      // нельзя. Возвращаем каретку в поле скана только после самого скана.
      if (variables.barcode) {
        // Введённое НЕ стираем: в поле видно опечатку или обрывок штрихкода.
        // Выделяем — следующий скан напечатается поверх выделения и заменит его.
        scanner.ref.current?.focus();
        scanner.ref.current?.select();
      }
    },
  });
  // Скан отправляет актуальное значение поля — из кнопки, Enter или авто-очереди.
  submitScan.current = (code: string) =>
    scan.mutate({ barcode: code, quantity: Number(quantity) || 1, ...lotFields(scanLot) });

  const bind = useMutation({
    mutationFn: (input: { asnLineId: string; barcode: string }) =>
      inboundApi.bindBarcode(id, input.asnLineId, input.barcode),
    onSuccess: (_sku, input) => {
      setUnknownBarcode(null);
      setMessage({ kind: 'ok', text: t('inbound.bind.done', { barcode: input.barcode }) });
      queryClient.invalidateQueries({ queryKey: ['mdm', 'skus'] });
      // Код теперь заведён — повторяем тот же приём, ради которого его и сканировали.
      scan.mutate({ barcode: input.barcode, quantity: Number(quantity) || 1, ...lotFields(scanLot) });
    },
    onError: fail,
  });

  const doPutAway = useMutation({
    mutationFn: () =>
      inboundApi.putAway(id, {
        receiptLineId: putAwayLine!.id,
        qtyOk: Number(putAway.qtyOk) || 0,
        qtyDamaged: Number(putAway.qtyDamaged) || 0,
        binId: putAway.binId,
      }),
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('inbound.putAway.done') });
      setPutAwayLine(null);
      refresh();
    },
    onError: fail,
  });

  const complete = useMutation({
    mutationFn: () => inboundApi.complete(id),
    onSuccess: (result) => {
      if (result.hasDiscrepancy) {
        const text = result.discrepancies
          .map((row) =>
            t('inbound.discrepancyRow', { expected: row.expectedQty, received: row.receivedQty }),
          )
          .join('; ');
        setMessage({ kind: 'error', text: t('inbound.closedWithDiscrepancy', { details: text }) });
      } else {
        setMessage({ kind: 'ok', text: t('inbound.closedOk') });
      }
      refresh();
      setTimeout(() => navigate('/inbound'), 1500);
    },
    onError: fail,
  });

  if (receipt.isLoading) {
    return <div className="p-6 text-sm text-muted-foreground">{t('inbound.loadingReceipt')}</div>;
  }
  if (receipt.isError || !receipt.data) {
    return (
      <div className="space-y-3 p-6">
        <p className="text-sm text-destructive">{t('inbound.notFound')}</p>
        <Link to="/inbound" className="text-sm underline">
          {t('inbound.toList')}
        </Link>
      </div>
    );
  }

  const data = receipt.data;
  const pending = data.lines.filter((line) => line.status === 'RECEIVED');
  const isOpen = data.status === 'OPEN';
  const planLines = asn.data?.lines ?? [];

  return (
    <div className="mx-auto max-w-xl space-y-4 p-4 pb-28">
      <ScanFlash flash={feedback.flash} />
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('inbound.title')}</h1>
        <Link to="/inbound" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>
      <p className="text-sm text-muted-foreground">
        {isOpen ? t('inbound.receiptOpen') : t('inbound.receiptClosed')} ·{' '}
        {t('inbound.receiptSummary', { lines: data.lines.length, pending: pending.length })}
      </p>

      {message && (
        <div
          role="status"
          className={
            message.kind === 'ok'
              ? 'space-y-2 rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
              : 'space-y-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
          }
        >
          <p>{message.text}</p>
          {message.showPlan && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => planRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
            >
              {t('inbound.plan.open')}
            </Button>
          )}
        </div>
      )}

      {storageBins.length === 0 && (
        <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {t('inbound.noBins')}
        </p>
      )}

      <section ref={planRef} className="space-y-2">
        <h2 className="text-sm font-medium text-muted-foreground">{t('inbound.plan.title')}</h2>
        {asn.isLoading && <p className="text-sm text-muted-foreground">{t('inbound.plan.loading')}</p>}
        {asn.isError && (
          <p className="text-sm text-destructive">{t('inbound.plan.error')}</p>
        )}
        {planLines.map((line) => {
          const remaining = Math.max(0, line.expectedQty - line.receivedQty);
          const sku = skuById.get(line.skuId);
          return (
            <Card key={line.id}>
              <CardContent className="space-y-2 p-4">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="font-medium">{line.skuCode}</span>
                  <span className="text-sm tabular-nums text-muted-foreground">
                    {t('inbound.plan.counts', {
                      expected: line.expectedQty,
                      received: line.receivedQty,
                      remaining,
                    })}
                  </span>
                </div>
                <div className="text-sm text-muted-foreground">{line.skuName}</div>
                {sku && sku.barcodes.length === 0 && (
                  <div className="text-xs text-muted-foreground">{t('inbound.plan.noBarcode')}</div>
                )}
                {isOpen && (
                  <div className="flex justify-end">
                    <Button
                      variant={remaining > 0 ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setReceiveLine(line)}
                    >
                      {t('inbound.plan.receive')}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
        {!asn.isLoading && !asn.isError && planLines.length === 0 && (
          <p className="text-sm text-muted-foreground">{t('inbound.plan.empty')}</p>
        )}
      </section>

      <section className="space-y-3">
        <h2 className="text-sm font-medium text-muted-foreground">{t('inbound.receivedTitle')}</h2>
        {data.lines.map((line) => (
          <Card key={line.id} className={line.status !== 'RECEIVED' ? 'opacity-60' : undefined}>
            <CardContent className="space-y-2 p-4">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-medium">{line.skuCode}</span>
                <span className="text-sm text-muted-foreground">
                  {t(`inbound.lineStatus.${line.status}` as MessageKey)}
                </span>
              </div>
              <div className="text-sm text-muted-foreground">{line.skuName}</div>
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="tabular-nums">
                  {t('inbound.receivedQty', { qty: line.qtyReceived })}
                  {line.qtyDamaged > 0 && (
                    <span className="text-destructive">
                      {' '}
                      · {t('inbound.damaged', { qty: line.qtyDamaged })}
                    </span>
                  )}
                </span>
                {isOpen && line.status === 'RECEIVED' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setPutAwayLine(line);
                      setPutAway({
                        qtyOk: String(line.qtyReceived),
                        qtyDamaged: '0',
                        binId: storageBins[0]?.id ?? '',
                      });
                    }}
                  >
                    {t('inbound.putAwayAction')}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
        {data.lines.length === 0 && (
          <p className="text-sm text-muted-foreground">{t('inbound.nothingScanned')}</p>
        )}
      </section>

      {putAwayLine && (
        <Card>
          <CardContent className="space-y-3 p-4">
            <div className="text-sm font-medium">
              {t('inbound.putAwayTitle', { sku: putAwayLine.skuCode, qty: putAwayLine.qtyReceived })}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="qty-ok">{t('inbound.putAwayOk')}</Label>
                <Input
                  id="qty-ok"
                  inputMode="numeric"
                  value={putAway.qtyOk}
                  onChange={(event) =>
                    setPutAway({ ...putAway, qtyOk: event.target.value.replace(/[^\d]/g, '') })
                  }
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="qty-damaged">{t('inbound.putAwayDamaged')}</Label>
                <Input
                  id="qty-damaged"
                  inputMode="numeric"
                  value={putAway.qtyDamaged}
                  onChange={(event) =>
                    setPutAway({ ...putAway, qtyDamaged: event.target.value.replace(/[^\d]/g, '') })
                  }
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="bin">{t('inbound.storageBin')}</Label>
              <Select
                id="bin"
                value={putAway.binId}
                onChange={(event) => setPutAway({ ...putAway, binId: event.target.value })}
              >
                {storageBins.map((bin) => (
                  <option key={bin.id} value={bin.id}>
                    {bin.code}
                  </option>
                ))}
              </Select>
            </div>
            {/* Сумма обязана сойтись с принятым — это проверяет и сервер. */}
            <p className="text-xs text-muted-foreground">
              {t('inbound.sumHint', { qty: putAwayLine.qtyReceived })}
            </p>
            <div className="flex gap-2">
              <Button
                disabled={
                  doPutAway.isPending ||
                  !putAway.binId ||
                  Number(putAway.qtyOk) + Number(putAway.qtyDamaged) !== putAwayLine.qtyReceived
                }
                onClick={() => doPutAway.mutate()}
              >
                {t('inbound.putAwayAction')}
              </Button>
              <Button variant="ghost" onClick={() => setPutAwayLine(null)}>
                {t('common.cancel')}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {isOpen && pending.length === 0 && data.lines.length > 0 && (
        <Button className="w-full" disabled={complete.isPending} onClick={() => complete.mutate()}>
          {t('inbound.complete')}
        </Button>
      )}

      {receiveLine && (
        <ReceiveLineDialog
          // Ключ по строке: смена позиции должна пересобрать поля, а не донести
          // количество от предыдущего товара.
          key={receiveLine.id}
          line={receiveLine}
          sku={skuById.get(receiveLine.skuId)}
          busy={scan.isPending}
          onClose={() => setReceiveLine(null)}
          onSubmit={(values) =>
            scan.mutate({
              asnLineId: receiveLine.id,
              quantity: values.quantity,
              ...lotFields(values),
            })
          }
        />
      )}

      {unknownBarcode && planLines.length > 0 && (
        <BindBarcodeDialog
          key={unknownBarcode}
          barcode={unknownBarcode}
          lines={planLines}
          busy={bind.isPending || scan.isPending}
          onClose={() => setUnknownBarcode(null)}
          onSubmit={(asnLineId) => bind.mutate({ asnLineId, barcode: unknownBarcode })}
        />
      )}

      {isOpen && (
        <form
          className="fixed inset-x-0 bottom-0 border-t bg-background p-3"
          onSubmit={(event) => {
            event.preventDefault();
            scanner.submit();
          }}
        >
          <div className="mx-auto max-w-xl space-y-2">
            <details className="rounded-md border border-border px-3 py-1.5">
              <summary className="cursor-pointer text-xs text-muted-foreground">
                {t('inbound.moreFields')}
              </summary>
              <div className="grid gap-2 py-2 sm:grid-cols-2">
                <div className="space-y-1">
                  <Label htmlFor="scan-lot">{t('inbound.lotCode')}</Label>
                  <Input
                    id="scan-lot"
                    autoComplete="off"
                    placeholder={t('inbound.lotCodePlaceholder')}
                    value={scanLot.lotCode}
                    onChange={(event) => setScanLot({ ...scanLot, lotCode: event.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="scan-expiry">{t('inbound.expiryDate')}</Label>
                  <Input
                    id="scan-expiry"
                    type="date"
                    value={scanLot.expiryDate}
                    onChange={(event) => setScanLot({ ...scanLot, expiryDate: event.target.value })}
                  />
                </div>
              </div>
              {/* Партия держится между сканами: коробки одной поставки обычно из одной. */}
              <p className="pb-1 text-xs text-muted-foreground">{t('inbound.lotKeptHint')}</p>
            </details>
            <div className="flex items-end gap-2">
              <div className="flex-1 space-y-1">
                <Label htmlFor="scan">{t('inbound.barcode')}</Label>
                {/* Неуправляемое поле: значение читаем из DOM при отправке —
                    быстрый скан не потеряет символы из-за отставания React-стейта. */}
                <Input
                  id="scan"
                  ref={scanner.ref}
                  autoFocus
                  autoComplete="off"
                  placeholder={t('inbound.scanBox')}
                  onChange={() => scanner.onInput()}
                />
              </div>
              <div className="w-20 space-y-1">
                <Label htmlFor="scan-qty">{t('inbound.qty')}</Label>
                <Input
                  id="scan-qty"
                  inputMode="numeric"
                  value={quantity}
                  onChange={(event) => setQuantity(event.target.value.replace(/[^\d]/g, ''))}
                />
              </div>
              {/* Кнопка НЕ смотрит на React-стейт: сканер вставляет значение без
                  события input, и по стейту она осталась бы серой навсегда. */}
              <Button type="submit" disabled={scan.isPending}>
                {t('inbound.ok')}
              </Button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
