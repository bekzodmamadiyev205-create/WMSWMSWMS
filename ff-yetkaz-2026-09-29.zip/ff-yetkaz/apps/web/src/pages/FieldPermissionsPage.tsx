import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ACL_ENTITIES,
  ACL_ENTITY_TITLES,
  ACL_FIELDS,
  ROLES,
  type AclEntity,
  type FieldPermissionDto,
  type FieldPermissionMatrixDto,
  type FieldPermissionUpdatePayload,
  type Role,
} from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { DataTable, type DataTableColumn } from '@/components/ui/data-table';
import { ConfirmDialog } from '@/components/ui/dialog';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Select } from '@/components/ui/select';
import { Tabs } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/toast';
import { Toolbar, ToolbarGroup, ToolbarSearch, ToolbarSpacer } from '@/components/ui/toolbar';

/**
 * Две ручки матрицы зовёт только этот экран, поэтому клиент лежит рядом с ним,
 * а не в общем `lib/`: отдельный модуль на два вызова читать всё равно никто не станет.
 */
const aclApi = {
  matrix: (): Promise<FieldPermissionMatrixDto> =>
    apiFetch<FieldPermissionMatrixDto>('/field-permissions'),

  update: (payload: FieldPermissionUpdatePayload): Promise<FieldPermissionMatrixDto> =>
    apiFetch<FieldPermissionMatrixDto>('/field-permissions', { method: 'PUT', body: payload }),
};

const QUERY_KEY = ['field-permissions'] as const;

/**
 * Умолчание таблицы прав на бэкенде — «видно и можно править, удалять нельзя».
 * Строка, равная ему, не хранится вовсе: матрица — список исключений. Отсюда и
 * поведение сохранения: ячейка, вернувшаяся к этим значениям, уходит на сервер
 * и там УДАЛЯЕТСЯ, а не записывается.
 */
const DEFAULT_RIGHTS: Rights = { view: true, edit: true, delete: false };

/** ADMIN в матрицу не попадает: сервер отвергает такие строки целиком. */
const EDITABLE_ROLES: Role[] = ROLES.filter((role) => role !== 'ADMIN');

const RIGHT_KEYS = ['view', 'edit', 'delete'] as const;
type RightKey = (typeof RIGHT_KEYS)[number];

interface Rights {
  view: boolean;
  edit: boolean;
  delete: boolean;
}

interface DraftCell {
  role: Role;
  entity: AclEntity;
  field: string;
  rights: Rights;
  /**
   * Значение ячейки на момент, когда пользователь взялся её править. По нему
   * видно, ЧТО именно он поменял, и по нему же перед записью проверяется, не
   * трогал ли эту ячейку кто-то ещё.
   */
  base: Rights;
}

interface SaveVars {
  mode: 'merge' | 'reset';
  /** Ячейки, изменённые в этой сессии. Только они накладываются на свежую матрицу. */
  cells: DraftCell[];
  successText: string;
  failText: string;
}

type SaveOutcome =
  | { kind: 'saved'; matrix: FieldPermissionMatrixDto }
  | { kind: 'conflict'; matrix: FieldPermissionMatrixDto; cells: DraftCell[] };

const RIGHT_GLYPH: Record<RightKey, string> = { view: '👁', edit: '✎', delete: '🗑' };

function cellKey(role: Role, entity: AclEntity, field: string): string {
  return `${role}|${entity}|${field}`;
}

function toRights(dto: FieldPermissionDto): Rights {
  return { view: dto.canView, edit: dto.canEdit, delete: dto.canDelete };
}

function sameRights(a: Rights, b: Rights): boolean {
  return a.view === b.view && a.edit === b.edit && a.delete === b.delete;
}

function isDefault(rights: Rights): boolean {
  return sameRights(rights, DEFAULT_RIGHTS);
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function permissionMap(matrix: FieldPermissionMatrixDto): Map<string, FieldPermissionDto> {
  const map = new Map<string, FieldPermissionDto>();
  for (const permission of matrix.permissions) {
    map.set(cellKey(permission.role, permission.entity, permission.field), permission);
  }
  return map;
}

function storedRights(stored: Map<string, FieldPermissionDto>, cell: DraftCell): Rights {
  const found = stored.get(cellKey(cell.role, cell.entity, cell.field));
  return found ? toRights(found) : DEFAULT_RIGHTS;
}

/**
 * Ячейки, которые за время работы со страницей увёл кто-то другой: сейчас на
 * сервере не то, что видел пользователь, когда брался их править.
 */
function conflictingCells(fresh: FieldPermissionMatrixDto, cells: DraftCell[]): DraftCell[] {
  const stored = permissionMap(fresh);
  return cells.filter((cell) => !sameRights(storedRights(stored, cell), cell.base));
}

/**
 * Тело PUT: АКТУАЛЬНАЯ матрица с сервера плюс правки пользователя поверх неё.
 * Отправлять снимок, снятый при открытии страницы, нельзя — ручка принимает
 * весь список целиком, и запрет, снятый кем-то другим полчаса назад, вернулся
 * бы из нашего снимка обратно, никак себя не обозначив.
 */
function mergePermissions(
  fresh: FieldPermissionMatrixDto,
  cells: DraftCell[],
): FieldPermissionDto[] {
  const result = permissionMap(fresh);
  for (const cell of cells) {
    result.set(cellKey(cell.role, cell.entity, cell.field), {
      role: cell.role,
      entity: cell.entity,
      field: cell.field,
      canView: cell.rights.view,
      canEdit: cell.rights.edit,
      canDelete: cell.rights.delete,
    });
  }

  const known = new Map<AclEntity, Set<string>>();
  for (const item of fresh.entities) known.set(item.entity, new Set(item.fields));

  // Строку на поле, которого больше нет в контракте (осталась от прошлой схемы),
  // сервер отвергает вместе со всем запросом. Такое правило и так мертво — фильтр
  // ответа спрашивает права по именам реальных ключей, — поэтому не отправляем
  // его вовсе: одна мусорная запись не должна блокировать сохранение матрицы.
  // Вычистить её можно «Сбросить всё»: полностью разрешающие строки сервер удаляет.
  return [...result.values()].filter((row) => known.get(row.entity)?.has(row.field) ?? false);
}

/** Полностью разрешающая строка = удаление на сервере, поэтому сброс — это отправка всех существующих ограничений в умолчание. */
function resetPermissions(fresh: FieldPermissionMatrixDto): FieldPermissionDto[] {
  return fresh.permissions.map<FieldPermissionDto>((dto) => ({
    ...dto,
    canView: true,
    canEdit: true,
    canDelete: false,
  }));
}

function isStatus(error: unknown, status: number): boolean {
  return error instanceof ApiError && error.status === status;
}

/* ─────────────────────────────── мелкие детали ──────────────────────────── */

function ShieldIcon(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3 4.5 6v5.5c0 4.6 3.2 8.4 7.5 9.5 4.3-1.1 7.5-4.9 7.5-9.5V6L12 3Z" />
      <path d="M9.5 12.2 11.3 14l3.4-3.6" />
    </svg>
  );
}

function LockIcon({ className }: { className?: string }): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={cn('h-3.5 w-3.5', className)}>
      <rect x="4" y="10" width="16" height="10" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </svg>
  );
}

function WarningIcon(): React.ReactElement {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className="h-4 w-4">
      <path d="M12 4 2.8 20h18.4L12 4Z" />
      <path d="M12 10v4" />
      <path d="M12 17h.01" />
    </svg>
  );
}

/**
 * Один флажок права. Это чек-бокс, а не переключатель: у ячейки три независимых
 * состояния, и роль `checkbox` — единственное, что скринридер прочитает как
 * «включено/выключено» без собственной подписи рядом с каждым значком.
 *
 * Тон противоположен привычному: разрешение — молчаливый контур, запрет —
 * красная заливка. Закрытых ячеек в матрице единицы, и искать глазами нужно
 * именно их, а не сплошную зелёную стену из «всё можно».
 */
function RightToggle({
  granted,
  disabled,
  label,
  glyph,
  onToggle,
}: {
  granted: boolean;
  disabled: boolean;
  label: string;
  glyph: string;
  onToggle: () => void;
}): React.ReactElement {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={granted}
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onToggle}
      className={cn(
        'inline-flex h-6 w-6 items-center justify-center rounded-md text-[11px] leading-none ring-1 ring-inset transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:ring-offset-background',
        granted
          ? 'text-muted-foreground ring-border hover:bg-accent hover:text-foreground'
          : 'bg-destructive/10 text-destructive ring-destructive/30 hover:bg-destructive/20',
        disabled && 'cursor-not-allowed opacity-40 hover:bg-transparent',
      )}
    >
      <span aria-hidden="true">{glyph}</span>
    </button>
  );
}

function ForbiddenCard({ title, body }: { title: string; body: string }): React.ReactElement {
  return (
    <Card className="border-warning/40 bg-warning/5">
      <CardContent className="flex items-start gap-3 p-5">
        <span className="mt-0.5 shrink-0 text-warning">
          <LockIcon className="h-5 w-5" />
        </span>
        <div className="space-y-1">
          <p className="text-sm font-medium text-foreground">{title}</p>
          <p className="text-sm leading-relaxed text-muted-foreground">{body}</p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ──────────────────────────────── страница ──────────────────────────────── */

export function FieldPermissionsPage(): React.ReactElement {
  const { t } = useI18n();
  const toast = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const [entity, setEntity] = React.useState<AclEntity>('order');
  const [search, setSearch] = React.useState('');
  const [restrictedOnly, setRestrictedOnly] = React.useState(false);
  const [draft, setDraft] = React.useState<Record<string, DraftCell>>({});
  const [resetOpen, setResetOpen] = React.useState(false);
  const [conflicts, setConflicts] = React.useState<DraftCell[]>([]);

  const matrix = useQuery({
    queryKey: QUERY_KEY,
    queryFn: aclApi.matrix,
    retry: (attempt, error) => !isStatus(error, 403) && attempt < 2,
  });

  const serverMap = React.useMemo(() => {
    const map = new Map<string, FieldPermissionDto>();
    for (const permission of matrix.data?.permissions ?? []) {
      map.set(cellKey(permission.role, permission.entity, permission.field), permission);
    }
    return map;
  }, [matrix.data]);

  const savedRights = React.useCallback(
    (role: Role, target: AclEntity, field: string): Rights => {
      const stored = serverMap.get(cellKey(role, target, field));
      return stored ? toRights(stored) : DEFAULT_RIGHTS;
    },
    [serverMap],
  );

  const rightsOf = React.useCallback(
    (role: Role, target: AclEntity, field: string): Rights =>
      draft[cellKey(role, target, field)]?.rights ?? savedRights(role, target, field),
    [draft, savedRights],
  );

  // В черновике лежат ТОЛЬКО реально изменённые ячейки: вернувшаяся к исходному
  // значению из него выбывает (см. `toggle`). Иначе она поехала бы на сервер
  // вместе с остальными и затёрла бы чужую правку — своим же прежним значением.
  const changed = React.useMemo(() => Object.values(draft), [draft]);

  // Пока матрица едет, вкладки и список полей берутся из общих контрактов:
  // иначе экран начинается с пустого набора сущностей и «прыгает» после ответа.
  const entities = React.useMemo(
    () =>
      matrix.data?.entities ??
      ACL_ENTITIES.map((value) => ({
        entity: value,
        title: ACL_ENTITY_TITLES[value],
        fields: [...ACL_FIELDS[value]],
      })),
    [matrix.data],
  );

  const fields = entities.find((item) => item.entity === entity)?.fields ?? [];

  /** Сколько ячеек сущности отличается от умолчания — с учётом несохранённой правки. */
  const restrictionsByEntity = React.useMemo(() => {
    const counts = new Map<AclEntity, number>();
    for (const item of entities) {
      let total = 0;
      for (const field of item.fields) {
        for (const role of EDITABLE_ROLES) {
          if (!isDefault(rightsOf(role, item.entity, field))) total += 1;
        }
      }
      counts.set(item.entity, total);
    }
    return counts;
  }, [entities, rightsOf]);

  const totalRestrictions = [...restrictionsByEntity.values()].reduce((sum, value) => sum + value, 0);

  const fieldLabel = React.useCallback(
    (target: AclEntity, field: string): string => {
      // Ключ может быть не заведён (сущности кроме заказов и остатков) —
      // тогда `t` возвращает сам ключ, и честнее показать имя поля из DTO.
      const key = `acl.field.${target}.${field}` as MessageKey;
      const label = t(key);
      return label === key ? field : label;
    },
    [t],
  );

  const entityLabel = React.useCallback(
    (item: { entity: AclEntity; title: string }): string => {
      const key = `acl.entity.${item.entity}` as MessageKey;
      const label = t(key);
      return label === key ? item.title : label;
    },
    [t],
  );

  const toggle = React.useCallback(
    (role: Role, field: string, right: RightKey): void => {
      const key = cellKey(role, entity, field);
      const current = rightsOf(role, entity, field);

      let next: Rights;
      if (right === 'view') {
        // Снятый просмотр гасит правку и удаление: разрешать запись в поле,
        // которого роль не получает в ответе, значит хранить право, которое
        // никогда не сработает, — и врать администратору галочкой.
        next = current.view ? { view: false, edit: false, delete: false } : { ...current, view: true };
      } else if (right === 'edit') {
        next = { ...current, edit: !current.edit };
      } else {
        next = { ...current, delete: !current.delete };
      }

      setDraft((prev) => {
        const base = prev[key]?.base ?? savedRights(role, entity, field);
        const draftNext = { ...prev };
        if (sameRights(next, base)) {
          delete draftNext[key];
          return draftNext;
        }
        draftNext[key] = { role, entity, field, rights: next, base };
        return draftNext;
      });
    },
    [entity, rightsOf, savedRights],
  );

  const cellTitle = React.useCallback(
    (cell: DraftCell): string => {
      const item = entities.find((candidate) => candidate.entity === cell.entity);
      const role = t(`users.role.${cell.role}` as MessageKey);
      const entityName = entityLabel(item ?? { entity: cell.entity, title: cell.entity });
      return `${role} · ${entityName} · ${fieldLabel(cell.entity, cell.field)}`;
    },
    [entities, entityLabel, fieldLabel, t],
  );

  /**
   * Ячейки, за которые взялись двое. Пользователь узнаёт об этом до записи и
   * решает сам: «Отмена» оставит чужую правку, повторное «Сохранить» — свою.
   * Черновик при этом переносится на новое значение сервера, иначе тот же
   * конфликт докладывался бы бесконечно.
   */
  const rebaseDraft = React.useCallback((fresh: FieldPermissionMatrixDto): void => {
    const stored = permissionMap(fresh);
    setDraft((prev) => {
      const next: Record<string, DraftCell> = {};
      for (const [key, cell] of Object.entries(prev)) {
        const base = storedRights(stored, cell);
        // Чужая правка совпала с нашей — менять больше нечего.
        if (sameRights(cell.rights, base)) continue;
        next[key] = { ...cell, base };
      }
      return next;
    });
  }, []);

  // Оптимистичного апдейта тут нет намеренно: черновик и так показан на экране,
  // а подменять им кэш до ответа значило бы стереть признак «не сохранено».
  const save = useMutation({
    mutationFn: async (vars: SaveVars): Promise<SaveOutcome> => {
      // Матрица перечитывается ПЕРЕД записью, а не берётся из кэша: между
      // открытием страницы и нажатием «Сохранить» проходят десятки минут, и
      // PUT со старым снимком воскрешает всё, что за это время сняли другие.
      const fresh = await aclApi.matrix();

      if (vars.mode === 'reset') {
        return { kind: 'saved', matrix: await aclApi.update({ permissions: resetPermissions(fresh) }) };
      }

      const collisions = conflictingCells(fresh, vars.cells);
      if (collisions.length > 0) return { kind: 'conflict', matrix: fresh, cells: collisions };

      return {
        kind: 'saved',
        matrix: await aclApi.update({ permissions: mergePermissions(fresh, vars.cells) }),
      };
    },
    onSuccess: (outcome, vars) => {
      queryClient.setQueryData<FieldPermissionMatrixDto>(QUERY_KEY, outcome.matrix);
      if (outcome.kind === 'conflict') {
        setConflicts(outcome.cells);
        rebaseDraft(outcome.matrix);
        toast.error(vars.failText, outcome.cells.map(cellTitle).join('; '));
        return;
      }
      setConflicts([]);
      setDraft({});
      toast.success(vars.successText);
    },
    onError: (error, vars) => toast.error(vars.failText, errorText(error)),
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: QUERY_KEY });
    },
  });

  const visibleFields = React.useMemo(() => {
    const needle = search.trim().toLowerCase();
    return fields.filter((field) => {
      if (restrictedOnly && EDITABLE_ROLES.every((role) => isDefault(rightsOf(role, entity, field)))) {
        return false;
      }
      if (!needle) return true;
      return field.toLowerCase().includes(needle) || fieldLabel(entity, field).toLowerCase().includes(needle);
    });
  }, [fields, search, restrictedOnly, entity, rightsOf, fieldLabel]);

  const columns: Array<DataTableColumn<string>> = [
    {
      key: 'field',
      header: t('acl.field'),
      width: '15rem',
      cell: (field) => (
        <div className="min-w-0">
          <p className="truncate text-sm font-medium text-foreground">{fieldLabel(entity, field)}</p>
          <p className="truncate font-mono text-[11px] text-muted-foreground">{field}</p>
        </div>
      ),
    },
    {
      key: 'ADMIN',
      align: 'center',
      width: '9rem',
      header: (
        <span className="inline-flex items-center gap-1" title={t('acl.adminTooltip')}>
          <LockIcon />
          {t('users.role.ADMIN')}
        </span>
      ),
      cell: () => (
        <span
          title={t('acl.adminTooltip')}
          className="inline-flex cursor-help items-center gap-1 rounded-md bg-muted px-2 py-1 text-[11px] text-muted-foreground ring-1 ring-inset ring-border"
        >
          <LockIcon />
          {t('acl.adminLocked')}
        </span>
      ),
    },
    ...EDITABLE_ROLES.map<DataTableColumn<string>>((role) => ({
      key: role,
      align: 'center',
      width: '9rem',
      header: t(`users.role.${role}` as MessageKey),
      cell: (field) => {
        const rights = rightsOf(role, entity, field);
        const roleName = t(`users.role.${role}` as MessageKey);
        const label = fieldLabel(entity, field);
        return (
          <div className="flex items-center justify-center gap-1">
            {RIGHT_KEYS.map((right) => (
              <RightToggle
                key={right}
                granted={rights[right]}
                // Право на невидимое поле недоступно и выключено: см. легенду.
                disabled={right !== 'view' && !rights.view}
                glyph={RIGHT_GLYPH[right]}
                label={t('acl.cellAria', {
                  role: roleName,
                  field: label,
                  right: t(`acl.right.${right}` as MessageKey),
                })}
                onToggle={() => toggle(role, field, right)}
              />
            ))}
          </div>
        );
      },
    })),
  ];

  const forbidden = isStatus(matrix.error, 403) || (user !== null && !user.roles.includes('ADMIN'));

  if (forbidden) {
    return (
      <PageContainer>
        <PageHeader icon={<ShieldIcon />} title={t('acl.title')} description={t('acl.subtitle')} />
        <ForbiddenCard title={t('acl.forbidden.title')} body={t('acl.forbidden.body')} />
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        icon={<ShieldIcon />}
        title={t('acl.title')}
        description={t('acl.restrictedCount', { count: totalRestrictions })}
        actions={
          <Button
            variant="outline"
            size="sm"
            disabled={serverMap.size === 0 || save.isPending}
            onClick={() => setResetOpen(true)}
          >
            {t('acl.reset')}
          </Button>
        }
      />

      <Card className="border-info/30 bg-info/5">
        <CardContent className="space-y-2 p-4">
          <p className="text-sm leading-relaxed text-foreground">{t('acl.hint.role')}</p>
          <p className="flex items-start gap-2 text-sm leading-relaxed text-muted-foreground">
            <span className="mt-0.5 shrink-0 text-warning">
              <WarningIcon />
            </span>
            {t('acl.hint.export')}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-1.5 p-4 text-xs leading-relaxed text-muted-foreground">
          <p className="text-sm font-medium text-foreground">{t('acl.legend.title')}</p>
          <p>
            <span aria-hidden="true">{RIGHT_GLYPH.view}</span> {t('acl.legend.view')}
          </p>
          <p>
            <span aria-hidden="true">{RIGHT_GLYPH.edit}</span> {t('acl.legend.edit')}
          </p>
          <p>
            <span aria-hidden="true">{RIGHT_GLYPH.delete}</span> {t('acl.legend.delete')}
          </p>
          <p className="pt-1 text-foreground">{t('acl.legend.viewImplies')}</p>
          <p>{t('acl.legend.default')}</p>
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center gap-2">
        <Tabs<AclEntity>
          value={entity}
          onValueChange={(next) => {
            setEntity(next);
            setSearch('');
          }}
          items={entities.map((item) => ({
            value: item.entity,
            label: entityLabel(item),
            badge: restrictionsByEntity.get(item.entity) || undefined,
          }))}
          className="max-w-full overflow-x-auto"
        />
      </div>

      {matrix.isError ? (
        <Card>
          <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
            <span className="text-sm text-destructive">{t('acl.loadError')}</span>
            <Button variant="outline" size="sm" onClick={() => void matrix.refetch()}>
              {t('ui.retry')}
            </Button>
          </CardContent>
        </Card>
      ) : null}

      {/* Тихо победить чужую правку в матрице прав нельзя: снятый кем-то запрет,
          вернувшийся сам собой, обнаружится в тот день, когда лишнее поле уже
          уехало в выгрузку. Поэтому спорные ячейки названы поимённо, а решение
          остаётся за администратором: «Отмена» — оставить чужое, «Сохранить»
          ещё раз — записать своё поверх. */}
      {conflicts.length > 0 ? (
        <Card className="border-warning/40 bg-warning/5">
          <CardContent className="flex items-start gap-3 p-4">
            <span className="mt-0.5 shrink-0 text-warning">
              <WarningIcon />
            </span>
            <div className="min-w-0 space-y-1">
              <p className="text-sm font-medium text-foreground">{t('acl.saveFailed')}</p>
              <ul className="space-y-0.5 text-sm text-muted-foreground">
                {conflicts.map((cell) => (
                  <li key={cellKey(cell.role, cell.entity, cell.field)}>{cellTitle(cell)}</li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      ) : null}

      <DataTable<string>
        columns={columns}
        rows={visibleFields}
        getRowKey={(field) => field}
        loading={matrix.isLoading}
        skeletonRows={10}
        maxHeight="60vh"
        emptyTitle={t('acl.noFields')}
        emptyDescription={t('acl.noFieldsHint')}
        emptyAction={
          search || restrictedOnly ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSearch('');
                setRestrictedOnly(false);
              }}
            >
              {t('ui.reset')}
            </Button>
          ) : undefined
        }
        toolbar={
          <Toolbar>
            <ToolbarGroup className="w-full sm:w-64">
              <ToolbarSearch value={search} onChange={setSearch} placeholder={t('acl.searchPlaceholder')} />
            </ToolbarGroup>
            <ToolbarGroup>
              <Select
                value={restrictedOnly ? 'restricted' : 'all'}
                onChange={(event) => setRestrictedOnly(event.target.value === 'restricted')}
                className="h-9 w-auto py-0 text-sm"
                aria-label={t('acl.restrictedOnly')}
              >
                <option value="all">{t('ui.all')}</option>
                <option value="restricted">{t('acl.restrictedOnly')}</option>
              </Select>
            </ToolbarGroup>
            <ToolbarSpacer />
            <Badge variant={totalRestrictions > 0 ? 'warning' : 'muted'} size="sm">
              {t('acl.restrictedCount', { count: totalRestrictions })}
            </Badge>
          </Toolbar>
        }
      />

      {/* Панель сохранения появляется только при расхождении с сервером: постоянно
          висящая кнопка «Сохранить» не отличает состояние «всё записано» от «есть
          несохранённое», и матрицу закрывают, не нажав её. */}
      {changed.length > 0 ? (
        <div className="premium-card sticky bottom-4 z-30 flex animate-slide-up flex-wrap items-center justify-between gap-3 px-4 py-3 shadow-lg">
          <p className="text-sm font-medium text-foreground">
            {t('acl.unsaved', { count: changed.length })}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setDraft({});
                setConflicts([]);
              }}
              disabled={save.isPending}
            >
              {t('ui.cancel')}
            </Button>
            <Button
              size="sm"
              className="gap-2"
              disabled={save.isPending}
              onClick={() =>
                save.mutate({
                  mode: 'merge',
                  cells: changed,
                  successText: t('acl.saved'),
                  failText: t('acl.saveFailed'),
                })
              }
            >
              {save.isPending ? (
                <span aria-hidden className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" />
              ) : null}
              {t('ui.save')}
            </Button>
          </div>
        </div>
      ) : null}

      <ConfirmDialog
        open={resetOpen}
        onClose={() => setResetOpen(false)}
        onConfirm={() => {
          setDraft({});
          setConflicts([]);
          // Список ограничений для снятия собирается из СВЕЖЕЙ матрицы (см.
          // mutationFn): по снимку страницы сброс прошёл бы мимо запретов,
          // заведённых после её открытия, и обещание «матрица станет полностью
          // разрешающей» оказалось бы ложным.
          save.mutate({
            mode: 'reset',
            cells: [],
            successText: t('acl.resetDone'),
            failText: t('acl.resetFailed'),
          });
          setResetOpen(false);
        }}
        busy={save.isPending}
        danger
        title={t('acl.reset.title')}
        description={t('acl.reset.body')}
        confirmLabel={t('acl.reset')}
      />
    </PageContainer>
  );
}
