import * as React from 'react';
import { keepPreviousData, useQueries, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  DEFAULT_PAGE_SIZE,
  MAX_PAGE_SIZE,
  RETURN_REASONS,
  RETURN_SORT_FIELDS,
  RETURN_STATUSES,
  type PageDto,
  type ReturnDto,
  type ReturnSortField,
  type ReturnStatus,
  type SortDirection,
} from '@ff/shared';
import { apiFetch } from '@/lib/api';
import { rangeToQuery, type DateRange } from '@/lib/date-range';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { mdmApi } from '@/lib/mdm';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { CHART_COLORS, DonutChart } from '@/components/ui/charts';
import { DataTable, type DataTableColumn, type DataTableSort } from '@/components/ui/data-table';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { DropdownMenu } from '@/components/ui/dropdown-menu';
import { KpiCard, KpiGrid } from '@/components/ui/kpi-card';
import { Badge } from '@/components/ui/badge';
import { PageContainer, PageHeader } from '@/components/ui/page-header';
import { Pagination } from '@/components/ui/pagination';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { Select } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Toolbar, ToolbarGroup, ToolbarSearch } from '@/components/ui/toolbar';
import { ExportButton } from '@/components/ExportButton';
import { Icon } from '@/components/icons';
import { ReturnCreateDialog } from '@/components/ReturnCreateDialog';
import { dateLocale, RETURN_STATUS_TONE, returnStatusKey } from '@/components/ReturnTimeline';

/** Цвет статуса на диаграмме. Порядок токенов подобран так, чтобы соседние
 *  по смыслу статусы («принят» и «на хранении») не сливались в один оттенок. */
const STATUS_COLOR: Record<ReturnStatus, string> = {
  ACCEPTED: CHART_COLORS[1],
  IN_STORAGE: CHART_COLORS[0],
  MOVING: CHART_COLORS[4],
  COMPLETED: CHART_COLORS[3],
  CANCELLED: CHART_COLORS[5],
};

type FilterKey =
  | 'dateFrom'
  | 'dateTo'
  | 'sellerId'
  | 'warehouseId'
  | 'status'
  | 'reason'
  | 'search'
  | 'page'
  | 'pageSize'
  | 'sort'
  | 'direction';

interface Filters {
  range: DateRange;
  sellerId: string;
  warehouseId: string;
  status: string;
  reason: string;
  search: string;
  page: number;
  pageSize: number;
  sort: ReturnSortField;
  direction: SortDirection;
}

const DEFAULT_SORT: ReturnSortField = 'createdAt';

function isSortField(value: string): value is ReturnSortField {
  return (RETURN_SORT_FIELDS as readonly string[]).includes(value);
}

function positiveInt(raw: string | null, fallback: number, max: number): number {
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 1) return fallback;
  return Math.min(Math.floor(parsed), max);
}

/**
 * Фильтры живут в адресной строке, а не в состоянии компонента: ссылка на
 * «возвраты этого селлера за август» должна открываться у соседа такой же, а
 * кнопка «назад» из карточки — возвращать к тому же отфильтрованному списку.
 */
function useUrlFilters(): {
  filters: Filters;
  patch: (next: Partial<Record<FilterKey, string | number | null>>) => void;
  reset: () => void;
} {
  const [params, setParams] = useSearchParams();

  const filters = React.useMemo<Filters>(() => {
    const sort = params.get('sort') ?? '';
    return {
      range: { from: params.get('dateFrom'), to: params.get('dateTo') },
      sellerId: params.get('sellerId') ?? '',
      warehouseId: params.get('warehouseId') ?? '',
      status: params.get('status') ?? '',
      reason: params.get('reason') ?? '',
      search: params.get('search') ?? '',
      page: positiveInt(params.get('page'), 1, 100_000),
      pageSize: positiveInt(params.get('pageSize'), DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE),
      sort: isSortField(sort) ? sort : DEFAULT_SORT,
      direction: params.get('direction') === 'asc' ? 'asc' : 'desc',
    };
  }, [params]);

  const patch = React.useCallback(
    (next: Partial<Record<FilterKey, string | number | null>>): void => {
      setParams(
        (previous) => {
          const draft = new URLSearchParams(previous);
          for (const [key, value] of Object.entries(next)) {
            if (value === null || value === '') draft.delete(key);
            else draft.set(key, String(value));
          }
          // Смена любого фильтра возвращает на первую страницу: иначе новый фильтр
          // применён, а человек смотрит на пустую седьмую страницу и решает, что
          // записей нет вовсе.
          if (next.page === undefined) draft.delete('page');
          return draft;
        },
        { replace: true },
      );
    },
    [setParams],
  );

  const reset = React.useCallback((): void => setParams(new URLSearchParams(), { replace: true }), [setParams]);

  return { filters, patch, reset };
}

function buildQuery(entries: Record<string, string | number | undefined>): string {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(entries)) {
    if (value === undefined || value === '') continue;
    query.set(key, String(value));
  }
  return query.toString();
}

export function ReturnsPage(): React.ReactElement {
  const { t, language } = useI18n();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { filters, patch, reset } = useUrlFilters();

  const [creating, setCreating] = React.useState(false);
  const [searchDraft, setSearchDraft] = React.useState(filters.search);

  // Внешняя правка адреса (кнопка «назад», сброс фильтров) обязана вернуться в поле.
  React.useEffect(() => setSearchDraft(filters.search), [filters.search]);

  // Поиск уходит в URL с задержкой: без неё каждая буква — это новый запрос к серверу
  // и новая запись в истории браузера.
  React.useEffect(() => {
    if (searchDraft === filters.search) return;
    const timer = window.setTimeout(() => patch({ search: searchDraft || null }), 350);
    return () => window.clearTimeout(timer);
  }, [searchDraft, filters.search, patch]);

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const warehouses = useQuery({ queryKey: ['mdm', 'warehouses'], queryFn: mdmApi.warehouses });

  /** Фильтры без страницы и сортировки — общая часть для списка, счётчиков и выгрузки. */
  const scope = React.useMemo(
    () => ({
      ...rangeToQuery(filters.range),
      sellerId: filters.sellerId || undefined,
      warehouseId: filters.warehouseId || undefined,
      reason: filters.reason || undefined,
      search: filters.search || undefined,
    }),
    [filters.range, filters.sellerId, filters.warehouseId, filters.reason, filters.search],
  );

  /**
   * Выгрузка обязана совпадать с экраном ПОСТРОЧНО, поэтому берёт фильтры
   * вместе со статусом. `scope` статус не содержит намеренно — он общий для
   * счётчиков по каждому статусу, и брать его для файла значит выгрузить
   * все возвраты вместо отфильтрованных, не сказав об этом ни слова.
   */
  const exportParams = React.useMemo(
    () => ({ ...scope, status: filters.status || undefined, sort: filters.sort, direction: filters.direction }),
    [scope, filters.status, filters.sort, filters.direction],
  );

  const listParams = React.useMemo(
    () => ({
      ...scope,
      status: filters.status || undefined,
      page: filters.page,
      pageSize: filters.pageSize,
      sort: filters.sort,
      direction: filters.direction,
    }),
    [scope, filters.status, filters.page, filters.pageSize, filters.sort, filters.direction],
  );

  const list = useQuery({
    queryKey: ['returns', 'list', listParams],
    queryFn: () => apiFetch<PageDto<ReturnDto>>(`/returns?${buildQuery(listParams)}`),
    // Страница не мигает пустой таблицей при листании: старые строки остаются
    // на месте, пока едет новая страница.
    placeholderData: keepPreviousData,
  });

  /**
   * Разбивка по статусам. Пять запросов вместо одного — сознательный размен:
   * отдельной ручки с итогами по статусам у возвратов в контракте нет, а
   * `pageSize: 1` означает пять COUNT'ов по тем же индексам и НОЛЬ переданных
   * строк. Альтернатива — считать по загруженной странице — врёт с первой же
   * сотни возвратов, потому что видит только 50 из них.
   */
  const counts = useQueries({
    queries: RETURN_STATUSES.map((status) => ({
      queryKey: ['returns', 'count', status, scope],
      queryFn: () =>
        apiFetch<PageDto<ReturnDto>>(`/returns?${buildQuery({ ...scope, status, page: 1, pageSize: 1 })}`),
      select: (page: PageDto<ReturnDto>): number => page.total,
      placeholderData: keepPreviousData,
    })),
  });

  const countOf = (status: ReturnStatus): number | undefined =>
    counts[RETURN_STATUSES.indexOf(status)]?.data;
  const countsLoading = counts.some((query) => query.isLoading);
  const countsError = counts.some((query) => query.isError);

  const retryCounts = (): void => {
    for (const query of counts) void query.refetch();
  };

  /**
   * Прочерк вместо цифры, когда запрос не ответил. Ноль от неизвестности на
   * плитке неотличим, а решения по ним разные: «завершённых сегодня нет» —
   * повод разбираться со складом, «мы не смогли сосчитать» — с сетью.
   */
  const tileValue = (value: number, unknown: boolean): React.ReactNode => (unknown ? '—' : value);

  const rows = list.data?.rows ?? [];
  const total = list.data?.total ?? 0;
  const inWork = (countOf('ACCEPTED') ?? 0) + (countOf('MOVING') ?? 0);
  const restockedOnPage = rows.reduce((sum, row) => sum + row.totalRestocked, 0);

  const slices = RETURN_STATUSES.map((status) => ({
    key: status,
    name: t(returnStatusKey(status)),
    value: countOf(status) ?? 0,
    color: STATUS_COLOR[status],
  })).filter((slice) => slice.value > 0);

  const donutTotal = slices.reduce((sum, slice) => sum + slice.value, 0);

  const sellerLabel = React.useCallback(
    (row: ReturnDto): string =>
      row.sellerName ?? sellers.data?.find((seller) => seller.id === row.sellerId)?.code ?? '—',
    [sellers.data],
  );

  const warehouseLabel = React.useCallback(
    (row: ReturnDto): string =>
      row.warehouseCode ?? warehouses.data?.find((w) => w.id === row.warehouseId)?.code ?? '—',
    [warehouses.data],
  );

  const columns: Array<DataTableColumn<ReturnDto>> = [
    {
      key: 'returnNo',
      header: t('returns.col.no'),
      sortable: true,
      width: '11rem',
      cell: (row) => (
        <Link
          to={`/returns/${row.id}`}
          className="rounded font-mono text-xs font-medium text-primary underline-offset-2 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {row.returnNo}
        </Link>
      ),
    },
    {
      key: 'createdAt',
      header: t('returns.col.date'),
      sortable: true,
      width: '9rem',
      cell: (row) => (
        <span className="whitespace-nowrap tabular-nums text-muted-foreground">
          {new Date(row.createdAt).toLocaleDateString(dateLocale(language))}
        </span>
      ),
    },
    {
      key: 'status',
      header: t('returns.col.status'),
      sortable: true,
      width: '10rem',
      cell: (row) => (
        <Badge variant={RETURN_STATUS_TONE[row.status]} dot>
          {t(returnStatusKey(row.status))}
        </Badge>
      ),
    },
    {
      key: 'seller',
      header: t('returns.col.seller'),
      hideable: true,
      cell: (row) => <span className="truncate">{sellerLabel(row)}</span>,
    },
    {
      key: 'warehouse',
      header: t('returns.col.warehouse'),
      hideable: true,
      width: '8rem',
      cell: (row) => <span className="text-muted-foreground">{warehouseLabel(row)}</span>,
    },
    {
      key: 'order',
      header: t('returns.col.order'),
      hideable: true,
      width: '11rem',
      cell: (row) =>
        row.orderId ? (
          <Link
            to={`/orders/${row.orderId}`}
            className="rounded font-mono text-xs text-primary underline-offset-2 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {row.orderCode ?? row.orderExternalId ?? row.orderId}
          </Link>
        ) : (
          <span className="text-muted-foreground">—</span>
        ),
    },
    {
      key: 'reason',
      header: t('returns.col.reason'),
      hideable: true,
      cell: (row) => (
        <span className="truncate text-muted-foreground">
          {t(`returns.reason.${row.reason}` as MessageKey)}
        </span>
      ),
    },
    {
      key: 'totalQuantity',
      header: t('returns.col.accepted'),
      sortable: true,
      align: 'right',
      width: '7rem',
      cell: (row) => row.totalQuantity,
    },
    {
      key: 'totalRestocked',
      header: t('returns.col.restocked'),
      align: 'right',
      width: '11rem',
      cell: (row) => {
        const share = row.totalQuantity > 0 ? row.totalRestocked / row.totalQuantity : 0;
        return (
          <div className="flex items-center justify-end gap-2">
            <span className="tabular-nums">{row.totalRestocked}</span>
            <span
              aria-hidden="true"
              className="h-1.5 w-14 shrink-0 overflow-hidden rounded-full bg-muted"
              title={`${Math.round(share * 100)}%`}
            >
              <span
                className={cn('block h-full rounded-full', share >= 1 ? 'bg-success' : 'bg-primary')}
                style={{ width: `${Math.round(share * 100)}%` }}
              />
            </span>
          </div>
        );
      },
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      width: '3rem',
      cell: (row) => (
        <DropdownMenu
          label={t('ui.more')}
          items={[
            { key: 'open', label: t('returns.open'), onSelect: () => navigate(`/returns/${row.id}`) },
            {
              key: 'order',
              label: t('returns.openOrder'),
              disabled: !row.orderId,
              onSelect: () => {
                if (row.orderId) navigate(`/orders/${row.orderId}`);
              },
            },
          ]}
        />
      ),
    },
  ];

  const sort: DataTableSort = { key: filters.sort, direction: filters.direction };
  const filtersActive =
    Boolean(filters.range.from || filters.range.to) ||
    Boolean(filters.sellerId || filters.warehouseId || filters.status || filters.reason || filters.search);

  return (
    <PageContainer>
      <PageHeader
        title={t('returns.title')}
        description={t('returns.subtitle')}
        icon={Icon.truck()}
        actions={
          <>
            <ExportButton path={`/returns/export?${buildQuery(exportParams)}`} />
            <Button onClick={() => setCreating(true)}>{t('returns.new')}</Button>
          </>
        }
      />

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_20rem]">
        <KpiGrid className="sm:grid-cols-2 lg:grid-cols-3">
          <KpiCard
            label={t('returns.kpi.total')}
            value={tileValue(total, list.isError)}
            loading={list.isLoading}
            icon={Icon.truck()}
          />
          <KpiCard
            label={t('returns.kpi.inWork')}
            value={tileValue(inWork, countsError)}
            hint={t('returns.kpi.inWorkHint')}
            tone="warning"
            loading={countsLoading}
            icon={Icon.alert()}
          />
          <KpiCard
            label={t('returns.kpi.inStorage')}
            value={tileValue(countOf('IN_STORAGE') ?? 0, countsError)}
            tone="info"
            loading={countsLoading}
            icon={Icon.stock()}
            onClick={() => patch({ status: 'IN_STORAGE' })}
          />
          <KpiCard
            label={t('returns.kpi.completed')}
            value={tileValue(countOf('COMPLETED') ?? 0, countsError)}
            tone="success"
            loading={countsLoading}
            icon={Icon.check()}
            onClick={() => patch({ status: 'COMPLETED' })}
          />
          <KpiCard
            label={t('returns.kpi.units')}
            value={tileValue(restockedOnPage, list.isError)}
            hint={t('returns.kpi.onPage')}
            loading={list.isLoading}
            icon={Icon.warehouse()}
          />
        </KpiGrid>

        <section className="premium-card p-4">
          <h2 className="text-sm font-medium text-card-foreground">{t('returns.kpi.byStatus')}</h2>
          <div className="mt-3">
            {countsLoading ? (
              <Skeleton className="h-[150px] w-full" />
            ) : countsError ? (
              // «Нет данных за период» здесь означало бы «возвратов не было». Это
              // утверждение, которого у нас нет: счётчики просто не ответили.
              <div className="flex flex-col items-center gap-2 py-6 text-center">
                <p className="text-xs text-destructive">{t('returns.loadError')}</p>
                <Button variant="outline" size="sm" onClick={retryCounts}>
                  {t('ui.retry')}
                </Button>
              </div>
            ) : donutTotal > 0 ? (
              <DonutChart
                slices={slices}
                size={150}
                centerLabel={t('ui.chart.total')}
                centerValue={String(donutTotal)}
              />
            ) : (
              <p className="py-6 text-center text-xs text-muted-foreground">{t('ui.chart.noData')}</p>
            )}
          </div>
        </section>
      </div>

      <div className="premium-card p-3">
        <Toolbar>
          <ToolbarGroup label={t('ui.date.range')}>
            <DateRangePicker
              value={filters.range}
              onChange={(range) => patch({ dateFrom: range.from, dateTo: range.to })}
              compact
            />
          </ToolbarGroup>

          <ToolbarGroup label={t('returns.filter.seller')} className="w-full sm:w-52">
            <SearchableSelect
              value={filters.sellerId}
              onChange={(value) => patch({ sellerId: value || null })}
              clearLabel={t('returns.filter.allSellers')}
              placeholder={t('returns.filter.allSellers')}
              searchPlaceholder={t('returns.filter.searchSeller')}
              className="h-9"
              options={(sellers.data ?? []).map((seller) => ({
                value: seller.id,
                triggerLabel: seller.code,
                label: `${seller.code} — ${seller.legalName}`,
                keywords: `${seller.code} ${seller.legalName}`,
              }))}
            />
          </ToolbarGroup>

          <ToolbarGroup label={t('returns.filter.warehouse')} className="w-full sm:w-44">
            <Select
              value={filters.warehouseId}
              className="h-9"
              onChange={(event) => patch({ warehouseId: event.target.value || null })}
            >
              <option value="">{t('returns.filter.allWarehouses')}</option>
              {(warehouses.data ?? []).map((warehouse) => (
                <option key={warehouse.id} value={warehouse.id}>
                  {warehouse.code}
                </option>
              ))}
            </Select>
          </ToolbarGroup>

          <ToolbarGroup label={t('returns.filter.status')} className="w-full sm:w-44">
            <Select
              value={filters.status}
              className="h-9"
              onChange={(event) => patch({ status: event.target.value || null })}
            >
              <option value="">{t('returns.filter.allStatuses')}</option>
              {RETURN_STATUSES.map((status) => (
                <option key={status} value={status}>
                  {t(returnStatusKey(status))}
                </option>
              ))}
            </Select>
          </ToolbarGroup>

          <ToolbarGroup label={t('returns.filter.reason')} className="w-full sm:w-52">
            <Select
              value={filters.reason}
              className="h-9"
              onChange={(event) => patch({ reason: event.target.value || null })}
            >
              <option value="">{t('returns.filter.allReasons')}</option>
              {RETURN_REASONS.map((reason) => (
                <option key={reason} value={reason}>
                  {t(`returns.reason.${reason}` as MessageKey)}
                </option>
              ))}
            </Select>
          </ToolbarGroup>

          <ToolbarGroup label={t('ui.search')} className="w-full sm:w-64">
            <ToolbarSearch
              value={searchDraft}
              onChange={setSearchDraft}
              placeholder={t('returns.searchPlaceholder')}
            />
          </ToolbarGroup>

          {filtersActive ? (
            <Button variant="ghost" size="sm" onClick={reset}>
              {t('ui.reset')}
            </Button>
          ) : null}
        </Toolbar>
      </div>

      {list.isError ? (
        <div className="premium-card flex flex-wrap items-center justify-between gap-3 p-4">
          <span className="text-sm text-destructive">{t('returns.loadError')}</span>
          <Button variant="outline" size="sm" onClick={() => void list.refetch()}>
            {t('ui.retry')}
          </Button>
        </div>
      ) : (
        <DataTable
          columns={columns}
          rows={rows}
          getRowKey={(row) => row.id}
          loading={list.isLoading}
          skeletonRows={Math.min(10, filters.pageSize)}
          columnVisibility
          sort={sort}
          onSortChange={(next) =>
            patch({
              sort: next && isSortField(next.key) ? next.key : DEFAULT_SORT,
              direction: next?.direction ?? 'desc',
            })
          }
          onRowClick={(row) => navigate(`/returns/${row.id}`)}
          emptyTitle={filtersActive ? t('returns.emptyFiltered') : t('returns.empty')}
          emptyDescription={filtersActive ? t('returns.emptyFilteredHint') : t('returns.emptyHint')}
          emptyAction={
            filtersActive ? (
              <Button variant="outline" size="sm" onClick={reset}>
                {t('ui.reset')}
              </Button>
            ) : (
              <Button size="sm" onClick={() => setCreating(true)}>
                {t('returns.new')}
              </Button>
            )
          }
          toolbar={
            <span className="text-xs text-muted-foreground">
              {t('returns.found', { n: total })}
            </span>
          }
          footer={
            <Pagination
              page={filters.page}
              pageSize={filters.pageSize}
              total={total}
              onPageChange={(page) => patch({ page })}
              onPageSizeChange={(pageSize) => patch({ pageSize })}
            />
          }
        />
      )}

      <ReturnCreateDialog
        open={creating}
        onClose={() => setCreating(false)}
        onCreated={(created) => {
          void queryClient.invalidateQueries({ queryKey: ['returns'] });
          navigate(`/returns/${created.id}`);
        }}
      />
    </PageContainer>
  );
}
