import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate, useParams } from 'react-router-dom';
import type { PickTaskLineDto } from '@ff/shared';
import { ApiError } from '@/lib/api';
import { useI18n, type MessageKey } from '@/lib/i18n';
import { apiErrorCode, pickingApi } from '@/lib/picking';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScanFlash, useScanFeedback } from '@/components/scan-feedback';
import { useScannerInput } from '@/lib/use-scanner';

function LineRow({
  line,
  onShort,
  onManual,
  busy,
}: {
  line: PickTaskLineDto;
  onShort: (line: PickTaskLineDto) => void;
  onManual: (line: PickTaskLineDto) => void;
  busy: boolean;
}): React.ReactElement {
  const { t } = useI18n();
  const done = line.status !== 'PENDING';
  return (
    <Card className={done ? 'opacity-60' : undefined}>
      <CardContent className="space-y-2 p-4">
        <div className="flex items-baseline justify-between gap-2">
          {/* Код ячейки — самое крупное: сборщик идёт по нему. */}
          <span className="text-lg font-semibold tabular-nums">{line.binCode}</span>
          <span className="text-sm text-muted-foreground">
            {t(`picking.lineStatus.${line.status}` as MessageKey)}
          </span>
        </div>
        <div className="text-sm">
          <span className="font-medium">{line.skuCode}</span>
          <span className="text-muted-foreground"> · {line.skuName}</span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <span className="tabular-nums">
            {line.qtyPicked} / {line.qtyRequested}
          </span>
          {!done && (
            <div className="flex gap-2">
              {/* Товар в руках, а штрихкода нет — это не недобор. */}
              <Button variant="outline" size="sm" disabled={busy} onClick={() => onManual(line)}>
                {t('picking.manualButton')}
              </Button>
              <Button variant="ghost" size="sm" disabled={busy} onClick={() => onShort(line)}>
                {t('picking.shortButton')}
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export function PickingTaskPage(): React.ReactElement {
  const { id = '' } = useParams();
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const [quantity, setQuantity] = React.useState('1');
  const [message, setMessage] = React.useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [shortLine, setShortLine] = React.useState<PickTaskLineDto | null>(null);
  const [shortReason, setShortReason] = React.useState('');
  const [manualLine, setManualLine] = React.useState<PickTaskLineDto | null>(null);
  const [manualQty, setManualQty] = React.useState('1');
  /** Последний скан упёрся в незнакомый штрихкод — предлагаем ручной отбор. */
  const [barcodeUnknown, setBarcodeUnknown] = React.useState(false);
  const feedback = useScanFeedback();
  const submitScan = React.useRef<(code: string) => void>(() => {});
  const scanner = useScannerInput((code) => submitScan.current(code));

  const task = useQuery({ queryKey: ['picking', 'task', id], queryFn: () => pickingApi.task(id) });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ['picking'] });

  const scan = useMutation({
    mutationFn: (code: string) => pickingApi.scan(id, code, Number(quantity) || 1),
    onSuccess: (result) => {
      setMessage({ kind: 'ok', text: t('picking.scan.creditedMessage', { n: result.remaining }) });
      feedback.signalOk(
        result.remaining > 0
          ? t('picking.scan.remaining', { n: result.remaining })
          : t('picking.scan.credited'),
      );
      setBarcodeUnknown(false);
      scanner.clear();
      setQuantity('1');
      scanner.ref.current?.focus();
      refresh();
    },
    onError: (error) => {
      const text = error instanceof ApiError ? error.message : t('common.error.network');
      setMessage({ kind: 'error', text });
      feedback.signalErr(text);
      setBarcodeUnknown(apiErrorCode(error) === 'BARCODE_UNKNOWN');
      // Код на ошибке НЕ стираем — он нужен глазам сборщика и для повторной
      // попытки. Вместо очистки выделяем его: следующий скан заменит выделенное,
      // а не допишется к прошлому.
      scanner.ref.current?.focus();
      scanner.ref.current?.select();
    },
  });
  // Скан отправляет актуальное значение поля — из кнопки, Enter или авто-очереди.
  submitScan.current = (code: string) => scan.mutate(code);

  /** Открыть ручное подтверждение: по умолчанию — весь остаток по строке. */
  const openManual = (line: PickTaskLineDto): void => {
    setShortLine(null);
    setManualLine(line);
    setManualQty(String(line.qtyRequested - line.qtyPicked));
  };

  const openShort = (line: PickTaskLineDto): void => {
    setManualLine(null);
    setShortLine(line);
  };

  const manual = useMutation({
    mutationFn: () => pickingApi.pick(id, manualLine!.id, Number(manualQty) || 0),
    onSuccess: (result) => {
      setMessage({ kind: 'ok', text: t('picking.manual.success', { n: result.remaining }) });
      feedback.signalOk(
        result.remaining > 0
          ? t('picking.scan.remaining', { n: result.remaining })
          : t('picking.scan.credited'),
      );
      setManualLine(null);
      setBarcodeUnknown(false);
      scanner.clear();
      scanner.ref.current?.focus();
      refresh();
    },
    onError: (error) => {
      const text = error instanceof ApiError ? error.message : t('common.error.network');
      setMessage({ kind: 'error', text });
      feedback.signalErr(text);
    },
  });

  const short = useMutation({
    mutationFn: () => pickingApi.short(id, shortLine!.id, shortReason.trim()),
    onSuccess: (result) => {
      setMessage({
        kind: 'ok',
        text: result.reallocated ? t('picking.short.reallocated') : t('picking.short.flagged'),
      });
      setShortLine(null);
      setShortReason('');
      refresh();
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : t('common.error.network'),
      }),
  });

  const complete = useMutation({
    mutationFn: () => pickingApi.complete(id),
    onSuccess: () => {
      refresh();
      navigate('/picking');
    },
    onError: (error) =>
      setMessage({
        kind: 'error',
        text: error instanceof ApiError ? error.message : t('common.error.network'),
      }),
  });

  if (task.isLoading) {
    return <div className="p-6 text-sm text-muted-foreground">{t('picking.loadingTask')}</div>;
  }
  if (task.isError || !task.data) {
    return (
      <div className="space-y-3 p-6">
        <p className="text-sm text-destructive">{t('picking.notFound')}</p>
        <Link to="/picking" className="text-sm underline">
          {t('picking.toList')}
        </Link>
      </div>
    );
  }

  const lines = task.data.lines;
  const pending = lines.filter((line) => line.status === 'PENDING');
  const canComplete = pending.length === 0 && task.data.status === 'IN_PROGRESS';

  return (
    <div className="mx-auto max-w-xl space-y-4 p-4 pb-28">
      <ScanFlash flash={feedback.flash} />
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('picking.taskTitle')}</h1>
        <Link to="/picking" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>
      <p className="text-sm text-muted-foreground">
        {t(`picking.taskStatus.${task.data.status}` as MessageKey)} ·{' '}
        {t('picking.pickedOfTotal', { done: lines.length - pending.length, total: lines.length })}
      </p>

      {message && (
        <p
          role="status"
          className={
            message.kind === 'ok'
              ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
              : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
          }
        >
          {message.text}
        </p>
      )}

      {/* Незнакомый штрихкод — не тупик: товар может быть заведён без кода,
          и строка задания сама подтверждает, что берём именно его. */}
      {barcodeUnknown && pending.length > 0 && (
        <Card>
          <CardContent className="flex flex-wrap items-center justify-between gap-2 p-4">
            <span className="text-sm">
              {pending.length === 1 ? t('picking.manual.offer') : t('picking.manual.offerMany')}
            </span>
            {pending.length === 1 && (
              <Button size="sm" onClick={() => openManual(pending[0])}>
                {t('picking.manualButton')}
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {lines.map((line) => (
          <LineRow
            key={line.id}
            line={line}
            busy={short.isPending || manual.isPending}
            onShort={openShort}
            onManual={openManual}
          />
        ))}
      </div>

      {manualLine && (
        <Card>
          <CardContent className="space-y-3 p-4">
            <div className="text-sm font-medium">
              {t('picking.manual.heading', {
                sku: manualLine.skuCode,
                bin: manualLine.binCode,
              })}
            </div>
            <p className="text-sm text-muted-foreground">{t('picking.manual.hint')}</p>
            <div className="w-28 space-y-2">
              <Label htmlFor="manual-qty">{t('picking.qty')}</Label>
              <Input
                id="manual-qty"
                inputMode="numeric"
                value={manualQty}
                onChange={(event) => setManualQty(event.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button
                disabled={
                  manual.isPending ||
                  !Number.isInteger(Number(manualQty)) ||
                  Number(manualQty) < 1 ||
                  Number(manualQty) > manualLine.qtyRequested - manualLine.qtyPicked
                }
                onClick={() => manual.mutate()}
              >
                {t('picking.confirm')}
              </Button>
              <Button variant="ghost" onClick={() => setManualLine(null)}>
                {t('common.cancel')}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {shortLine && (
        <Card>
          <CardContent className="space-y-3 p-4">
            <div className="text-sm font-medium">
              {t('picking.shortHeading', { sku: shortLine.skuCode, bin: shortLine.binCode })}
            </div>
            <div className="space-y-2">
              <Label htmlFor="reason">{t('picking.reason')}</Label>
              <Input
                id="reason"
                value={shortReason}
                onChange={(event) => setShortReason(event.target.value)}
                placeholder={t('picking.reasonPlaceholder')}
              />
            </div>
            <div className="flex gap-2">
              <Button
                disabled={shortReason.trim().length < 3 || short.isPending}
                onClick={() => short.mutate()}
              >
                {t('picking.confirm')}
              </Button>
              <Button variant="ghost" onClick={() => setShortLine(null)}>
                {t('common.cancel')}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {canComplete && (
        <Button className="w-full" disabled={complete.isPending} onClick={() => complete.mutate()}>
          {t('picking.complete')}
        </Button>
      )}

      {/* Панель скана прижата к низу: на телефоне до неё дотягивается большой палец. */}
      {pending.length > 0 && (
        <form
          className="fixed inset-x-0 bottom-0 border-t bg-background p-3"
          onSubmit={(event) => {
            event.preventDefault();
            scanner.submit();
          }}
        >
          <div className="mx-auto flex max-w-xl items-end gap-2">
            <div className="flex-1 space-y-1">
              <Label htmlFor="barcode">{t('picking.barcode')}</Label>
              {/* Неуправляемое поле: значение читаем из DOM при отправке —
                  быстрый скан не потеряет символы из-за отставания React-стейта. */}
              <Input
                id="barcode"
                ref={scanner.ref}
                autoFocus
                autoComplete="off"
                onChange={() => scanner.onInput()}
                placeholder={t('picking.scanPlaceholder')}
              />
            </div>
            <div className="w-20 space-y-1">
              <Label htmlFor="qty">{t('picking.qty')}</Label>
              <Input
                id="qty"
                inputMode="numeric"
                value={quantity}
                onChange={(event) => setQuantity(event.target.value)}
              />
            </div>
            {/* Гасим кнопку ТОЛЬКО по ходу запроса. Раньше она зависела от
                React-стейта поля, а значение читается из DOM: быстрый скан
                отправлялся, пока стейт отставал, и кнопка оставалась серой —
                ручной ввод после такого скана было нечем подтвердить. Пустой
                ввод отсекает сам scanner.submit(). */}
            <Button type="submit" disabled={scan.isPending}>
              {t('picking.ok')}
            </Button>
          </div>
        </form>
      )}
    </div>
  );
}
