import * as React from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import type { SellerDto } from '@ff/shared';
import { ApiError } from '@/lib/api';
import { mdmApi } from '@/lib/mdm';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

type Msg = { kind: 'ok' | 'error'; text: string } | null;

function Message({ message }: { message: Msg }) {
  if (!message) return null;
  return (
    <p
      role="status"
      className={
        message.kind === 'ok'
          ? 'rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm'
          : 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive'
      }
    >
      {message.text}
    </p>
  );
}

const emptyForm = { code: '', legalName: '', taxId: '', contactEmail: '', contactPhone: '', address: '' };

/** Управление селлерами (клиентами 3PL): создать, изменить, отключить, удалить. Только ADMIN. */
export function SellersPage(): React.ReactElement {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [message, setMessage] = React.useState<Msg>(null);
  const [creating, setCreating] = React.useState(false);
  const [form, setForm] = React.useState(emptyForm);

  const sellers = useQuery({ queryKey: ['mdm', 'sellers'], queryFn: mdmApi.sellers });
  const fail = (error: unknown) =>
    setMessage({ kind: 'error', text: error instanceof ApiError ? error.message : (error as Error).message });
  const refresh = () => queryClient.invalidateQueries({ queryKey: ['mdm', 'sellers'] });

  const create = useMutation({
    mutationFn: () => {
      if (form.code.trim().length < 2 || form.legalName.trim().length < 2) {
        throw new Error(t('sellersPage.validationMin'));
      }
      return mdmApi.createSeller({
        code: form.code.trim(),
        legalName: form.legalName.trim(),
        taxId: form.taxId.trim() || undefined,
        contactEmail: form.contactEmail.trim() || undefined,
        contactPhone: form.contactPhone.trim() || undefined,
        address: form.address.trim() || undefined,
      });
    },
    onSuccess: () => {
      setMessage({ kind: 'ok', text: t('sellersPage.created') });
      setForm(emptyForm);
      setCreating(false);
      refresh();
    },
    onError: fail,
  });

  const list = sellers.data ?? [];

  return (
    <div className="mx-auto max-w-3xl space-y-4 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{t('sellersPage.title')}</h1>
        <Link to="/" className="text-sm text-muted-foreground underline">
          {t('common.back')}
        </Link>
      </div>

      <Message message={message} />

      {!creating && <Button onClick={() => setCreating(true)}>{t('sellersPage.new')}</Button>}

      {creating && (
        <Card>
          <CardContent className="space-y-3 p-4">
            <div className="text-sm font-medium">{t('sellersPage.new')}</div>
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1">
                <Label htmlFor="s-code">{t('sellersPage.code')}</Label>
                <Input
                  id="s-code"
                  value={form.code}
                  placeholder="SELLER1"
                  onChange={(event) => setForm({ ...form, code: event.target.value })}
                />
              </div>
              <div className="space-y-1 sm:col-span-2">
                <Label htmlFor="s-name">{t('sellersPage.legalName')}</Label>
                <Input
                  id="s-name"
                  value={form.legalName}
                  onChange={(event) => setForm({ ...form, legalName: event.target.value })}
                />
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1">
                <Label htmlFor="s-tax">{t('sellersPage.taxId')}</Label>
                <Input
                  id="s-tax"
                  value={form.taxId}
                  onChange={(event) => setForm({ ...form, taxId: event.target.value })}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="s-email">Email</Label>
                <Input
                  id="s-email"
                  type="email"
                  value={form.contactEmail}
                  onChange={(event) => setForm({ ...form, contactEmail: event.target.value })}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="s-phone">{t('sellersPage.phone')}</Label>
                <Input
                  id="s-phone"
                  value={form.contactPhone}
                  placeholder="+998901112233"
                  onChange={(event) => setForm({ ...form, contactPhone: event.target.value })}
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="s-addr">{t('sellersPage.address')}</Label>
              <Input
                id="s-addr"
                value={form.address}
                onChange={(event) => setForm({ ...form, address: event.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button
                disabled={create.isPending || form.code.trim().length < 2 || form.legalName.trim().length < 2}
                onClick={() => create.mutate()}
              >
                {t('common.create')}
              </Button>
              <Button
                variant="ghost"
                onClick={() => {
                  setCreating(false);
                  setForm(emptyForm);
                }}
              >
                {t('common.cancel')}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {sellers.isLoading && <p className="text-sm text-muted-foreground">{t('common.loading')}</p>}
      {sellers.isError && (
        <Card>
          <CardContent className="flex items-center justify-between gap-3 p-4">
            <span className="text-sm text-destructive">{t('sellersPage.loadError')}</span>
            <Button variant="outline" size="sm" onClick={() => sellers.refetch()}>
              {t('common.retry')}
            </Button>
          </CardContent>
        </Card>
      )}
      {!sellers.isLoading && list.length === 0 && (
        <p className="text-sm text-muted-foreground">{t('sellersPage.empty')}</p>
      )}

      <div className="space-y-2">
        {list.map((seller) => (
          <SellerCard
            key={seller.id}
            seller={seller}
            onDone={(text) => {
              setMessage({ kind: 'ok', text });
              refresh();
            }}
            onError={fail}
          />
        ))}
      </div>
    </div>
  );
}

function SellerCard({
  seller,
  onDone,
  onError,
}: {
  seller: SellerDto;
  onDone: (text: string) => void;
  onError: (error: unknown) => void;
}): React.ReactElement {
  const { t } = useI18n();
  const [editing, setEditing] = React.useState(false);
  const [confirmDelete, setConfirmDelete] = React.useState(false);
  const [draft, setDraft] = React.useState({
    legalName: seller.legalName,
    taxId: seller.taxId ?? '',
    contactEmail: seller.contactEmail ?? '',
    contactPhone: seller.contactPhone ?? '',
    address: seller.address ?? '',
  });

  const save = useMutation({
    mutationFn: () => {
      // Пустой email не отправляем: бэкенд валидирует @IsEmail и отбил бы «».
      const email = draft.contactEmail.trim();
      return mdmApi.updateSeller(seller.id, {
        legalName: draft.legalName.trim(),
        taxId: draft.taxId.trim(),
        contactPhone: draft.contactPhone.trim(),
        address: draft.address.trim(),
        ...(email ? { contactEmail: email } : {}),
      });
    },
    onSuccess: () => {
      setEditing(false);
      onDone(t('sellersPage.saved'));
    },
    onError,
  });

  const toggle = useMutation({
    mutationFn: () => mdmApi.updateSeller(seller.id, { isActive: !seller.isActive }),
    onSuccess: () => onDone(t('sellersPage.saved')),
    onError,
  });

  const remove = useMutation({
    mutationFn: () => mdmApi.deleteSeller(seller.id),
    onSuccess: () => {
      setConfirmDelete(false);
      onDone(t('sellersPage.deleted'));
    },
    onError,
  });

  const contacts = [seller.contactPhone, seller.contactEmail, seller.taxId ? t('sellersPage.taxPrefix', { value: seller.taxId }) : '']
    .filter(Boolean)
    .join(' · ');

  return (
    <Card className={seller.isActive ? undefined : 'opacity-60'}>
      <CardContent className="space-y-2 p-4">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <div className="min-w-0">
            <span className="font-medium">{seller.legalName}</span>
            <span className="ml-2 rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{seller.code}</span>
          </div>
          <span className={seller.isActive ? 'text-sm text-muted-foreground' : 'text-sm text-destructive'}>
            {seller.isActive ? t('sellersPage.active') : t('sellersPage.disabled')}
          </span>
        </div>

        {!editing && contacts && <div className="text-sm text-muted-foreground">{contacts}</div>}
        {!editing && seller.address && <div className="text-sm text-muted-foreground">{seller.address}</div>}

        {editing ? (
          <div className="space-y-2 border-t pt-3">
            <div className="grid gap-2 sm:grid-cols-2">
              <div className="space-y-1">
                <Label htmlFor={`e-name-${seller.id}`}>{t('sellersPage.legalName')}</Label>
                <Input
                  id={`e-name-${seller.id}`}
                  value={draft.legalName}
                  onChange={(event) => setDraft({ ...draft, legalName: event.target.value })}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor={`e-tax-${seller.id}`}>{t('sellersPage.taxId')}</Label>
                <Input
                  id={`e-tax-${seller.id}`}
                  value={draft.taxId}
                  onChange={(event) => setDraft({ ...draft, taxId: event.target.value })}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor={`e-email-${seller.id}`}>Email</Label>
                <Input
                  id={`e-email-${seller.id}`}
                  type="email"
                  value={draft.contactEmail}
                  onChange={(event) => setDraft({ ...draft, contactEmail: event.target.value })}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor={`e-phone-${seller.id}`}>{t('sellersPage.phone')}</Label>
                <Input
                  id={`e-phone-${seller.id}`}
                  value={draft.contactPhone}
                  onChange={(event) => setDraft({ ...draft, contactPhone: event.target.value })}
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor={`e-addr-${seller.id}`}>{t('sellersPage.address')}</Label>
              <Input
                id={`e-addr-${seller.id}`}
                value={draft.address}
                onChange={(event) => setDraft({ ...draft, address: event.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                disabled={save.isPending || draft.legalName.trim().length < 2}
                onClick={() => save.mutate()}
              >
                {t('common.save')}
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setEditing(false);
                  setDraft({
                    legalName: seller.legalName,
                    taxId: seller.taxId ?? '',
                    contactEmail: seller.contactEmail ?? '',
                    contactPhone: seller.contactPhone ?? '',
                    address: seller.address ?? '',
                  });
                }}
              >
                {t('common.cancel')}
              </Button>
            </div>
          </div>
        ) : confirmDelete ? (
          <div className="flex flex-wrap items-center gap-2 border-t pt-3">
            <span className="text-sm">
              {t('sellersPage.confirmDelete', { code: seller.code })}
            </span>
            <Button
              size="sm"
              variant="outline"
              className="border-destructive/40 text-destructive hover:bg-destructive/10"
              disabled={remove.isPending}
              onClick={() => remove.mutate()}
            >
              {t('sellersPage.delete')}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(false)}>
              {t('common.cancel')}
            </Button>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => setEditing(true)}>
              {t('sellersPage.edit')}
            </Button>
            <Button size="sm" variant="ghost" disabled={toggle.isPending} onClick={() => toggle.mutate()}>
              {seller.isActive ? t('sellersPage.disable') : t('sellersPage.enable')}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-destructive hover:bg-destructive/10"
              onClick={() => setConfirmDelete(true)}
            >
              {t('sellersPage.delete')}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
