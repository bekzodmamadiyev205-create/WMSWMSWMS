export const API_BASE = (import.meta.env.VITE_API_BASE ?? 'http://localhost:3001').replace(
  /\/+$/,
  '',
);
const TOKEN_KEY = 'ff.accessToken';

export const tokenStorage = {
  get: (): string | null => localStorage.getItem(TOKEN_KEY),
  set: (token: string): void => localStorage.setItem(TOKEN_KEY, token),
  clear: (): void => localStorage.removeItem(TOKEN_KEY),
};

/** Конверт ошибки, который отдаёт AllExceptionsFilter на бэке. */
export interface ApiErrorBody {
  error: string;
  message: string;
  details?: unknown;
  correlationId: string | null;
}

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly body: ApiErrorBody | null,
  ) {
    super(body?.message ?? `Ошибка запроса (${status}).`);
    this.name = 'ApiError';
  }
}

export interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: unknown;
  /** false — не подставлять токен (логин, health). */
  auth?: boolean;
  idempotencyKey?: string;
  signal?: AbortSignal;
}

export async function apiFetch<T>(path: string, options: ApiOptions = {}): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };

  if (options.auth !== false) {
    const token = tokenStorage.get();
    if (token) headers.Authorization = `Bearer ${token}`;
  }
  if (options.idempotencyKey) headers['Idempotency-Key'] = options.idempotencyKey;

  const response = await fetch(`${API_BASE}/api/v1${path}`, {
    method: options.method ?? 'GET',
    headers,
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
    signal: options.signal,
  });

  if (!response.ok) {
    let body: ApiErrorBody | null = null;
    try {
      body = (await response.json()) as ApiErrorBody;
    } catch {
      body = null;
    }

    // Протухший или отозванный токен — чистим и уводим на логин,
    // иначе интерфейс останется в подвешенном состоянии.
    if (response.status === 401 && options.auth !== false) {
      tokenStorage.clear();
      if (!window.location.pathname.startsWith('/login')) {
        window.location.assign('/login');
      }
    }
    throw new ApiError(response.status, body);
  }

  if (response.status === 204) return undefined as T;
  // Пустое тело при 200 — тоже «нет данных». Без этой проверки response.json()
  // бросает SyntaxError, и запрос навсегда остаётся в состоянии ошибки.
  const text = await response.text();
  return (text ? JSON.parse(text) : undefined) as T;
}
