import type {
  OrderDto,
  OrderImportOrderDto,
  OrderImportResultDto,
  OrderIntakeResultDto,
  OrderListQuery,
  OrderListTotalsDto,
  OrderStatus,
  OrderTrackDto,
  PageDto,
  UpdateOrderPayload,
} from '@ff/shared';
import { MAX_PAGE_SIZE } from '@ff/shared';
import { apiFetch } from '@/lib/api';
import {
  buildQuery,
  queryParams,
  queryParamsForExport,
  queryParamsWithoutPaging,
} from '@/lib/query-string';

export interface CreateOrderInput {
  sellerId: string;
  channel: string;
  externalId: string;
  recipientName: string;
  recipientPhone: string;
  address: string;
  region?: string;
  codAmount?: string;
  currency?: string;
  weightKg?: string;
  lines: Array<{ skuId: string; quantity: number }>;
}

export interface ImportOrdersInput {
  sellerId: string;
  channel: string;
  orders: OrderImportOrderDto[];
}

/** Варианты бейджа из `components/ui/badge.tsx` — статус красится только ими. */
export type BadgeTone =
  | 'default'
  | 'secondary'
  | 'success'
  | 'warning'
  | 'info'
  | 'destructive'
  | 'muted';

const ORDERS_PATH = '/orders';

export const ordersApi = {
  /**
   * Список заказов. Отдаёт СТРАНИЦУ, а не массив: без `total` невозможно ни
   * листать, ни честно написать «показано 50 из 4183». Фильтрация и сортировка
   * серверные — клиентский фильтр поверх первой страницы врёт ровно с того
   * момента, когда заказов стало больше страницы, и заметить это нельзя.
   */
  list: (query: OrderListQuery = {}): Promise<PageDto<OrderDto>> =>
    apiFetch<PageDto<OrderDto>>(`${ORDERS_PATH}${buildQuery(queryParams(query))}`),

  /** То же самое; имя оставлено для экранов, которым важно, что ответ — страница. */
  listPage: (query: OrderListQuery = {}): Promise<PageDto<OrderDto>> =>
    apiFetch<PageDto<OrderDto>>(`${ORDERS_PATH}${buildQuery(queryParams(query))}`),

  /**
   * Легаси-обёртка под старую форму ответа (голый массив).
   *
   * Оставлена только ради экранов, которые ещё не переведены на страницы, и
   * честно ограничена одной страницей максимального размера: молча склеивать
   * все страницы значило бы делать неизвестное заранее число запросов и снова
   * тащить весь склад в браузер.
   */
  listAll: async (query: OrderListQuery = {}): Promise<OrderDto[]> => {
    const page = await apiFetch<PageDto<OrderDto>>(
      `${ORDERS_PATH}${buildQuery(queryParams({ ...query, pageSize: query.pageSize ?? MAX_PAGE_SIZE }))}`,
    );
    return page.rows;
  },

  /**
   * Итоги по ТЕКУЩЕМУ фильтру — считает SQL. Постраничные параметры сюда не
   * попадают: сумма по видимой странице это не итог, а совпадение.
   */
  totals: (
    query: Omit<OrderListQuery, 'page' | 'pageSize' | 'sort' | 'direction'> = {},
  ): Promise<OrderListTotalsDto> =>
    apiFetch<OrderListTotalsDto>(
      `${ORDERS_PATH}/totals${buildQuery(queryParamsWithoutPaging(query))}`,
    ),

  get: (id: string): Promise<OrderDto> => apiFetch<OrderDto>(`${ORDERS_PATH}/${id}`),

  /** Трек статусов заказа: кто, когда и откуда куда перевёл. */
  track: (id: string): Promise<OrderTrackDto> =>
    apiFetch<OrderTrackDto>(`${ORDERS_PATH}/${id}/track`),

  /** Найти заказ по коду: наш FF-код, номер клиента или номер отправления. */
  byCode: (code: string): Promise<OrderDto> =>
    apiFetch<OrderDto>(`${ORDERS_PATH}/by-code${buildQuery({ code })}`),

  create: (input: CreateOrderInput): Promise<OrderIntakeResultDto> =>
    apiFetch<OrderIntakeResultDto>(ORDERS_PATH, { method: 'POST', body: input }),

  import: (input: ImportOrdersInput): Promise<OrderImportResultDto> =>
    apiFetch<OrderImportResultDto>(`${ORDERS_PATH}/import`, { method: 'POST', body: input }),

  /** Повторить резерв после прихода товара. */
  reserve: (id: string): Promise<OrderIntakeResultDto> =>
    apiFetch<OrderIntakeResultDto>(`${ORDERS_PATH}/${id}/reserve`, { method: 'POST', body: {} }),

  /** «Расходный»: коробка физически выдана со склада. */
  dispatch: (id: string): Promise<OrderDto> =>
    apiFetch<OrderDto>(`${ORDERS_PATH}/${id}/dispatch`, { method: 'POST', body: {} }),

  update: (id: string, payload: UpdateOrderPayload): Promise<OrderDto> =>
    apiFetch<OrderDto>(`${ORDERS_PATH}/${id}`, { method: 'PATCH', body: payload }),

  cancel: (id: string, reason: string): Promise<OrderDto> =>
    apiFetch<OrderDto>(`${ORDERS_PATH}/${id}/cancel`, { method: 'POST', body: { reason } }),

  /**
   * Путь выгрузки, а не запрос: файл забирает `downloadFile` — он умеет читать
   * поток байтами и разбирать имя из Content-Disposition, чего `apiFetch` не
   * может по устройству (он парсит тело JSON'ом).
   */
  exportPath: (query: OrderListQuery = {}): string =>
    `${ORDERS_PATH}/export${buildQuery(queryParamsForExport(query))}`,
};

/** Человеческие названия статусов заказа — одни и те же во всех экранах. */
export const ORDER_STATUS_TITLE: Record<OrderStatus, string> = {
  NEW: 'новый',
  VALIDATED: 'проверен',
  RESERVED: 'товар зарезервирован',
  PICKING: 'идёт сборка',
  PICKED: 'собран',
  PACKING: 'идёт упаковка',
  PACKED: 'упакован',
  READY_TO_SHIP: 'готов к отгрузке',
  DISPATCHED: 'выдан со склада',
  SHIPPED: 'передан курьеру',
  DELIVERED: 'доставлен',
  RETURNED: 'возвращён',
  CANCELLED: 'отменён',
};

/**
 * Цвет статуса. Смысл, а не палитра: `warning` — «работа идёт прямо сейчас»,
 * `default` — «этап закрыт, ждём следующего», `info` — «заказ в пути»,
 * `success`/`destructive` — терминальные исходы. Таблица одна на все экраны:
 * иначе один и тот же статус в списке и в карточке будет разного цвета.
 */
export const ORDER_STAGE_TONE: Record<OrderStatus, BadgeTone> = {
  NEW: 'info',
  VALIDATED: 'secondary',
  RESERVED: 'secondary',
  PICKING: 'warning',
  PACKING: 'warning',
  PICKED: 'default',
  PACKED: 'default',
  READY_TO_SHIP: 'default',
  DISPATCHED: 'info',
  SHIPPED: 'info',
  DELIVERED: 'success',
  RETURNED: 'warning',
  CANCELLED: 'destructive',
};

/**
 * Счастливый путь заказа по порядку — по нему таймлайн рисует дорожку.
 * `RETURNED`/`CANCELLED` сюда не входят намеренно: это съезды с маршрута, а не
 * его продолжение, и в линейной шкале они выглядели бы «следующим шагом после
 * доставки».
 */
export const ORDER_PIPELINE: OrderStatus[] = [
  'NEW',
  'VALIDATED',
  'RESERVED',
  'PICKING',
  'PICKED',
  'PACKING',
  'PACKED',
  'READY_TO_SHIP',
  'DISPATCHED',
  'SHIPPED',
  'DELIVERED',
];
