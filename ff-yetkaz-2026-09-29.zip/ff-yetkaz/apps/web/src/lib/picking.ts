import type { PickScanResultDto, PickTaskDto, ShortPickResultDto } from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';

/**
 * Машинный код ошибки из конверта бэка. Разбирать текст сообщения нельзя: он
 * приходит по-русски и меняется, а поведение экрана от него зависит.
 */
export function apiErrorCode(error: unknown): string | null {
  if (!(error instanceof ApiError)) return null;
  const body = error.body as { code?: unknown } | null;
  return typeof body?.code === 'string' ? body.code : null;
}

export const pickingApi = {
  myTasks: () => apiFetch<PickTaskDto[]>('/picking/tasks?mine=true'),
  openTasks: () => apiFetch<PickTaskDto[]>('/picking/tasks?status=NEW'),
  task: (id: string) => apiFetch<PickTaskDto>(`/picking/tasks/${id}`),

  /** Задание из одного или нескольких заказов одного склада (batch). */
  create: (orderIds: string[]) =>
    apiFetch<PickTaskDto>('/picking/tasks', { method: 'POST', body: { orderIds } }),

  assign: (id: string) => apiFetch<PickTaskDto>(`/picking/tasks/${id}/assign`, { method: 'POST', body: {} }),

  scan: (id: string, barcode: string, quantity: number) =>
    apiFetch<PickScanResultDto>(`/picking/tasks/${id}/scan`, {
      method: 'POST',
      body: { barcode, quantity },
    }),

  /** Отбор без скана: товар без штрихкода подтверждается по строке задания. */
  pick: (id: string, lineId: string, quantity: number) =>
    apiFetch<PickScanResultDto>(`/picking/tasks/${id}/lines/${lineId}/pick`, {
      method: 'POST',
      body: { quantity },
    }),

  short: (id: string, lineId: string, reason: string) =>
    apiFetch<ShortPickResultDto>(`/picking/tasks/${id}/lines/${lineId}/short`, {
      method: 'POST',
      body: { reason },
    }),

  complete: (id: string) =>
    apiFetch<PickTaskDto>(`/picking/tasks/${id}/complete`, { method: 'POST', body: {} }),
};
