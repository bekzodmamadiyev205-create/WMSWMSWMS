import type { Role, UserSummaryDto } from '@ff/shared';
import { apiFetch } from '@/lib/api';

export interface CreateUserInput {
  email: string;
  fullName: string;
  password: string;
  roles: Role[];
  sellerId?: string;
  departmentId?: string;
}

export const usersApi = {
  list: () => apiFetch<UserSummaryDto[]>('/users'),

  create: (input: CreateUserInput) =>
    apiFetch<UserSummaryDto>('/users', { method: 'POST', body: input }),

  update: (
    id: string,
    input: { fullName?: string; isActive?: boolean; roles?: Role[]; departmentId?: string | null },
  ) => apiFetch<UserSummaryDto>(`/users/${id}`, { method: 'PATCH', body: input }),

  setPassword: (id: string, password: string) =>
    apiFetch<void>(`/users/${id}/password`, { method: 'POST', body: { password } }),
};
