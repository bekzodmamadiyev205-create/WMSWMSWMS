import type { DepartmentDto } from '@ff/shared';
import { apiFetch } from '@/lib/api';

export interface CreateDepartmentInput {
  code: string;
  name: string;
  description?: string;
}

export interface UpdateDepartmentInput {
  name?: string;
  description?: string;
  isActive?: boolean;
}

export const departmentsApi = {
  list: () => apiFetch<DepartmentDto[]>('/departments'),

  create: (input: CreateDepartmentInput) =>
    apiFetch<DepartmentDto>('/departments', { method: 'POST', body: input }),

  update: (id: string, input: UpdateDepartmentInput) =>
    apiFetch<DepartmentDto>(`/departments/${id}`, { method: 'PATCH', body: input }),
};
