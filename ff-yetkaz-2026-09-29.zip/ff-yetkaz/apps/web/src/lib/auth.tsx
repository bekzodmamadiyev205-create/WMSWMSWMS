import * as React from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import type { AuthUser, LoginResponse } from '@ff/shared';
import { apiFetch, tokenStorage } from '@/lib/api';

interface AuthContextValue {
  user: AuthUser | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = React.createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }): React.ReactElement {
  const [token, setToken] = React.useState<string | null>(() => tokenStorage.get());
  const queryClient = useQueryClient();

  // Профиль тянем с бэка, а не из токена: в токене нет отображаемого имени,
  // и роли могли измениться после его выдачи.
  const { data: user, isLoading } = useQuery({
    queryKey: ['auth', 'me', token],
    queryFn: () => apiFetch<AuthUser>('/auth/me'),
    enabled: token !== null,
    retry: false,
    staleTime: 5 * 60 * 1000,
  });

  const login = React.useCallback(
    async (email: string, password: string) => {
      const result = await apiFetch<LoginResponse>('/auth/login', {
        method: 'POST',
        body: { email, password },
        auth: false,
      });
      tokenStorage.set(result.accessToken);
      setToken(result.accessToken);
      queryClient.setQueryData(['auth', 'me', result.accessToken], result.user);
    },
    [queryClient],
  );

  const logout = React.useCallback(() => {
    tokenStorage.clear();
    setToken(null);
    queryClient.clear();
  }, [queryClient]);

  const value = React.useMemo<AuthContextValue>(
    () => ({ user: user ?? null, token, isLoading: token !== null && isLoading, login, logout }),
    [user, token, isLoading, login, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = React.useContext(AuthContext);
  if (!context) throw new Error('useAuth должен вызываться внутри <AuthProvider>.');
  return context;
}
