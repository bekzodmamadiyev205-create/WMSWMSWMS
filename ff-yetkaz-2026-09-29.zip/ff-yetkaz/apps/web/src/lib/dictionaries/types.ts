import type { ru } from './ru';

/** Ключ словаря: опечатка в вызове перевода не соберётся. */
export type MessageKey = keyof typeof ru;

/** Словарь языка: обязаны быть ВСЕ ключи эталона. */
export type Dictionary = Record<MessageKey, string>;
