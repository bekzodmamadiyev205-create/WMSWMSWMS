import type { OpsDashboardDto, SellerDashboardDto } from '@ff/shared';
import { apiFetch } from '@/lib/api';

export const dashboardApi = {
  ops: () => apiFetch<OpsDashboardDto>('/dashboard/ops'),
  seller: (sellerId?: string) =>
    apiFetch<SellerDashboardDto>(`/dashboard/seller${sellerId ? `?sellerId=${sellerId}` : ''}`),
};
