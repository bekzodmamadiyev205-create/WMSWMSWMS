import type {
  PackCompletionDto,
  PackageDto,
  PackageShipmentDto,
  PackingQueueItemDto,
  ShipmentDto,
} from '@ff/shared';
import { apiFetch, API_BASE, tokenStorage } from '@/lib/api';

export interface CompletePackingInput {
  weightG: number;
  lengthMm?: number;
  widthMm?: number;
  heightMm?: number;
  comment?: string;
}

export const packingApi = {
  queue: () => apiFetch<PackingQueueItemDto[]>('/packing/queue'),
  package: (id: string) => apiFetch<PackageDto>(`/packing/packages/${id}`),
  shipment: (id: string) =>
    apiFetch<PackageShipmentDto>(`/packing/packages/${id}/shipment`).then(
      (result) => result.shipment,
    ),

  start: (orderId: string) =>
    apiFetch<PackageDto>(`/packing/orders/${orderId}/start`, { method: 'POST', body: {} }),

  complete: (orderId: string, input: CompletePackingInput) =>
    apiFetch<PackCompletionDto>(`/packing/orders/${orderId}/complete`, {
      method: 'POST',
      body: input,
    }),

  issueLabel: (packageId: string) =>
    apiFetch<ShipmentDto>(`/packing/packages/${packageId}/label`, { method: 'POST', body: {} }),

  /**
   * Этикетку нельзя открыть простым window.open: ручка требует токен в
   * заголовке. Поэтому качаем сами и отдаём blob-ссылку.
   */
  async labelUrl(packageId: string): Promise<string> {
    const token = tokenStorage.get();
    const response = await fetch(`${API_BASE}/api/v1/packing/packages/${packageId}/label.pdf`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!response.ok) throw new Error('Не удалось получить этикетку.');
    return URL.createObjectURL(await response.blob());
  },
};
