import * as React from 'react';
import { ru } from '@/lib/dictionaries/ru';
import type { Dictionary, MessageKey } from '@/lib/dictionaries/types';

/**
 * Свой i18n на словарях, без библиотеки. Четыре языка и плоские ключи не
 * оправдывают i18next с его загрузчиками и неймспейсами; словарь — обычный
 * объект, опечатка в ключе ловится TypeScript'ом на сборке.
 *
 * Эталонный русский приходит статически, остальные три — отдельными кусками по
 * требованию: вместе они весят под 190 КБ текста, и раньше их скачивал каждый,
 * включая сборщика на складском терминале, который язык не меняет никогда.
 */
export type { Dictionary, MessageKey };

export const LANGUAGES = [
  { code: 'ru', flag: '🇷🇺', native: 'Русский', word: 'Язык' },
  { code: 'uz', flag: '🇺🇿', native: "O'zbekcha", word: 'Til' },
  { code: 'en', flag: '🇬🇧', native: 'English', word: 'Language' },
  { code: 'zh', flag: '🇨🇳', native: '中文', word: '语言' },
] as const;

export type Language = (typeof LANGUAGES)[number]['code'];

const STORAGE_KEY = 'ff.language';

const LOADERS: Record<Exclude<Language, 'ru'>, () => Promise<{ default: Dictionary }>> = {
  uz: () => import('@/lib/dictionaries/uz'),
  en: () => import('@/lib/dictionaries/en'),
  zh: () => import('@/lib/dictionaries/zh'),
};

/** Загруженное держим в модуле, а не в состоянии: возврат к языку не должен
 *  стоить ещё одного запроса, а переключений за смену бывает много. */
const loaded = new Map<Language, Dictionary>([['ru', ru]]);

async function loadDictionary(language: Language): Promise<Dictionary> {
  const cached = loaded.get(language);
  if (cached) return cached;
  try {
    const module = await LOADERS[language as Exclude<Language, 'ru'>]();
    loaded.set(language, module.default);
    return module.default;
  } catch {
    // Кусок не доехал (обрыв связи, протухший кэш после деплоя). Показать
    // русский честнее, чем пустой экран: интерфейс остаётся рабочим.
    return ru;
  }
}

function detectLanguage(): Language {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved && LANGUAGES.some((lang) => lang.code === saved)) return saved as Language;
  const browser = navigator.language.slice(0, 2).toLowerCase();
  if (LANGUAGES.some((lang) => lang.code === browser)) return browser as Language;
  return 'ru';
}

interface I18nValue {
  language: Language;
  setLanguage: (language: Language) => void;
  /** Перевод с подстановками: t('users.passwordHint', { n: 12 }). */
  t: (key: MessageKey, params?: Record<string, string | number>) => string;
}

const I18nContext = React.createContext<I18nValue | null>(null);

export function I18nProvider({ children }: { children: React.ReactNode }): React.ReactElement | null {
  const initial = React.useRef(detectLanguage()).current;
  const [language, setLanguageState] = React.useState<Language>(initial);
  const [dictionary, setDictionary] = React.useState<Dictionary | null>(
    () => loaded.get(initial) ?? null,
  );

  // Первый заход на неэталонном языке: ждём словарь, а не показываем русский.
  // Мигнуть чужим языком и перерисоваться выглядит поломкой; пауза в сотню
  // миллисекунд на загрузку соседнего куска — нет.
  React.useEffect(() => {
    if (dictionary) return;
    let alive = true;
    void loadDictionary(initial).then((dict) => {
      if (alive) setDictionary(dict);
    });
    return () => {
      alive = false;
    };
  }, [dictionary, initial]);

  const setLanguage = React.useCallback((next: Language) => {
    localStorage.setItem(STORAGE_KEY, next);
    // Сначала словарь, потом переключение: иначе экран на кадр уезжает в
    // русский и возвращается — ровно то мигание, которого мы избегаем.
    void loadDictionary(next).then((dict) => {
      setDictionary(dict);
      setLanguageState(next);
      document.documentElement.lang = next;
    });
  }, []);

  React.useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const t = React.useCallback(
    (key: MessageKey, params?: Record<string, string | number>) => {
      // Пропуск в словаре не роняет экран: показывается русский текст.
      let text: string = dictionary?.[key] ?? ru[key] ?? key;
      if (params) {
        for (const [name, value] of Object.entries(params)) {
          text = text.replaceAll(`{${name}}`, String(value));
        }
      }
      return text;
    },
    [dictionary],
  );

  const value = React.useMemo(() => ({ language, setLanguage, t }), [language, setLanguage, t]);

  // До загрузки словаря не рисуем ничего — это единственный кадр, и только у
  // тех, кто выбрал не русский.
  if (!dictionary) return null;

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nValue {
  const value = React.useContext(I18nContext);
  if (!value) throw new Error('useI18n вызван вне I18nProvider.');
  return value;
}
