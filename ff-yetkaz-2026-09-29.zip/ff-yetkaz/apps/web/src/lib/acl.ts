import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import type {
  EffectiveFieldAcl,
  EffectiveFieldAclDto,
  FieldPermissionMatrixDto,
  FieldPermissionUpdatePayload,
} from '@ff/shared';
import { canEditField, canViewField } from '@ff/shared';
import { apiFetch } from '@/lib/api';

const PATH = '/field-permissions';

export const aclApi = {
  /** Полная матрица «роль × сущность × поле» — то, что правит администратор. */
  matrix: (): Promise<FieldPermissionMatrixDto> => apiFetch<FieldPermissionMatrixDto>(PATH),

  /** Сохранение целиком, а не по одному чек-боксу: матрица правится пачкой. */
  save: (payload: FieldPermissionUpdatePayload): Promise<FieldPermissionMatrixDto> =>
    apiFetch<FieldPermissionMatrixDto>(PATH, { method: 'PUT', body: payload }),

  /** Что реально можно ТЕКУЩЕМУ пользователю — свёрнутая по его ролям выжимка. */
  effective: (): Promise<EffectiveFieldAclDto> =>
    apiFetch<EffectiveFieldAclDto>(`${PATH}/effective`),
};

export interface FieldAcl {
  acl: EffectiveFieldAcl;
  /** Администратор: матрица к нему не применяется вовсе. */
  unrestricted: boolean;
  canView: (entity: string, field: string) => boolean;
  canEdit: (entity: string, field: string) => boolean;
  isLoading: boolean;
}

/** Пустая матрица — общая ссылка, чтобы не пересоздавать объект на каждый рендер. */
const EMPTY_ACL: EffectiveFieldAcl = {};

/**
 * Права на колонки для текущего пользователя.
 *
 * Пока запрос идёт (и если он упал) — разрешаем ВСЁ. Это осознанный выбор в
 * пользу разрешительного умолчания: интерфейс, спрятавший половину полей из-за
 * сетевой ошибки, выглядит как потеря данных и порождает панические обращения,
 * тогда как показанное лишнее поле бэкенд всё равно вырежет из ответа —
 * настоящая защита стоит на сервере, здесь только удобство.
 *
 * `staleTime` в пять минут: права меняются раз в месяц, а спрашивать их будет
 * каждый список и каждая карточка.
 */
export function useFieldAcl(): FieldAcl {
  const query = useQuery({
    queryKey: ['acl', 'effective'],
    queryFn: () => aclApi.effective(),
    staleTime: 5 * 60 * 1000,
  });

  const data = query.data;
  const acl = data?.acl ?? EMPTY_ACL;
  const unrestricted = data?.unrestricted ?? true;
  // Нет ответа — не режем ничего (см. комментарий выше).
  const permissive = !data || unrestricted;
  const isLoading = query.isLoading;

  return React.useMemo<FieldAcl>(
    () => ({
      acl,
      unrestricted,
      canView: (entity: string, field: string): boolean =>
        permissive ? true : canViewField(acl, entity, field),
      canEdit: (entity: string, field: string): boolean =>
        permissive ? true : canEditField(acl, entity, field),
      isLoading,
    }),
    [acl, unrestricted, permissive, isLoading],
  );
}
