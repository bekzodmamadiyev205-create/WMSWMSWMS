import type {
  CreateOrderCategoryPayload,
  OrderCategoryDto,
  UpdateOrderCategoryPayload,
} from '@ff/shared';
import { apiFetch } from '@/lib/api';
import { buildQuery } from '@/lib/query-string';

const PATH = '/order-categories';

export const orderCategoriesApi = {
  /**
   * По умолчанию только действующие категории: выключенная не должна
   * предлагаться в форме нового заказа. Экран управления справочником просит
   * `includeInactive`, иначе выключенную категорию невозможно было бы включить
   * обратно — она просто исчезала бы из списка.
   */
  list: (includeInactive = false): Promise<OrderCategoryDto[]> =>
    apiFetch<OrderCategoryDto[]>(
      // Только `?includeInactive=true`: строка 'false' в наивном разборе на
      // сервере истинна, и «покажи только действующие» дало бы обратное.
      `${PATH}${buildQuery(includeInactive ? { includeInactive: 'true' } : {})}`,
    ),

  create: (payload: CreateOrderCategoryPayload): Promise<OrderCategoryDto> =>
    apiFetch<OrderCategoryDto>(PATH, { method: 'POST', body: payload }),

  update: (id: string, payload: UpdateOrderCategoryPayload): Promise<OrderCategoryDto> =>
    apiFetch<OrderCategoryDto>(`${PATH}/${id}`, { method: 'PATCH', body: payload }),

  /**
   * Отдаёт `{ deleted }`, а не 204: удалить категорию, на которую уже ссылаются
   * заказы, нельзя — сервер выключает её вместо удаления и говорит об этом
   * флагом. Интерфейс обязан показать разное сообщение для этих двух исходов.
   */
  remove: (id: string): Promise<{ deleted: boolean }> =>
    apiFetch<{ deleted: boolean }>(`${PATH}/${id}`, { method: 'DELETE' }),
};
