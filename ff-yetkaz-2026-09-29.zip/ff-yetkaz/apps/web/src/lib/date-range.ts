/**
 * Диапазон дат для отчётных фильтров: обе границы ВКЛЮЧИТЕЛЬНЫЕ.
 *
 * Бэкенду `dateTo` уходит как включительная дата, поэтому здесь нигде нет
 * «минус один день» — иначе интерфейс молча терял бы последние сутки периода,
 * а расхождение обнаружилось бы только при сверке с бухгалтерией.
 *
 * Даты — строки `YYYY-MM-DD` в ЛОКАЛЬНОМ времени пользователя. `null` означает
 * открытую сторону («за всё время»).
 */
export interface DateRange {
  from: string | null;
  to: string | null;
}

export type DateRangePresetKey =
  | 'today'
  | 'yesterday'
  | 'last7'
  | 'last30'
  | 'thisMonth'
  | 'lastMonth'
  | 'thisQuarter'
  | 'thisYear'
  | 'allTime'
  | 'custom';

/** Порядок кнопок в панели фильтра. `custom` сюда не входит — это не пресет, а признак ручного выбора. */
export const DATE_RANGE_PRESETS: readonly DateRangePresetKey[] = [
  'today',
  'yesterday',
  'last7',
  'last30',
  'thisMonth',
  'lastMonth',
  'thisQuarter',
  'thisYear',
  'allTime',
] as const;

function pad2(value: number): string {
  return value < 10 ? `0${value}` : String(value);
}

/**
 * Формат ведём из ЛОКАЛЬНЫХ геттеров, а не через `toISOString()`.
 * `toISOString()` переводит в UTC, и в Ташкенте (UTC+5) всё, что раньше 05:00,
 * уезжает на предыдущую дату — «сегодня» в фильтре стало бы вчерашним днём.
 */
export function isoDate(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

/**
 * Обратная операция к `isoDate`. Собираем через `new Date(y, m, d)` — локальную
 * полночь. `new Date('2026-08-20')` разбирается как UTC-полночь и в UTC+5
 * отображается тем же днём, но при любой арифметике сдвигается назад.
 */
export function parseIso(s: string): Date {
  const parts = s.split('-');
  const year = Number(parts[0]);
  const month = Number(parts[1]);
  const day = Number(parts[2]);
  return new Date(year, month - 1, day);
}

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

function addDays(d: Date, days: number): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + days);
}

/** Полночь по UTC из локальных компонент — только для СЧЁТА дней, не для показа. */
function dayIndex(d: Date): number {
  return Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86_400_000;
}

/**
 * Окно пресета. «Периоды до сегодня» (`thisMonth`/`thisQuarter`/`thisYear`)
 * заканчиваются СЕГОДНЯШНИМ днём, а не концом периода: будущих данных в отчёте
 * не бывает, а правая граница в будущем ломает сравнение периодов.
 * `lastMonth` — наоборот, полный прошлый месяц: он уже закрыт.
 */
export function presetRange(key: DateRangePresetKey, today: Date = new Date()): DateRange {
  const now = startOfDay(today);
  const iso = isoDate(now);

  switch (key) {
    case 'today':
      return { from: iso, to: iso };
    case 'yesterday': {
      const y = isoDate(addDays(now, -1));
      return { from: y, to: y };
    }
    // «Последние 7 дней» ВКЛЮЧАЮТ сегодня: today−6 … today. Классическая ошибка
    // отчётов — взять today−7 и получить восемь суток в «недельной» метрике.
    case 'last7':
      return { from: isoDate(addDays(now, -6)), to: iso };
    case 'last30':
      return { from: isoDate(addDays(now, -29)), to: iso };
    case 'thisMonth':
      return { from: isoDate(new Date(now.getFullYear(), now.getMonth(), 1)), to: iso };
    case 'lastMonth': {
      const first = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      // День 0 следующего месяца = последний день предыдущего; длину месяца не считаем.
      const last = new Date(now.getFullYear(), now.getMonth(), 0);
      return { from: isoDate(first), to: isoDate(last) };
    }
    case 'thisQuarter': {
      // Квартал выводится из номера месяца — таблица соответствий не нужна.
      const firstMonth = Math.floor(now.getMonth() / 3) * 3;
      return { from: isoDate(new Date(now.getFullYear(), firstMonth, 1)), to: iso };
    }
    case 'thisYear':
      return { from: isoDate(new Date(now.getFullYear(), 0, 1)), to: iso };
    case 'allTime':
      return { from: null, to: null };
    // У ручного выбора канонического окна нет — возвращаем открытое, чтобы
    // вызов с этим ключом не приводил к «случайному» периоду.
    case 'custom':
      return { from: null, to: null };
  }
}

export function isSameRange(a: DateRange, b: DateRange): boolean {
  return a.from === b.from && a.to === b.to;
}

/** Какому пресету соответствует диапазон; `custom`, если ни одному. */
export function detectPreset(range: DateRange, today: Date = new Date()): DateRangePresetKey {
  for (const key of DATE_RANGE_PRESETS) {
    if (isSameRange(range, presetRange(key, today))) return key;
  }
  return 'custom';
}

/** Параметры запроса: открытая сторона не превращается в пустую строку, а выпадает совсем. */
export function rangeToQuery(range: DateRange): { dateFrom?: string; dateTo?: string } {
  const query: { dateFrom?: string; dateTo?: string } = {};
  if (range.from) query.dateFrom = range.from;
  if (range.to) query.dateTo = range.to;
  return query;
}

/** Длина периода в днях с учётом включительных границ; `null` — период открыт. */
export function daysInRange(range: DateRange): number | null {
  if (!range.from || !range.to) return null;
  return dayIndex(parseIso(range.to)) - dayIndex(parseIso(range.from)) + 1;
}

/**
 * Предыдущее (−1) или следующее (+1) окно той же длины — для сравнения
 * «период к периоду». Окна стыкуются встык, без нахлёста и без дыры:
 * предыдущее заканчивается за день до начала текущего.
 */
export function shiftRange(range: DateRange, direction: -1 | 1): DateRange {
  const length = daysInRange(range);
  // Открытый период сдвигать не от чего — возвращаем как есть.
  if (length === null || !range.from || !range.to) return range;

  if (direction === -1) {
    const to = addDays(parseIso(range.from), -1);
    return { from: isoDate(addDays(to, -(length - 1))), to: isoDate(to) };
  }
  const from = addDays(parseIso(range.to), 1);
  return { from: isoDate(from), to: isoDate(addDays(from, length - 1)) };
}

/**
 * Словарь отдаёт полные имена месяцев («Август»), а в подпись фильтра они не
 * помещаются. Режем до трёх букв всё, что длиннее — иероглифические имена
 * («八月») короткие и остаются целыми. Регистр снижаем ВСЕГДА: иначе короткие
 * имена («Май», «Июль») остались бы с заглавной, а длинные — со строчной,
 * и подпись «1 Май – 3 авг» выглядела бы опечаткой.
 */
function shortMonth(d: Date, monthName: (m: number) => string): string {
  const name = monthName(d.getMonth() + 1);
  return (name.length > 3 ? name.slice(0, 3) : name).toLowerCase();
}

function dayLabel(d: Date, monthName: (m: number) => string): string {
  return `${d.getDate()} ${shortMonth(d, monthName)} ${d.getFullYear()}`;
}

/**
 * Подпись диапазона: `1 – 20 авг 2026`, `20 авг 2026`, `с 1 авг 2026`.
 * Повторяющиеся месяц и год из левой части убираются — читается быстрее.
 * Предлог у открытой стороны по-русски: собрать её можно только ручным вводом
 * одной границы, в самом фильтре такой диапазон не создаётся.
 */
export function formatRangeLabel(range: DateRange, monthName: (m: number) => string): string {
  const from = range.from ? parseIso(range.from) : null;
  const to = range.to ? parseIso(range.to) : null;

  if (from && to) {
    if (range.from === range.to) return dayLabel(from, monthName);
    const sameYear = from.getFullYear() === to.getFullYear();
    if (sameYear && from.getMonth() === to.getMonth()) {
      return `${from.getDate()} – ${dayLabel(to, monthName)}`;
    }
    if (sameYear) {
      return `${from.getDate()} ${shortMonth(from, monthName)} – ${dayLabel(to, monthName)}`;
    }
    return `${dayLabel(from, monthName)} – ${dayLabel(to, monthName)}`;
  }
  if (from) return `с ${dayLabel(from, monthName)}`;
  if (to) return `по ${dayLabel(to, monthName)}`;
  return '';
}
