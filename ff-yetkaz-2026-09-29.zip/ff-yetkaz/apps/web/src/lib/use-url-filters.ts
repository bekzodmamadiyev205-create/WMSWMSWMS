import * as React from 'react';
import { useSearchParams } from 'react-router-dom';

/**
 * Фильтры списка живут в адресной строке, а не в `useState`.
 *
 * Причина прикладная: отфильтрованный список — это ссылка. Её отправляют
 * коллеге, кладут в закладки и открывают после F5. Состояние в компоненте
 * теряет всё это на первой же перезагрузке, и «покажи мне вот эти заказы»
 * превращается в устную инструкцию «выбери там-то, потом там-то».
 *
 * Значения, равные умолчанию, из URL вычищаются: иначе ссылка на пустой список
 * выглядела бы как `?search=&status=&page=1&sort=createdAt&direction=desc`.
 */
export interface UrlFilters<T extends Record<string, string>> {
  values: T;
  set: (patch: Partial<T>) => void;
  reset: () => void;
  /** Сколько фильтров отличается от умолчания — для бейджа «Фильтры (3)». */
  activeCount: number;
}

/** Ключ страницы: смена любого другого фильтра обязана вернуть на первую. */
const PAGE_KEY = 'page';

export function useUrlFilters<T extends Record<string, string>>(defaults: T): UrlFilters<T> {
  const [searchParams, setSearchParams] = useSearchParams();

  /**
   * Умолчания фиксируем один раз. Вызывающий почти всегда передаёт объектный
   * литерал прямо в вызов — его личность меняется на каждый рендер, и любой
   * useMemo/useCallback с ним в зависимостях пересоздавался бы всегда,
   * а `set` в зависимостях эффекта дал бы бесконечный цикл.
   */
  const defaultsRef = React.useRef(defaults);

  const values = React.useMemo<T>(() => {
    const result = { ...defaultsRef.current };
    for (const key of Object.keys(defaultsRef.current)) {
      const raw = searchParams.get(key);
      if (raw !== null) result[key as keyof T] = raw as T[keyof T];
    }
    return result;
  }, [searchParams]);

  const set = React.useCallback(
    (patch: Partial<T>): void => {
      setSearchParams(
        (prev) => {
          const next = new URLSearchParams(prev);
          const touchedKeys = Object.keys(patch);

          for (const key of touchedKeys) {
            const value = patch[key as keyof T];
            if (value === undefined) continue;
            if (value === defaultsRef.current[key as keyof T]) next.delete(key);
            else next.set(key, value);
          }

          // Смена фильтра при открытой пятой странице показывает пустоту:
          // строк под новый фильтр столько не набирается. Возвращаем на первую,
          // но только если страницу не задали этим же вызовом явно.
          if (PAGE_KEY in defaultsRef.current && !touchedKeys.includes(PAGE_KEY)) {
            next.delete(PAGE_KEY);
          }

          return next;
        },
        // replace: правка фильтра не должна копить историю — иначе «назад»
        // после десяти нажатий в поиске уводит на десять шагов назад по буквам.
        { replace: true },
      );
    },
    [setSearchParams],
  );

  const reset = React.useCallback((): void => {
    setSearchParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        // Чужие параметры (например, открытая карточка) не трогаем — сброс
        // фильтров не обязан закрывать модалку.
        for (const key of Object.keys(defaultsRef.current)) next.delete(key);
        return next;
      },
      { replace: true },
    );
  }, [setSearchParams]);

  const activeCount = React.useMemo<number>(() => {
    let count = 0;
    for (const key of Object.keys(defaultsRef.current)) {
      // Страница — не фильтр: считать её активной значит показывать «Фильтры (1)»
      // просто потому, что человек пролистнул список.
      if (key === PAGE_KEY) continue;
      if (values[key as keyof T] !== defaultsRef.current[key as keyof T]) count += 1;
    }
    return count;
  }, [values]);

  return { values, set, reset, activeCount };
}
