import type {
  AnalyticsOverviewDto,
  AnalyticsQuery,
  BiViewDto,
  SellerAnalyticsDto,
} from '@ff/shared';
import { apiFetch } from '@/lib/api';
import { downloadFile } from '@/lib/download';
import { buildQuery, queryParams } from '@/lib/query-string';

const PATH = '/analytics';

/**
 * BI-слой. Клиент здесь ничего не агрегирует — только рисует. Витрина,
 * собранная в браузере из первой страницы заказов, начинает врать ровно на
 * следующей странице, и заметить это невозможно: график продолжает рисоваться.
 */
/**
 * У списка селлеров и его выгрузки шага графика нет. Глобальный ValidationPipe
 * работает с `forbidNonWhitelisted`, поэтому лишний `granularity` — это не
 * «сервер его проигнорирует», а 400, который экран покажет как «нет данных».
 */
const withoutGranularity = (query: AnalyticsQuery): AnalyticsQuery => {
  const { granularity: _granularity, ...rest } = query;
  return rest;
};

export const analyticsApi = {
  overview: (query: AnalyticsQuery = {}): Promise<AnalyticsOverviewDto> =>
    apiFetch<AnalyticsOverviewDto>(`${PATH}/overview${buildQuery(queryParams(query))}`),

  sellers: (query: AnalyticsQuery = {}): Promise<SellerAnalyticsDto> =>
    apiFetch<SellerAnalyticsDto>(`${PATH}/sellers${buildQuery(queryParams(withoutGranularity(query)))}`),

  /**
   * Та же сводка, но в области видимости селлера: скоуп сервер берёт ИЗ ТОКЕНА,
   * а не из параметра, поэтому подставленный чужой `sellerId` ничего не откроет.
   */
  sellerSummary: (query: AnalyticsQuery = {}): Promise<AnalyticsOverviewDto> =>
    apiFetch<AnalyticsOverviewDto>(`${PATH}/seller-summary${buildQuery(queryParams(query))}`),

  /** Описание витрин для внешнего BI (Metabase / Superset). */
  /**
   * Ручка витрин отвечает конвертом `{ views }`. Принимаем и голый массив:
   * экран не должен падать из-за того, какая из двух форм на сервере.
   */
  biViews: async (): Promise<BiViewDto[]> => {
    const result = await apiFetch<BiViewDto[] | { views: BiViewDto[] } | null>(
      `${PATH}/bi-views`,
    );
    if (Array.isArray(result)) return result;
    return result?.views ?? [];
  },

  exportSellers: (query: AnalyticsQuery = {}): Promise<void> =>
    downloadFile(`${PATH}/sellers/export${buildQuery(queryParams(withoutGranularity(query)))}`, 'sellers.xlsx'),

  sellersExportPath: (query: AnalyticsQuery = {}): string =>
    `${PATH}/sellers/export${buildQuery(queryParams(withoutGranularity(query)))}`,
};
