import * as React from 'react';

/**
 * Ввод со сканера-«пистолета» на экранах склада.
 *
 * Сканер работает как клавиатура: символы штрихкода приходят «очередью» и обычно
 * завершаются Enter. Но не каждый сканер настроен слать Enter, поэтому мы ловим
 * саму очередь (частые нажатия подряд) и отправляем сами — кнопку жать не нужно.
 *
 * Значение берём из DOM-поля (`ref.current.value`), а не из React-стейта: при
 * быстром скане стейт не успевает обновиться, и в отправку уходил бы обрывок
 * штрихкода → ложное «не найдено». Поэтому поле делаем НЕуправляемым (без
 * `value=`), а `onInput` вызываем из его `onChange`.
 *
 * @param onScan вызывается с полным штрихкодом, когда скан завершён.
 * @param opts.minLength ниже этой длины авто-отправка по «очереди» не срабатывает
 *   (короткий ручной ввод отправляется кнопкой/Enter, а не сам).
 */
export function useScannerInput(
  onScan: (code: string) => void,
  opts?: { minLength?: number },
): {
  ref: React.RefObject<HTMLInputElement>;
  onInput: () => void;
  submit: () => void;
  clear: () => void;
} {
  const minLength = opts?.minLength ?? 3;
  const ref = React.useRef<HTMLInputElement>(null);
  const timer = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const burst = React.useRef(0);
  const last = React.useRef(0);
  const onScanRef = React.useRef(onScan);
  onScanRef.current = onScan;

  const submit = React.useCallback(() => {
    clearTimeout(timer.current);
    burst.current = 0;
    const code = (ref.current?.value ?? '').trim();
    if (code) onScanRef.current(code);
  }, []);

  const clear = React.useCallback(() => {
    if (ref.current) ref.current.value = '';
    burst.current = 0;
  }, []);

  const onInput = React.useCallback(() => {
    const now = Date.now();
    // Символы сканера идут очень часто (единицы мс). Ручной набор — намного реже.
    if (now - last.current < 45) burst.current += 1;
    else burst.current = 0;
    last.current = now;

    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      const code = (ref.current?.value ?? '').trim();
      // Пришло «очередью» и достаточной длины — это скан, отправляем сами.
      if (code.length >= minLength && burst.current >= 3) submit();
    }, 110);
  }, [minLength, submit]);

  React.useEffect(() => () => clearTimeout(timer.current), []);

  return { ref, onInput, submit, clear };
}
