/**
 * Разбор CSV без зависимостей.
 *
 * Кавычки поддержаны намеренно: названия товаров у клиентов регулярно содержат
 * запятые («Чайник, 1.7 л»), и наивный `split(',')` разваливает такую строку на
 * две колонки — молча и с правдоподобным результатом.
 *
 * Разделитель определяется по первой строке: Excel в русской локали сохраняет
 * CSV с точкой с запятой, и заставлять оператора это чинить руками — плохая идея.
 */
export function parseCsv(text: string): string[][] {
  const clean = text.replace(/^﻿/, '').replace(/\r\n?/g, '\n');
  const delimiter = detectDelimiter(clean);

  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;

  for (let i = 0; i < clean.length; i += 1) {
    const char = clean[i];

    if (quoted) {
      if (char === '"') {
        // Удвоенная кавычка внутри поля — это экранированная кавычка.
        if (clean[i + 1] === '"') {
          field += '"';
          i += 1;
        } else {
          quoted = false;
        }
      } else {
        field += char;
      }
      continue;
    }

    if (char === '"') quoted = true;
    else if (char === delimiter) {
      row.push(field);
      field = '';
    } else if (char === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else field += char;
  }

  if (field !== '' || row.length > 0) {
    row.push(field);
    rows.push(row);
  }

  // Пустые строки в конце файла — обычное дело, они не данные.
  return rows.filter((cells) => cells.some((cell) => cell.trim() !== ''));
}

function detectDelimiter(text: string): string {
  const firstLine = text.split('\n', 1)[0] ?? '';
  const semicolons = (firstLine.match(/;/g) ?? []).length;
  const commas = (firstLine.match(/,/g) ?? []).length;
  const tabs = (firstLine.match(/\t/g) ?? []).length;
  if (tabs > semicolons && tabs > commas) return '\t';
  return semicolons > commas ? ';' : ',';
}

/**
 * Сопоставляет заголовки файла с полями. Регистр и пробелы игнорируются,
 * у каждого поля несколько допустимых имён — оператор не должен подгонять
 * шапку под нас.
 */
export function mapHeaders(
  header: string[],
  aliases: Record<string, string[]>,
): Record<string, number> {
  const normalized = header.map((cell) => cell.trim().toLowerCase());
  const map: Record<string, number> = {};
  for (const [field, names] of Object.entries(aliases)) {
    const index = normalized.findIndex((cell) => names.includes(cell));
    if (index >= 0) map[field] = index;
  }
  return map;
}

/**
 * Деньги из ячейки — строкой, без float: «12 345,50» → «12345.50».
 *
 * Три разных исхода намеренно различимы: `undefined` — ячейка пуста (заказ без
 * наложенного платежа), `null` — в ячейке не число (строку надо показать
 * оператору, а не тихо превратить в заказ без оплаты).
 */
export function cellMoney(value: string | undefined): string | null | undefined {
  if (value === undefined) return undefined;
  const clean = value.trim().replace(/\s/g, '').replace(',', '.');
  if (clean === '') return undefined;
  return /^\d+(\.\d{1,2})?$/.test(clean) ? clean : null;
}

/** Число из ячейки: пусто и мусор дают undefined, а не 0. */
export function cellNumber(value: string | undefined): number | undefined {
  if (value === undefined) return undefined;
  const clean = value.trim().replace(/\s/g, '').replace(',', '.');
  if (clean === '') return undefined;
  const parsed = Number(clean);
  return Number.isFinite(parsed) ? Math.round(parsed) : undefined;
}
