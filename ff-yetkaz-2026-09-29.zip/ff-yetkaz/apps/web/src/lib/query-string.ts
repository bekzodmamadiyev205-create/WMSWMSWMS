/**
 * Сборка query-строки — единственная на все api-клиенты.
 *
 * Модуль появился не ради красоты: шаблонные строки вида `?sellerId=${id}`
 * ломаются ровно там, где это дороже всего заметить. Пустое значение уезжает
 * как `?sellerId=` — бэкенд читает это как «фильтр по пустому селлеру», а не
 * как «фильтра нет». Поиск «+998901112233» без кодирования приезжает на сервер
 * с пробелом вместо плюса и не находит ничего. И то и другое выглядит как
 * «данных нет», а не как ошибка.
 */

export type QueryValue = string | number | boolean | null | undefined;

/**
 * `'' | null | undefined` выбрасываются целиком, остальное кодируется.
 * Пустая строка приравнена к «не задано» намеренно: в интерфейсе сброшенный
 * селект и незаполненный поиск дают именно её.
 */
export function buildQuery(params: Record<string, QueryValue>): string {
  const search = new URLSearchParams();

  for (const [key, value] of Object.entries(params)) {
    if (value === null || value === undefined || value === '') continue;
    search.set(key, String(value));
  }

  const encoded = search.toString();
  return encoded ? `?${encoded}` : '';
}

/**
 * Приводит типизированный объект-фильтр (`OrderListQuery`, `StockTableQuery`…)
 * к плоскому набору параметров.
 *
 * Нужен из-за правила TypeScript: у **интерфейса** нет неявной индексной
 * сигнатуры, поэтому `OrderListQuery` нельзя передать напрямую туда, где ждут
 * `Record<string, …>`. Альтернатива — расписывать каждое поле руками в каждом
 * клиенте, и любое новое поле фильтра тихо терялось бы по дороге.
 *
 * Значения не-скаляры (массивы, объекты) отбрасываются: в query им не место,
 * а `String({})` дал бы на сервере `[object Object]`.
 */
export function queryParams<T extends object>(query: T): Record<string, QueryValue> {
  const params: Record<string, QueryValue> = {};

  for (const [key, value] of Object.entries(query) as Array<[string, unknown]>) {
    if (value === null || value === undefined) continue;
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      params[key] = value;
    }
  }

  return params;
}

/**
 * То же самое, но без ключей постраничной навигации — для ручек итогов
 * (`/orders/totals`, `/inventory/stock/table/totals`). Итог обязан считаться по
 * ВСЕМУ фильтру: страница и сортировка на сумму не влияют, а посланные вместе с
 * фильтром сбивали бы кэш ответа на каждом перелистывании.
 */
export function queryParamsWithoutPaging<T extends object>(query: T): Record<string, QueryValue> {
  const params = queryParams(query);
  delete params.page;
  delete params.pageSize;
  delete params.sort;
  delete params.direction;
  return params;
}

/**
 * Для ручек выгрузки: убираем только страницу, сортировку оставляем.
 *
 * Разница с `queryParamsWithoutPaging` принципиальная. Выгрузка обязана
 * содержать ВЕСЬ отфильтрованный набор — файл «Экспорт в Excel», в котором
 * оказались только 50 видимых строк, обнаруживается уже после того, как его
 * отправили бухгалтеру. А вот порядок строк наоборот должен совпадать с
 * экраном, поэтому `sort`/`direction` едут дальше.
 */
export function queryParamsForExport<T extends object>(query: T): Record<string, QueryValue> {
  const params = queryParams(query);
  delete params.page;
  delete params.pageSize;
  return params;
}
