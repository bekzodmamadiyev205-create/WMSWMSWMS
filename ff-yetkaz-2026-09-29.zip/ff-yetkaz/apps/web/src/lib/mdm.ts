import type {
  BarcodeKind,
  BinLocationDto,
  SellerDto,
  SkuDto,
  SkuImportResultDto,
  SkuImportRowDto,
  WarehouseDto,
} from '@ff/shared';
import { apiFetch } from '@/lib/api';

export interface CreateSellerInput {
  code: string;
  legalName: string;
  taxId?: string;
  contactEmail?: string;
  contactPhone?: string;
  address?: string;
}

export interface UpdateSellerInput {
  legalName?: string;
  taxId?: string;
  contactEmail?: string;
  contactPhone?: string;
  address?: string;
  isActive?: boolean;
}

export interface CreateWarehouseInput {
  code: string;
  name: string;
  address?: string;
  timezone?: string;
}

export interface CreateSkuInput {
  sellerId: string;
  skuCode: string;
  name: string;
  weightG?: number;
  lengthMm?: number;
  widthMm?: number;
  heightMm?: number;
}

/**
 * Тип кода и признак «основной» — решение оператора, а не константа клиента.
 * Раньше здесь было зашито `EAN13`/`isPrimary: true`: внутренний код склада
 * приезжал в справочник помеченным как EAN, а привязать второй код товару было
 * нельзя — он молча отбирал бы у первого признак основного.
 */
export interface AddBarcodeInput {
  barcode: string;
  kind?: BarcodeKind;
  isPrimary?: boolean;
}

export const mdmApi = {
  sellers: () => apiFetch<SellerDto[]>('/sellers'),
  createSeller: (input: CreateSellerInput) =>
    apiFetch<SellerDto>('/sellers', { method: 'POST', body: input }),
  updateSeller: (id: string, input: UpdateSellerInput) =>
    apiFetch<SellerDto>(`/sellers/${id}`, { method: 'PATCH', body: input }),
  deleteSeller: (id: string) => apiFetch<void>(`/sellers/${id}`, { method: 'DELETE' }),

  warehouses: () => apiFetch<WarehouseDto[]>('/warehouses'),
  createWarehouse: (input: CreateWarehouseInput) =>
    apiFetch<WarehouseDto>('/warehouses', { method: 'POST', body: input }),

  bins: (warehouseId: string) => apiFetch<BinLocationDto[]>(`/warehouses/${warehouseId}/bins`),
  createBin: (input: { warehouseId: string; code: string; kind: string }) =>
    apiFetch<BinLocationDto>('/bin-locations', { method: 'POST', body: input }),

  skus: (params: { sellerId?: string; q?: string } = {}) => {
    const query = new URLSearchParams({ limit: '500' });
    if (params.sellerId) query.set('sellerId', params.sellerId);
    if (params.q) query.set('q', params.q);
    return apiFetch<SkuDto[]>(`/skus?${query.toString()}`);
  },
  createSku: (input: CreateSkuInput) => apiFetch<SkuDto>('/skus', { method: 'POST', body: input }),
  addBarcode: (skuId: string, input: AddBarcodeInput) =>
    apiFetch<SkuDto>(`/skus/${skuId}/barcodes`, { method: 'POST', body: input }),
  // Ответ — обновлённый SKU, а не пустое тело: список кодов в диалоге обязан
  // прийти с сервера, иначе он разойдётся с базой при гонке двух вкладок.
  removeBarcode: (skuId: string, barcodeId: string) =>
    apiFetch<SkuDto>(`/skus/${skuId}/barcodes/${barcodeId}`, { method: 'DELETE' }),

  importSkus: (sellerId: string, rows: SkuImportRowDto[]) =>
    apiFetch<SkuImportResultDto>('/skus/import', { method: 'POST', body: { sellerId, rows } }),
};
