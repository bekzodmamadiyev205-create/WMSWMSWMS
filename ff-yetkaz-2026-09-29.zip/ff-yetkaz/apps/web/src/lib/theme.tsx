import * as React from 'react';

/**
 * Тема через класс `dark` на <html> — так уже настроен Tailwind
 * (`darkMode: ['class']`), и обе палитры давно описаны в index.css.
 * По умолчанию — системная настройка, выбор пользователя переживает
 * перезагрузку в localStorage.
 */
const STORAGE_KEY = 'ff.theme';

export type Theme = 'light' | 'dark';

function detectTheme(): Theme {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved === 'light' || saved === 'dark') return saved;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

interface ThemeValue {
  theme: Theme;
  toggle: () => void;
}

const ThemeContext = React.createContext<ThemeValue | null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }): React.ReactElement {
  const [theme, setTheme] = React.useState<Theme>(detectTheme);

  React.useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const toggle = React.useCallback(() => {
    setTheme((current) => {
      const next = current === 'dark' ? 'light' : 'dark';
      localStorage.setItem(STORAGE_KEY, next);
      return next;
    });
  }, []);

  const value = React.useMemo(() => ({ theme, toggle }), [theme, toggle]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeValue {
  const value = React.useContext(ThemeContext);
  if (!value) throw new Error('useTheme вызван вне ThemeProvider.');
  return value;
}
