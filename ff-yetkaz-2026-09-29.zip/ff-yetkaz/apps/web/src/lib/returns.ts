import type {
  CreateReturnPayload,
  MoveReturnPayload,
  PageDto,
  ReturnDto,
  ReturnListQuery,
  ReturnReason,
  ReturnStatus,
  StoreReturnPayload,
} from '@ff/shared';
import { apiFetch } from '@/lib/api';
import type { BadgeTone } from '@/lib/orders';
import { buildQuery, queryParams, queryParamsForExport } from '@/lib/query-string';

const PATH = '/returns';

export const returnsApi = {
  list: (query: ReturnListQuery = {}): Promise<PageDto<ReturnDto>> =>
    apiFetch<PageDto<ReturnDto>>(`${PATH}${buildQuery(queryParams(query))}`),

  /** Карточка возврата: тот же DTO, но с заполненным `events` (журнал статусов). */
  get: (id: string): Promise<ReturnDto> => apiFetch<ReturnDto>(`${PATH}/${id}`),

  create: (payload: CreateReturnPayload): Promise<ReturnDto> =>
    apiFetch<ReturnDto>(PATH, { method: 'POST', body: payload }),

  /** Раскладка: годное уходит в остаток, брак — в брак. */
  store: (id: string, payload: StoreReturnPayload): Promise<ReturnDto> =>
    apiFetch<ReturnDto>(`${PATH}/${id}/store`, { method: 'POST', body: payload }),

  move: (id: string, payload: MoveReturnPayload): Promise<ReturnDto> =>
    apiFetch<ReturnDto>(`${PATH}/${id}/move`, { method: 'POST', body: payload }),

  complete: (id: string): Promise<ReturnDto> =>
    apiFetch<ReturnDto>(`${PATH}/${id}/complete`, { method: 'POST', body: {} }),

  cancel: (id: string, comment?: string): Promise<ReturnDto> =>
    apiFetch<ReturnDto>(`${PATH}/${id}/cancel`, { method: 'POST', body: { comment } }),

  exportPath: (query: ReturnListQuery = {}): string =>
    `${PATH}/export${buildQuery(queryParamsForExport(query))}`,
};

/**
 * Русские подписи статусов и причин. На экранах они проходят через i18n, но
 * базовый словарь нужен здесь: он же используется в выгрузках, подсказках и
 * везде, где `t()` недоступен.
 */
export const RETURN_STATUS_TITLE: Record<ReturnStatus, string> = {
  ACCEPTED: 'принят',
  IN_STORAGE: 'на хранении',
  MOVING: 'перемещение',
  COMPLETED: 'завершён',
  CANCELLED: 'отменён',
};

export const RETURN_STATUS_TONE: Record<ReturnStatus, BadgeTone> = {
  ACCEPTED: 'info',
  IN_STORAGE: 'default',
  MOVING: 'warning',
  COMPLETED: 'success',
  CANCELLED: 'destructive',
};

export const RETURN_REASON_TITLE: Record<ReturnReason, string> = {
  CUSTOMER_REFUSED: 'покупатель отказался',
  NOT_DELIVERED: 'не доставлен',
  DAMAGED_IN_TRANSIT: 'повреждён в пути',
  WRONG_ITEM: 'не тот товар',
  DEFECT: 'брак',
  OTHER: 'другое',
};
