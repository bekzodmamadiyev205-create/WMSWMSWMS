import type {
  PageDto,
  StockSummaryDto,
  StockTableQuery,
  StockTableRowDto,
  StockTableTotalsDto,
} from '@ff/shared';
import { apiFetch } from '@/lib/api';
import {
  buildQuery,
  queryParams,
  queryParamsForExport,
  queryParamsWithoutPaging,
} from '@/lib/query-string';

export const inventoryApi = {
  /** Свод остатка с раскладкой по ячейкам — исходная ручка, без постраничности. */
  stock: (
    params: { warehouseId?: string; sellerId?: string; skuId?: string } = {},
  ): Promise<StockSummaryDto[]> =>
    apiFetch<StockSummaryDto[]>(`/inventory/stock${buildQuery(queryParams(params))}`),

  /**
   * Витрина остатков: строка = SKU × склад × статус, страница с сервера.
   * Разрез по статусу принципиален — доступное к продаже и лежащее в браке это
   * разные числа, и складывать их в одну ячейку значит врать кладовщику.
   */
  table: (query: StockTableQuery = {}): Promise<PageDto<StockTableRowDto>> =>
    apiFetch<PageDto<StockTableRowDto>>(
      `/inventory/stock/table${buildQuery(queryParams(query))}`,
    ),

  /**
   * Итоги по всему фильтру. Принимает тот же объект, что и `table`, а параметры
   * страницы отбрасывает сам: заставлять экран собирать второй, «очищенный»
   * фильтр — верный способ получить итог, посчитанный не по тому, что на экране.
   */
  tableTotals: (query: StockTableQuery = {}): Promise<StockTableTotalsDto> =>
    apiFetch<StockTableTotalsDto>(
      `/inventory/stock/table/totals${buildQuery(queryParamsWithoutPaging(query))}`,
    ),

  exportPath: (query: StockTableQuery = {}): string =>
    `/inventory/stock/export${buildQuery(queryParamsForExport(query))}`,
};

/** Русские названия статусов единицы хранения — рядом с количеством. */
export const STOCK_STATUS_TITLE: Record<string, string> = {
  EXPECTED: 'ожидается',
  RECEIVED: 'принято',
  INSPECTED: 'осмотрено',
  AVAILABLE: 'доступно',
  RESERVED: 'в резерве',
  PICKED: 'собрано',
  PACKED: 'упаковано',
  SHIPPED: 'отгружено',
  DAMAGED: 'брак',
  QUARANTINE: 'карантин',
};
