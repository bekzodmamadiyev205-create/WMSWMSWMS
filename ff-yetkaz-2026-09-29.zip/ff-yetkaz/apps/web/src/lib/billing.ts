import type { ChargeKind, SkuDto, TariffPlanDto, TariffRuleDto, TariffUnit } from '@ff/shared';
import { apiFetch } from '@/lib/api';
import type { Language } from '@/lib/i18n';

const PLANS_PATH = '/billing/tariff-plans';
const RULES_PATH = '/billing/tariff-rules';

export interface CreatePlanInput {
  code: string;
  name: string;
  currency: string;
  isDefault?: boolean;
  isActive?: boolean;
}

export interface UpdatePlanInput {
  name?: string;
  currency?: string;
  isDefault?: boolean;
  /**
   * План не удаляется — выключается. На него ссылаются уже проведённые
   * начисления, и удаление сделало бы их безродными задним числом.
   */
  isActive?: boolean;
}

export interface AddRuleInput {
  kind: ChargeKind;
  unit: TariffUnit;
  price: string;
  minQty?: string;
  /**
   * Составляющая цены (`BASE`/`WEIGHT`/…). Внутри одной услуги единица
   * уникальна для СВОЕЙ составляющей — так «паллета + перевес по кг» считаются
   * оба, а «за заказ» и «за кг» в одной составляющей по-прежнему конфликт.
   */
  component?: string;
  /**
   * Срок действия ставки. Без него правка цены переписывала бы историю:
   * пересчёт прошлого периода взял бы сегодняшний тариф.
   */
  effectiveFrom?: string;
  effectiveTo?: string | null;
}

export interface UpdateRuleInput {
  kind?: ChargeKind;
  unit?: TariffUnit;
  component?: string;
  price?: string;
  minQty?: string;
  effectiveFrom?: string;
  effectiveTo?: string | null;
}

/**
 * Нормы укладки: сколько единиц в коробке и на паллете. Живут на SKU, но
 * правятся из тарифов — по ним считаются `PER_BOX`/`PER_PALLET`. Число коробок
 * не хранится как факт: склад считает штуки, и требовать от кладовщика вводить
 * ещё и тару значит гарантированно получить расхождение.
 */
export interface PackingNormsInput {
  unitsPerBox: number | null;
  unitsPerPallet: number | null;
}

export type SkuPackingNormsDto = SkuDto & {
  unitsPerBox: number | null;
  unitsPerPallet: number | null;
};

export const billingApi = {
  plans: (): Promise<TariffPlanDto[]> => apiFetch<TariffPlanDto[]>(PLANS_PATH),

  createPlan: (input: CreatePlanInput): Promise<TariffPlanDto> =>
    apiFetch<TariffPlanDto>(PLANS_PATH, { method: 'POST', body: input }),

  updatePlan: (id: string, input: UpdatePlanInput): Promise<TariffPlanDto> =>
    apiFetch<TariffPlanDto>(`${PLANS_PATH}/${id}`, { method: 'PATCH', body: input }),

  addRule: (planId: string, input: AddRuleInput): Promise<TariffRuleDto> =>
    apiFetch<TariffRuleDto>(`${PLANS_PATH}/${planId}/rules`, { method: 'POST', body: input }),

  updateRule: (id: string, input: UpdateRuleInput): Promise<TariffRuleDto> =>
    apiFetch<TariffRuleDto>(`${RULES_PATH}/${id}`, { method: 'PATCH', body: input }),

  deleteRule: (id: string): Promise<void> =>
    apiFetch<void>(`${RULES_PATH}/${id}`, { method: 'DELETE' }),

  setPackingNorms: (skuId: string, input: PackingNormsInput): Promise<SkuPackingNormsDto> =>
    apiFetch<SkuPackingNormsDto>(`/billing/skus/${skuId}/packing-norms`, {
      method: 'PATCH',
      body: input,
    }),
};

/**
 * Названия услуг и единиц тарификации — доменные термины, а не общий UI-текст,
 * поэтому живут рядом с экраном, а не в общем словаре. Четыре языка всё равно
 * поддержаны: оператор видит услугу на своём языке.
 */
const KIND_LABELS: Record<Language, Record<ChargeKind, string>> = {
  ru: {
    INBOUND: 'Приёмка',
    STORAGE: 'Хранение',
    PICKING: 'Сборка',
    PACKING: 'Упаковка',
    DELIVERY: 'Доставка',
    COD_FEE: 'Комиссия COD',
    SURCHARGE: 'Надбавка',
  },
  uz: {
    INBOUND: 'Qabul',
    STORAGE: 'Saqlash',
    PICKING: 'Yig‘ish',
    PACKING: 'Qadoqlash',
    DELIVERY: 'Yetkazish',
    COD_FEE: 'COD komissiyasi',
    SURCHARGE: 'Ustama',
  },
  en: {
    INBOUND: 'Inbound',
    STORAGE: 'Storage',
    PICKING: 'Picking',
    PACKING: 'Packing',
    DELIVERY: 'Delivery',
    COD_FEE: 'COD fee',
    SURCHARGE: 'Surcharge',
  },
  zh: {
    INBOUND: '收货',
    STORAGE: '仓储',
    PICKING: '拣货',
    PACKING: '打包',
    DELIVERY: '配送',
    COD_FEE: 'COD 手续费',
    SURCHARGE: '附加费',
  },
};

const UNIT_LABELS: Record<Language, Record<TariffUnit, string>> = {
  ru: {
    PER_ORDER: 'за заказ',
    PER_UNIT: 'за единицу',
    PER_KG: 'за кг',
    PER_M3_DAY: 'за м³·сутки',
    PERCENT_OF_COD: '% от COD',
    FLAT: 'фиксированно',
    PER_BOX: 'за коробку',
    PER_PALLET: 'за паллету',
    PER_BOX_DAY: 'за коробко-сутки',
    PER_PALLET_DAY: 'за паллето-сутки',
  },
  uz: {
    PER_ORDER: 'buyurtmaga',
    PER_UNIT: 'donaga',
    PER_KG: 'kg ga',
    PER_M3_DAY: 'm³·kunga',
    PERCENT_OF_COD: 'CODdan %',
    FLAT: 'qat’iy',
    PER_BOX: 'quti uchun',
    PER_PALLET: 'palet uchun',
    PER_BOX_DAY: 'quti-kun uchun',
    PER_PALLET_DAY: 'palet-kun uchun',
  },
  en: {
    PER_ORDER: 'per order',
    PER_UNIT: 'per unit',
    PER_KG: 'per kg',
    PER_M3_DAY: 'per m³·day',
    PERCENT_OF_COD: '% of COD',
    FLAT: 'flat',
    PER_BOX: 'per box',
    PER_PALLET: 'per pallet',
    PER_BOX_DAY: 'per box-day',
    PER_PALLET_DAY: 'per pallet-day',
  },
  zh: {
    PER_ORDER: '每单',
    PER_UNIT: '每件',
    PER_KG: '每公斤',
    PER_M3_DAY: '每立方米·天',
    PERCENT_OF_COD: 'COD 百分比',
    FLAT: '固定',
    PER_BOX: '每箱',
    PER_PALLET: '每托盘',
    PER_BOX_DAY: '每箱·天',
    PER_PALLET_DAY: '每托盘·天',
  },
};

export const chargeKindLabel = (lang: Language, kind: ChargeKind): string =>
  KIND_LABELS[lang]?.[kind] ?? kind;

export const tariffUnitLabel = (lang: Language, unit: TariffUnit): string =>
  UNIT_LABELS[lang]?.[unit] ?? unit;

/**
 * Составляющие комбинированного тарифа. Отдельный словарь, а не переиспользование
 * `KIND_LABELS`: `SURCHARGE` есть и там и там, но означает разное — вид услуги
 * против части цены внутри услуги. Один словарь на двоих означал бы, что
 * переименование в одном месте молча меняет смысл в другом.
 */
export const COMPONENT_LABELS: Record<Language, Record<string, string>> = {
  ru: {
    BASE: 'Базовая',
    WEIGHT: 'По весу',
    VOLUME: 'По объёму',
    HANDLING: 'Обработка',
    SURCHARGE: 'Надбавка',
  },
  uz: {
    BASE: 'Asosiy',
    WEIGHT: 'Vazn bo‘yicha',
    VOLUME: 'Hajm bo‘yicha',
    HANDLING: 'Ishlov berish',
    SURCHARGE: 'Ustama',
  },
  en: {
    BASE: 'Base',
    WEIGHT: 'Weight',
    VOLUME: 'Volume',
    HANDLING: 'Handling',
    SURCHARGE: 'Surcharge',
  },
  zh: {
    BASE: '基础',
    WEIGHT: '按重量',
    VOLUME: '按体积',
    HANDLING: '操作',
    SURCHARGE: '附加费',
  },
};

/**
 * Набор составляющих открытый (`TariffComponent` включает `string`): оператор
 * вправе завести свою. Незнакомый код показываем как есть — прочерк вместо
 * названия выглядел бы как потеря строки тарифа.
 */
export const tariffComponentLabel = (lang: Language, code: string): string =>
  COMPONENT_LABELS[lang]?.[code] ?? code;
