import type { AsnDto, ReceiptCompletionDto, ReceiptDto, SkuDto } from '@ff/shared';
import { ApiError, apiFetch } from '@/lib/api';

export interface CreateAsnInput {
  sellerId: string;
  warehouseId: string;
  externalRef?: string;
  lines: Array<{ skuId: string; expectedQty: number }>;
}

/**
 * Вход приёмки одной позиции. Ровно одно из `barcode` | `asnLineId`: код ищет SKU
 * глобально, строка заявки задаёт его однозначно. Пустые поля не уезжают на сервер —
 * `JSON.stringify` выбрасывает `undefined`, а глобальный ValidationPipe с
 * `forbidNonWhitelisted` отбил бы лишний ключ.
 */
export interface ScanInput {
  barcode?: string;
  asnLineId?: string;
  quantity: number;
  lotCode?: string;
  expiryDate?: string;
}

/**
 * Машинный код ошибки из конверта (`code`). По нему экран предлагает действие, а не
 * просто печатает текст: разбирать русскую строку сообщения — значит сломаться на
 * первой же её правке. Читаем мягко: поле необязательное и в типе конверта его может
 * ещё не быть.
 */
export function apiErrorCode(error: unknown): string | undefined {
  if (!(error instanceof ApiError) || !error.body) return undefined;
  const { code } = error.body as unknown as { code?: unknown };
  return typeof code === 'string' ? code : undefined;
}

export const inboundApi = {
  asns: (status?: string) =>
    apiFetch<AsnDto[]>(`/inbound/asns${status ? `?status=${status}` : ''}`),
  asn: (id: string) => apiFetch<AsnDto>(`/inbound/asns/${id}`),

  createAsn: (input: CreateAsnInput) =>
    apiFetch<AsnDto>('/inbound/asns', { method: 'POST', body: input }),
  submitAsn: (id: string) =>
    apiFetch<AsnDto>(`/inbound/asns/${id}/submit`, { method: 'POST', body: {} }),
  closeAsn: (id: string) =>
    apiFetch<AsnDto>(`/inbound/asns/${id}/close`, { method: 'POST', body: {} }),
  cancelAsn: (id: string) =>
    apiFetch<AsnDto>(`/inbound/asns/${id}/cancel`, { method: 'POST', body: {} }),

  receipt: (id: string) => apiFetch<ReceiptDto>(`/inbound/receipts/${id}`),
  createReceipt: (asnId: string) =>
    apiFetch<ReceiptDto>('/inbound/receipts', { method: 'POST', body: { asnId } }),
  scan: (receiptId: string, input: ScanInput) =>
    apiFetch<ReceiptDto>(`/inbound/receipts/${receiptId}/scan`, {
      method: 'POST',
      body: {
        barcode: input.barcode,
        asnLineId: input.asnLineId,
        quantity: input.quantity,
        lotCode: input.lotCode,
        expiryDate: input.expiryDate,
      },
    }),
  /** Привязка неизвестного кода к позиции заявки: отдаёт обновлённый SKU. */
  bindBarcode: (receiptId: string, asnLineId: string, barcode: string) =>
    apiFetch<SkuDto>(`/inbound/receipts/${receiptId}/lines/${asnLineId}/barcode`, {
      method: 'POST',
      body: { barcode },
    }),
  putAway: (
    receiptId: string,
    input: { receiptLineId: string; qtyOk: number; qtyDamaged: number; binId: string },
  ) => apiFetch<ReceiptDto>(`/inbound/receipts/${receiptId}/put-away`, { method: 'POST', body: input }),
  complete: (receiptId: string) =>
    apiFetch<ReceiptCompletionDto>(`/inbound/receipts/${receiptId}/complete`, {
      method: 'POST',
      body: {},
    }),
};
