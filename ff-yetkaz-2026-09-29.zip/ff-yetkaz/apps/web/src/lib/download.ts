import { API_BASE, ApiError, tokenStorage, type ApiErrorBody } from '@/lib/api';

/**
 * Скачивание файла с бэкенда (выгрузки в xlsx).
 *
 * Почему это НЕ `apiFetch`. `apiFetch` читает ответ как текст и разбирает его
 * JSON'ом — для xlsx это приговор: `response.text()` декодирует байты как UTF-8,
 * невалидные последовательности заменяются на U+FFFD, и восстановить исходный
 * поток из такой строки уже нельзя. Файл нужно забирать `response.blob()`,
 * поэтому у выгрузок свой транспорт. Всё остальное — заголовок авторизации,
 * разбор конверта ошибки и реакция на 401 — повторено один в один, иначе
 * протухший токен на выгрузке вёл бы себя иначе, чем на любом другом запросе.
 */

/** Имя по умолчанию: без расширения браузер сохранит файл как `download`. */
const FALLBACK_NAME = 'export.xlsx';

/**
 * Имя файла из `Content-Disposition`.
 *
 * Приоритет у RFC 5987 (`filename*=UTF-8''…`) — именно он несёт кириллицу;
 * в обычном `filename=` сервер вынужден оставлять ASCII-транслитерацию, и взяв
 * его первым мы бы выбросили нормальное имя, которое сервер уже прислал.
 */
export function filenameFromDisposition(header: string | null): string | null {
  if (!header) return null;

  const extended = /filename\*\s*=\s*(?:UTF-8|utf-8)?'[^']*'([^;]+)/i.exec(header);
  if (extended?.[1]) {
    try {
      return sanitize(decodeURIComponent(extended[1].trim()));
    } catch {
      // Битое процентное кодирование — не повод ронять скачивание.
    }
  }

  const quoted = /filename\s*=\s*"([^"]*)"/i.exec(header);
  if (quoted?.[1]) return sanitize(quoted[1]);

  const plain = /filename\s*=\s*([^;]+)/i.exec(header);
  if (plain?.[1]) return sanitize(plain[1].trim());

  return null;
}

/** Разделители пути из имени убираем: сервер не должен уметь диктовать папку. */
function sanitize(name: string): string | null {
  const clean = name.replace(/[\/]/g, '_').trim();
  return clean.length > 0 ? clean : null;
}

export async function downloadFile(path: string, fallbackName?: string): Promise<void> {
  const headers: Record<string, string> = {};
  const token = tokenStorage.get();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${API_BASE}/api/v1${path}`, { method: 'GET', headers });

  if (!response.ok) {
    let body: ApiErrorBody | null = null;
    try {
      body = (await response.json()) as ApiErrorBody;
    } catch {
      body = null;
    }

    // Ровно та же реакция, что и в apiFetch: иначе выгрузка по протухшему
    // токену молча падала бы, оставляя интерфейс «залогиненным».
    if (response.status === 401) {
      tokenStorage.clear();
      if (!window.location.pathname.startsWith('/login')) {
        window.location.assign('/login');
      }
    }
    throw new ApiError(response.status, body);
  }

  const blob = await response.blob();
  const name =
    filenameFromDisposition(response.headers.get('Content-Disposition')) ??
    fallbackName ??
    FALLBACK_NAME;

  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  // Ссылка обязана быть в документе: в Firefox click() по неприкреплённому
  // элементу не запускает скачивание вовсе.
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();

  // Отзываем не сразу: часть браузеров дочитывает blob уже после возврата из
  // click(), и мгновенный revoke даёт пустой файл. Пары секунд достаточно,
  // чтобы скачивание стартовало, и память не держится дольше нужного.
  window.setTimeout(() => URL.revokeObjectURL(url), 4_000);
}
